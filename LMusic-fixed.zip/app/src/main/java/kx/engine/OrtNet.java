package kx.engine;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;
import ai.onnxruntime.NodeInfo;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Обёртка над ONNX Runtime для Separator.Net. */
final class OrtNet implements Separator.Net, AutoCloseable {
    private final OrtEnvironment env;
    private final OrtSession session;
    private final File model;
    private final String[] names;
    private final long[][] shapes;

    OrtNet(File model) throws Exception {
        this.model = model;
        env = OrtEnvironment.getEnvironment();
        // ORT_NOT_IMPLEMENTED часто вызывает графовая оптимизация (подставляет слитые узлы без ядра под нужный тип) —
        // поэтому при отказе пробуем более мягкие уровни, вплоть до «без оптимизаций».
        OrtSession.SessionOptions.OptLevel[] levels = {
            OrtSession.SessionOptions.OptLevel.ALL_OPT,
            OrtSession.SessionOptions.OptLevel.BASIC_OPT,
            OrtSession.SessionOptions.OptLevel.NO_OPT
        };
        OrtSession s;
        try {
            s = open(model, levels);
        } catch (Exception e) {
            // у ORT на CPU нет ядра EyeLike для части типов (bool/float16): переписываем такие узлы в файле модели и пробуем снова
            if (String.valueOf(e.getMessage()).contains("EyeLike") && OrtPatch.fixEyeLike(model)) s = open(model, levels);
            else throw e;
        }
        session = s;
        List<String> n = new ArrayList<>(session.getInputNames());
        names = n.toArray(new String[0]);
        Map<String, NodeInfo> info = session.getInputInfo();
        shapes = new long[names.length][];
        for (int i = 0; i < names.length; i++) {
            NodeInfo ni = info.get(names[i]);
            shapes[i] = ni != null && ni.getInfo() instanceof TensorInfo ? ((TensorInfo) ni.getInfo()).getShape() : new long[0];
        }
    }

    private OrtSession open(File model, OrtSession.SessionOptions.OptLevel[] levels) throws Exception {
        Exception first = null;
        for (OrtSession.SessionOptions.OptLevel lv : levels) {
            OrtSession.SessionOptions o = new OrtSession.SessionOptions();
            try {
                int cpu = Runtime.getRuntime().availableProcessors();
                o.setIntraOpNumThreads(Math.max(2, Math.min(4, cpu)));
                o.setOptimizationLevel(lv);
                return env.createSession(model.getAbsolutePath(), o);
            } catch (Exception e) {
                if (first == null) first = e;
            } finally {
                try { o.close(); } catch (Throwable ignored) { }
            }
        }
        throw first != null ? first : new Exception("ort_session_failed");
    }

    /** drumsep: оси объявлены динамическими, но трейс сделан на 40 с (1 764 000 отсчётов) — на другой длине Add в encoder.4 не сходится (336 против 337). */
    @Override public int segmentHint() { return model.getName().toLowerCase(java.util.Locale.ROOT).contains("drumsep") ? 1764000 : 0; }

    @Override public int inputCount() { return names.length; }

    @Override public long[] inputShape(int i) { return shapes[i]; }

    @Override public Separator.Out run(float[][] inputs, long[][] sh) throws Exception {
        try {
            return run0(inputs, sh);
        } catch (Exception e) {
            // для разбора ошибок формы: что подали и что объявлено в модели (видно в логе режима разработчика)
            StringBuilder d = new StringBuilder(" || build=b5-drumsep40-bigout seg=").append(segmentHint()).append(" model=").append(model.getName());
            for (int i = 0; i < names.length; i++) {
                d.append(" [").append(names[i]).append(" объявлено ").append(java.util.Arrays.toString(shapes[i]));
                if (sh != null && i < sh.length && sh[i] != null) d.append(", подано ").append(java.util.Arrays.toString(sh[i]));
                d.append(']');
            }
            throw new Exception(e.getMessage() + d, e);
        }
    }

    private Separator.Out run0(float[][] inputs, long[][] sh) throws Exception {
        Map<String, OnnxTensor> in = new HashMap<>();
        List<OnnxTensor> opened = new ArrayList<>();
        try {
            for (int i = 0; i < names.length; i++) {
                ByteBuffer bb = ByteBuffer.allocateDirect(inputs[i].length * 4).order(ByteOrder.nativeOrder());
                FloatBuffer fb = bb.asFloatBuffer();
                fb.put(inputs[i]);
                fb.rewind();
                OnnxTensor t = OnnxTensor.createTensor(env, fb, sh[i]);
                opened.add(t);
                in.put(names[i], t);
            }
            try (OrtSession.Result res = session.run(in)) {
                List<float[]> data = new ArrayList<>();
                List<FloatBuffer> bigs = new ArrayList<>();
                List<long[]> shp = new ArrayList<>();
                for (Map.Entry<String, OnnxValue> e : res) {
                    OnnxTensor t = (OnnxTensor) e.getValue();
                    FloatBuffer fb = t.getFloatBuffer();
                    if (fb.remaining() > 8_000_000) { // > 32 МБ: в кучу Java не копируем (на Android она ~512 МБ), держим в нативной памяти
                        FloatBuffer nb = ByteBuffer.allocateDirect(fb.remaining() * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
                        nb.put(fb);
                        nb.rewind();
                        data.add(null);
                        bigs.add(nb);
                    } else {
                        float[] a = new float[fb.remaining()];
                        fb.get(a);
                        data.add(a);
                        bigs.add(null);
                    }
                    shp.add(t.getInfo().getShape());
                }
                Separator.Out out = new Separator.Out(data.toArray(new float[0][]), shp.toArray(new long[0][]));
                out.big = bigs.toArray(new FloatBuffer[0]);
                return out;
            }
        } finally {
            for (OnnxTensor t : opened) { try { t.close(); } catch (Throwable ignored) { } }
        }
    }

    @Override public void close() {
        try { session.close(); } catch (Throwable ignored) { }
    }
}

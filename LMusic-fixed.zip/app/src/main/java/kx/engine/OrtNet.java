package kx.engine;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;
import ai.onnxruntime.NodeInfo;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Обёртка над ONNX Runtime для Separator.Net. */
final class OrtNet implements Separator.Net, AutoCloseable {
    private final OrtEnvironment env;
    private final OrtSession session;
    private final String[] names;
    private final long[][] shapes;

    OrtNet(File model) throws Exception {
        env = OrtEnvironment.getEnvironment();
        // ORT_NOT_IMPLEMENTED часто вызывает графовая оптимизация (подставляет слитые узлы без ядра под нужный тип) —
        // поэтому при отказе пробуем более мягкие уровни, вплоть до «без оптимизаций».
        OrtSession.SessionOptions.OptLevel[] levels = {
            OrtSession.SessionOptions.OptLevel.ALL_OPT,
            OrtSession.SessionOptions.OptLevel.BASIC_OPT,
            OrtSession.SessionOptions.OptLevel.NO_OPT
        };
        OrtSession s = null;
        Exception first = null;
        for (OrtSession.SessionOptions.OptLevel lv : levels) {
            OrtSession.SessionOptions o = new OrtSession.SessionOptions();
            try {
                int cpu = Runtime.getRuntime().availableProcessors();
                o.setIntraOpNumThreads(Math.max(2, Math.min(4, cpu)));
                o.setOptimizationLevel(lv);
                s = env.createSession(model.getAbsolutePath(), o);
                break;
            } catch (Exception e) {
                if (first == null) first = e;
            } finally {
                try { o.close(); } catch (Throwable ignored) { }
            }
        }
        if (s == null) throw first != null ? first : new Exception("ort_session_failed");
        session = s;
        List<String> n = new ArrayList<>(session.getInputNames());
        names = n.toArray(new String[0]);
        Map<String, NodeInfo> info = session.getInputInfo();
        shapes = new long[names.length][];
        for (int i = 0; i < names.length; i++) {
            NodeInfo ni = info.get(names[i]);
            shapes[i] = ni != null && ni.getInfo() instanceof TensorInfo ? ((TensorInfo) ni.getInfo()).getShape() : new long[0];
        }
    }

    @Override public int inputCount() { return names.length; }

    @Override public long[] inputShape(int i) { return shapes[i]; }

    @Override public Separator.Out run(float[][] inputs, long[][] sh) throws Exception {
        Map<String, OnnxTensor> in = new HashMap<>();
        List<OnnxTensor> opened = new ArrayList<>();
        try {
            for (int i = 0; i < names.length; i++) {
                ByteBuffer bb = ByteBuffer.allocateDirect(inputs[i].length * 4).order(ByteOrder.nativeOrder());
                FloatBuffer fb = bb.asFloatBuffer();
                fb.put(inputs[i]);
                fb.rewind();
                OnnxTensor t = OnnxTensor.createTensor(env, fb, sh[i]);
                opened.add(t);
                in.put(names[i], t);
            }
            try (OrtSession.Result res = session.run(in)) {
                List<float[]> data = new ArrayList<>();
                List<long[]> shp = new ArrayList<>();
                for (Map.Entry<String, OnnxValue> e : res) {
                    OnnxTensor t = (OnnxTensor) e.getValue();
                    FloatBuffer fb = t.getFloatBuffer();
                    float[] a = new float[fb.remaining()];
                    fb.get(a);
                    data.add(a);
                    shp.add(t.getInfo().getShape());
                }
                return new Separator.Out(data.toArray(new float[0][]), shp.toArray(new long[0][]));
            }
        } finally {
            for (OnnxTensor t : opened) { try { t.close(); } catch (Throwable ignored) { } }
        }
    }

    @Override public void close() {
        try { session.close(); } catch (Throwable ignored) { }
    }
}

package kx.engine;

import java.util.Arrays;

/**
 * Разделение на дорожки: Demucs-подобные модели (один вход «звук» или два входа «звук + спектр») и MDX-Net (спектр).
 * Нейросеть спрятана за интерфейсом Net, поэтому вся обвязка (окна, наложение, нормализация) проверяется отдельно от ONNX Runtime.
 */
final class Separator {
    static final int RATE = 44100;

    interface Net {
        int inputCount();
        /** Форма входа i; неизвестные (динамические) размеры — значения <= 0. */
        long[] inputShape(int i);
        /** Длина куска в отсчётах для моделей с динамическими осями, но фиксированной длиной внутри графа (0 — нет подсказки). */
        default int segmentHint() { return 0; }
        Out run(float[][] inputs, long[][] shapes) throws Exception;
    }

    static final class Out {
        final float[][] data;
        final long[][] shapes;
        /** Очень большие выходы (спектр drumsep ~226 МБ) лежат в нативной памяти, а не в куче Java: data[i] == null, данные в big[i]. */
        java.nio.FloatBuffer[] big;
        Out(float[][] d, long[][] s) { data = d; shapes = s; }

        /** len отсчётов выхода idx, начиная с off, в массив dst (или в сам выход, если он в куче — тогда dst не нужен, возвращается пара через arraycopy). */
        void part(int idx, int off, int len, float[] dst) {
            if (data[idx] != null) { System.arraycopy(data[idx], off, dst, 0, len); return; }
            java.nio.FloatBuffer b = big[idx].duplicate();
            b.position(off);
            b.get(dst, 0, len);
        }
    }

    interface Prog {
        void on(float fraction);
        boolean cancelled();
    }

    /** Приёмник готового звука одной дорожки: куски идут строго подряд, от начала трека к концу (в памяти целиком дорожка не хранится). */
    interface Sink {
        void write(float[] l, float[] r, int off, int len) throws Exception;
    }

    static final class Cancelled extends Exception { Cancelled() { super("cancelled"); } }

    private static void check(Prog p) throws Cancelled { if (p != null && p.cancelled()) throw new Cancelled(); }

    /** Число шагов нейросети для трека такой длины (для расчёта общего процента). */
    static int steps(Net net, int n, boolean mdx) {
        if (mdx) {
            long[] sh = net.inputShape(0);
            int dimT = sh.length >= 4 && sh[3] > 0 ? (int) sh[3] : 256;
            int dimF = sh.length >= 4 && sh[2] > 0 ? (int) sh[2] : 3072;
            int gen = 1024 * (dimT - 1) - 2 * dimF;
            return Math.max(1, (n + gen - 1) / gen);
        }
        int seg = demucsSegment(net);
        int stride = (int) (0.75 * seg);
        return Math.max(1, (n + stride - 1) / stride);
    }

    static boolean isMdx(Net net) {
        if (net.inputCount() != 1) return false;
        long[] s = net.inputShape(0);
        return s.length == 4 && s[1] == 4;
    }

    private static int demucsSegment(Net net) {
        for (int i = 0; i < net.inputCount(); i++) {
            long[] s = net.inputShape(i);
            if (s.length == 3 && s[2] > 0) return (int) s[2];
        }
        return net.segmentHint() > 0 ? net.segmentHint() : 343980;
    }

    // ---------------------------------------------------------------- Demucs

    /**
     * mix: [2][n] 44,1 кГц. want[s] — какие дорожки нужны (по индексу выхода модели). Возвращает [S][2][n] (null у ненужных).
     * Порядок и число дорожек определяются моделью (S берётся из формы выхода).
     */
    static void demucs(Net net, float[][] mix, int n, Sink[] sinks, Prog prog) throws Exception {
        final int T = demucsSegment(net);
        final boolean twoIn = net.inputCount() >= 2;
        int specIdx = -1, wavIdx = -1;
        for (int i = 0; i < net.inputCount(); i++) {
            long[] s = net.inputShape(i);
            if (s.length == 4) specIdx = i; else if (s.length == 3) wavIdx = i;
        }
        if (wavIdx < 0) wavIdx = 0;
        int F = 0, Tf = 0, nfft = 4096;
        if (twoIn && specIdx >= 0) {
            long[] s = net.inputShape(specIdx);
            F = (int) s[2]; Tf = (int) s[3];
            nfft = 2 * F;
        }
        final int hop = nfft / 4;
        final int le = (int) Math.ceil(T / (double) hop);
        if (twoIn && Tf <= 0) Tf = le;
        SepStft stft = twoIn ? new SepStft(nfft, hop) : null;
        final int pad = hop / 2 * 3;

        // глобальная нормализация, как в demucs.separate: по среднему каналу
        double sum = 0, sum2 = 0;
        for (int i = 0; i < n; i++) { double v = 0.5 * (mix[0][i] + mix[1][i]); sum += v; sum2 += v * v; }
        double mean = sum / Math.max(1, n);
        double var = Math.max(0, sum2 / Math.max(1, n) - mean * mean);
        double std = Math.sqrt(var);
        if (std < 1e-8) std = 1.0;
        final float fm = (float) mean, fs = (float) std;

        final int stride = (int) (0.75 * T);
        float[] weight = new float[T];
        for (int i = 0; i < T; i++) weight[i] = (i < T / 2 ? i + 1 : T - i) / (float) (T / 2);
        float[] sumW = new float[T];      // окно весов; готовые отсчёты сразу уходят в Sink, поэтому память не растёт с длиной трека
        float[] sp = null, tp = null; // буферы одной дорожки из больших выходов модели
        float[][][] acc = null;       // окно накопления [дорожка][канал][T]
        int S = 0;
        float[] cl = new float[T], cr = new float[T];
        float[] outL = new float[T], outR = new float[T];
        int chunks = Math.max(1, (n + stride - 1) / stride), done = 0;
        for (int off = 0; off < n; off += stride) {
            check(prog);
            int len = Math.min(T, n - off);
            Arrays.fill(cl, 0f); Arrays.fill(cr, 0f);
            for (int i = 0; i < len; i++) { cl[i] = (mix[0][off + i] - fm) / fs; cr[i] = (mix[1][off + i] - fm) / fs; }
            float[] wav = new float[2 * T];
            System.arraycopy(cl, 0, wav, 0, T);
            System.arraycopy(cr, 0, wav, T, T);
            float[][] ins = new float[net.inputCount()][];
            long[][] shp = new long[net.inputCount()][];
            ins[wavIdx] = wav; shp[wavIdx] = new long[]{1, 2, T};
            if (twoIn && specIdx >= 0) {
                float[] pl = SepStft.reflectPad(cl, T, pad, pad + le * hop - T);
                float[] pr = SepStft.reflectPad(cr, T, pad, pad + le * hop - T);
                pl = SepStft.reflectPad(pl, pl.length, nfft / 2, nfft / 2);
                pr = SepStft.reflectPad(pr, pr.length, nfft / 2, nfft / 2);
                float[] x = new float[4 * F * Tf];
                stft.analyze(pl, pr, F, 1f / (float) Math.sqrt(nfft), x, 2, Tf);
                ins[specIdx] = x; shp[specIdx] = new long[]{1, 4, F, Tf};
            }
            Out o = net.run(ins, shp);
            // выходы: 4-мерный [1,S,2,T] — время; 5-мерный [1,S,4,F,Tf] — спектр
            int ti = -1, fi = -1;
            for (int i = 0; i < o.shapes.length; i++) {
                if (o.shapes[i].length == 4) ti = i; else if (o.shapes[i].length == 5) fi = i;
            }
            if (ti < 0 && fi < 0) throw new IllegalStateException("model_output");
            int s = (int) o.shapes[ti >= 0 ? ti : fi][1];
            if (acc == null) {
                S = s;
                acc = new float[S][][];
                for (int k = 0; k < S; k++) if (k < sinks.length && sinks[k] != null) acc[k] = new float[2][T];
            }
            float[] ol = fi >= 0 ? new float[(Tf + 3) * hop + nfft] : null;
            float[] or = fi >= 0 ? new float[ol.length] : null;
            for (int k = 0; k < S; k++) {
                if (acc[k] == null) continue;
                float[] sl = new float[T], sr = new float[T];
                if (fi >= 0) {
                    int Fo = (int) o.shapes[fi][3], To = (int) o.shapes[fi][4];
                    if (sp == null || sp.length != 4 * Fo * To) sp = new float[4 * Fo * To];
                    o.part(fi, k * 4 * Fo * To, 4 * Fo * To, sp);
                    stft.synth(sp, 0, Fo, To, 2, To + 4, 1f / (float) Math.sqrt(nfft), ol, or);
                    int st = nfft / 2 + pad;
                    System.arraycopy(ol, st, sl, 0, T);
                    System.arraycopy(or, st, sr, 0, T);
                }
                if (ti >= 0) {
                    if (tp == null || tp.length != 2 * T) tp = new float[2 * T];
                    o.part(ti, k * 2 * T, 2 * T, tp);
                    for (int i = 0; i < T; i++) { sl[i] += tp[i]; sr[i] += tp[T + i]; }
                }
                for (int i = 0; i < len; i++) {
                    float w = weight[i];
                    acc[k][0][i] += sl[i] * w;
                    acc[k][1][i] += sr[i] * w;
                }
            }
            for (int i = 0; i < len; i++) sumW[i] += weight[i];
            // отсчёты до off+stride больше не получат вкладов от следующих кусков — отдаём их в файл
            final boolean last = off + stride >= n;
            final int cnt = last ? len : Math.min(stride, len);
            for (int k = 0; k < S; k++) {
                if (acc[k] == null) continue;
                float[] a0 = acc[k][0], a1 = acc[k][1];
                for (int i = 0; i < cnt; i++) {
                    float w = sumW[i];
                    outL[i] = (w > 1e-9f ? a0[i] / w : 0f) * fs + fm;
                    outR[i] = (w > 1e-9f ? a1[i] / w : 0f) * fs + fm;
                }
                sinks[k].write(outL, outR, 0, cnt);
                if (!last) { // сдвигаем хвост окна в начало
                    System.arraycopy(a0, stride, a0, 0, T - stride); Arrays.fill(a0, T - stride, T, 0f);
                    System.arraycopy(a1, stride, a1, 0, T - stride); Arrays.fill(a1, T - stride, T, 0f);
                }
            }
            if (!last) { System.arraycopy(sumW, stride, sumW, 0, T - stride); Arrays.fill(sumW, T - stride, T, 0f); }
            done++;
            if (prog != null) prog.on(done / (float) chunks);
        }
        if (acc == null) throw new IllegalStateException("empty");
    }

    // ---------------------------------------------------------------- MDX-Net

    /**
     * MDX-Net (UVR-MDX-NET-Inst_*): первичная дорожка модели — инструментал. inst получает инструментал × instGain,
     * vocals — разность «микс − инструментал». Любой из приёмников может быть null. Целиком дорожки в памяти не хранятся.
     */
    static void mdx(Net net, float[][] mix, int n, Sink inst, float instGain, Sink vocals, Prog prog) throws Exception {
        long[] sh = net.inputShape(0);
        final int dimF = sh[2] > 0 ? (int) sh[2] : 3072;
        final int dimT = sh[3] > 0 ? (int) sh[3] : 256;
        final int nfft = 2 * dimF, hop = 1024;
        final int chunk = hop * (dimT - 1), trim = nfft / 2, gen = chunk - 2 * trim;
        SepStft stft = new SepStft(nfft, hop);
        int count = Math.max(1, (n + gen - 1) / gen);
        float[] al = new float[chunk], ar = new float[chunk];
        float[] ol = new float[(dimT - 1) * hop + nfft], or = new float[ol.length];
        float[] i1 = new float[gen], i2 = new float[gen], v1 = new float[gen], v2 = new float[gen];
        for (int i = 0; i < count; i++) {
            check(prog);
            int st = i * gen;
            for (int t = 0; t < chunk; t++) { // кусочек микса с нулевыми краями — копию всего трека не делаем
                int m = st - trim + t;
                if (m >= 0 && m < n) { al[t] = mix[0][m]; ar[t] = mix[1][m]; } else { al[t] = 0f; ar[t] = 0f; }
            }
            float[] l2 = SepStft.reflectPad(al, chunk, nfft / 2, nfft / 2);
            float[] r2 = SepStft.reflectPad(ar, chunk, nfft / 2, nfft / 2);
            float[] x = new float[4 * dimF * dimT];
            stft.analyze(l2, r2, dimF, 1f, x, 0, dimT);
            Arrays.fill(x, 0, 3 * dimT, 0f);                               // нули для трёх нижних бинов L.re
            Arrays.fill(x, dimF * dimT, dimF * dimT + 3 * dimT, 0f);       // L.im
            Arrays.fill(x, 2 * dimF * dimT, 2 * dimF * dimT + 3 * dimT, 0f); // R.re
            Arrays.fill(x, 3 * dimF * dimT, 3 * dimF * dimT + 3 * dimT, 0f);// R.im
            Out o = net.run(new float[][]{x}, new long[][]{{1, 4, dimF, dimT}});
            stft.synth(o.data[0], 0, dimF, dimT, 0, dimT, 1f / nfft, ol, or);
            int keepFrom = nfft / 2 + trim;   // центр-дополнение STFT + срез краёв кусочка
            int dst = i * gen;
            int cnt = Math.min(gen, n - dst);
            if (cnt > 0) {
                if (inst != null) {
                    for (int t = 0; t < cnt; t++) { i1[t] = ol[keepFrom + t] * instGain; i2[t] = or[keepFrom + t] * instGain; }
                    inst.write(i1, i2, 0, cnt);
                }
                if (vocals != null) {
                    for (int t = 0; t < cnt; t++) { v1[t] = mix[0][dst + t] - ol[keepFrom + t]; v2[t] = mix[1][dst + t] - or[keepFrom + t]; }
                    vocals.write(v1, v2, 0, cnt);
                }
            }
            if (prog != null) prog.on((i + 1) / (float) count);
        }
    }
}

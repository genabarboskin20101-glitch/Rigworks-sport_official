package org.webterm.bridge;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Window;
import android.view.WindowManager;

/** Internal helper Activity that receives the result from Android's folder picker. */
public final class BridgePickerActivity extends Activity {
    public static final String ACTION_PICK_FOLDER = "org.webterm.bridge.action.PICK_FOLDER";
    static final String PREFS_NAME = "webterm_native_bridge";
    static final String PREF_TREE_URI = "selected_tree_uri";
    static final String PREF_PICK_STATUS = "last_pick_status";
    private static final int REQUEST_PICK_TREE = 7331;

    @Override protected void onCreate(Bundle state) {
        setTheme(android.R.style.Theme_Translucent_NoTitleBar);
        super.onCreate(state);
        Window w = getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        if (!ACTION_PICK_FOLDER.equals(getIntent() == null ? null : getIntent().getAction())) {
            finish(); return;
        }
        if (state != null) return;
        try {
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= 26) {
                String saved = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(PREF_TREE_URI, "");
                if (saved != null && !saved.isEmpty()) {
                    try { picker.putExtra(DocumentsContract.EXTRA_INITIAL_URI, Uri.parse(saved)); }
                    catch (Exception ignored) { }
                }
            }
            startActivityForResult(picker, REQUEST_PICK_TREE);
        } catch (ActivityNotFoundException e) {
            saveStatus("picker_unavailable"); finish();
        } catch (Exception e) {
            saveStatus("picker_failed"); finish();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_TREE) return;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                if ((flags & Intent.FLAG_GRANT_READ_URI_PERMISSION) == 0) throw new SecurityException("No persistable read permission returned");
                getContentResolver().takePersistableUriPermission(uri, flags);
                SharedPreferences.Editor edit = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                edit.putString(PREF_TREE_URI, uri.toString());
                edit.putString(PREF_PICK_STATUS, "selected");
                edit.apply();
            } catch (SecurityException e) {
                saveStatus("persist_permission_failed");
            } catch (Exception e) {
                saveStatus("folder_selection_failed");
            }
        } else {
            saveStatus("cancelled");
        }
        finish();
    }

    private void saveStatus(String status) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(PREF_PICK_STATUS, status).apply();
    }
}

package org.webterm.bridge;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * Narrow, app-private Android bridge. There is intentionally no Runtime.exec,
 * ProcessBuilder, root access, raw sockets, or unrestricted shared-storage API.
 */
public final class TermuxBridge {
    private static final int MAX_TEXT_BYTES = 1024 * 1024;
    private static final int MAX_LIST_ITEMS = 200;
    private final Context context;
    private volatile String expectedToken;
    private volatile Boolean localBuild;
    private volatile boolean localPageActive;

    TermuxBridge(Context context) {
        this.context = context.getApplicationContext();
    }

    // Updated by TermuxFactory on the Android main thread; JS bridge calls run on another thread.
    void setLocalPageActive(boolean active) {
        this.localPageActive = active;
    }

    private JSONObject result(boolean ok) {
        JSONObject o = new JSONObject();
        try { o.put("ok", ok); } catch (Exception ignored) { }
        return o;
    }

    private String fail(String message) {
        JSONObject o = result(false);
        try { o.put("error", message == null ? "operation_failed" : message); }
        catch (Exception ignored) { }
        return o.toString();
    }

    private String success(String key, Object value) {
        JSONObject o = result(true);
        try { o.put(key, value); } catch (Exception ignored) { }
        return o.toString();
    }

    private String loadExpectedToken() {
        if (expectedToken != null) return expectedToken;
        synchronized (this) {
            if (expectedToken != null) return expectedToken;
            String value = "";
            try (InputStream in = context.getAssets().open("www/.termux-bridge-token")) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[128]; int n;
                while ((n = in.read(buf)) > 0 && out.size() < 512) out.write(buf, 0, n);
                value = new String(out.toByteArray(), StandardCharsets.UTF_8).trim();
            } catch (Exception ignored) { }
            expectedToken = value;
            return value;
        }
    }

    private boolean isLocalBuild() {
        if (localBuild != null) return localBuild.booleanValue();
        boolean local = false;
        try (InputStream in = context.getAssets().open("www/config.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[512]; int n;
            while ((n = in.read(buf)) > 0 && out.size() < 16384) out.write(buf, 0, n);
            JSONObject cfg = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
            local = "local".equals(cfg.optString("mode", ""));
        } catch (Exception ignored) { }
        localBuild = Boolean.valueOf(local);
        return local;
    }

    private boolean authorized(String token) {
        String expected = loadExpectedToken();
        if (expected.length() < 32 || token == null || token.length() != expected.length()) return false;
        int diff = 0;
        for (int i = 0; i < expected.length(); i++) diff |= expected.charAt(i) ^ token.charAt(i);
        return diff == 0 && isLocalBuild() && localPageActive;
    }

    private File root() throws Exception {
        File r = new File(context.getFilesDir(), "webterm").getCanonicalFile();
        if (!r.exists() && !r.mkdirs()) throw new Exception("cannot_create_sandbox");
        return r;
    }

    private File resolve(String relativePath) throws Exception {
        String p = relativePath == null ? "" : relativePath.trim();
        if (p.length() > 512) throw new Exception("path_too_long");
        if (p.startsWith("/") || p.indexOf('\\') >= 0 || p.indexOf('\0') >= 0) throw new Exception("invalid_relative_path");
        File root = root();
        if (p.isEmpty()) return root;
        String[] parts = p.split("/", -1);
        for (String part : parts) {
            if (part.isEmpty() || ".".equals(part) || "..".equals(part)) throw new Exception("invalid_path_segment");
            if (part.length() > 100) throw new Exception("path_segment_too_long");
        }
        File target = new File(root, p).getCanonicalFile();
        String prefix = root.getPath() + File.separator;
        if (!target.getPath().startsWith(prefix)) throw new Exception("path_outside_sandbox");
        return target;
    }

    @JavascriptInterface public String getDeviceInfo(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            JSONObject d = new JSONObject();
            d.put("manufacturer", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER);
            d.put("brand", Build.BRAND == null ? "" : Build.BRAND);
            d.put("model", Build.MODEL == null ? "" : Build.MODEL);
            d.put("androidRelease", Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE);
            d.put("sdkInt", Build.VERSION.SDK_INT);
            d.put("bridgeVersion", "1.0.0");
            return success("device", d).toString();
        } catch (Exception e) { return fail("device_info_failed"); }
    }

    @JavascriptInterface public String getStorageInfo(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            StatFs s = new StatFs(context.getFilesDir().getAbsolutePath());
            JSONObject d = new JSONObject();
            d.put("sandbox", "app-private/webterm");
            d.put("totalBytes", s.getTotalBytes());
            d.put("availableBytes", s.getAvailableBytes());
            d.put("usedBytes", Math.max(0L, s.getTotalBytes() - s.getAvailableBytes()));
            d.put("note", "Filesystem statistics are for the app data volume, not all device RAM/storage.");
            return success("storage", d).toString();
        } catch (Exception e) { return fail("storage_info_failed"); }
    }

    @JavascriptInterface public String listFiles(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File dir = resolve(relativePath);
            if (!dir.isDirectory()) return fail("not_a_directory");
            File[] files = dir.listFiles();
            if (files == null) files = new File[0];
            Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            JSONArray rows = new JSONArray();
            for (int i = 0; i < files.length && i < MAX_LIST_ITEMS; i++) {
                File f = files[i]; JSONObject item = new JSONObject();
                item.put("name", f.getName()); item.put("type", f.isDirectory() ? "dir" : "file");
                item.put("size", f.isFile() ? f.length() : 0L); rows.put(item);
            }
            JSONObject o = result(true); o.put("path", relativePath == null ? "" : relativePath); o.put("entries", rows);
            if (files.length > MAX_LIST_ITEMS) o.put("truncated", true);
            return o.toString();
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String readTextFile(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File f = resolve(relativePath);
            if (!f.isFile()) return fail("not_a_file");
            if (f.length() > MAX_TEXT_BYTES) return fail("file_too_large_max_1MiB");
            try (InputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) {
                    if (out.size() + n > MAX_TEXT_BYTES) return fail("file_too_large_max_1MiB");
                    out.write(buf, 0, n);
                }
                JSONObject o = result(true); o.put("content", new String(out.toByteArray(), StandardCharsets.UTF_8));
                o.put("size", out.size()); return o.toString();
            }
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String writeTextFile(String token, String relativePath, String content) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            if (content == null) content = "";
            byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_TEXT_BYTES) return fail("content_too_large_max_1MiB");
            File f = resolve(relativePath);
            if (f.equals(root())) return fail("path_is_directory");
            File parent = f.getParentFile();
            if (parent == null || !parent.isDirectory()) return fail("parent_directory_missing");
            try (FileOutputStream out = new FileOutputStream(f, false)) { out.write(bytes); out.flush(); }
            JSONObject o = result(true); o.put("path", relativePath); o.put("bytesWritten", bytes.length); return o.toString();
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String makeDirectory(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File f = resolve(relativePath);
            if (f.equals(root())) return fail("root_already_exists");
            if (f.exists()) return fail("already_exists");
            if (!f.mkdirs()) return fail("mkdir_failed");
            return success("path", relativePath);
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String deleteFile(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File f = resolve(relativePath);
            if (f.equals(root())) return fail("cannot_delete_sandbox_root");
            if (!f.exists()) return fail("not_found");
            if (f.isDirectory()) {
                String[] children = f.list();
                if (children != null && children.length != 0) return fail("directory_not_empty");
            }
            if (!f.delete()) return fail("delete_failed");
            return success("deleted", relativePath);
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String networkStatus(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            JSONObject n = new JSONObject();
            n.put("connected", ni != null && ni.isConnected());
            n.put("type", ni == null ? "none" : (ni.getTypeName() == null ? "unknown" : ni.getTypeName()));
            return success("network", n).toString();
        } catch (Exception e) { return fail("network_status_failed"); }
    }

    @JavascriptInterface public String shareText(String token, final String text) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        if (text == null || text.length() > 20000) return fail("text_too_long_max_20000_chars");
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, text);
                Intent chooser = Intent.createChooser(send, "Поделиться текстом");
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(chooser);
            } catch (Exception ignored) { }
        });
        return success("queued", true);
    }

    @JavascriptInterface public String vibrate(String token, int millis) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        int duration = Math.max(0, Math.min(500, millis));
        try {
            Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return fail("vibrator_unavailable");
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(duration);
            return success("durationMs", duration);
        } catch (Exception e) { return fail("vibration_failed"); }
    }
}

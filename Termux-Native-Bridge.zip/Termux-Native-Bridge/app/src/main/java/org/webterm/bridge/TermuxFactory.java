package org.webterm.bridge;

import android.app.Activity;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * AppComponentFactory shim injected into the WebView wrapper APK.
 * It delegates AndroidX instantiation to the original CoreComponentFactory and
 * installs a deliberately limited JavaScript bridge into the local bundled page.
 */
public final class TermuxFactory extends AppComponentFactory {
    private static final Map<WebView, TermuxBridge> INSTALLED =
            Collections.synchronizedMap(new WeakHashMap<WebView, TermuxBridge>());
    private static final Map<WebView, Boolean> MONITORED =
            Collections.synchronizedMap(new WeakHashMap<WebView, Boolean>());
    private volatile AppComponentFactory delegate;
    private volatile boolean delegateResolved;
    private volatile boolean callbacksRegistered;

    private AppComponentFactory getDelegate(ClassLoader cl) {
        if (delegateResolved) return delegate;
        synchronized (this) {
            if (delegateResolved) return delegate;
            try {
                Class<?> type = Class.forName("androidx.core.app.CoreComponentFactory", false, cl);
                Object value = type.getDeclaredConstructor().newInstance();
                if (value instanceof AppComponentFactory && value.getClass() != getClass()) {
                    delegate = (AppComponentFactory) value;
                }
            } catch (Throwable ignored) {
                delegate = null; // Fall back to the platform factory if AndroidX is absent.
            }
            delegateResolved = true;
            return delegate;
        }
    }

    @Override
    public Application instantiateApplication(ClassLoader cl, String className) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        AppComponentFactory d = getDelegate(cl);
        Application app = d != null ? d.instantiateApplication(cl, className)
                                    : super.instantiateApplication(cl, className);
        registerCallbacks(app);
        return app;
    }

    private void registerCallbacks(Application app) {
        if (app == null || callbacksRegistered) return;
        synchronized (this) {
            if (callbacksRegistered) return;
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityCreated(Activity a, Bundle state) { scheduleInstall(a); }
                @Override public void onActivityStarted(Activity a) { scheduleInstall(a); }
                @Override public void onActivityResumed(Activity a) { scheduleInstall(a); }
                @Override public void onActivityPaused(Activity a) { }
                @Override public void onActivityStopped(Activity a) { }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle state) { }
                @Override public void onActivityDestroyed(Activity a) { }
            });
            callbacksRegistered = true;
        }
    }

    private void scheduleInstall(final Activity activity) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final long deadline = android.os.SystemClock.uptimeMillis() + 10000L;
        final Runnable[] task = new Runnable[1];
        task[0] = new Runnable() {
            @Override public void run() {
                if (activity.isFinishing() || activity.isDestroyed()) return;
                View root = activity.getWindow() == null ? null : activity.getWindow().getDecorView();
                WebView webView = findWebView(root);
                if (webView != null) {
                    final TermuxBridge bridge;
                    boolean justInstalled = false;
                    boolean startMonitor = false;
                    synchronized (INSTALLED) {
                        TermuxBridge existing = INSTALLED.get(webView);
                        if (existing == null) {
                            existing = new TermuxBridge(activity.getApplicationContext());
                            webView.addJavascriptInterface(existing, "TermuxBridge");
                            INSTALLED.put(webView, existing);
                            justInstalled = true;
                        }
                        bridge = existing;
                        if (!MONITORED.containsKey(webView)) {
                            MONITORED.put(webView, Boolean.TRUE);
                            startMonitor = true;
                        }
                    }
                    // addJavascriptInterface becomes visible to JS after a navigation.
                    // Recheck URL only from this main-thread monitor, never from @JavascriptInterface.
                    if (justInstalled) {
                        String currentUrl = webView.getUrl();
                        boolean local = currentUrl != null && currentUrl.startsWith("file:///android_asset/www/");
                        bridge.setLocalPageActive(local);
                        if (local) {
                            webView.post(() -> {
                                String now = webView.getUrl();
                                if (now != null && now.startsWith("file:///android_asset/www/")) webView.reload();
                            });
                        }
                    }
                    if (startMonitor) monitorPage(activity, webView, bridge);
                    return;
                }
                if (android.os.SystemClock.uptimeMillis() < deadline) {
                    handler.postDelayed(this, 180L);
                }
            }
        };
        handler.post(task[0]);
    }


    private void monitorPage(final Activity activity, final WebView webView, final TermuxBridge bridge) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable[] monitor = new Runnable[1];
        monitor[0] = new Runnable() {
            @Override public void run() {
                if (activity.isFinishing() || activity.isDestroyed()) {
                    bridge.setLocalPageActive(false);
                    return;
                }
                boolean local = false;
                try {
                    String url = webView.getUrl();
                    local = url != null && url.startsWith("file:///android_asset/www/");
                } catch (Throwable ignored) { }
                bridge.setLocalPageActive(local);
                handler.postDelayed(this, 350L);
            }
        };
        handler.post(monitor[0]);
    }

    private WebView findWebView(View view) {
        if (view == null) return null;
        if (view instanceof WebView) return (WebView) view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                WebView found = findWebView(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    @Override public Activity instantiateActivity(ClassLoader cl, String name, Intent intent) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        AppComponentFactory d = getDelegate(cl);
        return d != null ? d.instantiateActivity(cl, name, intent) : super.instantiateActivity(cl, name, intent);
    }
    @Override public BroadcastReceiver instantiateReceiver(ClassLoader cl, String name, Intent intent) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        AppComponentFactory d = getDelegate(cl);
        return d != null ? d.instantiateReceiver(cl, name, intent) : super.instantiateReceiver(cl, name, intent);
    }
    @Override public Service instantiateService(ClassLoader cl, String name, Intent intent) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        AppComponentFactory d = getDelegate(cl);
        return d != null ? d.instantiateService(cl, name, intent) : super.instantiateService(cl, name, intent);
    }
    @Override public ContentProvider instantiateProvider(ClassLoader cl, String name) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        AppComponentFactory d = getDelegate(cl);
        return d != null ? d.instantiateProvider(cl, name) : super.instantiateProvider(cl, name);
    }
}

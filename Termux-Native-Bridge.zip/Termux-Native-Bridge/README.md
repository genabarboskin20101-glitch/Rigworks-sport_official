# Нативный мост Termux Native Bridge для APK Builder

Это отдельный Android-слой для WebTerm Lite. Он не превращает HTML в полноценный Termux и **не исполняет произвольные shell-команды**. Мост предоставляет только:

- сведения об устройстве и статистику раздела данных приложения;
- сетевой статус Android;
- чтение, запись, список, создание папок и удаление пустых/одиночных объектов **только внутри приватного каталога `files/webterm`**;
- системный диалог «Поделиться» для текста и короткую вибрацию.

Каждый вызов требует случайный build-time токен, который внедряет APK Builder. Вызовы доступны только при конфигурации `mode: local` и пока основной WebView показывает `file:///android_asset/www/`; проверка URL обновляется на UI-потоке и читается мостом как потокобезопасный флаг. Не загружайте недоверенные скрипты, страницы или iframe внутрь локальной страницы, которой разрешён нативный мост: любой доверенный скрипт этой страницы имеет доступ к токену. Проверка внешних `script src`/`iframe src` в Builder — дополнительная эвристика, не полноценный аудит кода. Этот мост — ограниченная привилегия, а не песочница для произвольного JavaScript.

## Сборка DEX через GitHub Actions

1. Создайте приватный или публичный репозиторий GitHub и загрузите туда всё содержимое этой папки.
2. Откройте **Actions → Build Termux Native Bridge DEX → Run workflow**. При push workflow также запускается автоматически.
3. Откройте завершённый запуск workflow, скачайте artifact `termux-bridge-dex` и извлеките `termux-bridge.dex`.
4. В `Apkbuilder.html` откройте блок «Нативный мост Android (Termux)», включите его и выберите полученный `termux-bridge.dex`.
5. Выберите локальный HTML (например, WebTerm Lite), не режим «Адрес сайта», затем соберите и подпишите APK.

## API из JavaScript

В локальном `index.html` Builder внедряет `window.__termuxBridgeToken`. Пример:

```js
const token = window.__termuxBridgeToken;
const device = JSON.parse(TermuxBridge.getDeviceInfo(token));
const list = JSON.parse(TermuxBridge.listFiles(token, ''));
const read = JSON.parse(TermuxBridge.readTextFile(token, 'notes.txt'));
const write = JSON.parse(TermuxBridge.writeTextFile(token, 'notes.txt', 'Привет'));
const network = JSON.parse(TermuxBridge.networkStatus(token));
```

Методы возвращают JSON-строку со свойством `ok`. Каталог `webterm` автоматически создаётся внутри приватного каталога приложения. Не поддерживаются пути за пределы sandbox.

## Технические требования и ограничения

- Работает на Android 9 (API 28) и новее — это соответствует использованному в Builder механизму `AppComponentFactory`.
- Builder патчит `android:appComponentFactory` на `org.webterm.bridge.TermuxFactory`, добавляет bridge DEX как `classes2.dex` и встраивает непредсказуемый токен в локальный `index.html` и `assets/www/.termux-bridge-token`.
- Одновременно с существующей опцией KX использовать нельзя: обе функции занимают `classes2.dex` и атрибут `appComponentFactory`. Не включайте KX для той же сборки.
- Данная папка содержит исходный код и workflow, а не готовый, протестированный на устройстве APK. В текущей среде Android SDK/Gradle не доступны, поэтому DEX не был скомпилирован здесь; его собирает workflow GitHub Actions. После получения DEX соберите подписанный APK и проверьте его на Android 9+ до распространения.

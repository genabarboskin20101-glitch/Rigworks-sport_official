# Нативный мост Termux Native Bridge для APK Builder

Это отдельный Android-слой для WebTerm Lite. Он не превращает HTML в полноценный Termux и **не исполняет произвольные shell-команды**. Мост предоставляет только:

- сведения об устройстве и статистику раздела данных приложения;
- сетевой статус Android;
- чтение, запись, список, создание папок и удаление пустых/одиночных объектов **только внутри приватного каталога `files/webterm`**;
- выбор одной папки через системный Storage Access Framework (SAF), с постоянным разрешением только на выбранное пользователем дерево; просмотр, чтение, запись текстовых файлов и создание подпапок в этом дереве;
- системный диалог «Поделиться» для текста и короткую вибрацию.

Каждый вызов требует случайный build-time токен, который внедряет APK Builder. Вызовы доступны только при конфигурации `mode: local` и пока основной WebView показывает локальный bundle по `https://appassets.androidplatform.net/assets/www/` (или совместимый `file:///android_asset/www/`); проверка URL обновляется на UI-потоке и читается мостом как потокобезопасный флаг. Не загружайте недоверенные скрипты, страницы или iframe внутрь локальной страницы, которой разрешён нативный мост: любой доверенный скрипт этой страницы имеет доступ к токену. Проверка внешних `script src`/`iframe src` в Builder — дополнительная эвристика, не полноценный аудит кода. Этот мост — ограниченная привилегия, а не песочница для произвольного JavaScript.

## Сборка DEX через GitHub Actions

Workflow компилирует `TermuxFactory.java`, `TermuxBridge.java` и `BridgePickerActivity.java` напрямую через `javac` и Android SDK `d8`, затем проверяет подпись/контрольную сумму DEX и наличие всех обязательных классов. Ошибочный или неполный DEX не будет опубликован как артефакт.

1. Создайте приватный или публичный репозиторий GitHub и загрузите туда всё содержимое этой папки (либо следуйте `README-Android-phone.txt`, если загружаете архив с телефона).
2. Откройте **Actions → Build Termux Native Bridge DEX → Run workflow**. При изменении исходников workflow также запускается автоматически.
3. Откройте последний успешный запуск workflow, скачайте artifact `termux-bridge-dex` и извлеките `termux-bridge.dex`. Используйте именно артефакт из последнего запуска, не `classes.dex` из постороннего APK.
4. В `Apkbuilder.html` откройте блок «Нативный мост Android (Termux)», включите его и выберите полученный `termux-bridge.dex`.
5. Выберите локальный HTML (например, WebTerm Lite), не режим «Адрес сайта», затем соберите и подпишите APK.

## API из JavaScript

В локальном `index.html` Builder внедряет `window.__termuxBridgeToken`. Пример:

```js
const token = window.__termuxBridgeToken;
const device = JSON.parse(TermuxBridge.getDeviceInfo(token));
const list = JSON.parse(TermuxBridge.listFiles(token, ''));
const read = JSON.parse(TermuxBridge.readTextFile(token, 'notes.txt'));
const write = JSON.parse(TermuxBridge.writeTextFile(token, 'notes.txt', 'Привет'));
const network = JSON.parse(TermuxBridge.networkStatus(token));
// Открывает системный выбор папки; после выбора можно проверить статус:
const pick = JSON.parse(TermuxBridge.pickSharedFolder(token));
const folder = JSON.parse(TermuxBridge.sharedFolderStatus(token));
const shared = JSON.parse(TermuxBridge.listSharedFolderFiles(token, ''));
```

Методы возвращают JSON-строку со свойством `ok`. Каталог `webterm` автоматически создаётся внутри приватного каталога приложения. Приватные команды не принимают пути за пределами sandbox. Команды `android-shared-*` работают только в папке, которую пользователь выбрал через `android-folder-pick`; доступ ограничен выданным Android URI-грантом. Доступ к `Android/data`, `Android/obb` и некоторым системным местам может ограничиваться самим Android и провайдером документов.

## Технические требования и ограничения

- Работает на Android 9 (API 28) и новее — это соответствует использованному в Builder механизму `AppComponentFactory`.
- Builder патчит `android:appComponentFactory` на `org.webterm.bridge.TermuxFactory`, добавляет bridge DEX как `classes2.dex` и встраивает непредсказуемый токен в локальный `index.html` и `assets/www/.termux-bridge-token`.
- Одновременно с существующей опцией KX использовать нельзя: обе функции занимают `classes2.dex` и атрибут `appComponentFactory`. Не включайте KX для той же сборки.
- Данная папка содержит исходный код и workflow, а не готовый, протестированный на устройстве APK. В текущей среде Android SDK/Gradle не доступны, поэтому DEX не был скомпилирован здесь; его собирает workflow GitHub Actions. После получения DEX соберите подписанный APK и проверьте его на Android 9+ до распространения.

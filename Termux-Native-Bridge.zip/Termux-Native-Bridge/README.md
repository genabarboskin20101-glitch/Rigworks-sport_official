# Нативный мост Termux Native Bridge для APK Builder

Это отдельный Android-слой для WebTerm Lite. Он не превращает HTML в полноценный Termux. По умолчанию доступны фиксированные безопасные интерфейсы; опциональная встроенная сборка GNU Bash позволяет выполнять произвольные команды от имени обычного UID приложения, но не от root. Мост предоставляет только:

- сведения об устройстве и статистику раздела данных приложения;
- сетевой статус Android;
- чтение, запись, список, создание папок и удаление пустых/одиночных объектов **только внутри приватного каталога `files/webterm`**;
- выбор одной папки через системный Storage Access Framework (SAF), с постоянным разрешением только на выбранное пользователем дерево; просмотр, чтение, запись текстовых файлов и создание подпапок в этом дереве;
- системный диалог «Поделиться» для текста и короткую вибрацию;
- ограниченный запуск read-only диагностических утилит Android (`android-run`) с отдельными `stdout`, `stderr`, кодом завершения, таймаутом и лимитом вывода. Разрешённый набор: `id`, `uname`, `date`, `uptime`, `df`, `ps`, `model`, `android-version`, `sdk`. Команды запускаются через фиксированный argv (`toybox`/`getprop`), не через shell. Дополнительно метод `runBashCommand` запускает **отдельный GNU Bash 5.3.20 ARM64-процесс** только если `libbash.so` встроен в APK; он не запускается от root, имеет таймаут 10 секунд, максимум 4096 символов команды и до 32 КБ на каждый stdout/stderr. Переменные и `cd` между запусками не сохраняются. Без `libbash.so` команда недоступна.

Каждый вызов требует случайный build-time токен, который внедряет APK Builder. Вызовы доступны только при конфигурации `mode: local` и пока основной WebView показывает локальный bundle по `https://appassets.androidplatform.net/assets/www/` (или совместимый `file:///android_asset/www/`); проверка URL обновляется на UI-потоке и читается мостом как потокобезопасный флаг. Не загружайте недоверенные скрипты, страницы или iframe внутрь локальной страницы, которой разрешён нативный мост: любой доверенный скрипт этой страницы имеет доступ к токену. Проверка внешних `script src`/`iframe src` в Builder — дополнительная эвристика, не полноценный аудит кода. Этот мост — ограниченная привилегия, а не песочница для произвольного JavaScript.

## Сборка DEX через GitHub Actions

Workflow компилирует Java-классы напрямую через `javac` и Android SDK `d8`, проверяет классы, контрольную сумму DEX и метод `runBashCommand`. Дополнительно он собирает GNU Bash 5.3.20 из исходников GNU для Android ARM64 с Android NDK, проверяет источник/патчи SHA-256, ELF-архитектуру и интерпретатор `/system/bin/linker64`, затем публикует второй артефакт `webterm-bash-arm64` с `libbash.so`. Успех этих шагов означает сборку/структурную проверку, но не заменяет тест запуска на физическом устройстве.

1. Создайте приватный или публичный репозиторий GitHub и загрузите туда всё содержимое этой папки (либо следуйте `README-Android-phone.txt`, если загружаете архив с телефона).
2. Откройте **Actions → Build Termux Native Bridge DEX → Run workflow**. При изменении исходников workflow также запускается автоматически.
3. Откройте последний успешный запуск workflow, скачайте artifact `termux-bridge-dex` и извлеките `termux-bridge.dex`. Если нужен настоящий Bash, скачайте второй artifact `webterm-bash-arm64` и извлеките `libbash.so`. Используйте артефакты из одного и того же последнего запуска.
4. В `Apkbuilder.html` откройте блок «Нативный мост Android (Termux)», включите его и выберите полученный `termux-bridge.dex`.
5. Выберите локальный HTML (например, обновлённый WebTerm Lite), не режим «Адрес сайта». Чтобы включить Bash, отметьте «Встроить настоящий GNU Bash (ARM64)» и выберите `libbash.so`. Builder меняет `android:extractNativeLibs` на `true`, добавляет `lib/arm64-v8a/libbash.so`, проверяет ELF и выполняет самопроверку собранного APK. Затем подпишите APK.

## API из JavaScript

В локальном `index.html` Builder внедряет `window.__termuxBridgeToken`. Пример:

```js
const token = window.__termuxBridgeToken;
const device = JSON.parse(TermuxBridge.getDeviceInfo(token));
const list = JSON.parse(TermuxBridge.listFiles(token, ''));
const read = JSON.parse(TermuxBridge.readTextFile(token, 'notes.txt'));
const write = JSON.parse(TermuxBridge.writeTextFile(token, 'notes.txt', 'Привет'));
const network = JSON.parse(TermuxBridge.networkStatus(token));
// Только фиксированная диагностика; передать можно лишь имя из allowlist:
const nativeDiag = JSON.parse(TermuxBridge.runDiagnosticCommand(token, 'uname'));
// nativeDiag: { ok, command, stdout, stderr, exitCode, timedOut, ... }
// Открывает системный выбор папки; после выбора можно проверить статус:
const pick = JSON.parse(TermuxBridge.pickSharedFolder(token));
const folder = JSON.parse(TermuxBridge.sharedFolderStatus(token));
const shared = JSON.parse(TermuxBridge.listSharedFolderFiles(token, ''));
```

Методы возвращают JSON-строку со свойством `ok`. Каталог `webterm` автоматически создаётся внутри приватного каталога приложения. Приватные команды не принимают пути за пределами sandbox. Команды `android-shared-*` работают только в папке, которую пользователь выбрал через `android-folder-pick`; доступ ограничен выданным Android URI-грантом. Доступ к `Android/data`, `Android/obb` и некоторым системным местам может ограничиваться самим Android и провайдером документов.

## Технические требования и ограничения

- Работает на Android 9 (API 28) и новее — это соответствует использованному в Builder механизму `AppComponentFactory`.
- Builder патчит `android:appComponentFactory` на `org.webterm.bridge.TermuxFactory`, добавляет bridge DEX как `classes2.dex` и встраивает непредсказуемый токен в локальный `index.html` и `assets/www/.termux-bridge-token`.
- Одновременно с существующей опцией KX использовать нельзя: обе функции занимают `classes2.dex` и атрибут `appComponentFactory`. Не включайте KX для той же сборки.
- Встроенный Bash рассчитан только на `arm64-v8a` / AArch64. В первой версии это одноразовый `bash -c`: переменные, каталог `cd`, jobs и интерактивная история между вызовами не сохраняются. `PATH` содержит `/system/bin` и `/system/xbin`, то есть утилиты Android Toybox; полный набор GNU coreutils, Python и пакетный менеджер пока не входят в комплект.
- Не передавайте строку Bash недоверенным HTML/JS: команда может выполнять действия с разрешениями самого приложения. Мост не имеет root, а доступ к пользовательской общей папке продолжается только через отдельные SAF-методы.
- Данная папка содержит исходный код и workflow, а не готовый, протестированный на устройстве APK. В текущей среде Android SDK/Gradle не доступны, поэтому DEX не был скомпилирован здесь; его собирает workflow GitHub Actions. После получения DEX соберите подписанный APK и проверьте его на Android 9+ до распространения.

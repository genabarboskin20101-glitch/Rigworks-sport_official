package org.webterm.bridge;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.database.Cursor;
import android.provider.DocumentsContract;
import android.content.UriPermission;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Android bridge for the trusted bundled WebTerm UI. Native diagnostics use a
 * fixed allowlist. Optional GNU Bash is executed one-shot only when a verified
 * ARM64 binary has been packaged in nativeLibraryDir; it never gains root. The
 * bridge remains gated by the unpredictable build token and local-page guard.
 */
public final class TermuxBridge {
    private static final int MAX_TEXT_BYTES = 1024 * 1024;
    private static final int MAX_LIST_ITEMS = 200;
    private static final int MAX_PROCESS_OUTPUT_BYTES = 16384;
    private static final int MAX_BASH_OUTPUT_BYTES = 32768;
    private static final int MAX_BASH_COMMAND_CHARS = 4096;
    private static final long PROCESS_TIMEOUT_MS = 3500L;
    private static final long BASH_TIMEOUT_MS = 10000L;
    private static final String PREFS_NAME = "webterm_native_bridge";
    private static final String PREF_TREE_URI = "selected_tree_uri";
    private static final String PREF_PICK_STATUS = "last_pick_status";
    private static final String MIME_DIRECTORY = DocumentsContract.Document.MIME_TYPE_DIR;
    private static final String[] DOCUMENT_PROJECTION = new String[] {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
    };
    private final Context context;
    private final WeakReference<Activity> hostActivity;
    private static final int REQUEST_CODE_TERMUX_PERMISSION = 0x4C52;
    private volatile String expectedToken;
    private volatile Boolean localBuild;
    private volatile boolean localPageActive;

    TermuxBridge(Context context, Activity activity) {
        this.context = context.getApplicationContext();
        this.hostActivity = new WeakReference<>(activity);
    }

    // Updated by TermuxFactory on the Android main thread; JS bridge calls run on another thread.
    void setLocalPageActive(boolean active) {
        this.localPageActive = active;
    }

    private JSONObject result(boolean ok) {
        JSONObject o = new JSONObject();
        try { o.put("ok", ok); } catch (Exception ignored) { }
        return o;
    }

    private String fail(String message) {
        JSONObject o = result(false);
        try { o.put("error", message == null ? "operation_failed" : message); }
        catch (Exception ignored) { }
        return o.toString();
    }

    private String success(String key, Object value) {
        JSONObject o = result(true);
        try { o.put(key, value); } catch (Exception ignored) { }
        return o.toString();
    }

    private String loadExpectedToken() {
        if (expectedToken != null) return expectedToken;
        synchronized (this) {
            if (expectedToken != null) return expectedToken;
            String value = "";
            try (InputStream in = context.getAssets().open("www/.termux-bridge-token")) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[128]; int n;
                while ((n = in.read(buf)) > 0 && out.size() < 512) out.write(buf, 0, n);
                value = new String(out.toByteArray(), StandardCharsets.UTF_8).trim();
            } catch (Exception ignored) { }
            expectedToken = value;
            return value;
        }
    }

    private boolean isLocalBuild() {
        if (localBuild != null) return localBuild.booleanValue();
        boolean local = false;
        try (InputStream in = context.getAssets().open("www/config.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[512]; int n;
            while ((n = in.read(buf)) > 0 && out.size() < 16384) out.write(buf, 0, n);
            JSONObject cfg = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
            local = "local".equals(cfg.optString("mode", ""));
        } catch (Exception ignored) { }
        localBuild = Boolean.valueOf(local);
        return local;
    }

    private boolean authorized(String token) {
        String expected = loadExpectedToken();
        if (expected.length() < 32 || token == null || token.length() != expected.length()) return false;
        int diff = 0;
        for (int i = 0; i < expected.length(); i++) diff |= expected.charAt(i) ^ token.charAt(i);
        return diff == 0 && isLocalBuild() && localPageActive;
    }

    private File root() throws Exception {
        File r = new File(context.getFilesDir(), "webterm").getCanonicalFile();
        if (!r.exists() && !r.mkdirs()) throw new Exception("cannot_create_sandbox");
        return r;
    }

    private File resolve(String relativePath) throws Exception {
        String p = relativePath == null ? "" : relativePath.trim();
        if (p.length() > 512) throw new Exception("path_too_long");
        if (p.startsWith("/") || p.indexOf('\\') >= 0 || p.indexOf('\0') >= 0) throw new Exception("invalid_relative_path");
        File root = root();
        if (p.isEmpty()) return root;
        String[] parts = p.split("/", -1);
        for (String part : parts) {
            if (part.isEmpty() || ".".equals(part) || "..".equals(part)) throw new Exception("invalid_path_segment");
            if (part.length() > 100) throw new Exception("path_segment_too_long");
        }
        File target = new File(root, p).getCanonicalFile();
        String prefix = root.getPath() + File.separator;
        if (!target.getPath().startsWith(prefix)) throw new Exception("path_outside_sandbox");
        return target;
    }

    @JavascriptInterface public String getDeviceInfo(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            JSONObject d = new JSONObject();
            d.put("manufacturer", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER);
            d.put("brand", Build.BRAND == null ? "" : Build.BRAND);
            d.put("model", Build.MODEL == null ? "" : Build.MODEL);
            d.put("androidRelease", Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE);
            d.put("sdkInt", Build.VERSION.SDK_INT);
            d.put("bridgeVersion", "1.3.0");
            return success("device", d).toString();
        } catch (Exception e) { return fail("device_info_failed"); }
    }

    @JavascriptInterface public String getStorageInfo(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            StatFs s = new StatFs(context.getFilesDir().getAbsolutePath());
            JSONObject d = new JSONObject();
            d.put("sandbox", "app-private/webterm");
            d.put("totalBytes", s.getTotalBytes());
            d.put("availableBytes", s.getAvailableBytes());
            d.put("usedBytes", Math.max(0L, s.getTotalBytes() - s.getAvailableBytes()));
            d.put("note", "Filesystem statistics are for the app data volume, not all device RAM/storage.");
            return success("storage", d).toString();
        } catch (Exception e) { return fail("storage_info_failed"); }
    }

    @JavascriptInterface public String listFiles(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File dir = resolve(relativePath);
            if (!dir.isDirectory()) return fail("not_a_directory");
            File[] files = dir.listFiles();
            if (files == null) files = new File[0];
            Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            JSONArray rows = new JSONArray();
            for (int i = 0; i < files.length && i < MAX_LIST_ITEMS; i++) {
                File f = files[i]; JSONObject item = new JSONObject();
                item.put("name", f.getName()); item.put("type", f.isDirectory() ? "dir" : "file");
                item.put("size", f.isFile() ? f.length() : 0L); rows.put(item);
            }
            JSONObject o = result(true); o.put("path", relativePath == null ? "" : relativePath); o.put("entries", rows);
            if (files.length > MAX_LIST_ITEMS) o.put("truncated", true);
            return o.toString();
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String readTextFile(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File f = resolve(relativePath);
            if (!f.isFile()) return fail("not_a_file");
            if (f.length() > MAX_TEXT_BYTES) return fail("file_too_large_max_1MiB");
            try (InputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) {
                    if (out.size() + n > MAX_TEXT_BYTES) return fail("file_too_large_max_1MiB");
                    out.write(buf, 0, n);
                }
                JSONObject o = result(true); o.put("content", new String(out.toByteArray(), StandardCharsets.UTF_8));
                o.put("size", out.size()); return o.toString();
            }
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String writeTextFile(String token, String relativePath, String content) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            if (content == null) content = "";
            byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_TEXT_BYTES) return fail("content_too_large_max_1MiB");
            File f = resolve(relativePath);
            if (f.equals(root())) return fail("path_is_directory");
            File parent = f.getParentFile();
            if (parent == null || !parent.isDirectory()) return fail("parent_directory_missing");
            try (FileOutputStream out = new FileOutputStream(f, false)) { out.write(bytes); out.flush(); }
            JSONObject o = result(true); o.put("path", relativePath); o.put("bytesWritten", bytes.length); return o.toString();
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String makeDirectory(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File f = resolve(relativePath);
            if (f.equals(root())) return fail("root_already_exists");
            if (f.exists()) return fail("already_exists");
            if (!f.mkdirs()) return fail("mkdir_failed");
            return success("path", relativePath);
        } catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String deleteFile(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            File f = resolve(relativePath);
            if (f.equals(root())) return fail("cannot_delete_sandbox_root");
            if (!f.exists()) return fail("not_found");
            if (f.isDirectory()) {
                String[] children = f.list();
                if (children != null && children.length != 0) return fail("directory_not_empty");
            }
            if (!f.delete()) return fail("delete_failed");
            return success("deleted", relativePath);
        } catch (Exception e) { return fail(e.getMessage()); }
    }


    private static final class SharedDocument {
        final String id;
        final String name;
        final String mimeType;
        final long size;
        SharedDocument(String id, String name, String mimeType, long size) {
            this.id = id; this.name = name; this.mimeType = mimeType; this.size = size;
        }
        boolean isDirectory() { return MIME_DIRECTORY.equals(mimeType); }
    }

    private SharedPreferences bridgePrefs() {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private Uri selectedTreeUri(boolean requireWrite) throws Exception {
        String saved = bridgePrefs().getString(PREF_TREE_URI, "");
        if (saved == null || saved.isEmpty()) throw new Exception("no_shared_folder_selected_run_android-folder-pick");
        Uri uri = Uri.parse(saved);
        if (!"content".equals(uri.getScheme())) throw new Exception("invalid_shared_folder_uri");
        boolean read = false, write = false;
        for (UriPermission p : context.getContentResolver().getPersistedUriPermissions()) {
            if (uri.equals(p.getUri())) { read = p.isReadPermission(); write = p.isWritePermission(); break; }
        }
        if (!read) throw new Exception("shared_folder_read_permission_missing_reselect_folder");
        if (requireWrite && !write) throw new Exception("shared_folder_is_read_only_reselect_folder_with_write_access");
        return uri;
    }

    private static String[] sharedPathParts(String relativePath, boolean allowRoot) throws Exception {
        String p = relativePath == null ? "" : relativePath.trim();
        if (p.length() > 512) throw new Exception("path_too_long");
        if (p.isEmpty()) {
            if (allowRoot) return new String[0];
            throw new Exception("path_required");
        }
        if (p.startsWith("/") || p.indexOf('\\') >= 0 || p.indexOf('\0') >= 0) throw new Exception("invalid_relative_path");
        String[] parts = p.split("/", -1);
        for (String part : parts) {
            if (part.isEmpty() || ".".equals(part) || "..".equals(part)) throw new Exception("invalid_path_segment");
            if (part.length() > 100) throw new Exception("path_segment_too_long");
        }
        return parts;
    }

    private SharedDocument findSharedChild(Uri tree, String parentId, String name) throws Exception {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        try (Cursor c = context.getContentResolver().query(children, DOCUMENT_PROJECTION, null, null, null)) {
            if (c == null) throw new Exception("shared_folder_list_failed");
            while (c.moveToNext()) {
                String childName = c.isNull(1) ? "" : c.getString(1);
                if (!name.equals(childName)) continue;
                String id = c.getString(0);
                String mime = c.isNull(2) ? "" : c.getString(2);
                long size = c.isNull(3) ? 0L : Math.max(0L, c.getLong(3));
                return new SharedDocument(id, childName, mime, size);
            }
        } catch (SecurityException e) { throw new Exception("shared_folder_permission_denied"); }
        return null;
    }

    private SharedDocument resolveSharedDocument(Uri tree, String relativePath, boolean allowRoot) throws Exception {
        String[] parts = sharedPathParts(relativePath, allowRoot);
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        SharedDocument current = new SharedDocument(rootId, "", MIME_DIRECTORY, 0L);
        for (String part : parts) {
            if (!current.isDirectory()) throw new Exception("not_a_directory");
            SharedDocument child = findSharedChild(tree, current.id, part);
            if (child == null) throw new Exception("shared_file_not_found");
            current = child;
        }
        return current;
    }

    private Uri sharedDocumentUri(Uri tree, SharedDocument document) {
        return DocumentsContract.buildDocumentUriUsingTree(tree, document.id);
    }

    @JavascriptInterface public String pickSharedFolder(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            Intent i = new Intent(context, BridgePickerActivity.class);
            i.setAction(BridgePickerActivity.ACTION_PICK_FOLDER);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return success("started", true);
        } catch (Exception e) { return fail("folder_picker_unavailable"); }
    }

    @JavascriptInterface public String sharedFolderStatus(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            Uri tree = selectedTreeUri(false);
            boolean write = false;
            for (UriPermission p : context.getContentResolver().getPersistedUriPermissions()) {
                if (tree.equals(p.getUri())) { write = p.isWritePermission(); break; }
            }
            String folderName = DocumentsContract.getTreeDocumentId(tree);
            try (Cursor c = context.getContentResolver().query(sharedDocumentUri(tree,
                    new SharedDocument(DocumentsContract.getTreeDocumentId(tree), "", MIME_DIRECTORY, 0L)),
                    new String[] { DocumentsContract.Document.COLUMN_DISPLAY_NAME }, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0) && !c.getString(0).isEmpty()) folderName = c.getString(0);
            } catch (Exception ignored) { }
            JSONObject o = result(true); o.put("selected", true); o.put("folderName", folderName); o.put("writeAllowed", write);
            return o.toString();
        } catch (Exception e) {
            JSONObject o = result(true); try { o.put("selected", false); o.put("status", bridgePrefs().getString(PREF_PICK_STATUS, "not_selected")); }
            catch (Exception ignored) { }
            return o.toString();
        }
    }

    @JavascriptInterface public String listSharedFolderFiles(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            Uri tree = selectedTreeUri(false);
            SharedDocument dir = resolveSharedDocument(tree, relativePath, true);
            if (!dir.isDirectory()) return fail("not_a_directory");
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dir.id);
            JSONArray rows = new JSONArray(); int count = 0; boolean truncated = false;
            try (Cursor c = context.getContentResolver().query(children, DOCUMENT_PROJECTION, null, null, null)) {
                if (c == null) return fail("shared_folder_list_failed");
                while (c.moveToNext()) {
                    if (count >= MAX_LIST_ITEMS) { truncated = true; break; }
                    String id = c.getString(0);
                    String name = c.isNull(1) ? "" : c.getString(1);
                    String mime = c.isNull(2) ? "" : c.getString(2);
                    long size = c.isNull(3) ? 0L : Math.max(0L, c.getLong(3));
                    JSONObject item = new JSONObject();
                    item.put("name", name); item.put("type", MIME_DIRECTORY.equals(mime) ? "dir" : "file");
                    item.put("size", size); rows.put(item); count++;
                }
            }
            JSONObject o = result(true); o.put("path", relativePath == null ? "" : relativePath); o.put("entries", rows);
            if (truncated) o.put("truncated", true);
            return o.toString();
        } catch (SecurityException e) { return fail("shared_folder_permission_denied"); }
        catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String readSharedTextFile(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            Uri tree = selectedTreeUri(false);
            SharedDocument doc = resolveSharedDocument(tree, relativePath, false);
            if (doc.isDirectory()) return fail("not_a_file");
            if (doc.size > MAX_TEXT_BYTES) return fail("file_too_large_max_1MiB");
            try (InputStream in = context.getContentResolver().openInputStream(sharedDocumentUri(tree, doc));
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                if (in == null) return fail("cannot_open_shared_file");
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) {
                    if (out.size() + n > MAX_TEXT_BYTES) return fail("file_too_large_max_1MiB");
                    out.write(buf, 0, n);
                }
                JSONObject o = result(true); o.put("path", relativePath); o.put("content", new String(out.toByteArray(), StandardCharsets.UTF_8));
                o.put("size", out.size()); return o.toString();
            }
        } catch (SecurityException e) { return fail("shared_folder_permission_denied"); }
        catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String writeSharedTextFile(String token, String relativePath, String content) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            Uri tree = selectedTreeUri(true);
            if (content == null) content = "";
            byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_TEXT_BYTES) return fail("content_too_large_max_1MiB");
            String[] parts = sharedPathParts(relativePath, false);
            String name = parts[parts.length - 1];
            StringBuilder parentPath = new StringBuilder();
            for (int i = 0; i < parts.length - 1; i++) { if (parentPath.length() > 0) parentPath.append('/'); parentPath.append(parts[i]); }
            SharedDocument parent = resolveSharedDocument(tree, parentPath.toString(), true);
            if (!parent.isDirectory()) return fail("parent_not_a_directory");
            SharedDocument existing = findSharedChild(tree, parent.id, name);
            Uri target;
            if (existing != null) {
                if (existing.isDirectory()) return fail("path_is_directory");
                target = sharedDocumentUri(tree, existing);
            } else {
                target = DocumentsContract.createDocument(context.getContentResolver(), sharedDocumentUri(tree, parent), "text/plain", name);
                if (target == null) return fail("create_shared_file_failed");
            }
            try (java.io.OutputStream out = context.getContentResolver().openOutputStream(target, "wt")) {
                if (out == null) return fail("cannot_open_shared_file_for_write");
                out.write(bytes); out.flush();
            }
            JSONObject o = result(true); o.put("path", relativePath); o.put("bytesWritten", bytes.length); return o.toString();
        } catch (SecurityException e) { return fail("shared_folder_write_permission_denied"); }
        catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String makeSharedDirectory(String token, String relativePath) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            Uri tree = selectedTreeUri(true);
            String[] parts = sharedPathParts(relativePath, false);
            String name = parts[parts.length - 1];
            StringBuilder parentPath = new StringBuilder();
            for (int i = 0; i < parts.length - 1; i++) { if (parentPath.length() > 0) parentPath.append('/'); parentPath.append(parts[i]); }
            SharedDocument parent = resolveSharedDocument(tree, parentPath.toString(), true);
            if (!parent.isDirectory()) return fail("parent_not_a_directory");
            if (findSharedChild(tree, parent.id, name) != null) return fail("already_exists");
            Uri created = DocumentsContract.createDocument(context.getContentResolver(), sharedDocumentUri(tree, parent), MIME_DIRECTORY, name);
            if (created == null) return fail("mkdir_failed");
            return success("path", relativePath);
        } catch (SecurityException e) { return fail("shared_folder_write_permission_denied"); }
        catch (Exception e) { return fail(e.getMessage()); }
    }

    @JavascriptInterface public String networkStatus(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            JSONObject n = new JSONObject();
            n.put("connected", ni != null && ni.isConnected());
            n.put("type", ni == null ? "none" : (ni.getTypeName() == null ? "unknown" : ni.getTypeName()));
            return success("network", n).toString();
        } catch (Exception e) { return fail("network_status_failed"); }
    }

    /**
     * Runs one of a short list of read-only Android diagnostics. The command
     * name is looked up in a fixed table; no shell is invoked and no extra
     * arguments from JavaScript are accepted. Output is capped and execution
     * is time-limited so a terminal page cannot create a general command runner.
     */
    private static String[] diagnosticArgv(String name) {
        switch (name) {
            case "id": return new String[] { "/system/bin/toybox", "id" };
            case "uname": return new String[] { "/system/bin/toybox", "uname", "-a" };
            case "date": return new String[] { "/system/bin/toybox", "date" };
            case "uptime": return new String[] { "/system/bin/toybox", "uptime" };
            case "df": return new String[] { "/system/bin/toybox", "df", "-h", "/data" };
            case "ps": return new String[] { "/system/bin/toybox", "ps", "-A" };
            case "model": return new String[] { "/system/bin/getprop", "ro.product.model" };
            case "android-version": return new String[] { "/system/bin/getprop", "ro.build.version.release" };
            case "sdk": return new String[] { "/system/bin/getprop", "ro.build.version.sdk" };
            default: return null;
        }
    }

    private static final class ProcessCapture implements Runnable {
        private final InputStream input;
        private final ByteArrayOutputStream output = new ByteArrayOutputStream();
        private volatile boolean truncated;
        private final int limit;
        ProcessCapture(InputStream input, int limit) { this.input = input; this.limit = limit; }
        @Override public void run() {
            byte[] buffer = new byte[4096];
            try {
                int n;
                while ((n = input.read(buffer)) != -1) {
                    int remaining = limit - output.size();
                    if (remaining > 0) {
                        int keep = Math.min(remaining, n);
                        output.write(buffer, 0, keep);
                        if (keep < n) truncated = true;
                    } else if (n > 0) {
                        truncated = true;
                    }
                    // Continue draining even after the cap, so the child process cannot block.
                }
            } catch (Exception ignored) { }
            finally { try { input.close(); } catch (Exception ignored) { } }
        }
        String text() { return new String(output.toByteArray(), StandardCharsets.UTF_8); }
        boolean wasTruncated() { return truncated; }
    }



    /**
     * Ask Android to show the runtime permission dialog for Termux RUN_COMMAND.
     * Merely declaring the permission in AndroidManifest.xml does not show a dialog;
     * the user must explicitly approve it. This is invoked only from the trusted
     * bundled Lira Terminal page after the user attempts to run a command.
     */
    @JavascriptInterface public String requestTermuxPermission(String token) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        if (Build.VERSION.SDK_INT < 23) return success("granted", true);
        try {
            if (context.checkSelfPermission("com.termux.permission.RUN_COMMAND") == PackageManager.PERMISSION_GRANTED)
                return success("granted", true);
        } catch (Exception e) {
            return fail("permission_check_failed_" + e.getClass().getSimpleName());
        }
        final Activity activity = hostActivity.get();
        if (activity == null || activity.isFinishing() || activity.isDestroyed())
            return fail("activity_unavailable_for_permission_prompt");
        activity.runOnUiThread(() -> {
            try {
                if (!activity.isFinishing() && !activity.isDestroyed() &&
                    context.checkSelfPermission("com.termux.permission.RUN_COMMAND") != PackageManager.PERMISSION_GRANTED) {
                    activity.requestPermissions(
                        new String[] { "com.termux.permission.RUN_COMMAND" },
                        REQUEST_CODE_TERMUX_PERMISSION
                    );
                }
            } catch (Throwable ignored) { }
        });
        JSONObject o = result(true);
        try { o.put("requested", true); } catch (Exception ignored) { }
        return o.toString();
    }

    /**
     * Runs a user-entered Termux command through Termux RUN_COMMAND.
     * The JS caller is authorized only for the bundled, token-gated local page.
     * Output is written to the user-selected Download/LiraAI folder so the UI can
     * read it through the existing SAF tree grant. Commands run as the Termux user,
     * not as root; the interface is intentionally a terminal, so commands are user-supplied.
     */
    @JavascriptInterface public String runTermuxCommand(String token, String command) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        String cmd = command == null ? "" : command.trim();
        if (cmd.isEmpty()) return fail("empty_command");
        if (cmd.length() > 4096) return fail("command_too_long_max_4096_chars");
        if (cmd.indexOf('\0') >= 0) return fail("invalid_command");
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                if (context.checkSelfPermission("com.termux.permission.RUN_COMMAND") != PackageManager.PERMISSION_GRANTED)
                    return fail("grant_Run_commands_in_Termux_environment_permission_to_Lira_Terminal_in_Android_settings");
            } catch (Exception ignored) { }
        }
        String script =
                "set +e\n" +
                "BASE=\"$HOME/storage/downloads/LiraAI\"\n" +
                "mkdir -p \"$BASE/terminal\" \"$BASE/backups\" \"$BASE/models\" \"$BASE/corpus\" || exit 73\n" +
                "OUT=\"$BASE/terminal/last-output.txt\"\n" +
                "STATE=\"$BASE/terminal/status.json\"\n" +
                "PWD_FILE=\"$BASE/terminal/cwd.txt\"\n" +
                "CMD=\"$1\"\n" +
                "PREV_CWD=\"$(cat \"$PWD_FILE\" 2>/dev/null)\"\n" +
                "if [ -n \"$PREV_CWD\" ] && [ -d \"$PREV_CWD\" ]; then cd \"$PREV_CWD\"; else cd \"$HOME\"; fi\n" +
                "printf '{\"running\":true,\"started\":\"%s\"}\\n' \"$(date)\" > \"$STATE\"\n" +
                "{ printf '$ %s\\n' \"$CMD\"; eval \"$CMD\"; RC=$?; printf '\\n[exit=%s]\\n' \"$RC\"; } > \"$OUT\" 2>&1\n" +
                "printf '%s\\n' \"$PWD\" > \"$PWD_FILE\"\n" +
                "printf '{\"running\":false,\"exit_code\":%s,\"finished\":\"%s\"}\\n' \"$RC\" \"$(date)\" > \"$STATE\"\n" +
                "exit 0\n";
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.termux", "com.termux.app.RunCommandService"));
            intent.setAction("com.termux.RUN_COMMAND");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[] { "-lc", script, "lira-terminal", cmd });
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            intent.putExtra("com.termux.RUN_COMMAND_LABEL", "Lira Terminal");
            intent.putExtra("com.termux.RUN_COMMAND_DESCRIPTION", "Runs a command typed in the local Lira Terminal interface.");
            context.startService(intent);
            JSONObject o = result(true);
            o.put("accepted", true);
            o.put("commandLength", cmd.length());
            o.put("output", "Download/LiraAI/terminal/last-output.txt");
            return o.toString();
        } catch (SecurityException e) {
            return fail("termux_permission_denied_enable_RUN_COMMAND_and_allow_external_apps");
        } catch (Exception e) {
            return fail("termux_run_command_failed_" + e.getClass().getSimpleName());
        }
    }

    @JavascriptInterface public String runDiagnosticCommand(String token, String commandName) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        String name = commandName == null ? "" : commandName.trim().toLowerCase(Locale.ROOT);
        String[] argv = diagnosticArgv(name);
        if (argv == null) return fail("unsupported_diagnostic_command_use_android_run_help");
        Process process = null;
        try {
            // Use an argv vector, never /system/bin/sh -c, and keep cwd inside the app sandbox.
            ProcessBuilder builder = new ProcessBuilder(argv);
            builder.directory(root());
            builder.redirectErrorStream(false);
            process = builder.start();
            final Process child = process;
            ProcessCapture stdout = new ProcessCapture(child.getInputStream(), MAX_PROCESS_OUTPUT_BYTES);
            ProcessCapture stderr = new ProcessCapture(child.getErrorStream(), MAX_PROCESS_OUTPUT_BYTES);
            Thread stdoutThread = new Thread(stdout, "WebTerm-process-stdout");
            Thread stderrThread = new Thread(stderr, "WebTerm-process-stderr");
            stdoutThread.setDaemon(true);
            stderrThread.setDaemon(true);
            stdoutThread.start();
            stderrThread.start();

            boolean finished = child.waitFor(PROCESS_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            if (!finished) {
                child.destroy();
                if (!child.waitFor(200L, TimeUnit.MILLISECONDS)) child.destroyForcibly();
            }
            int exitCode = child.isAlive() ? -1 : child.exitValue();
            stdoutThread.join(500L);
            stderrThread.join(500L);

            JSONObject result = result(true);
            result.put("command", name);
            result.put("stdout", stdout.text());
            result.put("stderr", stderr.text());
            result.put("exitCode", exitCode);
            result.put("timedOut", !finished);
            result.put("stdoutTruncated", stdout.wasTruncated());
            result.put("stderrTruncated", stderr.wasTruncated());
            result.put("execution", "fixed-argv-allowlist");
            return result.toString();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (process != null) process.destroy();
            return fail("process_interrupted");
        } catch (Exception e) {
            if (process != null) process.destroy();
            return fail("process_start_failed_" + e.getClass().getSimpleName());
        }
    }

    /**
     * Executes one command string using the GNU Bash executable embedded in the APK
     * as lib/arm64-v8a/libbash.so. This is intentionally a one-shot shell process:
     * environment variables and cd state do not persist between calls. Access is
     * still gated by the same unguessable token and trusted local-WebView check.
     * The actual Bash program must be packaged inside the APK (nativeLibraryDir),
     * not downloaded/executed from a writable app-data directory, due to Android
     * W^X restrictions on modern target SDKs.
     */
    @JavascriptInterface public String runBashCommand(String token, String commandText) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        if (commandText == null) return fail("bash_command_required");
        String command = commandText.trim();
        if (command.isEmpty()) return fail("bash_command_required");
        if (command.length() > MAX_BASH_COMMAND_CHARS) return fail("bash_command_too_long_max_4096_chars");
        if (command.indexOf('\0') >= 0) return fail("bash_command_contains_nul");

        File binary = new File(context.getApplicationInfo().nativeLibraryDir, "libbash.so");
        if (!binary.isFile()) return fail("bash_runtime_missing_rebuild_apk_with_libbash.so_arm64");

        Process process = null;
        try {
            File sandbox = root();
            File home = new File(sandbox, "home/guest");
            File tmp = new File(sandbox, "tmp");
            if (!home.isDirectory() && !home.mkdirs()) return fail("bash_home_create_failed");
            if (!tmp.isDirectory() && !tmp.mkdirs()) return fail("bash_tmp_create_failed");

            ProcessBuilder builder = new ProcessBuilder(binary.getAbsolutePath(), "--noprofile", "--norc", "-c", command);
            builder.directory(home);
            builder.redirectErrorStream(false);
            java.util.Map<String, String> env = builder.environment();
            env.put("HOME", home.getAbsolutePath());
            env.put("TMPDIR", tmp.getAbsolutePath());
            env.put("PWD", home.getAbsolutePath());
            env.put("PATH", "/system/bin:/system/xbin");
            env.put("TERM", "dumb");
            env.put("LANG", "C");
            env.remove("BASH_ENV");
            env.remove("ENV");
            process = builder.start();

            final Process child = process;
            ProcessCapture stdout = new ProcessCapture(child.getInputStream(), MAX_BASH_OUTPUT_BYTES);
            ProcessCapture stderr = new ProcessCapture(child.getErrorStream(), MAX_BASH_OUTPUT_BYTES);
            Thread stdoutThread = new Thread(stdout, "WebTerm-bash-stdout");
            Thread stderrThread = new Thread(stderr, "WebTerm-bash-stderr");
            stdoutThread.setDaemon(true);
            stderrThread.setDaemon(true);
            stdoutThread.start();
            stderrThread.start();

            boolean finished = child.waitFor(BASH_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            if (!finished) {
                child.destroy();
                if (!child.waitFor(200L, TimeUnit.MILLISECONDS)) child.destroyForcibly();
            }
            int exitCode = child.isAlive() ? -1 : child.exitValue();
            stdoutThread.join(700L);
            stderrThread.join(700L);

            JSONObject o = result(true);
            o.put("shell", "GNU Bash (one-shot)");
            o.put("stdout", stdout.text());
            o.put("stderr", stderr.text());
            o.put("exitCode", exitCode);
            o.put("timedOut", !finished);
            o.put("stdoutTruncated", stdout.wasTruncated());
            o.put("stderrTruncated", stderr.wasTruncated());
            o.put("workingDirectory", home.getAbsolutePath());
            return o.toString();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (process != null) process.destroy();
            return fail("bash_process_interrupted");
        } catch (Exception e) {
            if (process != null) process.destroy();
            return fail("bash_process_start_failed_" + e.getClass().getSimpleName());
        }
    }

    @JavascriptInterface public String shareText(String token, final String text) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        if (text == null || text.length() > 20000) return fail("text_too_long_max_20000_chars");
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, text);
                Intent chooser = Intent.createChooser(send, "Поделиться текстом");
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(chooser);
            } catch (Exception ignored) { }
        });
        return success("queued", true);
    }

    @JavascriptInterface public String vibrate(String token, int millis) {
        if (!authorized(token)) return fail("bridge_denied_or_remote_page");
        int duration = Math.max(0, Math.min(500, millis));
        try {
            Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return fail("vibrator_unavailable");
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(duration);
            return success("durationMs", duration);
        } catch (Exception e) { return fail("vibration_failed"); }
    }
}

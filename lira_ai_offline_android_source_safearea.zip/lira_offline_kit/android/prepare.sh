#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d "vendor/llama.cpp/.git" ]; then
  mkdir -p vendor
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git vendor/llama.cpp
fi
if [ ! -f "vendor/llama.cpp/examples/llama.android/gradle/libs.versions.toml" ]; then
  echo "Не найден официальный Android-модуль llama.cpp. Проверьте клонирование репозитория." >&2
  exit 1
fi
# Reuse the Gradle Wrapper distributed with the official Android example.
UPSTREAM="vendor/llama.cpp/examples/llama.android"
if [ -f "$UPSTREAM/gradlew" ] && [ -d "$UPSTREAM/gradle/wrapper" ]; then
  cp "$UPSTREAM/gradlew" ./gradlew
  cp "$UPSTREAM/gradlew.bat" ./gradlew.bat 2>/dev/null || true
  mkdir -p ./gradle
  rm -rf ./gradle/wrapper
  cp -R "$UPSTREAM/gradle/wrapper" ./gradle/wrapper
  chmod +x ./gradlew
else
  echo "Предупреждение: Gradle Wrapper не найден в upstream-проекте. Откройте проект через Android Studio и проверьте настройки Gradle." >&2
fi
mkdir -p app/src/main/assets/www
cp ../web/index.html app/src/main/assets/www/index.html
printf '\nПодготовка завершена. Откройте эту папку в Android Studio или выполните ./gradlew assembleDebug.\n'

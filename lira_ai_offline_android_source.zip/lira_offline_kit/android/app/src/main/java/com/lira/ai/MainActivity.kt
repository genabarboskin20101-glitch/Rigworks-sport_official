package com.lira.ai

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadataReader
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Native Android host for the existing Lira web interface.
 * The inference implementation comes from the upstream llama.cpp Android example module.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val engineDeferred = CompletableDeferred<InferenceEngine>()
    private val engineLock = Mutex()
    private val downloadLock = Mutex()
    private val preferences by lazy { getSharedPreferences("lira-offline", MODE_PRIVATE) }

    @Volatile private var engineInstance: InferenceEngine? = null
    @Volatile private var selectedModel: File? = null
    @Volatile private var engineError: String? = null
    @Volatile private var pageFinished = false
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importAndLoadModel(uri)
    }

    private val attachmentPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        fileChooserCallback?.onReceiveValue(uris.toTypedArray())
        fileChooserCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.addJavascriptInterface(this, "LiraNativeBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return true
                // Only bundled app assets can execute in this WebView; this protects the JS bridge.
                return !url.startsWith("file:///android_asset/")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageFinished = true
                notifyStatus()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                attachmentPicker.launch(arrayOf("*/*"))
                return true
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/www/index.html")
        startInferenceEngine()
    }

    private fun startInferenceEngine() {
        ioScope.launch {
            try {
                val engine = AiChat.getInferenceEngine(applicationContext)
                val state = engine.state.first {
                    it is InferenceEngine.State.Initialized || it is InferenceEngine.State.ModelReady || it is InferenceEngine.State.Error
                }
                if (state is InferenceEngine.State.Error) throw state.exception
                engineInstance = engine
                engineDeferred.complete(engine)

                val savedPath = preferences.getString(KEY_MODEL_PATH, null)
                val savedFile = savedPath?.let(::File)?.takeIf { it.isFile && it.canRead() }
                if (savedFile != null) {
                    selectedModel = savedFile
                    try {
                        engineLock.withLock { prepareModel(engine, savedFile, DEFAULT_SYSTEM_PROMPT) }
                    } catch (t: Throwable) {
                        engineError = "Не удалось загрузить модель: ${t.message ?: t.javaClass.simpleName}"
                    }
                }
                notifyStatus()
            } catch (t: Throwable) {
                engineError = t.message ?: t.javaClass.simpleName
                if (!engineDeferred.isCompleted) engineDeferred.completeExceptionally(t)
                notifyStatus()
            }
        }
    }

    private suspend fun prepareModel(engine: InferenceEngine, model: File, systemPrompt: String) {
        when (engine.state.value) {
            is InferenceEngine.State.ModelReady,
            is InferenceEngine.State.Error -> engine.cleanUp()
            else -> Unit
        }
        engine.loadModel(model.absolutePath)
        engine.setSystemPrompt(systemPrompt.ifBlank { DEFAULT_SYSTEM_PROMPT })
        engineError = null
    }

    private fun importAndLoadModel(uri: Uri) {
        ioScope.launch {
            try {
                val engine = engineDeferred.await()
                engineLock.withLock {
                    // Validate the selected file before copying it into the private app folder.
                    contentResolver.openInputStream(uri)?.use { input ->
                        GgufMetadataReader.create().readStructuredMetadata(input)
                    } ?: throw IllegalArgumentException("Не удалось прочитать файл модели")

                    val displayName = queryDisplayName(uri)
                    val safeName = displayName
                        .substringAfterLast('/')
                        .replace(Regex("[^A-Za-z0-9._-]"), "_")
                        .let { if (it.endsWith(".gguf", ignoreCase = true)) it else "$it.gguf" }
                    val directory = File(filesDir, "models").apply { mkdirs() }
                    val target = File(directory, "model_${System.currentTimeMillis()}_$safeName")
                    contentResolver.openInputStream(uri)?.use { source ->
                        FileOutputStream(target).use { destination -> source.copyTo(destination) }
                    } ?: throw IllegalArgumentException("Не удалось скопировать модель")

                    prepareModel(engine, target, DEFAULT_SYSTEM_PROMPT)
                    selectedModel = target
                    preferences.edit().putString(KEY_MODEL_PATH, target.absolutePath).apply()
                    notifyStatus()
                    showToast("Модель загружена: ${target.name}")
                }
            } catch (t: Throwable) {
                engineError = t.message ?: t.javaClass.simpleName
                notifyStatus()
                showToast("Ошибка импорта модели: ${engineError}")
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index) ?: "model.gguf"
            }
        }
        return "model.gguf"
    }

    /** Called by the HTML settings screen. Returns JSON synchronously. */
    @JavascriptInterface
    fun getStatus(): String {
        val file = selectedModel
        val state = engineInstance?.state?.value
        val ready = state is InferenceEngine.State.ModelReady || state is InferenceEngine.State.Generating
        return JSONObject()
            .put("bridge", true)
            .put("engineInitialized", engineDeferred.isCompleted && !engineDeferred.isCancelled)
            .put("modelConfigured", file?.isFile == true)
            .put("modelReady", ready)
            .put("modelName", file?.let(::friendlyModelName) ?: "")
            .put("error", engineError ?: "")
            .toString()
    }

    @JavascriptInterface
    fun chooseModel() {
        runOnUiThread { modelPicker.launch(arrayOf("*/*")) }
    }

    /** Download a public model from a direct HTTPS file URL. Chat generation itself is local. */
    @JavascriptInterface
    fun downloadModel(urlText: String) {
        val parsed = Uri.parse(urlText.trim())
        if (!parsed.scheme.equals("https", ignoreCase = true) || parsed.host.isNullOrBlank()) {
            callJs("onDownloadError", "Укажи прямую HTTPS-ссылку на файл модели")
            return
        }
        ioScope.launch {
            try {
                downloadLock.withLock {
                    callJs("onDownloadProgress", "-1", "0", "0")
                    val downloadedFile = downloadHttpsModel(urlText.trim())
                    try {
                        FileInputStream(downloadedFile).use { input ->
                            GgufMetadataReader.create().readStructuredMetadata(input)
                        }
                    } catch (t: Throwable) {
                        downloadedFile.delete()
                        throw IllegalArgumentException("Скачанный файл не распознан как совместимая GGUF-модель: ${t.message ?: "ошибка формата"}")
                    }
                    val engine = engineDeferred.await()
                    engineLock.withLock {
                        prepareModel(engine, downloadedFile, DEFAULT_SYSTEM_PROMPT)
                        selectedModel = downloadedFile
                        preferences.edit().putString(KEY_MODEL_PATH, downloadedFile.absolutePath).apply()
                    }
                    callJs("onDownloadDone", friendlyModelName(downloadedFile))
                    notifyStatus()
                    showToast("Модель скачана и готова к офлайн-работе")
                }
            } catch (t: Throwable) {
                callJs("onDownloadError", t.message ?: t.javaClass.simpleName)
            }
        }
    }

    private fun downloadHttpsModel(urlText: String): File {
        var current = URL(urlText)
        val rawName = Uri.parse(urlText).lastPathSegment?.let { Uri.decode(it) }.orEmpty().ifBlank { "model.gguf" }
        val safeName = rawName.substringAfterLast('/')
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .let { if (it.endsWith(".gguf", ignoreCase = true)) it else "$it.gguf" }
        val directory = File(filesDir, "models").apply { mkdirs() }
        val target = File(directory, "model_${System.currentTimeMillis()}_$safeName")
        val partial = File(directory, target.name + ".part")
        var succeeded = false
        try {
            for (redirect in 0..8) {
                if (!current.protocol.equals("https", ignoreCase = true)) {
                    throw IllegalArgumentException("Разрешены только HTTPS-ссылки и HTTPS-перенаправления")
                }
                val connection = (current.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 20_000
                    readTimeout = 30_000
                    setRequestProperty("User-Agent", "LiraAI-Offline/0.1")
                    setRequestProperty("Accept-Encoding", "identity")
                }
                val code = connection.responseCode
                if (code in 300..399) {
                    val location = connection.getHeaderField("Location")
                    connection.disconnect()
                    if (location.isNullOrBlank()) throw IllegalStateException("Сервер вернул перенаправление без адреса")
                    current = URL(current, location)
                    continue
                }
                if (code !in 200..299) {
                    val message = connection.responseMessage ?: "HTTP $code"
                    connection.disconnect()
                    throw IllegalStateException("Ошибка скачивания: HTTP $code ($message)")
                }
                val total = connection.contentLengthLong
                var downloaded = 0L
                var lastReport = 0L
                connection.inputStream.use { input ->
                    FileOutputStream(partial).use { output ->
                        val buffer = ByteArray(256 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count)
                            downloaded += count
                            val now = System.currentTimeMillis()
                            if (now - lastReport >= 200) {
                                val percent = if (total > 0L) (downloaded * 100.0 / total).coerceIn(0.0, 100.0) else -1.0
                                callJs("onDownloadProgress", String.format(java.util.Locale.US, "%.1f", percent), downloaded.toString(), total.toString())
                                lastReport = now
                            }
                        }
                    }
                }
                connection.disconnect()
                if (downloaded == 0L) throw IllegalStateException("Сервер вернул пустой файл")
                if (!partial.renameTo(target)) {
                    partial.copyTo(target, overwrite = true)
                    partial.delete()
                }
                succeeded = true
                callJs("onDownloadProgress", "100.0", downloaded.toString(), total.toString())
                return target
            }
            throw IllegalStateException("Слишком много перенаправлений")
        } finally {
            if (!succeeded) partial.delete()
        }
    }

    private fun friendlyModelName(file: File): String = file.name.replaceFirst(Regex("^model_[0-9]+_"), "")

    /** Receives the entire visible conversation; callbacks stream the answer back to JavaScript. */
    @JavascriptInterface
    fun generate(payload: String) {
        val request = try { JSONObject(payload) } catch (t: Throwable) {
            callJs("onError", "invalid-request", "Некорректный запрос: ${t.message}")
            return
        }
        val requestId = request.optString("requestId", "request-${System.currentTimeMillis()}")
        ioScope.launch {
            try {
                val engine = engineDeferred.await()
                engineLock.withLock {
                    val model = selectedModel?.takeIf { it.isFile && it.canRead() }
                        ?: throw IllegalStateException("Сначала выбери GGUF-модель в настройках Lira")
                    val systemPrompt = request.optString("systemPrompt", DEFAULT_SYSTEM_PROMPT)
                    val transcript = buildTranscript(request.optJSONArray("messages") ?: JSONArray())
                    val maxTokens = request.optInt("maxTokens", 1024).coerceIn(64, 4096)

                    // The upstream sample API exposes a single active conversation context. To keep
                    // separate Lira chats isolated, rebuild that context from this chat's transcript
                    // for each turn. This costs loading time, but avoids leaking one chat into another.
                    prepareModel(engine, model, systemPrompt)
                    engine.sendUserPrompt(transcript, maxTokens).collect { token ->
                        callJs("onToken", requestId, token)
                    }
                    callJs("onDone", requestId)
                }
            } catch (t: Throwable) {
                engineError = t.message ?: t.javaClass.simpleName
                callJs("onError", requestId, engineError ?: "Ошибка генерации")
            } finally {
                notifyStatus()
            }
        }
    }

    private fun buildTranscript(messages: JSONArray): String {
        val transcript = StringBuilder()
        transcript.append("Это история диалога с пользователем. Учитывай её и ответь на последнее сообщение пользователя. Не повторяй эту инструкцию.\n\n")
        var count = 0
        for (index in 0 until messages.length()) {
            val item = messages.optJSONObject(index) ?: continue
            val role = item.optString("role")
            if (role != "user" && role != "assistant") continue
            val content = item.optString("content").trim()
            if (content.isEmpty()) continue
            transcript.append(if (role == "user") "Пользователь: " else "Lira: ")
            transcript.append(content).append("\n\n")
            count++
        }
        if (count == 0) throw IllegalArgumentException("В сообщении нет текста для генерации")
        transcript.append("Ответь сейчас как Lira на последнее сообщение пользователя. Пиши прямо ответ, не пересказывай историю.")
        return transcript.toString()
    }

    private fun notifyStatus() {
        if (!pageFinished || !::webView.isInitialized) return
        val payload = getStatus()
        runOnUiThread {
            if (pageFinished) {
                webView.evaluateJavascript(
                    "if(window.LiraNativeCallbacks&&window.LiraNativeCallbacks.onStatus)window.LiraNativeCallbacks.onStatus($payload);",
                    null
                )
            }
        }
    }

    private fun callJs(functionName: String, vararg values: String) {
        val args = values.joinToString(",") { JSONObject.quote(it) }
        runOnUiThread {
            if (!pageFinished) return@runOnUiThread
            webView.evaluateJavascript(
                "if(window.LiraNativeCallbacks&&window.LiraNativeCallbacks.$functionName)window.LiraNativeCallbacks.$functionName($args);",
                null
            )
        }
    }

    private fun showToast(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        webView.stopLoading()
        webView.destroy()
        ioScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val KEY_MODEL_PATH = "model_path"
        private const val DEFAULT_SYSTEM_PROMPT = "Ты — Lira, полезный, честный и внимательный ИИ-ассистент. Отвечай по-русски, если пользователь пишет по-русски."
    }
}

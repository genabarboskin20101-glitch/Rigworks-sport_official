package kx.engine;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Base64;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;

/**
 * Нативный аудио-движок LMusic. Страница отдаёт ему файлы треков, а воспроизведение, кросс-фейд и эффекты считаются здесь,
 * в процессе приложения: поток микшера с приоритетом URGENT_AUDIO пишет в AudioTrack с большим буфером, а декодеры (MediaCodec)
 * заранее заполняют кольцевые буферы на несколько секунд. Процесс отрисовки WebView в этом не участвует, поэтому нагрузка на телефон
 * и «тормоза» страницы больше не рвут звук.
 *
 * Две «деки» (как два аудио-элемента страницы). Громкость каждой = vol * gain (две автоматизируемые кривые, как GainNode в Web Audio),
 * затем сумма -> цепочка эффектов (AudioDsp.Fx) -> AudioTrack.
 */
final class NativeAudio {
    interface Host {
        /** Выполнить JS в странице (из любого потока). */
        void js(String code);
    }

    private static final String TAG = "KXA";
    static final int OUT_RATE = 44100;
    private static final int BLOCK = 256;
    private static final double[] FREQS = {31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000};
    private static final long CACHE_LIMIT = 600L << 20;

    // ---------------------------------------------------------------------------------------- данные
    /** Кольцевой буфер декодированных кадров одного «отрезка» (после перемотки создаётся новый). */
    private static final class Seg {
        final float[] l, r;
        final int cap, rate;
        volatile long baseFrame;   // абсолютный номер кадра файла, лежащего в позиции 0
        volatile long wr;          // сколько кадров записано
        volatile long rd;          // сколько прочитано (для обратного давления)
        volatile boolean eos;

        Seg(int rate, long baseFrame) {
            this.rate = rate;
            this.cap = rate * 6;
            this.l = new float[cap];
            this.r = new float[cap];
            this.baseFrame = baseFrame;
        }
    }

    private static final class Deck {
        final int id;
        volatile Seg seg;
        volatile int tok;
        volatile boolean playing;
        volatile double rate = 1.0;
        volatile boolean ended;
        volatile double durationSec = -1;
        volatile int srcRate;
        volatile double rposPub;
        Decoder dec;
        File file;
        // поток микшера
        Seg mixSeg;
        double rpos;
        float run;
        double lastG = 0;
        final AudioDsp.AutoParam gain;
        final AudioDsp.AutoParam vol = new AudioDsp.AutoParam(1.0);

        Deck(int id) {
            this.id = id;
            this.gain = new AudioDsp.AutoParam(id == 0 ? 1.0 : 0.0);
        }
    }

    private final Context ctx;
    private final Host host;
    private final File dir;
    private final Deck[] decks = {new Deck(0), new Deck(1)};
    private final AudioDsp.Fx fx = new AudioDsp.Fx(OUT_RATE, FREQS);
    private final AudioDsp.Spectrum spec = new AudioDsp.Spectrum();
    private volatile byte[] specOut = new byte[AudioDsp.Spectrum.N / 2];
    private volatile long mixFrames;
    private volatile boolean quit;
    private volatile boolean visible = true;
    private volatile int bufferMs = 300;
    private volatile boolean trackStale;
    private volatile double latencySec;
    private volatile double duckTarget = 1.0;
    private double duck = 1.0;

    private Thread mixer, pusher;
    private final Object wakeLock = new Object();
    private boolean wake;
    private AudioTrack track;

    private final HashMap<String, FileOutputStream> puts = new HashMap<String, FileOutputStream>();

    // фокус
    private final Handler main = new Handler(Looper.getMainLooper());
    private AudioManager am;
    private AudioManager.OnAudioFocusChangeListener focusListener;
    private Object focusReq;
    private volatile boolean hasFocus, keepFocus;

    NativeAudio(Context ctx, Host host) {
        this.ctx = ctx.getApplicationContext();
        this.host = host;
        this.dir = new File(this.ctx.getCacheDir(), "kxa");
        this.dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) {
            for (File f : old) {
                if (f.getName().endsWith(".part")) f.delete();
            }
        }
    }

    void start(int bufMs) {
        bufferMs = Math.max(100, Math.min(999, bufMs));
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        focusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int change) {
                if (change == AudioManager.AUDIOFOCUS_LOSS) {
                    hasFocus = false;
                    keepFocus = false;
                    emit("{e:'focus',v:'loss'}");
                } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    keepFocus = true;
                    emit("{e:'focus',v:'transient'}");
                } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                    duckTarget = 0.25;
                } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
                    duckTarget = 1.0;
                    if (keepFocus) {
                        keepFocus = false;
                        emit("{e:'focus',v:'gain'}");
                    }
                }
            }
        };
        mixer = new Thread(new Runnable() {
            public void run() {
                mixLoop();
            }
        }, "kx-mixer");
        mixer.start();
        pusher = new Thread(new Runnable() {
            public void run() {
                pushLoop();
            }
        }, "kx-audio-state");
        pusher.setDaemon(true);
        pusher.start();
    }

    void release() {
        quit = true;
        synchronized (wakeLock) {
            wake = true;
            wakeLock.notifyAll();
        }
        for (Deck d : decks) {
            synchronized (d) {
                stopDecoder(d);
                d.playing = false;
                d.seg = null;
            }
        }
        try {
            if (mixer != null) mixer.join(1500);
        } catch (InterruptedException ignored) {
            // выходим
        }
        releaseTrack();
        abandonFocus();
    }

    // ---------------------------------------------------------------------------------------- события в страницу
    private void emit(String json) {
        try {
            host.js("window.__kxA&&window.__kxA(" + json + ")");
        } catch (Throwable t) {
            Log.w(TAG, "emit failed", t);
        }
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\'', ' ').replace('\\', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    // ---------------------------------------------------------------------------------------- кэш файлов
    private static String safe(String key) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < key.length() && i < 80; i++) {
            char c = key.charAt(i);
            if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '-') sb.append(c);
            else sb.append('_');
        }
        return sb.toString();
    }

    private File cacheFile(String key) {
        return new File(dir, safe(key) + ".bin");
    }

    boolean has(String key) {
        File f = cacheFile(key);
        if (f.isFile() && f.length() > 0) {
            f.setLastModified(System.currentTimeMillis());
            return true;
        }
        return false;
    }

    synchronized boolean putBegin(String key) {
        try {
            FileOutputStream old = puts.remove(key);
            if (old != null) old.close();
            puts.put(key, new FileOutputStream(new File(dir, safe(key) + ".part")));
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "putBegin failed", t);
            return false;
        }
    }

    synchronized boolean putChunk(String key, String b64) {
        try {
            FileOutputStream o = puts.get(key);
            if (o == null) return false;
            o.write(Base64.decode(b64, Base64.DEFAULT));
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "putChunk failed", t);
            return false;
        }
    }

    synchronized boolean putEnd(String key) {
        try {
            FileOutputStream o = puts.remove(key);
            if (o == null) return false;
            o.close();
            File part = new File(dir, safe(key) + ".part");
            File dst = cacheFile(key);
            if (dst.exists()) dst.delete();
            boolean ok = part.renameTo(dst);
            trimCache();
            return ok;
        } catch (Throwable t) {
            Log.w(TAG, "putEnd failed", t);
            return false;
        }
    }

    private void trimCache() {
        try {
            File[] fs = dir.listFiles();
            if (fs == null) return;
            long total = 0;
            for (File f : fs) total += f.length();
            if (total <= CACHE_LIMIT) return;
            Arrays.sort(fs, new Comparator<File>() {
                public int compare(File a, File b) {
                    return Long.compare(a.lastModified(), b.lastModified());
                }
            });
            for (File f : fs) {
                if (total <= CACHE_LIMIT * 8 / 10) break;
                boolean inUse = false;
                for (Deck d : decks) {
                    if (d.file != null && d.file.equals(f)) inUse = true;
                }
                if (inUse || f.getName().endsWith(".part")) continue;
                total -= f.length();
                f.delete();
            }
        } catch (Throwable t) {
            Log.w(TAG, "trimCache failed", t);
        }
    }

    // ---------------------------------------------------------------------------------------- команды дек
    void load(int di, String key, int tok) {
        Deck d = decks[di];
        synchronized (d) {
            stopDecoder(d);
            d.tok = tok;
            d.playing = false;
            d.ended = false;
            d.seg = null;
            d.srcRate = 0;
            d.rposPub = 0;
            d.durationSec = -1;
            File f = cacheFile(key);
            d.file = f;
            if (!f.isFile()) {
                emit("{e:'err',d:" + di + ",t:" + tok + ",m:'нет файла в кэше'}");
                return;
            }
            f.setLastModified(System.currentTimeMillis());
            d.dec = new Decoder(d, f.getPath(), tok);
            d.dec.start();
        }
    }

    void unload(int di) {
        Deck d = decks[di];
        synchronized (d) {
            stopDecoder(d);
            d.playing = false;
            d.ended = false;
            d.seg = null;
            d.srcRate = 0;
            d.file = null;
            d.tok++;
            d.rposPub = 0;
            d.durationSec = -1;
        }
    }

    void play(int di) {
        Deck d = decks[di];
        d.ended = false;
        d.playing = true;
        requestFocus();
        wakeMixer();
    }

    void pause(int di) {
        decks[di].playing = false;
    }

    void seek(int di, double sec) {
        Deck d = decks[di];
        synchronized (d) {
            if (d.dec == null) return;
            double dur = d.durationSec;
            if (sec < 0 || Double.isNaN(sec)) sec = 0;
            if (dur > 0 && sec > dur) sec = dur;
            if (d.srcRate == 0) {
                d.dec.startSec = sec;
                return;
            }
            Seg s = new Seg(d.srcRate, Math.round(sec * d.srcRate));
            d.ended = false;
            d.dec.requestSeek(s, sec);
            d.seg = s;
        }
        wakeMixer();
    }

    void rate(int di, double r) {
        decks[di].rate = Math.max(0.25, Math.min(4.0, r));
    }

    /** which: 0 — gain (автоматизация кросс-фейда), 1 — vol (громкость дека). op: 0 cancel, 1 set, 2 linear, 3 curve, 4 hold, 5 target. */
    void param(int di, int which, int op, double offset, double v, double extra, String curve) {
        Deck d = decks[di];
        AudioDsp.AutoParam p = which == 0 ? d.gain : d.vol;
        double t = mixFrames / (double) OUT_RATE + offset;
        switch (op) {
            case 0:
            case 4:
                p.cancel(t);
                break;
            case 1:
                p.setValueAt(v, t);
                break;
            case 2:
                p.linearRampTo(v, t);
                break;
            case 3:
                p.curveAt(parseCurve(curve), t, extra);
                break;
            case 6: // cancel + target: так страница меняет громкость дека
                p.cancel(t);
                p.targetAt(v, t, extra);
                break;
            default:
                p.targetAt(v, t, extra);
                break;
        }
    }

    private static float[] parseCurve(String s) {
        if (s == null || s.length() == 0) return null;
        String[] a = s.split(",");
        float[] c = new float[a.length];
        for (int i = 0; i < a.length; i++) {
            try {
                c[i] = Float.parseFloat(a[i]);
            } catch (NumberFormatException e) {
                c[i] = 0f;
            }
        }
        return c;
    }

    /** 17 чисел через запятую: 10 полос эквалайзера (дБ), бас (дБ), громкость, баланс, виртуализатор, мокрый, сухой, предусилитель. */
    void fx(String csv) {
        try {
            String[] a = csv.split(",");
            if (a.length < 17) return;
            double[] v = new double[17];
            for (int i = 0; i < 17; i++) v[i] = Double.parseDouble(a[i]);
            double[] eq = new double[10];
            System.arraycopy(v, 0, eq, 0, 10);
            fx.set(eq, v[10], v[11], v[12], v[13], v[14], v[15], v[16]);
        } catch (Throwable t) {
            Log.w(TAG, "fx failed", t);
        }
    }

    void setVisible(boolean v) {
        visible = v;
    }

    void setBufferMs(int ms) {
        int n = Math.max(100, Math.min(999, ms));
        if (n != bufferMs) {
            bufferMs = n;
            trackStale = true;
        }
    }

    private void stopDecoder(Deck d) {
        if (d.dec != null) {
            d.dec.stopNow();
            d.dec = null;
        }
    }

    private void wakeMixer() {
        synchronized (wakeLock) {
            wake = true;
            wakeLock.notifyAll();
        }
    }

    // ---------------------------------------------------------------------------------------- аудио-фокус
    @SuppressWarnings("deprecation")
    private void requestFocus() {
        try {
            if (hasFocus || am == null) return;
            int r;
            if (Build.VERSION.SDK_INT >= 26) {
                AudioAttributes attr = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
                AudioFocusRequest req = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(attr).setOnAudioFocusChangeListener(focusListener, main).build();
                focusReq = req;
                r = am.requestAudioFocus(req);
            } else {
                r = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            }
            hasFocus = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            keepFocus = false;
        } catch (Throwable t) {
            Log.w(TAG, "requestFocus failed", t);
        }
    }

    @SuppressWarnings("deprecation")
    private void abandonFocus() {
        try {
            if (am == null || !hasFocus) return;
            hasFocus = false;
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusReq != null) am.abandonAudioFocusRequest((AudioFocusRequest) focusReq);
            } else {
                am.abandonAudioFocus(focusListener);
            }
        } catch (Throwable t) {
            Log.w(TAG, "abandonFocus failed", t);
        }
    }

    // ---------------------------------------------------------------------------------------- AudioTrack
    private AudioTrack makeTrack() {
        int minBuf = AudioTrack.getMinBufferSize(OUT_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        int want = (int) ((long) OUT_RATE * bufferMs / 1000) * 4;
        int size = Math.max(minBuf * 2, want);
        size -= size % 4;
        AudioAttributes attr = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        AudioFormat fmt = new AudioFormat.Builder().setSampleRate(OUT_RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build();
        AudioTrack.Builder b = new AudioTrack.Builder().setAudioAttributes(attr).setAudioFormat(fmt)
                .setBufferSizeInBytes(size).setTransferMode(AudioTrack.MODE_STREAM);
        if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_POWER_SAVING);
        return b.build();
    }

    private void releaseTrack() {
        try {
            if (track != null) {
                try {
                    track.pause();
                    track.flush();
                } catch (Throwable ignored) {
                    // уже остановлен
                }
                track.release();
            }
        } catch (Throwable t) {
            Log.w(TAG, "releaseTrack failed", t);
        }
        track = null;
    }

    // ---------------------------------------------------------------------------------------- микшер
    private boolean anyActive() {
        for (Deck d : decks) {
            if (d.playing || d.run > 0f) return true;
        }
        return false;
    }

    private void waitWake() {
        synchronized (wakeLock) {
            while (!wake && !quit) {
                try {
                    wakeLock.wait(1000);
                } catch (InterruptedException e) {
                    return;
                }
            }
            wake = false;
        }
    }

    private void mixLoop() {
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        } catch (Throwable ignored) {
            // приоритет не критичен
        }
        final float[] aL = new float[BLOCK], aR = new float[BLOCK];
        final short[] pcm = new short[BLOCK * 2];
        long idle = 0, written = 0, specAcc = 0, blocks = 0;
        boolean started = false;
        while (!quit) {
            boolean any = anyActive();
            if (!any && track == null) {
                waitWake();
                idle = 0;
                continue;
            }
            if (!any) {
                idle += BLOCK;
                long limit = Math.max((long) OUT_RATE * (fx.reverbRunning ? 3 : 1) , (long) OUT_RATE * (bufferMs + 400) / 1000);
                if (idle >= limit) {
                    try {
                        if (track != null) {
                            track.pause();
                            track.flush();
                            if (trackStale) {
                                releaseTrack();
                                trackStale = false;
                            }
                        }
                    } catch (Throwable t) {
                        releaseTrack();
                    }
                    started = false;
                    written = 0;
                    fx.reset();
                    if (!keepFocus) abandonFocus();
                    idle = 0;
                    waitWake();
                    continue;
                }
            } else {
                idle = 0;
            }
            if (track == null) {
                try {
                    track = makeTrack();
                    started = false;
                    written = 0;
                } catch (Throwable t) {
                    Log.w(TAG, "makeTrack failed", t);
                    track = null;
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        return;
                    }
                    continue;
                }
            }
            Arrays.fill(aL, 0f);
            Arrays.fill(aR, 0f);
            double t1 = (mixFrames + BLOCK) / (double) OUT_RATE;
            duck += (duckTarget - duck) * 0.05;
            for (Deck d : decks) mixDeck(d, aL, aR, BLOCK, t1);
            fx.process(aL, aR, BLOCK);
            if (visible) {
                spec.push(aL, aR, BLOCK);
                specAcc += BLOCK;
                if (specAcc >= 1024) {
                    specAcc = 0;
                    spec.compute();
                    specOut = spec.out.clone();
                }
            }
            for (int i = 0; i < BLOCK; i++) {
                float l = aL[i] * 32767f, r = aR[i] * 32767f;
                pcm[2 * i] = (short) (l > 32767f ? 32767 : (l < -32768f ? -32768 : l));
                pcm[2 * i + 1] = (short) (r > 32767f ? 32767 : (r < -32768f ? -32768 : r));
            }
            int w;
            try {
                w = track.write(pcm, 0, BLOCK * 2);
            } catch (Throwable t) {
                w = -1;
            }
            if (w < 0) {
                Log.w(TAG, "track write error " + w);
                releaseTrack();
                started = false;
                continue;
            }
            written += BLOCK;
            mixFrames += BLOCK;
            if (!started && written >= BLOCK * 8L) {
                try {
                    track.play();
                    started = true;
                } catch (Throwable t) {
                    Log.w(TAG, "play failed", t);
                    releaseTrack();
                }
            }
            if ((++blocks & 15) == 0 && started) {
                try {
                    long head = track.getPlaybackHeadPosition() & 0xffffffffL;
                    latencySec = Math.max(0, (written - head) / (double) OUT_RATE);
                } catch (Throwable ignored) {
                    // нет данных
                }
            }
        }
    }

    private void mixDeck(Deck d, float[] oL, float[] oR, int n, double t1) {
        double g1 = d.vol.valueAt(t1) * d.gain.valueAt(t1);
        double g0 = d.lastG;
        d.lastG = g1;
        Seg seg = d.seg;
        if (seg != d.mixSeg) {
            d.mixSeg = seg;
            d.rpos = 0;
            d.rposPub = 0;
        }
        if (seg == null) {
            if (!d.playing) d.run = 0f;
            return;
        }
        if (!d.playing && d.run <= 0f) return;
        final float rs = (float) (1.0 / (0.008 * OUT_RATE));
        final double step = seg.rate / (double) OUT_RATE * d.rate;
        final boolean unity = Math.abs(step - 1.0) < 1e-9;
        final float[] sl = seg.l, sr = seg.r;
        final int cap = seg.cap;
        final long wr = seg.wr;
        final boolean eos = seg.eos;
        double rpos = d.rpos;
        float run = d.run;
        for (int i = 0; i < n; i++) {
            if (d.playing) {
                if (run < 1f) run = Math.min(1f, run + rs);
            } else {
                run = Math.max(0f, run - rs);
                if (run <= 0f) break;
            }
            long ip = (long) rpos;
            if (eos) {
                if (ip >= wr) {
                    if (!d.ended) {
                        d.ended = true;
                        d.playing = false;
                        emit("{e:'ended',d:" + d.id + ",t:" + d.tok + "}");
                    }
                    break;
                }
            } else if (ip + 2 >= wr) {
                break; // данных ещё нет: ждём декодер, позицию не двигаем
            }
            double f = rpos - ip;
            float yl, yr;
            if (f == 0.0 && unity) {
                int a = (int) (ip % cap);
                yl = sl[a];
                yr = sr[a];
            } else {
                int a0 = (int) (Math.max(0, ip - 1) % cap), a1 = (int) (ip % cap);
                int a2 = (int) (Math.min(wr - 1, ip + 1) % cap), a3 = (int) (Math.min(wr - 1, ip + 2) % cap);
                float ff = (float) f;
                yl = cubic(sl[a0], sl[a1], sl[a2], sl[a3], ff);
                yr = cubic(sr[a0], sr[a1], sr[a2], sr[a3], ff);
            }
            double g = g0 + (g1 - g0) * (i + 1) / n;
            float gg = (float) (g * run * duck);
            oL[i] += yl * gg;
            oR[i] += yr * gg;
            rpos += step;
        }
        d.rpos = rpos;
        d.run = run;
        d.rposPub = rpos;
        seg.rd = (long) rpos;
    }

    private static float cubic(float y0, float y1, float y2, float y3, float f) {
        return y1 + 0.5f * f * (y2 - y0 + f * (2f * y0 - 5f * y1 + 4f * y2 - y3 + f * (3f * (y1 - y2) + y3 - y0)));
    }

    // ---------------------------------------------------------------------------------------- состояние для страницы
    private void pushLoop() {
        final StringBuilder sb = new StringBuilder(256);
        String lastIdle = "";
        while (!quit) {
            try {
                Thread.sleep(visible ? 100 : 400);
            } catch (InterruptedException e) {
                return;
            }
            boolean playing = false;
            sb.setLength(0);
            sb.append("{s:[");
            for (int i = 0; i < 2; i++) {
                Deck d = decks[i];
                Seg seg = d.seg;
                double pos = 0;
                if (seg != null) {
                    pos = (seg.baseFrame + d.rposPub) / (double) seg.rate;
                    if (d.playing) pos -= latencySec * d.rate;
                    if (pos < 0) pos = 0;
                }
                if (d.playing) playing = true;
                if (i > 0) sb.append(',');
                sb.append("[").append(d.tok).append(',').append(String.format(java.util.Locale.US, "%.3f", pos)).append(',')
                        .append(d.playing ? 1 : 0).append(',').append(seg != null ? 1 : 0).append(']');
            }
            sb.append(']');
            if (playing && visible) {
                sb.append(",sp:'").append(Base64.encodeToString(specOut, Base64.NO_WRAP)).append('\'');
            }
            sb.append('}');
            String s = sb.toString();
            if (playing || !s.equals(lastIdle)) {
                emit(s);
                lastIdle = playing ? "" : s;
            }
        }
    }

    // ---------------------------------------------------------------------------------------- декодер
    private static final class Pend {
        final Seg seg;
        final double sec;

        Pend(Seg seg, double sec) {
            this.seg = seg;
            this.sec = sec;
        }
    }

    private final class Decoder extends Thread {
        private final Deck dk;
        private final String path;
        private final int tok;
        volatile boolean stop;
        volatile double startSec;
        private Pend pend;

        Decoder(Deck dk, String path, int tok) {
            super("kx-dec-" + dk.id);
            this.dk = dk;
            this.path = path;
            this.tok = tok;
        }

        void stopNow() {
            stop = true;
            interrupt();
        }

        synchronized void requestSeek(Seg s, double sec) {
            pend = new Pend(s, sec);
        }

        private synchronized Pend takePend() {
            Pend p = pend;
            pend = null;
            return p;
        }

        private synchronized boolean hasPend() {
            return pend != null;
        }

        @Override
        public void run() {
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            } catch (Throwable ignored) {
                // приоритет не критичен
            }
            MediaExtractor ex = null;
            MediaCodec codec = null;
            try {
                ex = new MediaExtractor();
                ex.setDataSource(path);
                int ti = -1;
                MediaFormat f = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat tf = ex.getTrackFormat(i);
                    String m = tf.getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("audio/")) {
                        ti = i;
                        f = tf;
                        break;
                    }
                }
                if (ti < 0) throw new IllegalStateException("нет звуковой дорожки");
                ex.selectTrack(ti);
                String mime = f.getString(MediaFormat.KEY_MIME);
                double durSec = f.containsKey(MediaFormat.KEY_DURATION) ? f.getLong(MediaFormat.KEY_DURATION) / 1e6 : -1;
                dk.durationSec = durSec;
                codec = MediaCodec.createDecoderByType(mime);
                codec.configure(f, null, null, 0);
                codec.start();
                double firstSeek = startSec;
                if (firstSeek > 0) ex.seekTo((long) (firstSeek * 1e6), MediaExtractor.SEEK_TO_PREVIOUS_SYNC);

                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                Seg seg = null;
                int outCh = 2, outRate = 0;
                boolean outFloat = false, inEos = false, outEos = false, first = true, announce = true, metaSent = false;
                long skip = 0;
                while (!stop) {
                    Pend p = takePend();
                    if (p != null && seg != null) {
                        seg = p.seg;
                        ex.seekTo((long) (p.sec * 1e6), MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                        codec.flush();
                        inEos = false;
                        outEos = false;
                        first = true;
                        announce = true;
                        skip = 0;
                    }
                    if (outEos) {
                        Thread.sleep(8);
                        continue;
                    }
                    if (seg != null) {
                        long free = seg.cap - (seg.wr - Math.max(0, seg.rd - 16));
                        if (free < 16384) {
                            Thread.sleep(4);
                            continue;
                        }
                    }
                    if (!inEos) {
                        int ii = codec.dequeueInputBuffer(0);
                        if (ii >= 0) {
                            ByteBuffer ib = codec.getInputBuffer(ii);
                            int n = ex.readSampleData(ib, 0);
                            if (n < 0) {
                                codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inEos = true;
                            } else {
                                codec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                                ex.advance();
                            }
                        }
                    }
                    int oi = codec.dequeueOutputBuffer(info, 8000);
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat of = codec.getOutputFormat();
                        int nr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        outCh = of.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? of.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
                        outFloat = of.containsKey("pcm-encoding") && of.getInteger("pcm-encoding") == AudioFormat.ENCODING_PCM_FLOAT;
                        if (seg == null || nr != outRate) {
                            outRate = nr;
                            double st;
                            synchronized (dk) {
                                if (dk.dec != this) return;
                                st = startSec;
                                seg = new Seg(outRate, Math.round(st * outRate));
                                dk.srcRate = outRate;
                                dk.seg = seg;
                            }
                            if (Math.abs(st - firstSeek) > 0.05) {
                                ex.seekTo((long) (st * 1e6), MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                                codec.flush();
                                inEos = false;
                            }
                            first = true;
                        }
                        continue;
                    }
                    if (oi < 0) continue;
                    if (seg == null) {
                        // формат вывода не сообщили: берём из текущего
                        MediaFormat of = codec.getOutputFormat();
                        outRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        outCh = of.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? of.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
                        synchronized (dk) {
                            if (dk.dec != this) return;
                            seg = new Seg(outRate, Math.round(startSec * outRate));
                            dk.srcRate = outRate;
                            dk.seg = seg;
                        }
                    }
                    int bytesPer = outFloat ? 4 : 2;
                    int frames = outCh > 0 ? info.size / (bytesPer * outCh) : 0;
                    if (frames > 0) {
                        ByteBuffer ob = codec.getOutputBuffer(oi);
                        ob.order(ByteOrder.nativeOrder());
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ShortBuffer sb = outFloat ? null : ob.asShortBuffer();
                        FloatBuffer fb = outFloat ? ob.asFloatBuffer() : null;
                        int done = 0;
                        if (first) {
                            first = false;
                            long idx = Math.round(info.presentationTimeUs * (double) outRate / 1e6);
                            long tgt = seg.baseFrame;
                            if (idx > tgt) seg.baseFrame = idx;
                            else skip = tgt - idx;
                        }
                        if (skip > 0) {
                            int s = (int) Math.min(skip, frames);
                            done = s;
                            skip -= s;
                        }
                        while (done < frames && !stop) {
                            long free = seg.cap - (seg.wr - Math.max(0, seg.rd - 16));
                            if (free <= 0) {
                                if (hasPend()) break;
                                Thread.sleep(3);
                                continue;
                            }
                            int k = (int) Math.min(Math.min(free, frames - done), 8192);
                            long w = seg.wr;
                            for (int j = 0; j < k; j++) {
                                int base = (done + j) * outCh;
                                float l, r;
                                if (outFloat) {
                                    l = fb.get(base);
                                    r = outCh > 1 ? fb.get(base + 1) : l;
                                } else {
                                    l = sb.get(base) * (1f / 32768f);
                                    r = outCh > 1 ? sb.get(base + 1) * (1f / 32768f) : l;
                                }
                                int wi = (int) ((w + j) % seg.cap);
                                seg.l[wi] = l;
                                seg.r[wi] = r;
                            }
                            seg.wr = w + k;
                            done += k;
                        }
                    }
                    boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    codec.releaseOutputBuffer(oi, false);
                    if (seg.wr > 0 && announce) {
                        announce = false;
                        if (!metaSent) {
                            metaSent = true;
                            emit("{e:'meta',d:" + dk.id + ",t:" + tok + ",dur:" + String.format(java.util.Locale.US, "%.3f", dk.durationSec) + ",rate:" + seg.rate + "}");
                        } else {
                            emit("{e:'seeked',d:" + dk.id + ",t:" + tok + "}");
                        }
                    }
                    if (eos) {
                        seg.eos = true;
                        outEos = true;
                        double real = (seg.baseFrame + seg.wr) / (double) seg.rate;
                        if (!(dk.durationSec > 0) || Math.abs(real - dk.durationSec) > 0.5) {
                            dk.durationSec = real;
                            emit("{e:'dur',d:" + dk.id + ",t:" + tok + ",dur:" + String.format(java.util.Locale.US, "%.3f", real) + "}");
                        }
                        if (announce) {
                            announce = false;
                            emit(metaSent ? "{e:'seeked',d:" + dk.id + ",t:" + tok + "}"
                                    : "{e:'meta',d:" + dk.id + ",t:" + tok + ",dur:" + String.format(java.util.Locale.US, "%.3f", real) + ",rate:" + seg.rate + "}");
                            metaSent = true;
                        }
                    }
                }
            } catch (InterruptedException e) {
                // остановлен
            } catch (Throwable t) {
                if (!stop) {
                    Log.w(TAG, "decoder failed", t);
                    emit("{e:'err',d:" + dk.id + ",t:" + tok + ",m:'" + clean(String.valueOf(t.getMessage())) + "'}");
                }
            } finally {
                try {
                    if (codec != null) {
                        codec.stop();
                        codec.release();
                    }
                } catch (Throwable ignored) {
                    // уже освобождён
                }
                try {
                    if (ex != null) ex.release();
                } catch (Throwable ignored) {
                    // уже освобождён
                }
            }
        }
    }
}

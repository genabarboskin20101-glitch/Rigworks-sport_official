# Сборка Lira Audio ONNX

1. Открой именно эту папку `android/` в Android Studio.
2. Используй JDK 17, Android SDK Platform 36 и дождись Gradle Sync.
3. В меню Android Studio выбери **Build → Build APK(s)**.
4. APK будет создан в `app/build/outputs/apk/debug/app-debug.apk`.

Командой можно синхронизировать web-файлы из `../web/`:

```bash
./prepare.sh
```

Проект больше не зависит от `llama.cpp` и не загружает его. Используется `com.microsoft.onnxruntime:onnxruntime-android:1.31.0`. В текущем окружении нет Android SDK и Gradle, поэтому локальная сборка APK не была выполнена.

Для установленного приложения сначала скачай или импортируй `UVR-MDX-NET-Inst_HQ_3.onnx`, затем добавь аудиофайл и нажми «Разделить аудио». Модель предсказывает инструментал, вокал вычисляется как разность исходного микса и инструментала. Результат можно прослушать и сохранить в WAV либо ZIP.

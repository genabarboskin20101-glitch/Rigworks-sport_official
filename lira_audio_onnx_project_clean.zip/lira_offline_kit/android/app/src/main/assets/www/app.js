(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = { audioReady: false, modelReady: false, busy: false, outputReady: false };
  let toastHandle = null;
  function toast(message) {
    const el = $('toast'); el.textContent = String(message || 'Готово'); el.classList.remove('hidden');
    clearTimeout(toastHandle); toastHandle = setTimeout(() => el.classList.add('hidden'), 3200);
  }
  function bridge() { return window.LiraNativeBridge; }
  function updateButton() {
    $('startProcess').disabled = !state.audioReady || !state.modelReady || state.busy;
    if (state.busy) $('processHint').textContent = 'Не закрывай приложение, пока обрабатывается аудио.';
    else if (!state.audioReady || !state.modelReady) $('processHint').textContent = 'Сначала выбери аудио и загрузи ONNX-модель.';
    else $('processHint').textContent = 'Аудио и модель готовы. Разделение запускается автоматически; кнопку можно использовать повторно.';
  }
  function setAudio(data) {
    state.audioReady = !!(data && data.ready);
    if (state.audioReady) {
      $('audioTitle').textContent = 'Аудиофайл добавлен'; $('audioSubtitle').textContent = 'Готов к локальной обработке';
      $('audioDropzone').classList.add('ready'); $('audioFileRow').classList.remove('hidden');
      $('audioFileName').textContent = data.name || 'audio'; $('audioFileMeta').textContent = data.meta || 'Готов к обработке';
    } else {
      $('audioTitle').textContent = 'Добавь аудиофайл'; $('audioSubtitle').textContent = 'Файл обрабатывается локально на устройстве';
      $('audioDropzone').classList.remove('ready'); $('audioFileRow').classList.add('hidden');
    }
    updateButton();
  }
  function setModel(data) {
    state.modelReady = !!(data && data.ready);
    $('modelName').textContent = data?.name || (state.modelReady ? 'Модель загружена' : 'Модель не загружена');
    $('modelMeta').textContent = data?.meta || 'UVR MDX-Net · целевой выход: инструментал';
    $('modelStatus').classList.toggle('ready', state.modelReady);
    $('modelStatus').innerHTML = state.modelReady ? '<span class="yellow-dot"></span> Модель готова к инференсу' : '<span class="yellow-dot"></span> Требуется файл модели';
    updateButton();
  }
  function setProgress(pct, title, message) {
    $('progressCard').classList.remove('hidden'); const value = Math.max(0, Math.min(100, Number(pct) || 0));
    $('progressBar').style.width = value + '%'; $('progressPercent').textContent = Math.round(value) + '%';
    $('progressTitle').textContent = title || 'Обработка'; $('progressMessage').textContent = message || 'Пожалуйста, подожди';
  }
  function markBusy(busy) {
    state.busy = !!busy; $('chooseAudio').disabled = state.busy; $('chooseModel').disabled = state.busy; $('downloadModel').disabled = state.busy; $('removeAudio').disabled = state.busy;
    $('startProcess').innerHTML = state.busy ? '<span>◌</span> Обработка…' : '<span>✦</span> Разделить аудио'; updateButton();
  }
  function setResult(data) {
    state.outputReady = !!(data && data.ready);
    if (!state.outputReady) { $('resultsPanel').classList.add('hidden'); $('vocalsPlayer').removeAttribute('src'); $('instrumentalPlayer').removeAttribute('src'); return; }
    $('resultsPanel').classList.remove('hidden');
    if (data.vocalsUrl) $('vocalsPlayer').src = data.vocalsUrl;
    if (data.instrumentalUrl) $('instrumentalPlayer').src = data.instrumentalUrl;
    $('resultsPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  window.LiraAudioApp = {
    setStatus(data) {
      setAudio({ ready: !!data.audioReady, name: data.audioName, meta: data.audioMeta });
      setModel({ ready: !!data.modelReady, name: data.modelName, meta: data.modelMeta });
      if (data.outputReady) setResult(data); if (data.error) toast(data.error);
    },
    onAudioSelected(data) {
      markBusy(false); setAudio(data); setResult({ ready: false });
      if (data?.ready && state.modelReady) startSeparation(true);
      else toast('Аудио добавлено. Как только модель будет готова, разделение начнётся автоматически.');
    },
    onModelStatus(data) {
      markBusy(false); setModel(data);
      if (data.ready) {
        setProgress(100, 'Модель готова', data.message || 'Модель загружена и готова к инференсу');
        if (state.audioReady) startSeparation(true);
      }
      if (data.message) toast(data.message);
    },
    onProgress(data) { markBusy(true); setProgress(data.percent, data.title, data.message); },
    onProcessStarted() { markBusy(true); setProgress(0, 'Подготовка аудио', 'Чтение и преобразование аудиофайла'); $('resultsPanel').classList.add('hidden'); },
    onProcessDone(data) { markBusy(false); setProgress(100, 'Разделение завершено', 'Дорожки готовы. Можно прослушать их и сохранить в файлы.'); setResult(data); toast('Вокал и инструментал готовы'); },
    onError(message) { markBusy(false); toast(message || 'Неизвестная ошибка'); setProgress(0, 'Не удалось выполнить операцию', String(message || 'Проверь аудио и модель')); },
    onExportDone(message) { toast(message || 'Файл сохранён'); },
    onDownloadProgress(data) { markBusy(true); setProgress(data.percent, 'Загрузка модели', data.message); }
  };
  $('chooseAudio').addEventListener('click', () => bridge()?.chooseAudio ? bridge().chooseAudio() : toast('Выбор аудио доступен в Android-приложении.'));
  $('removeAudio').addEventListener('click', () => { if (bridge()?.clearAudio) bridge().clearAudio(); setAudio({ ready: false }); setResult({ ready: false }); });
  $('chooseModel').addEventListener('click', () => bridge()?.chooseModel ? bridge().chooseModel() : toast('Выбор ONNX-модели доступен в Android-приложении.'));
  $('downloadModel').addEventListener('click', () => {
    if (bridge()?.downloadDefaultModel) { setProgress(0, 'Загрузка модели', 'Подключение к серверу модели…'); bridge().downloadDefaultModel(); }
    else toast('Загрузка модели доступна в Android-приложении.');
  });
  function startSeparation(automatic = false) {
    if (!state.audioReady || !state.modelReady || state.busy) return;
    markBusy(true); $('progressCard').classList.remove('hidden'); $('resultsPanel').classList.add('hidden');
    if (bridge()?.separateAudio) {
      if (automatic) setProgress(0, 'Автоматическое разделение', 'Модель и аудио готовы — начинаем обработку');
      bridge().separateAudio($('denoise').checked);
    } else {
      markBusy(false);
      toast('Запусти приложение в Android-оболочке для локального инференса.');
    }
  }
  $('startProcess').addEventListener('click', () => startSeparation(false));
  $('exportVocals').addEventListener('click', () => bridge()?.exportStem ? bridge().exportStem('vocals') : toast('Экспорт доступен в Android-приложении.'));
  $('exportInstrumental').addEventListener('click', () => bridge()?.exportStem ? bridge().exportStem('instrumental') : toast('Экспорт доступен в Android-приложении.'));
  $('exportAll').addEventListener('click', () => bridge()?.exportAll ? bridge().exportAll() : toast('Экспорт доступен в Android-приложении.'));
  const openHelp = () => $('helpModal').classList.remove('hidden'); const closeHelp = () => $('helpModal').classList.add('hidden');
  $('helpButton').addEventListener('click', openHelp); $('closeHelp').addEventListener('click', closeHelp); $('closeHelpButton').addEventListener('click', closeHelp);
  $('helpModal').addEventListener('click', (event) => { if (event.target === $('helpModal')) closeHelp(); });
  try { const raw = bridge()?.getStatus?.(); if (raw) window.LiraAudioApp.setStatus(JSON.parse(raw)); } catch (_) { /* Web preview has no native bridge. */ }
  updateButton();
})();

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p app/src/main/assets/www
cp ../web/index.html ../web/style.css ../web/app.js app/src/main/assets/www/
printf '\nГотово: веб-интерфейс скопирован в Android assets.\n'
printf 'Открой папку android/ в Android Studio, дождись Gradle Sync и выбери Build > Build APK(s).\n'

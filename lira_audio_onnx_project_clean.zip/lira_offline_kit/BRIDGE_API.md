# Lira Audio ONNX: Web ↔ Android bridge

The WebView UI communicates with `MainActivity` through `window.LiraNativeBridge`:

- `getStatus()` → JSON status snapshot.
- `chooseAudio()` → system audio picker.
- `chooseModel()` → ONNX file picker.
- `downloadDefaultModel()` → download the default UVR-MDX-Net Inst HQ 3 model.
- `separateAudio(denoise)` → run on-device MDX inference.
- `exportStem("vocals" | "instrumental")` → save a WAV stem.
- `exportAll()` → save both stems as a ZIP.
- `clearAudio()` → remove the selected audio from the app's private storage.

Native-to-web calls are defined on `window.LiraAudioApp`: `setStatus`, `onAudioSelected`, `onModelStatus`, `onProgress`, `onProcessStarted`, `onProcessDone`, `onError`, `onExportDone`, and `onDownloadProgress`.

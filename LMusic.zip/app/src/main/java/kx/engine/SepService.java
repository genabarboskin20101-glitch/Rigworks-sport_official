package kx.engine;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

/**
 * Foreground-сервис разделения на дорожки (тип dataSync). Пока идёт обработка, он держит приложение живым в фоне
 * (иначе свёрнутое приложение замораживают, и долгая обработка обрывается) и показывает в шторке уведомление
 * с ходом обработки: этап, модель, проценты, полоса прогресса и кнопка «Отмена».
 * Сервис объявляется в AndroidManifest.xml (kx.engine.SepService, foregroundServiceType=dataSync).
 */
public class SepService extends Service {
    private static final String TAG = "KX";
    private static final String CHANNEL = "lm_separate";
    private static final String ACT_CANCEL = "kx.engine.sep.CANCEL";
    private static final int ID = 7401, ID_RESULT = 7402;
    private static final int TYPE_DATA_SYNC = 1; // ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC

    static final int DONE = 0, ERROR = 1, CANCELLED = 2;

    private static volatile SepService inst;
    private static volatile boolean active;
    private static volatile Notification pending;
    private static volatile Runnable onCancel;
    private static volatile String title = "Разделение на дорожки";
    private static volatile int lastPct = -2;
    private static volatile String lastText = "";

    public SepService() { }

    // ------------------------------------------------------------------ управление из SepJob

    /** Запускает сервис и показывает уведомление «Подготовка…». cancel вызывается кнопкой «Отмена» в уведомлении. */
    static void begin(Context ctx, String trackTitle, Runnable cancel) {
        Context app = ctx.getApplicationContext();
        onCancel = cancel;
        active = true;
        lastPct = -2;
        lastText = "";
        title = trackTitle == null || trackTitle.isEmpty() ? "Разделение на дорожки" : trackTitle;
        pending = build(app, 0, true, "Подготовка", "Разделение на дорожки");
        try {
            Intent i = new Intent(app, SepService.class);
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i);
            else app.startService(i);
        } catch (Throwable t) {
            // например, запуск из фона на Android 12+: обработка продолжится, просто без уведомления-сервиса
            Log.w(TAG, "sep service start failed", t);
            active = false;
        }
    }

    /** Обновляет ход обработки. pct < 0 — неопределённый прогресс (подключение к серверу). */
    static void progress(Context ctx, int pct, String head, String sub) {
        if (!active) return;
        if (pct == lastPct && head.equals(lastText)) return;
        lastPct = pct;
        lastText = head;
        Context app = ctx.getApplicationContext();
        String line = pct >= 0 ? head + " · " + pct + " %" : head;
        Notification n = build(app, Math.max(0, pct), pct < 0, line, sub);
        pending = n;
        try {
            NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(ID, n);
        } catch (Throwable t) {
            Log.w(TAG, "sep notify failed", t);
        }
    }

    /** Завершает сервис. DONE/ERROR оставляют обычное уведомление с итогом, CANCELLED его просто убирает. */
    static void finish(Context ctx, int mode, String text) {
        Context app = ctx.getApplicationContext();
        boolean wasActive = active;
        active = false;
        pending = null;
        onCancel = null;
        SepService s = inst;
        if (s != null) s.stopFg();
        else {
            try { app.stopService(new Intent(app, SepService.class)); } catch (Throwable ignored) { }
        }
        if (!wasActive && s == null) return;
        try {
            NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            nm.cancel(ID);
            if (mode == CANCELLED) return;
            ensureChannel(app, nm);
            Notification.Builder b = builder(app);
            b.setSmallIcon(mode == DONE ? android.R.drawable.stat_sys_download_done : android.R.drawable.stat_notify_error)
                    .setContentTitle(mode == DONE ? "Разделение завершено" : "Не удалось разделить трек")
                    .setContentText(text == null || text.isEmpty() ? title : text)
                    .setOngoing(false)
                    .setAutoCancel(true)
                    .setShowWhen(true)
                    .setCategory(mode == DONE ? Notification.CATEGORY_STATUS : Notification.CATEGORY_ERROR);
            PendingIntent open = openApp(app);
            if (open != null) b.setContentIntent(open);
            nm.notify(ID_RESULT, b.build());
        } catch (Throwable t) {
            Log.w(TAG, "sep result notify failed", t);
        }
    }

    // ------------------------------------------------------------------ уведомление

    private static void ensureChannel(Context c, NotificationManager nm) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Разделение на дорожки", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    private static Notification.Builder builder(Context c) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
    }

    private static PendingIntent openApp(Context c) {
        Intent launch = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (launch == null) return null;
        launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(c, 0, launch, fl);
    }

    private static Notification build(Context c, int pct, boolean indeterminate, String text, String sub) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) ensureChannel(c, nm);
        } catch (Throwable ignored) { }
        Notification.Builder b = builder(c);
        b.setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle(title)
                .setContentText(text)
                .setSubText(sub)
                .setProgress(100, pct, indeterminate)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        PendingIntent open = openApp(c);
        if (open != null) b.setContentIntent(open);
        Intent ci = new Intent(c, SepService.class).setAction(ACT_CANCEL);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent cancel = PendingIntent.getService(c, 1, ci, fl);
        b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_close_clear_cancel), "Отмена", cancel).build());
        return b.build();
    }

    // ------------------------------------------------------------------ жизненный цикл сервиса

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACT_CANCEL.equals(intent.getAction())) {
            Runnable r = onCancel;
            if (r != null) {
                try { r.run(); } catch (Throwable t) { Log.w(TAG, "sep cancel failed", t); }
            }
            if (!active) stopSelf();
            return START_NOT_STICKY;
        }
        Notification n = pending;
        if (n == null) n = build(this, 0, true, "Подготовка", "Разделение на дорожки");
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, TYPE_DATA_SYNC);
            else startForeground(ID, n);
        } catch (Throwable t) {
            // нет разрешения/типа в манифесте: обработка идёт и без сервиса
            Log.w(TAG, "sep startForeground failed", t);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!active) stopFg(); // обработка успела закончиться, пока сервис запускался
        return START_NOT_STICKY;
    }

    private void stopFg() {
        try {
            stopForeground(true);
        } catch (Throwable ignored) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

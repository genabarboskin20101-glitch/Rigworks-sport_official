package kx.engine;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;

/**
 * Делает приложение «аудиоплеером» для системы: MediaSession (экран блокировки, плитка медиа в шторке,
 * кнопки гарнитур и Bluetooth) и уведомление в стиле MediaStyle с обложкой и кнопками «назад / пауза / вперёд».
 * Страница передаёт данные через KExport.mediaSet()/mediaState()/mediaClear(), а команды из системы
 * приходят обратно вызовом window.__kxMedia('play'|'pause'|'next'|'prev'|'seek', позиция_мс).
 * Для показа уведомления на Android 13+ в билдере нужна галочка «Уведомления» (POST_NOTIFICATIONS).
 */
final class MediaNotif {
    interface Sink { void action(String name, long posMs); }

    private static final String TAG = "KX";
    static final String CHANNEL = "kx_media";
    private static final String PFX = "kx.engine.MEDIA.";
    static final int ID = 7301;
    private static final int REQ_PERM = 7302;

    private volatile Activity act;
    private final Sink sink;
    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaSession session;
    private BroadcastReceiver receiver;
    private Icon iPrev, iNext, iPlay, iPause, iSmall, iFavOn, iFavOff, iClose;
    private String title = "", artist = "", album = "";
    private long durMs;
    private long posMs;
    private boolean playing;
    private boolean started;
    private boolean askedPerm;
    private Bitmap art;
    private boolean fav;
    /** Момент (elapsedRealtime), к которому относится posMs: между сообщениями страницы позицию считаем сами. */
    private long posAt;
    private String artKey = "";

    MediaNotif(Activity a, Sink s) {
        act = a;
        sink = s;
    }

    /** Приложение открыли заново (новая Activity подхватила живую страницу). */
    void setActivity(Activity a) {
        act = a;
        askedPerm = false;
    }

    /** Текущая позиция воспроизведения (мс): при игре — последняя сообщённая + прошедшее время. */
    private long curPos() {
        long p = posMs;
        if (playing) p += Math.max(0L, SystemClock.elapsedRealtime() - posAt);
        if (durMs > 0 && p > durMs) p = durMs;
        return Math.max(0L, p);
    }

    /** Новый трек: название, исполнитель, альбом, длительность и обложка (JPEG в base64, может быть пустой). */
    void set(final String t, final String a, final String al, final long d, String artB64) {
        final String key = artB64 == null ? "" : artB64;
        Bitmap b = null;
        final boolean artChanged = !key.equals(artKey);
        if (artChanged) {
            try {
                if (key.length() > 0) {
                    byte[] raw = Base64.decode(key, Base64.DEFAULT);
                    b = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                }
            } catch (Throwable ignored) {
                // без обложки
            }
        }
        final Bitmap fb = b;
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    String nt = t == null ? "" : t, na = a == null ? "" : a, nal = al == null ? "" : al;
                    long nd = Math.max(0L, d);
                    boolean same = started && nt.equals(title) && na.equals(artist) && nal.equals(album);
                    if (same && nd == durMs && !artChanged) return; // ничего нового: не дёргаем систему повторно
                    if (!same) {
                        posMs = 0L; // другой трек: позицию пришлёт страница следом
                        posAt = SystemClock.elapsedRealtime();
                    }
                    title = nt;
                    artist = na;
                    album = nal;
                    durMs = nd;
                    if (artChanged) {
                        art = fb;
                        artKey = key;
                    }
                    started = true;
                    ensure();
                    publishMeta();
                    publishPlayback();
                    if (!same || artChanged) notifyShade();
                } catch (Throwable e) {
                    Log.w(TAG, "media set failed", e);
                }
            }
        });
    }

    /** Играет/пауза и позиция (мс): вызывается при смене состояния и перемотке. Уведомление пересобираем только при смене «играет/пауза». */
    void state(final boolean pl, final long pos) {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    boolean changed = pl != playing;
                    playing = pl;
                    posMs = Math.max(0L, pos);
                    posAt = SystemClock.elapsedRealtime();
                    if (!started) return;
                    ensure();
                    publishPlayback();
                    if (changed) notifyShade();
                } catch (Throwable e) {
                    Log.w(TAG, "media state failed", e);
                }
            }
        });
    }

    /** В уведомлении есть трек (играет или на паузе). */
    boolean active() {
        return started;
    }

    /** Очередь пуста / трек сброшен: убираем уведомление. */
    void clear() {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    started = false;
                    playing = false;
                    artKey = "";
                    art = null;
                    title = "";
                    MediaService.stop(act.getApplicationContext());
                    NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null) nm.cancel(ID);
                    if (session != null) session.setActive(false);
                } catch (Throwable e) {
                    Log.w(TAG, "media clear failed", e);
                }
            }
        });
    }

    /** Текущий трек в избранном (сердце в уведомлении закрашено). */
    void fav(final boolean f) {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (f == fav) return;
                    fav = f;
                    if (!started) return;
                    ensure();
                    publishPlayback();
                    notifyShade();
                } catch (Throwable e) {
                    Log.w(TAG, "media fav failed", e);
                }
            }
        });
    }

    void release() {
        try {
            MediaService.stop(act.getApplicationContext());
        } catch (Throwable ignored) {
            // сервис не запущен
        }
        try {
            NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(ID);
        } catch (Throwable ignored) {
            // нечего отменять
        }
        try {
            if (receiver != null) act.getApplicationContext().unregisterReceiver(receiver);
        } catch (Throwable ignored) {
            // уже снят
        }
        receiver = null;
        try {
            if (session != null) {
                session.setActive(false);
                session.release();
            }
        } catch (Throwable ignored) {
            // уже освобождена
        }
        session = null;
    }

    @SuppressWarnings("deprecation")
    private void ensure() {
        if (session != null) return;
        Context c = act.getApplicationContext();
        session = new MediaSession(c, "LMusic");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() { sink.action("play", 0L); }

            @Override
            public void onPause() { sink.action("pause", 0L); }

            @Override
            public void onStop() { sink.action("pause", 0L); }

            @Override
            public void onSkipToNext() { sink.action("next", 0L); }

            @Override
            public void onSkipToPrevious() { sink.action("prev", 0L); }

            @Override
            public void onSeekTo(long pos) { sink.action("seek", pos); }

            @Override
            public void onCustomAction(String action, android.os.Bundle extras) {
                if (action != null && action.startsWith(PFX)) sink.action(action.substring(PFX.length()), 0L);
            }
        });
        session.setActive(true);
        iPrev = icon(c, 0);
        iNext = icon(c, 1);
        iPlay = icon(c, 2);
        iPause = icon(c, 3);
        iSmall = icon(c, 4);
        iFavOff = icon(c, 5);
        iFavOn = icon(c, 6);
        iClose = icon(c, 7);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Воспроизведение", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
        }
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent i) {
                String a = i == null ? null : i.getAction();
                if (a == null || !a.startsWith(PFX)) return;
                String n = a.substring(PFX.length());
                if ("toggle".equals(n)) n = playing ? "pause" : "play";
                sink.action(n, 0L);
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(PFX + "prev");
        f.addAction(PFX + "next");
        f.addAction(PFX + "toggle");
        f.addAction(PFX + "fav");
        f.addAction(PFX + "close");
        if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(receiver, f, 4); // RECEIVER_NOT_EXPORTED
        else c.registerReceiver(receiver, f);
    }

    private void publishMeta() {
        if (session == null) return;
        MediaMetadata.Builder mb = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, durMs);
        if (art != null) {
            mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
            mb.putBitmap(MediaMetadata.METADATA_KEY_ART, art);
        }
        session.setMetadata(mb.build());
        if (!session.isActive()) session.setActive(true);
    }

    /** Состояние воспроизведения для полосы времени: позиция берётся «на сейчас», а не последняя сообщённая (иначе после любого обновления полоса прыгает назад). */
    private void publishPlayback() {
        if (session == null) return;
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, curPos(), playing ? 1f : 0f, SystemClock.elapsedRealtime())
                // Android 13+: плитка медиа в шторке строит кнопки из PlaybackState
                .addCustomAction(new PlaybackState.CustomAction.Builder(PFX + "fav", fav ? "Убрать из избранного" : "В избранное",
                        favRes(fav)).build())
                .addCustomAction(new PlaybackState.CustomAction.Builder(PFX + "close", "Закрыть",
                        closeRes()).build())
                .build());
    }

    /**
     * Значки для плитки плеера в шторке (Android 13+ строит её кнопки из PlaybackState.CustomAction, а там нужен ресурс
     * приложения, а не Bitmap): векторные ic_notif_fav_on / ic_notif_fav_off / ic_notif_close из res/drawable.
     * Они чёткие на любой плотности экрана и нарисованы по тем же контурам, что и значки в обычном уведомлении.
     */
    private int res(String name, int fallback) {
        try {
            Context c = act.getApplicationContext();
            int id = c.getResources().getIdentifier(name, "drawable", c.getPackageName());
            if (id != 0) return id;
        } catch (Throwable t) {
            Log.w(TAG, "res failed: " + name, t);
        }
        return fallback;
    }

    private int favRes(boolean on) {
        return res(on ? "ic_notif_fav_on" : "ic_notif_fav_off", on ? android.R.drawable.btn_star_big_on : android.R.drawable.btn_star_big_off);
    }

    private int closeRes() {
        return res("ic_notif_close", android.R.drawable.ic_menu_close_clear_cancel);
    }

    private PendingIntent pi(String name) {
        Context c = act.getApplicationContext();
        Intent i = new Intent(PFX + name).setPackage(c.getPackageName());
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, name.hashCode() & 0xffff, i, fl);
    }

    private void notifyShade() {
        try {
            Context c = act.getApplicationContext();
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 33 && !askedPerm
                    && act.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                askedPerm = true;
                act.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_PERM);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
            b.setSmallIcon(iSmall)
                    .setContentTitle(title)
                    .setContentText(artist)
                    .setOngoing(playing)
                    .setOnlyAlertOnce(true)
                    .setShowWhen(false)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_TRANSPORT);
            if (album.length() > 0) b.setSubText(album);
            if (art != null) b.setLargeIcon(art);
            Intent launch = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
                b.setContentIntent(PendingIntent.getActivity(c, 0, launch, fl));
            }
            b.addAction(new Notification.Action.Builder(fav ? iFavOn : iFavOff, fav ? "Убрать из избранного" : "В избранное", pi("fav")).build());
            b.addAction(new Notification.Action.Builder(iPrev, "Назад", pi("prev")).build());
            b.addAction(new Notification.Action.Builder(playing ? iPause : iPlay, playing ? "Пауза" : "Играть", pi("toggle")).build());
            b.addAction(new Notification.Action.Builder(iNext, "Вперёд", pi("next")).build());
            b.addAction(new Notification.Action.Builder(iClose, "Закрыть", pi("close")).build());
            b.setStyle(new Notification.MediaStyle()
                    .setMediaSession(session.getSessionToken())
                    .setShowActionsInCompactView(1, 2, 3));
            Notification n = b.build();
            // уведомление живёт в foreground-сервисе: пока он работает, система не выгружает приложение в фоне
            if (!(started && MediaService.show(c, n, playing))) nm.notify(ID, n);
        } catch (Throwable t) {
            Log.w(TAG, "media notification failed", t);
        }
    }

    /** Простое классическое сердечко (сетка 24×24, без острого «носика» и лишних изгибов). */
    private static void heart(Path path) {
        path.moveTo(12f, 21.35f);
        path.lineTo(10.55f, 20.03f);
        path.cubicTo(5.4f, 15.36f, 2f, 12.28f, 2f, 8.5f);
        path.cubicTo(2f, 5.42f, 4.42f, 3f, 7.5f, 3f);
        path.cubicTo(9.24f, 3f, 10.91f, 3.81f, 12f, 5.09f);
        path.cubicTo(13.09f, 3.81f, 14.76f, 3f, 16.5f, 3f);
        path.cubicTo(19.58f, 3f, 22f, 5.42f, 22f, 8.5f);
        path.cubicTo(22f, 12.28f, 18.6f, 15.36f, 13.45f, 20.04f);
        path.lineTo(12f, 21.35f);
        path.close();
    }

    /** Простые белые значки, нарисованные кодом (ресурсов в оболочке нет). */
    private static Icon icon(Context ctx, int kind) {
        // значок в уведомлении показывается в 24dp: рисуем сразу в точный размер в пикселях, иначе система масштабирует
        // картинку и линии «мылятся» (особенно тонкие, как у крестика); внутри рисуем в привычной сетке 96×96
        int s = Math.max(48, Math.round(24f * ctx.getResources().getDisplayMetrics().density));
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.scale(s / 96f, s / 96f);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFFFFFFF);
        Path path = new Path();
        switch (kind) {
            case 0: // назад
                c.drawRect(22f, 24f, 32f, 72f, p);
                path.moveTo(74f, 24f);
                path.lineTo(74f, 72f);
                path.lineTo(36f, 48f);
                path.close();
                c.drawPath(path, p);
                break;
            case 1: // вперёд
                c.drawRect(64f, 24f, 74f, 72f, p);
                path.moveTo(22f, 24f);
                path.lineTo(22f, 72f);
                path.lineTo(60f, 48f);
                path.close();
                c.drawPath(path, p);
                break;
            case 2: // играть
                path.moveTo(30f, 18f);
                path.lineTo(30f, 78f);
                path.lineTo(80f, 48f);
                path.close();
                c.drawPath(path, p);
                break;
            case 3: // пауза
                c.drawRect(26f, 20f, 44f, 76f, p);
                c.drawRect(52f, 20f, 70f, 76f, p);
                break;
            case 5: // сердце (контур): трек не в избранном
                c.translate(48f, 48f);
                c.scale(4f * 0.78f, 4f * 0.78f);
                c.translate(-12f, -12.2f);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.3f);
                p.setStrokeJoin(Paint.Join.ROUND);
                heart(path);
                c.drawPath(path, p);
                break;
            case 6: // сердце (залито): трек в избранном
                c.translate(48f, 48f);
                c.scale(4f * 0.78f, 4f * 0.78f);
                c.translate(-12f, -12.2f);
                heart(path);
                c.drawPath(path, p);
                break;
            case 7: // крестик: по размеру как соседние значки
                c.scale(4f, 4f);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.2f);
                p.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(7f, 7f, 17f, 17f, p);
                c.drawLine(17f, 7f, 7f, 17f, p);
                break;
            default: // нота (маленький значок уведомления)
                c.drawCircle(34f, 70f, 15f, p);
                c.drawRect(45f, 16f, 54f, 70f, p);
                path.moveTo(54f, 16f);
                path.lineTo(80f, 28f);
                path.lineTo(80f, 44f);
                path.lineTo(54f, 32f);
                path.close();
                c.drawPath(path, p);
                break;
        }
        return Icon.createWithBitmap(b);
    }
}

package kx.engine;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;

/**
 * Делает приложение «аудиоплеером» для системы: MediaSession (экран блокировки, плитка медиа в шторке,
 * кнопки гарнитур и Bluetooth) и уведомление в стиле MediaStyle с обложкой и кнопками «назад / пауза / вперёд».
 * Страница передаёт данные через KExport.mediaSet()/mediaState()/mediaClear(), а команды из системы
 * приходят обратно вызовом window.__kxMedia('play'|'pause'|'next'|'prev'|'seek', позиция_мс).
 * Для показа уведомления на Android 13+ в билдере нужна галочка «Уведомления» (POST_NOTIFICATIONS).
 */
final class MediaNotif {
    interface Sink { void action(String name, long posMs); }

    private static final String TAG = "KX";
    static final String CHANNEL = "kx_media";
    private static final String PFX = "kx.engine.MEDIA.";
    static final int ID = 7301;
    private static final int REQ_PERM = 7302;

    private final Activity act;
    private final Sink sink;
    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaSession session;
    private Icon iPrev, iNext, iPlay, iPause, iSmall, iFavOn, iFavOff, iClose;
    private String title = "", artist = "", album = "";
    private long durMs;
    private long posMs;
    private boolean playing;
    private boolean started;
    private boolean askedPerm;
    private Bitmap art;
    private boolean fav;

    MediaNotif(Activity a, Sink s) {
        act = a;
        sink = s;
    }

    /** Новый трек: название, исполнитель, альбом, длительность и обложка (JPEG в base64, может быть пустой). */
    void set(final String t, final String a, final String al, final long d, String artB64) {
        Bitmap b = null;
        try {
            if (artB64 != null && artB64.length() > 0) {
                byte[] raw = Base64.decode(artB64, Base64.DEFAULT);
                b = BitmapFactory.decodeByteArray(raw, 0, raw.length);
            }
        } catch (Throwable ignored) {
            // без обложки
        }
        final Bitmap fb = b;
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    title = t == null ? "" : t;
                    artist = a == null ? "" : a;
                    album = al == null ? "" : al;
                    durMs = Math.max(0L, d);
                    posMs = 0L;
                    art = fb;
                    started = true;
                    ensure();
                    publish();
                } catch (Throwable e) {
                    Log.w(TAG, "media set failed", e);
                }
            }
        });
    }

    /** Играет/пауза и позиция (мс): вызывается при смене состояния и перемотке. */
    void state(final boolean pl, final long pos) {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    playing = pl;
                    posMs = Math.max(0L, pos);
                    if (!started) return;
                    ensure();
                    publish();
                } catch (Throwable e) {
                    Log.w(TAG, "media state failed", e);
                }
            }
        });
    }

    /** В уведомлении есть трек (играет или на паузе). */
    boolean active() {
        return started;
    }

    /** Очередь пуста / трек сброшен: убираем уведомление. */
    void clear() {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    started = false;
                    playing = false;
                    MediaService.clearMetadata(act.getApplicationContext());
                    MediaService.stop(act.getApplicationContext());
                    NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null) nm.cancel(ID);
                    if (session != null) session.setActive(false);
                } catch (Throwable e) {
                    Log.w(TAG, "media clear failed", e);
                }
            }
        });
    }

    /** Текущий трек в избранном (сердце в уведомлении закрашено). */
    void fav(final boolean f) {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    fav = f;
                    if (!started) return;
                    ensure();
                    publish();
                } catch (Throwable e) {
                    Log.w(TAG, "media fav failed", e);
                }
            }
        });
    }

    void release() {
        try {
            MediaService.stop(act.getApplicationContext());
        } catch (Throwable ignored) {
            // сервис не запущен
        }
        try {
            NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(ID);
        } catch (Throwable ignored) {
            // нечего отменять
        }
        try {
            if (session != null) {
                session.setActive(false);
                session.release();
            }
        } catch (Throwable ignored) {
            // уже освобождена
        }
        session = null;
    }

    @SuppressWarnings("deprecation")
    private void ensure() {
        if (session != null) return;
        Context c = act.getApplicationContext();
        session = new MediaSession(c, "LMusic");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() { sink.action("play", 0L); }

            @Override
            public void onPause() { sink.action("pause", 0L); }

            @Override
            public void onStop() { sink.action("pause", 0L); }

            @Override
            public void onSkipToNext() { sink.action("next", 0L); }

            @Override
            public void onSkipToPrevious() { sink.action("prev", 0L); }

            @Override
            public void onSeekTo(long pos) { sink.action("seek", pos); }

            @Override
            public void onCustomAction(String action, android.os.Bundle extras) {
                if (action != null && action.startsWith(PFX)) sink.action(action.substring(PFX.length()), 0L);
            }
        });
        session.setActive(true);
        iPrev = icon(0);
        iNext = icon(1);
        iPlay = icon(2);
        iPause = icon(3);
        iSmall = icon(4);
        iFavOff = icon(5);
        iFavOn = icon(6);
        iClose = icon(7);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Воспроизведение", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void publish() {
        if (session == null) return;
        // метаданные
        MediaMetadata.Builder mb = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, durMs);
        if (art != null) {
            mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
            mb.putBitmap(MediaMetadata.METADATA_KEY_ART, art);
        }
        session.setMetadata(mb.build());
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, posMs, playing ? 1f : 0f, SystemClock.elapsedRealtime())
                        // Android 13+: плитка медиа в шторке строит кнопки из PlaybackState; значки — системные (своих ресурсов в оболочке нет)
                        .addCustomAction(new PlaybackState.CustomAction.Builder(PFX + "fav", fav ? "Убрать из избранного" : "В избранное",
                                favRes(fav)).build())
                        .addCustomAction(new PlaybackState.CustomAction.Builder(PFX + "close", "Закрыть",
                                android.R.drawable.ic_menu_close_clear_cancel).build())
                        .build());
        session.setActive(true);
        notifyShade();
    }

    /** Был ли подменён значок сердца в шаблоне (билдер кладёт маркер assets/kx_fav_icons вместе с белыми PNG-сердечками). */
    private Boolean favIcons;

    /**
     * Значок «в избранное» для плитки плеера в шторке (Android 13+ строит её кнопки из PlaybackState.CustomAction, а там
     * нужен ресурс приложения, а не Bitmap). Билдер подменяет содержимое двух неиспользуемых PNG шаблона белыми сердечками:
     * abc_ic_commit_search_api_mtrl_alpha — контур (не в избранном), abc_scrubber_control_off_mtrl_alpha — закрашенное (в избранном).
     * Если маркера нет (старый билдер) — прежние системные звёзды, чтобы не показать случайный чужой значок.
     */
    private int favRes(boolean on) {
        try {
            Context c = act.getApplicationContext();
            if (favIcons == null) {
                boolean ok = false;
                try {
                    c.getAssets().open("kx_fav_icons").close();
                    ok = true;
                } catch (Throwable ignored) {
                    // маркера нет
                }
                favIcons = ok;
            }
            if (favIcons) {
                int id = c.getResources().getIdentifier(on ? "abc_scrubber_control_off_mtrl_alpha" : "abc_ic_commit_search_api_mtrl_alpha",
                        "drawable", c.getPackageName());
                if (id != 0) return id;
            }
        } catch (Throwable t) {
            Log.w(TAG, "favRes failed", t);
        }
        return on ? android.R.drawable.btn_star_big_on : android.R.drawable.btn_star_big_off;
    }

    private PendingIntent pi(String name) {
        Context c = act.getApplicationContext();
        Intent i = new Intent(c, MediaActionReceiver.class).setAction(PFX + name);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, name.hashCode() & 0xffff, i, fl);
    }

    private void notifyShade() {
        try {
            Context c = act.getApplicationContext();
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 33 && !askedPerm
                    && act.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                askedPerm = true;
                act.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_PERM);
            }
            // Keep enough metadata to rebuild functional buttons if an OEM kills the app process.
            MediaService.saveMetadata(c, title, artist, album, playing, fav);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
            b.setSmallIcon(iSmall)
                    .setContentTitle(title)
                    .setContentText(artist)
                    .setOngoing(playing)
                    .setOnlyAlertOnce(true)
                    .setShowWhen(false)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_TRANSPORT);
            if (album.length() > 0) b.setSubText(album);
            if (art != null) b.setLargeIcon(art);
            Intent launch = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
                b.setContentIntent(PendingIntent.getActivity(c, 0, launch, fl));
            }
            b.addAction(new Notification.Action.Builder(fav ? iFavOn : iFavOff, fav ? "Убрать из избранного" : "В избранное", pi("fav")).build());
            b.addAction(new Notification.Action.Builder(iPrev, "Назад", pi("prev")).build());
            b.addAction(new Notification.Action.Builder(playing ? iPause : iPlay, playing ? "Пауза" : "Играть", pi(playing ? "pause" : "play")).build());
            b.addAction(new Notification.Action.Builder(iNext, "Вперёд", pi("next")).build());
            b.addAction(new Notification.Action.Builder(iClose, "Закрыть", pi("close")).build());
            b.setStyle(new Notification.MediaStyle()
                    .setMediaSession(session.getSessionToken())
                    .setShowActionsInCompactView(1, 2, 3));
            Notification n = b.build();
            // уведомление живёт в foreground-сервисе: пока он работает, система не выгружает приложение в фоне
            if (!(started && MediaService.show(c, n, playing))) nm.notify(ID, n);
        } catch (Throwable t) {
            Log.w(TAG, "media notification failed", t);
        }
    }

    private static void heart(Path path) {
        path.moveTo(48f, 80f);
        path.cubicTo(10f, 54f, 14f, 20f, 36f, 20f);
        path.cubicTo(43f, 20f, 47f, 24f, 48f, 29f);
        path.cubicTo(49f, 24f, 53f, 20f, 60f, 20f);
        path.cubicTo(82f, 20f, 86f, 54f, 48f, 80f);
        path.close();
    }

    /** Простые белые значки, нарисованные кодом (ресурсов в оболочке нет). */
    private static Icon icon(int kind) {
        int s = 96;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFFFFFFF);
        Path path = new Path();
        switch (kind) {
            case 0: // назад
                c.drawRect(22f, 24f, 32f, 72f, p);
                path.moveTo(74f, 24f);
                path.lineTo(74f, 72f);
                path.lineTo(36f, 48f);
                path.close();
                c.drawPath(path, p);
                break;
            case 1: // вперёд
                c.drawRect(64f, 24f, 74f, 72f, p);
                path.moveTo(22f, 24f);
                path.lineTo(22f, 72f);
                path.lineTo(60f, 48f);
                path.close();
                c.drawPath(path, p);
                break;
            case 2: // играть
                path.moveTo(30f, 18f);
                path.lineTo(30f, 78f);
                path.lineTo(80f, 48f);
                path.close();
                c.drawPath(path, p);
                break;
            case 3: // пауза
                c.drawRect(26f, 20f, 44f, 76f, p);
                c.drawRect(52f, 20f, 70f, 76f, p);
                break;
            case 5: // сердце (контур): трек не в избранном
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(7f);
                p.setStrokeJoin(Paint.Join.ROUND);
                heart(path);
                c.drawPath(path, p);
                break;
            case 6: // сердце (залито): трек в избранном
                heart(path);
                c.drawPath(path, p);
                break;
            case 7: // крестик
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(9f);
                p.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(28f, 28f, 68f, 68f, p);
                c.drawLine(68f, 28f, 28f, 68f, p);
                break;
            default: // нота (маленький значок уведомления)
                c.drawCircle(34f, 70f, 15f, p);
                c.drawRect(45f, 16f, 54f, 70f, p);
                path.moveTo(54f, 16f);
                path.lineTo(80f, 28f);
                path.lineTo(80f, 44f);
                path.lineTo(54f, 32f);
                path.close();
                c.drawPath(path, p);
                break;
        }
        return Icon.createWithBitmap(b);
    }
}

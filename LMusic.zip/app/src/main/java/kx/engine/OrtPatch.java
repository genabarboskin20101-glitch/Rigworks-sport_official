package kx.engine;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Правка файла модели .onnx на месте: у ONNX Runtime на CPU нет ядра EyeLike для части типов (bool, float16 и т. д.),
 * поэтому каждый такой узел заменяется цепочкой Cast(int64) → EyeLike(int64) → Cast(обратно в нужный тип).
 * Файл читается через memory-map (в куче Java не копируется), переписываются только узлы графа.
 */
final class OrtPatch {
    private OrtPatch() { }

    // ---------------------------------------------------------------- protobuf: чтение
    private static final class Pos { int p; }

    private static long varint(ByteBuffer b, Pos o) {
        long r = 0;
        int sh = 0;
        while (true) {
            int x = b.get(o.p++) & 0xFF;
            r |= (long) (x & 0x7F) << sh;
            if ((x & 0x80) == 0) return r;
            sh += 7;
        }
    }

    // ---------------------------------------------------------------- protobuf: запись
    private static void wVarint(ByteArrayOutputStream o, long v) {
        while ((v & ~0x7FL) != 0) { o.write((int) ((v & 0x7F) | 0x80)); v >>>= 7; }
        o.write((int) v);
    }

    private static void wTag(ByteArrayOutputStream o, int field, int wire) { wVarint(o, ((long) field << 3) | wire); }

    private static void wBytes(ByteArrayOutputStream o, int field, byte[] d) {
        wTag(o, field, 2);
        wVarint(o, d.length);
        o.write(d, 0, d.length);
    }

    private static void wStr(ByteArrayOutputStream o, int field, String s) { wBytes(o, field, s.getBytes(StandardCharsets.UTF_8)); }

    private static byte[] attrInt(String name, long v) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        wStr(o, 1, name);
        wTag(o, 3, 0); wVarint(o, v);
        wTag(o, 20, 0); wVarint(o, 2); // type = INT
        return o.toByteArray();
    }

    private static byte[] node(String op, String name, String in0, String in1, String out, List<byte[]> attrs) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        wStr(o, 1, in0);
        if (in1 != null) wStr(o, 1, in1);
        wStr(o, 2, out);
        wStr(o, 3, name);
        wStr(o, 4, op);
        if (attrs != null) for (byte[] a : attrs) wBytes(o, 5, a);
        return o.toByteArray();
    }

    // ---------------------------------------------------------------- разбор узла
    private static final class Rep { int start, end; byte[] data; }

    /** Возвращает заменяющие узлы (уже с тегом поля 1 графа) или null, если узел не EyeLike. */
    private static byte[] rewrite(byte[] n, boolean castLikeOk) {
        ByteBuffer b = ByteBuffer.wrap(n);
        Pos o = new Pos();
        String op = null, name = "", domain = "";
        List<String> ins = new ArrayList<>(), outs = new ArrayList<>();
        List<byte[]> keep = new ArrayList<>();
        long dtype = -1;
        while (o.p < n.length) {
            long tag = varint(b, o);
            int f = (int) (tag >>> 3), w = (int) (tag & 7);
            if (w == 2) {
                int len = (int) varint(b, o);
                int s = o.p;
                o.p += len;
                byte[] d = java.util.Arrays.copyOfRange(n, s, s + len);
                if (f == 1) ins.add(new String(d, StandardCharsets.UTF_8));
                else if (f == 2) outs.add(new String(d, StandardCharsets.UTF_8));
                else if (f == 3) name = new String(d, StandardCharsets.UTF_8);
                else if (f == 4) op = new String(d, StandardCharsets.UTF_8);
                else if (f == 7) domain = new String(d, StandardCharsets.UTF_8);
                else if (f == 5) {
                    // атрибут: ищем dtype, остальные сохраняем (например, k)
                    ByteBuffer ab = ByteBuffer.wrap(d);
                    Pos ap = new Pos();
                    String an = "";
                    long iv = 0;
                    while (ap.p < d.length) {
                        long at = varint(ab, ap);
                        int af = (int) (at >>> 3), aw = (int) (at & 7);
                        if (aw == 0) { long v = varint(ab, ap); if (af == 3) iv = v; }
                        else if (aw == 2) { int l = (int) varint(ab, ap); if (af == 1) an = new String(d, ap.p, l, StandardCharsets.UTF_8); ap.p += l; }
                        else if (aw == 1) ap.p += 8;
                        else if (aw == 5) ap.p += 4;
                        else return null;
                    }
                    if ("dtype".equals(an)) dtype = iv; else keep.add(d);
                }
            } else if (w == 0) varint(b, o);
            else if (w == 1) o.p += 8;
            else if (w == 5) o.p += 4;
            else return null;
        }
        if (!"EyeLike".equals(op) || !domain.isEmpty() || ins.isEmpty() || outs.isEmpty()) return null;
        if (ins.get(0).endsWith("__lm_i")) return null; // уже исправлен
        if (dtype < 0 && !castLikeOk) return null;
        String base = name.isEmpty() ? outs.get(0) : name;
        String a = base + "__lm_i", e = base + "__lm_e";
        List<byte[]> eyeAttrs = new ArrayList<>(keep);
        eyeAttrs.add(attrInt("dtype", 7)); // int64: для него ядро есть
        List<byte[]> c1 = new ArrayList<>();
        c1.add(attrInt("to", 7));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        wBytes(out, 1, node("Cast", base + "__lm_cast_in", ins.get(0), null, a, c1));
        wBytes(out, 1, node("EyeLike", base, a, null, e, eyeAttrs));
        if (dtype >= 0) {
            List<byte[]> c2 = new ArrayList<>();
            c2.add(attrInt("to", dtype));
            wBytes(out, 1, node("Cast", base + "__lm_cast_out", e, null, outs.get(0), c2));
        } else {
            wBytes(out, 1, node("CastLike", base + "__lm_castlike", e, ins.get(0), outs.get(0), null));
        }
        return out.toByteArray();
    }

    // ---------------------------------------------------------------- основной проход
    /** @return true, если файл изменён (найдены и заменены узлы EyeLike). */
    static boolean fixEyeLike(File src) throws IOException {
        File tmp = new File(src.getParentFile(), src.getName() + ".patch");
        try (RandomAccessFile raf = new RandomAccessFile(src, "r"); FileChannel ch = raf.getChannel()) {
            long size = ch.size();
            if (size > Integer.MAX_VALUE - 16) return false;
            MappedByteBuffer m = ch.map(FileChannel.MapMode.READ_ONLY, 0, size);
            Pos o = new Pos();
            int graphTag = -1, graphStart = -1, graphEnd = -1, opset = 0;
            while (o.p < size) {
                int tagPos = o.p;
                long tag = varint(m, o);
                int f = (int) (tag >>> 3), w = (int) (tag & 7);
                if (w == 2) {
                    int len = (int) varint(m, o);
                    if (f == 7 && graphTag < 0) { graphTag = tagPos; graphStart = o.p; graphEnd = o.p + len; }
                    else if (f == 8) {
                        // opset_import: domain(1), version(2)
                        Pos q = new Pos(); q.p = o.p;
                        int end = o.p + len; String dom = ""; long ver = 0;
                        while (q.p < end) {
                            long t = varint(m, q); int qf = (int) (t >>> 3), qw = (int) (t & 7);
                            if (qw == 0) { long v = varint(m, q); if (qf == 2) ver = v; }
                            else if (qw == 2) { int l = (int) varint(m, q); if (qf == 1) { byte[] d = new byte[l]; for (int i = 0; i < l; i++) d[i] = m.get(q.p + i); dom = new String(d, StandardCharsets.UTF_8); } q.p += l; }
                            else break;
                        }
                        if (dom.isEmpty() || dom.equals("ai.onnx")) opset = (int) ver;
                    }
                    o.p += len;
                } else if (w == 0) varint(m, o);
                else if (w == 1) o.p += 8;
                else if (w == 5) o.p += 4;
                else return false;
            }
            if (graphTag < 0) return false;
            boolean castLikeOk = opset >= 15;
            // узлы графа
            List<Rep> reps = new ArrayList<>();
            o.p = graphStart;
            while (o.p < graphEnd) {
                int tagPos = o.p;
                long tag = varint(m, o);
                int f = (int) (tag >>> 3), w = (int) (tag & 7);
                if (w == 2) {
                    int len = (int) varint(m, o);
                    if (f == 1 && len < (1 << 20)) {
                        byte[] nb = new byte[len];
                        for (int i = 0; i < len; i++) nb[i] = m.get(o.p + i);
                        // быстрый отбор: в узле должно встретиться слово EyeLike
                        if (indexOf(nb, "EyeLike".getBytes(StandardCharsets.US_ASCII)) >= 0) {
                            byte[] r = rewrite(nb, castLikeOk);
                            if (r != null) { Rep rp = new Rep(); rp.start = tagPos; rp.end = o.p + len; rp.data = r; reps.add(rp); }
                        }
                    }
                    o.p += len;
                } else if (w == 0) varint(m, o);
                else if (w == 1) o.p += 8;
                else if (w == 5) o.p += 4;
                else return false;
            }
            if (reps.isEmpty()) return false;
            long delta = 0;
            for (Rep r : reps) delta += r.data.length - (r.end - r.start);
            long newGraphLen = (graphEnd - graphStart) + delta;
            try (FileOutputStream fo = new FileOutputStream(tmp); FileChannel oc = fo.getChannel()) {
                write(oc, m, 0, graphTag);
                ByteArrayOutputStream h = new ByteArrayOutputStream();
                wTag(h, 7, 2); wVarint(h, newGraphLen);
                oc.write(ByteBuffer.wrap(h.toByteArray()));
                int cur = graphStart;
                for (Rep r : reps) {
                    write(oc, m, cur, r.start);
                    oc.write(ByteBuffer.wrap(r.data));
                    cur = r.end;
                }
                write(oc, m, cur, (int) size);
                oc.force(false);
            }
        } catch (IOException | RuntimeException e) {
            tmp.delete();
            throw e instanceof IOException ? (IOException) e : new IOException("onnx_patch_failed: " + e);
        }
        if (!src.delete() || !tmp.renameTo(src)) { tmp.delete(); throw new IOException("onnx_patch_publish_failed"); }
        return true;
    }

    private static void write(FileChannel oc, MappedByteBuffer m, int from, int to) throws IOException {
        if (to <= from) return;
        ByteBuffer d = m.duplicate();
        d.position(from);
        d.limit(to);
        while (d.hasRemaining()) oc.write(d);
    }

    private static int indexOf(byte[] h, byte[] n) {
        outer:
        for (int i = 0; i + n.length <= h.length; i++) {
            for (int j = 0; j < n.length; j++) if (h[i + j] != n[j]) continue outer;
            return i;
        }
        return -1;
    }

    // для проверки на ПК: java kx.engine.OrtPatch model.onnx
    public static void main(String[] a) throws Exception { System.out.println(fixEyeLike(new File(a[0]))); }
}

package kx.engine;

import java.util.ArrayList;

/**
 * Чистая DSP-часть нативного аудио-движка LMusic (без Android API, чтобы её можно было тестировать на обычной JVM).
 * Повторяет цепочку страницы: preamp -> 10-полосный эквалайзер -> бас -> виртуализатор -> громкость -> баланс -> реверб -> лимитер -> анализатор,
 * а также автоматизацию параметров (AudioParam) для кросс-фейда.
 */
final class AudioDsp {
    private AudioDsp() {
    }

    static double db2lin(double db) {
        return Math.pow(10.0, db / 20.0);
    }

    static double lin2db(double x) {
        return 20.0 * Math.log10(x);
    }

    // ------------------------------------------------------------------------------------------------
    // Автоматизация параметра (подмножество Web Audio AudioParam). Время — секунды часов микшера.
    // ------------------------------------------------------------------------------------------------
    static final class AutoParam {
        private static final int NONE = 0, RAMP = 1, CURVE = 2, TARGET = 3;
        private static final int EV_SET = 0, EV_LINEAR = 1, EV_CURVE = 2, EV_TARGET = 3;

        private static final class Ev {
            int type;
            double start, time, v, extra;
            float[] curve;
        }

        private double cur;
        private int seg = NONE;
        private double t0, t1, v0, v1, tc;
        private float[] curve;
        private double lastT = 0;
        private final ArrayList<Ev> q = new ArrayList<Ev>();

        AutoParam(double initial) {
            cur = initial;
        }

        /** Значение в момент t (t не должно убывать между вызовами; меньшее значение приравнивается к предыдущему). */
        synchronized double valueAt(double t) {
            if (t < lastT) t = lastT;
            lastT = t;
            while (!q.isEmpty()) {
                Ev e = q.get(0);
                if (e.start > t) break;
                q.remove(0);
                double v = evalSeg(e.start);
                switch (e.type) {
                    case EV_SET:
                        seg = NONE;
                        cur = e.v;
                        break;
                    case EV_LINEAR:
                        if (e.time <= e.start) {
                            seg = NONE;
                            cur = e.v;
                        } else {
                            seg = RAMP;
                            t0 = e.start;
                            t1 = e.time;
                            v0 = v;
                            v1 = e.v;
                        }
                        break;
                    case EV_CURVE:
                        seg = CURVE;
                        t0 = e.time;
                        t1 = e.time + e.extra;
                        v0 = v;
                        curve = e.curve;
                        break;
                    default:
                        seg = TARGET;
                        t0 = e.time;
                        v0 = v;
                        v1 = e.v;
                        tc = e.extra;
                        break;
                }
            }
            return evalSeg(t);
        }

        private double evalSeg(double t) {
            switch (seg) {
                case RAMP:
                    if (t >= t1) {
                        seg = NONE;
                        cur = v1;
                        return cur;
                    }
                    if (t <= t0) return v0;
                    return v0 + (v1 - v0) * (t - t0) / (t1 - t0);
                case CURVE: {
                    if (t >= t1) {
                        seg = NONE;
                        cur = curve[curve.length - 1];
                        return cur;
                    }
                    if (t <= t0) return curve[0];
                    double pos = (t - t0) / (t1 - t0) * (curve.length - 1);
                    int i = (int) pos;
                    if (i >= curve.length - 1) return curve[curve.length - 1];
                    double f = pos - i;
                    return curve[i] + (curve[i + 1] - curve[i]) * f;
                }
                case TARGET: {
                    if (t <= t0) return v0;
                    double v = v1 + (v0 - v1) * Math.exp(-(t - t0) / tc);
                    if (Math.abs(v - v1) < 1e-7) {
                        seg = NONE;
                        cur = v1;
                        return cur;
                    }
                    return v;
                }
                default:
                    return cur;
            }
        }

        private void insert(Ev e) {
            int i = q.size();
            while (i > 0 && q.get(i - 1).start > e.start) i--;
            q.add(i, e);
        }

        private double lastEventTime() {
            if (!q.isEmpty()) return q.get(q.size() - 1).time;
            return lastT;
        }

        synchronized void setValueAt(double v, double time) {
            Ev e = new Ev();
            e.type = EV_SET;
            e.start = time;
            e.time = time;
            e.v = v;
            insert(e);
        }

        synchronized void linearRampTo(double v, double time) {
            Ev e = new Ev();
            e.type = EV_LINEAR;
            e.start = Math.max(lastEventTime(), lastT);
            e.time = time;
            e.v = v;
            insert(e);
        }

        synchronized void curveAt(float[] c, double time, double dur) {
            if (c == null || c.length < 2 || dur <= 0) {
                setValueAt(c != null && c.length > 0 ? c[c.length - 1] : cur, time);
                return;
            }
            Ev e = new Ev();
            e.type = EV_CURVE;
            e.start = time;
            e.time = time;
            e.extra = dur;
            e.curve = c;
            insert(e);
        }

        synchronized void targetAt(double v, double time, double tconst) {
            if (tconst <= 1e-6) {
                setValueAt(v, time);
                return;
            }
            Ev e = new Ev();
            e.type = EV_TARGET;
            e.start = time;
            e.time = time;
            e.v = v;
            e.extra = tconst;
            insert(e);
        }

        /** cancelScheduledValues / cancelAndHoldAtTime: убирает события с временем >= time; активный участок замораживается на текущем значении. */
        synchronized void cancel(double time) {
            for (int i = q.size() - 1; i >= 0; i--) {
                if (q.get(i).time >= time) q.remove(i);
            }
            if (seg != NONE && time <= lastT + 1e-9) {
                double v = evalSeg(lastT);
                if (seg != NONE) {
                    seg = NONE;
                    cur = v;
                }
            }
        }

        synchronized double current() {
            return evalSeg(lastT);
        }

        synchronized boolean idle() {
            return q.isEmpty() && seg == NONE;
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Биквад (формулы Web Audio: peaking с линейной Q; шельфы без Q, S = 1).
    // ------------------------------------------------------------------------------------------------
    static final class Biquad {
        static final int PEAK = 0, LOW = 1, HIGH = 2;
        final int type;
        final double freq, q, fs;
        double gain, target;
        private double b0 = 1, b1, b2, a1, a2;
        private double lastGain = Double.NaN;
        private final double[] z = new double[4];
        boolean bypass = true;

        Biquad(int type, double freq, double q, double fs) {
            this.type = type;
            this.freq = freq;
            this.q = q;
            this.fs = fs;
        }

        void step(double alpha) {
            gain += (target - gain) * alpha;
            if (Math.abs(target - gain) < 1e-3) gain = target;
            if (gain == 0.0) {
                if (!bypass) {
                    bypass = true;
                    z[0] = z[1] = z[2] = z[3] = 0;
                }
                lastGain = Double.NaN;
                return;
            }
            bypass = false;
            if (gain != lastGain) {
                lastGain = gain;
                coefs(gain);
            }
        }

        private void coefs(double db) {
            double A = Math.pow(10.0, db / 40.0);
            double w0 = 2.0 * Math.PI * freq / fs;
            double cosw = Math.cos(w0), sinw = Math.sin(w0);
            double nb0, nb1, nb2, na0, na1, na2;
            if (type == PEAK) {
                double alpha = sinw / (2.0 * q);
                nb0 = 1 + alpha * A;
                nb1 = -2 * cosw;
                nb2 = 1 - alpha * A;
                na0 = 1 + alpha / A;
                na1 = -2 * cosw;
                na2 = 1 - alpha / A;
            } else {
                double alpha = sinw / 2.0 * Math.sqrt(2.0);
                double k = cosw, k2 = 2.0 * Math.sqrt(A) * alpha;
                double ap = A + 1, am = A - 1;
                if (type == LOW) {
                    nb0 = A * (ap - am * k + k2);
                    nb1 = 2 * A * (am - ap * k);
                    nb2 = A * (ap - am * k - k2);
                    na0 = ap + am * k + k2;
                    na1 = -2 * (am + ap * k);
                    na2 = ap + am * k - k2;
                } else {
                    nb0 = A * (ap + am * k + k2);
                    nb1 = -2 * A * (am + ap * k);
                    nb2 = A * (ap + am * k - k2);
                    na0 = ap - am * k + k2;
                    na1 = 2 * (am - ap * k);
                    na2 = ap - am * k - k2;
                }
            }
            double inv = 1.0 / na0;
            b0 = nb0 * inv;
            b1 = nb1 * inv;
            b2 = nb2 * inv;
            a1 = na1 * inv;
            a2 = na2 * inv;
        }

        void process(float[] l, float[] r, int off, int n) {
            if (bypass) return;
            double z0 = z[0], z1 = z[1], z2 = z[2], z3 = z[3];
            for (int i = off; i < off + n; i++) {
                double x = l[i];
                double y = b0 * x + z0;
                z0 = b1 * x - a1 * y + z1;
                z1 = b2 * x - a2 * y;
                l[i] = (float) y;
                x = r[i];
                y = b0 * x + z2;
                z2 = b1 * x - a1 * y + z3;
                z3 = b2 * x - a2 * y;
                r[i] = (float) y;
            }
            z[0] = Math.abs(z0) < 1e-30 ? 0 : z0;
            z[1] = Math.abs(z1) < 1e-30 ? 0 : z1;
            z[2] = Math.abs(z2) < 1e-30 ? 0 : z2;
            z[3] = Math.abs(z3) < 1e-30 ? 0 : z3;
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Реверберация (Freeverb-подобная, вместо свёртки со случайным импульсом 1.65 с).
    // Уровень выровнен под нормализованную свёртку Web Audio (энергия импульса -> усиление ~0.34 для некоррелированного шума).
    // ------------------------------------------------------------------------------------------------
    static final class Reverb {
        private static final int[] COMB = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
        private static final int[] APF = {556, 441, 341, 225};
        private static final int SPREAD = 23;

        private final float[][] cb = new float[16][];
        private final int[] ci = new int[16];
        private final float[] cs = new float[16];
        private final float[] cfb = new float[16];
        private final float[][] ab = new float[8][];
        private final int[] ai = new int[8];
        private final double fs;
        private volatile double damp = 0.28;
        private final double scale;
        private double currentRt60 = 2.0;

        Reverb(double fs, double rt60, double scale) {
            this.fs = fs;
            this.scale = scale;
            this.currentRt60 = rt60;
            double k = fs / 44100.0;
            for (int ch = 0; ch < 2; ch++) {
                for (int i = 0; i < 8; i++) {
                    int d = (int) Math.round((COMB[i] + ch * SPREAD) * k);
                    cb[ch * 8 + i] = new float[d];
                    cfb[ch * 8 + i] = (float) Math.pow(10.0, -3.0 * d / (rt60 * fs));
                }
                for (int i = 0; i < 4; i++) {
                    int d = (int) Math.round((APF[i] + ch * SPREAD) * k);
                    ab[ch * 4 + i] = new float[d];
                }
            }
        }

        void setParameters(double rt60, double damping) {
            double safeRt = Math.max(0.25, Math.min(5.0, rt60));
            double safeDamp = Math.max(0.02, Math.min(0.92, damping));
            if (Math.abs(currentRt60 - safeRt) > 0.015) {
                currentRt60 = safeRt;
                for (int i = 0; i < 16; i++) {
                    cfb[i] = (float) Math.pow(10.0, -3.0 * cb[i].length / (currentRt60 * fs));
                }
            }
            damp = safeDamp;
        }

        void clear() {
            for (int i = 0; i < 16; i++) {
                java.util.Arrays.fill(cb[i], 0f);
                ci[i] = 0;
                cs[i] = 0f;
            }
            for (int i = 0; i < 8; i++) {
                java.util.Arrays.fill(ab[i], 0f);
                ai[i] = 0;
            }
        }

        /** Вход: l, r. Результат (только мокрый сигнал, с учётом масштаба) пишется в wl, wr. */
        void process(float[] l, float[] r, float[] wl, float[] wr, int off, int n) {
            final float d1 = (float) (damp), d2 = (float) (1.0 - damp);
            for (int i = off; i < off + n; i++) {
                float in = (l[i] + r[i]) * 0.5f;
                float outL = 0f, outR = 0f;
                for (int c = 0; c < 8; c++) {
                    float[] b = cb[c];
                    int p = ci[c];
                    float y = b[p];
                    cs[c] = y * d2 + cs[c] * d1;
                    b[p] = in + cs[c] * cfb[c];
                    if (++p >= b.length) p = 0;
                    ci[c] = p;
                    outL += y;
                    b = cb[8 + c];
                    p = ci[8 + c];
                    y = b[p];
                    cs[8 + c] = y * d2 + cs[8 + c] * d1;
                    b[p] = in + cs[8 + c] * cfb[8 + c];
                    if (++p >= b.length) p = 0;
                    ci[8 + c] = p;
                    outR += y;
                }
                for (int a = 0; a < 4; a++) {
                    float[] b = ab[a];
                    int p = ai[a];
                    float bo = b[p];
                    float o = -outL + bo;
                    b[p] = outL + bo * 0.5f;
                    if (++p >= b.length) p = 0;
                    ai[a] = p;
                    outL = o;
                    b = ab[4 + a];
                    p = ai[4 + a];
                    bo = b[p];
                    o = -outR + bo;
                    b[p] = outR + bo * 0.5f;
                    if (++p >= b.length) p = 0;
                    ai[4 + a] = p;
                    outR = o;
                }
                wl[i] = (float) (outL * scale);
                wr[i] = (float) (outR * scale);
            }
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Лимитер: DynamicsCompressor из Web Audio (threshold -16 дБ, knee 20, ratio 10, attack 3 мс, release 120 мс)
    // со статической кривой и автоматической компенсацией громкости, как в Chromium; огибающая упрощена.
    // ------------------------------------------------------------------------------------------------
    static final class Limiter {
        private final double linThr, kneeThrDb, linKneeThr, slope, k, makeup;
        private final double atk, rel;
        private final float[] dl, dr;
        private int dp = 0;
        private double gain = 1.0;
        private final int look;

        Limiter(double fs, double thrDb, double kneeDb, double ratio, double attack, double release) {
            linThr = db2lin(thrDb);
            kneeThrDb = thrDb + kneeDb;
            linKneeThr = db2lin(kneeThrDb);
            slope = 1.0 / ratio;
            double minK = 0.1, maxK = 10000, kk = 5;
            for (int i = 0; i < 15; i++) {
                if (slopeAt(linKneeThr, kk) < slope) maxK = kk;
                else minK = kk;
                kk = Math.sqrt(minK * maxK);
            }
            k = kk;
            double full = saturate(1.0);
            makeup = Math.pow(1.0 / full, 0.6);
            atk = 1.0 - Math.exp(-1.0 / (attack * fs));
            rel = 1.0 - Math.exp(-1.0 / (release * fs));
            look = Math.max(1, (int) Math.round(0.006 * fs));
            dl = new float[look];
            dr = new float[look];
        }

        private double kneeCurve(double x, double kk) {
            if (x < linThr) return x;
            return linThr + (1.0 - Math.exp(-kk * (x - linThr))) / kk;
        }

        private double slopeAt(double x, double kk) {
            if (x < linThr) return 1.0;
            double x2 = x * 1.001;
            double xd = lin2db(x), x2d = lin2db(x2);
            double y = kneeCurve(x, kk), y2 = kneeCurve(x2, kk);
            return (lin2db(y2) - lin2db(y)) / (x2d - xd);
        }

        double saturate(double x) {
            if (x < linThr) return x;
            if (x < linKneeThr) return kneeCurve(x, k);
            double yKneeDb = lin2db(kneeCurve(linKneeThr, k));
            double yDb = yKneeDb + slope * (lin2db(x) - kneeThrDb);
            return db2lin(yDb);
        }

        double makeupGain() {
            return makeup;
        }

        void process(float[] l, float[] r, int off, int n) {
            for (int i = off; i < off + n; i++) {
                float xl = l[i], xr = r[i];
                double a = Math.max(Math.abs(xl), Math.abs(xr));
                double desired = a <= 1e-4 ? 1.0 : Math.min(1.0, saturate(a) / a);
                if (desired < gain) gain += (desired - gain) * atk;
                else gain += (desired - gain) * rel;
                float ol = dl[dp], or = dr[dp];
                dl[dp] = xl;
                dr[dp] = xr;
                if (++dp >= look) dp = 0;
                double g = gain * makeup;
                l[i] = (float) (ol * g);
                r[i] = (float) (or * g);
            }
        }

        void reset() {
            java.util.Arrays.fill(dl, 0f);
            java.util.Arrays.fill(dr, 0f);
            gain = 1.0;
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Анализатор: БПФ 256 точек, окно Блэкмана, сглаживание 0.3, -100..-30 дБ -> байты 0..255 (как AnalyserNode).
    // ------------------------------------------------------------------------------------------------
    static final class Spectrum {
        static final int N = 256;
        private final float[] ring = new float[N];
        private int rp = 0;
        private final double[] win = new double[N];
        private final double[] re = new double[N], im = new double[N];
        private final double[] smooth = new double[N / 2];
        final byte[] out = new byte[N / 2];

        Spectrum() {
            double a = 0.16, a0 = (1 - a) / 2, a1 = 0.5, a2 = a / 2;
            for (int i = 0; i < N; i++) {
                win[i] = a0 - a1 * Math.cos(2 * Math.PI * i / N) + a2 * Math.cos(4 * Math.PI * i / N);
            }
        }

        void push(float[] l, float[] r, int n) {
            for (int i = 0; i < n; i++) {
                ring[rp] = (l[i] + r[i]) * 0.5f;
                if (++rp >= N) rp = 0;
            }
        }

        void compute() {
            for (int i = 0; i < N; i++) {
                re[i] = ring[(rp + i) % N] * win[i];
                im[i] = 0;
            }
            fft(re, im);
            for (int k = 0; k < N / 2; k++) {
                double mag = Math.sqrt(re[k] * re[k] + im[k] * im[k]) / N;
                smooth[k] = 0.3 * smooth[k] + 0.7 * mag;
                double db = smooth[k] <= 1e-12 ? -200 : 20 * Math.log10(smooth[k]);
                double v = 255.0 * (db + 100.0) / 70.0;
                out[k] = (byte) (v < 0 ? 0 : (v > 255 ? 255 : (int) v));
            }
        }

        private static void fft(double[] re, double[] im) {
            int n = re.length;
            for (int i = 1, j = 0; i < n; i++) {
                int bit = n >> 1;
                for (; (j & bit) != 0; bit >>= 1) j ^= bit;
                j ^= bit;
                if (i < j) {
                    double t = re[i];
                    re[i] = re[j];
                    re[j] = t;
                    t = im[i];
                    im[i] = im[j];
                    im[j] = t;
                }
            }
            for (int len = 2; len <= n; len <<= 1) {
                double ang = -2 * Math.PI / len;
                double wr = Math.cos(ang), wi = Math.sin(ang);
                for (int i = 0; i < n; i += len) {
                    double cr = 1, ci = 0;
                    for (int j = 0; j < len / 2; j++) {
                        int a = i + j, b = i + j + len / 2;
                        double tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
                        re[b] = re[a] - tr;
                        im[b] = im[a] - ti;
                        re[a] += tr;
                        im[a] += ti;
                        double ncr = cr * wr - ci * wi;
                        ci = cr * wi + ci * wr;
                        cr = ncr;
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Вся цепочка эффектов.
    // ------------------------------------------------------------------------------------------------
    /** Сдвиг высоты тона без изменения длительности: две линии задержки с перекрёстным затуханием (Хэнн). ratio>1 — выше, <1 — ниже. */
    static final class PitchShifter {
        private static final int N = 8192, MASK = N - 1, W = 2048;
        private final float[] bl = new float[N], br = new float[N];
        private int w = 0;
        private double ph = 0;

        void reset() {
            java.util.Arrays.fill(bl, 0f);
            java.util.Arrays.fill(br, 0f);
            w = 0;
            ph = 0;
        }

        private static float tap(float[] b, int w, double delay) {
            double pos = w - delay;
            double fl = Math.floor(pos);
            float f = (float) (pos - fl);
            int i0 = ((int) fl) & MASK, i1 = (i0 + 1) & MASK;
            return b[i0] + (b[i1] - b[i0]) * f;
        }

        void process(float[] l, float[] r, int n, double ratio) {
            final double inc = (1.0 - ratio) / W;
            for (int i = 0; i < n; i++) {
                bl[w] = l[i];
                br[w] = r[i];
                double p0 = ph, p1 = ph + 0.5;
                if (p1 >= 1.0) p1 -= 1.0;
                double g0 = Math.sin(Math.PI * p0), g1 = Math.sin(Math.PI * p1);
                g0 *= g0;
                g1 *= g1;
                double d0 = p0 * W + 2, d1 = p1 * W + 2;
                l[i] = (float) (tap(bl, w, d0) * g0 + tap(bl, w, d1) * g1);
                r[i] = (float) (tap(br, w, d0) * g0 + tap(br, w, d1) * g1);
                w = (w + 1) & MASK;
                ph += inc;
                if (ph >= 1.0) ph -= 1.0;
                else if (ph < 0.0) ph += 1.0;
            }
        }
    }

    static final class Fx {
        static final int SB = 128;
        private final double fs;
        private final Biquad[] eq = new Biquad[10];
        private final Biquad bass;
        private final Reverb reverb;
        private final Limiter safetyLimiter;
        private final EffectCompressor compressor;
        private final PeakLimiter userLimiter;
        private final Echo echo;
        private final Flanger flanger;
        private float[] wl = new float[4096], wr = new float[4096];
        private float[] revInL = new float[4096], revInR = new float[4096];
        private final float[] predelayL, predelayR;
        private int predelayPos = 0;

        // Target values (written from JS/control thread, read by audio thread)
        private final double[] tEq = new double[10];
        private volatile double tBass, tVol = 1, tPan, tVirt, tWet, tDry = 1, tPre = 1;
        private volatile boolean echoClearReq, flangerClearReq;
        private volatile boolean voiceOn, compressorOn, userLimiterOn, echoOn, flangerOn, fxReverbOn, monoOn, stereoOn;
        private volatile double voiceLow = 120, voiceHigh = 9600, voiceAmount = 1;
        private volatile double limiterCeiling = -1, limiterRelease = 80;
        private volatile double echoDelay = 250, echoFeedback = .25, echoWet = .25;
        private volatile double flangerRate = .25, flangerDepth = 2.5, flangerBase = 2, flangerFeedback = .15, flangerWet = .35;
        private volatile double fxReverbWet = .25, fxReverbDry = 1, fxReverbRoom = .8, fxReverbDamping = .5, fxReverbPreDelay = 20, fxReverbWidth = 1;
        private volatile boolean oct8On;
        private volatile double oct8Depth = .5, oct8Period = 8;
        private double oct8Phase = 0;
        private volatile double monoAmount = 1, monoLeft = 1, monoRight = 1, stereoSwap = 0, phaseInvert = 0;

        // Smoothed main-chain values
        private double sVol = 1, sPan = 0, sVirt = 0, sWet = 0, sDry = 1, sPre = 1;
        private final float[] vdl, vdr;
        private int vp = 0;
        private final double aEq, aVol, aPan, aVirt, aWet, aPre;
        boolean reverbRunning = false;
        private double voiceHpX = 0, voiceHpY = 0, voiceLpY = 0;

        private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
        private static double at(double[] a, int i, double fallback) {
            return a != null && i >= 0 && i < a.length && Double.isFinite(a[i]) ? a[i] : fallback;
        }

        Fx(double fs, double[] freqs) {
            this.fs = fs;
            for (int i = 0; i < 10; i++) {
                int type = i == 0 ? Biquad.LOW : (i == 9 ? Biquad.HIGH : Biquad.PEAK);
                eq[i] = new Biquad(type, freqs[i], (i == 0 || i == 9) ? 0.8 : 1.05, fs);
            }
            bass = new Biquad(Biquad.LOW, 90, 0.72, fs);
            reverb = new Reverb(fs, REVERB_RT60, REVERB_SCALE);
            // The user limiter is optional; the final limiter is only a soft safety ceiling.
            safetyLimiter = new Limiter(fs, -1.0, 2.0, 20.0, 0.0015, 0.09);
            compressor = new EffectCompressor(fs);
            userLimiter = new PeakLimiter(fs);
            echo = new Echo(fs);
            flanger = new Flanger(fs);
            int d = (int) Math.round(0.012 * fs);
            vdl = new float[d];
            vdr = new float[d];
            predelayL = new float[Math.max(2, (int) Math.ceil(fs * 0.30))];
            predelayR = new float[predelayL.length];
            double dt = SB / fs;
            aEq = 1 - Math.exp(-dt / 0.05);
            aVol = 1 - Math.exp(-dt / 0.05);
            aPan = 1 - Math.exp(-dt / 0.05);
            aVirt = 1 - Math.exp(-dt / 0.03);
            aWet = 1 - Math.exp(-dt / 0.04);
            aPre = 1 - Math.exp(-dt / 0.02);
        }

        static final double REVERB_RT60 = 2.0;
        static final double REVERB_SCALE = 0.0211;

        synchronized void set(double[] eqDb, double bassDb, double vol, double pan, double virtAmount,
                              double wet, double dry, double pre) {
            set(eqDb, bassDb, vol, pan, virtAmount, wet, dry, pre, null);
        }

        synchronized void set(double[] eqDb, double bassDb, double vol, double pan, double virtAmount,
                              double wet, double dry, double pre, double[] fx) {
            for (int i = 0; i < 10; i++) tEq[i] = eqDb[i];
            tBass = bassDb;
            tVol = clamp(vol, 0, 12);
            tPan = clamp(pan, -1, 1);
            tVirt = clamp(virtAmount, 0, 1);
            tWet = clamp(wet, 0, 1);
            tDry = clamp(dry, 0, 1.5);
            tPre = clamp(pre, 0, 4);
            boolean oldEchoOn = echoOn;
            boolean oldFlangerOn = flangerOn;
            boolean oldVoiceOn = voiceOn;
            voiceOn = at(fx, 0, 0) >= 0.5;
            voiceLow = clamp(at(fx, 1, 120), 30, 1800);
            voiceHigh = clamp(at(fx, 2, 9600), 500, fs * 0.48);
            if (voiceHigh < voiceLow + 100) voiceHigh = Math.min(fs * 0.48, voiceLow + 100);
            voiceAmount = clamp(at(fx, 3, 1), 0, 1);

            compressorOn = at(fx, 4, 0) >= 0.5;
            double threshold = clamp(at(fx, 5, -18), -60, 0);
            double ratio = clamp(at(fx, 6, 4), 1, 30);
            double attack = clamp(at(fx, 7, 10), 0.1, 250) / 1000.0;
            double release = clamp(at(fx, 8, 120), 5, 2000) / 1000.0;
            double knee = clamp(at(fx, 9, 6), 0, 30);
            double makeup = clamp(at(fx, 10, 0), 0, 24);
            compressor.set(threshold, ratio, attack, release, knee, makeup);

            userLimiterOn = at(fx, 11, 0) >= 0.5;
            limiterCeiling = clamp(at(fx, 12, -1), -18, -0.05);
            limiterRelease = clamp(at(fx, 13, 80), 5, 1000);
            userLimiter.set(limiterCeiling, limiterRelease / 1000.0);

            echoOn = at(fx, 14, 0) >= 0.5;
            echoDelay = clamp(at(fx, 15, 250), 10, 1500);
            echoFeedback = clamp(at(fx, 16, .25), 0, .88);
            echoWet = clamp(at(fx, 17, .25), 0, 1);
            if (oldEchoOn && !echoOn) echoClearReq = true;

            flangerOn = at(fx, 18, 0) >= 0.5;
            flangerRate = clamp(at(fx, 19, .25), .05, 8);
            flangerDepth = clamp(at(fx, 20, 2.5), 0, 6);
            flangerBase = clamp(at(fx, 21, 2), .2, 12);
            flangerFeedback = clamp(at(fx, 22, .15), 0, .85);
            flangerWet = clamp(at(fx, 23, .35), 0, 1);
            if (oldFlangerOn && !flangerOn) flangerClearReq = true;

            fxReverbOn = at(fx, 24, 0) >= 0.5;
            fxReverbWet = clamp(at(fx, 25, .25), 0, 1);
            fxReverbDry = clamp(at(fx, 26, 1), 0, 1);
            fxReverbRoom = clamp(at(fx, 27, .8), 0, 1);
            fxReverbDamping = clamp(at(fx, 28, .5), 0, 1);
            fxReverbPreDelay = clamp(at(fx, 29, 20), 0, 250);
            fxReverbWidth = clamp(at(fx, 30, 1), 0, 1);

            monoOn = at(fx, 31, 0) >= 0.5;
            monoAmount = clamp(at(fx, 32, 1), 0, 1);
            monoLeft = clamp(at(fx, 33, 50), 0, 100) / 50.0;
            monoRight = clamp(at(fx, 34, 50), 0, 100) / 50.0;
            stereoOn = at(fx, 35, 0) >= 0.5;
            stereoSwap = clamp(at(fx, 36, 0), 0, 1);
            phaseInvert = clamp(at(fx, 37, 0), 0, 1);
            oct8Depth = clamp(at(fx, 38, 0), 0, 1);   // 0 = 8D off
            oct8On = oct8Depth > 0;
            oct8Period = clamp(at(fx, 39, 8), 1, 60);
            if (oldVoiceOn && !voiceOn) { voiceHpX = voiceHpY = voiceLpY = 0; }
        }

        /** True when the current reverb tail has finished. */
        boolean tailQuiet() { return !reverbRunning; }

        private void processVoice(float[] l, float[] r, int off, int n) {
            if (!voiceOn || voiceAmount <= 0) return;
            double hpA = Math.exp(-2.0 * Math.PI * voiceLow / fs);
            double lpA = Math.exp(-2.0 * Math.PI * voiceHigh / fs);
            double hpX = voiceHpX, hpY = voiceHpY, lpY = voiceLpY;
            for (int i = off; i < off + n; i++) {
                double mid = (l[i] + r[i]) * 0.5;
                double hp = hpA * (hpY + mid - hpX);
                hpX = mid; hpY = hp;
                lpY = (1.0 - lpA) * hp + lpA * lpY;
                float remove = (float) (lpY * voiceAmount);
                l[i] -= remove;
                r[i] -= remove;
            }
            voiceHpX = hpX; voiceHpY = hpY; voiceLpY = lpY;
        }

        void process(float[] l, float[] r, int n) {
            synchronized (this) {
                for (int i = 0; i < 10; i++) eq[i].target = tEq[i];
            }
            bass.target = tBass;
            if (wl.length < n) {
                wl = new float[n]; wr = new float[n];
                revInL = new float[n]; revInR = new float[n];
            }
            for (int off = 0; off < n; off += SB) {
                int m = Math.min(SB, n - off);
                if (echoClearReq) { echoClearReq = false; echo.clear(); }
                if (flangerClearReq) { flangerClearReq = false; flanger.clear(); }
                processVoice(l, r, off, m);
                if (compressorOn) compressor.process(l, r, off, m);

                // preamp
                double p0 = sPre;
                sPre += (tPre - sPre) * aPre;
                if (p0 != 1.0 || sPre != 1.0) {
                    for (int i = 0; i < m; i++) {
                        double g = p0 + (sPre - p0) * (i + 1) / m;
                        l[off + i] *= (float) g;
                        r[off + i] *= (float) g;
                    }
                }
                for (int b = 0; b < 10; b++) {
                    eq[b].step(aEq);
                    eq[b].process(l, r, off, m);
                }
                bass.step(aEq);
                bass.process(l, r, off, m);

                // Mono fold-down plus independent channel trims.
                if (monoOn) {
                    double amt = monoAmount, gl = monoLeft, gr = monoRight;
                    for (int i = off; i < off + m; i++) {
                        float xl = l[i], xr = r[i], mid = (xl + xr) * 0.5f;
                        l[i] = (float) ((xl * (1.0 - amt) + mid * amt) * gl);
                        r[i] = (float) ((xr * (1.0 - amt) + mid * amt) * gr);
                    }
                }

                // Optional stereo swap and right-channel polarity blend.
                if (stereoOn && (stereoSwap > 0 || phaseInvert > 0)) {
                    double sw = stereoSwap, ph = 1.0 - 2.0 * phaseInvert;
                    for (int i = off; i < off + m; i++) {
                        float xl = l[i], xr = r[i];
                        float sl = (float) (xl * (1.0 - sw) + xr * sw);
                        float sr = (float) (xr * (1.0 - sw) + xl * sw);
                        l[i] = sl;
                        r[i] = (float) (sr * ph);
                    }
                }

                if (flangerOn && flangerWet > 0) flanger.process(l, r, off, m, flangerRate, flangerDepth,
                        flangerBase, flangerFeedback, flangerWet);

                // Virtualizer
                sVirt += (tVirt - sVirt) * aVirt;
                if (Math.abs(tVirt - sVirt) < 1e-4) sVirt = tVirt;
                if (sVirt > 0) {
                    double direct = 1.0 - sVirt * 0.34, cross = sVirt * 0.34;
                    int dlen = vdl.length;
                    for (int i = off; i < off + m; i++) {
                        float xl = l[i], xr = r[i];
                        float dly = vdl[vp], dry2 = vdr[vp];
                        vdl[vp] = xl;
                        vdr[vp] = xr;
                        if (++vp >= dlen) vp = 0;
                        l[i] = (float) (direct * xl + cross * dry2);
                        r[i] = (float) (direct * xr + cross * dly);
                    }
                } else if (vdl[0] != 0f || vdl[vdl.length / 2] != 0f) {
                    java.util.Arrays.fill(vdl, 0f);
                    java.util.Arrays.fill(vdr, 0f);
                }

                // Volume
                double v0 = sVol;
                sVol += (tVol - sVol) * aVol;
                if (v0 != 1.0 || sVol != 1.0) {
                    for (int i = 0; i < m; i++) {
                        double g = v0 + (sVol - v0) * (i + 1) / m;
                        l[off + i] *= (float) g;
                        r[off + i] *= (float) g;
                    }
                }
                // Balance
                // 8D: balance travels around between the channels (±depth around the manual balance).
                double panGoal = tPan;
                if (oct8On && oct8Depth > 0) {
                    oct8Phase += 2.0 * Math.PI * m / (fs * oct8Period);
                    if (oct8Phase > 2.0 * Math.PI) oct8Phase -= 2.0 * Math.PI;
                    panGoal = clamp(tPan + oct8Depth * Math.sin(oct8Phase), -1, 1);
                }
                sPan += (panGoal - sPan) * aPan;
                if (Math.abs(panGoal - sPan) < 1e-4) sPan = panGoal;
                if (sPan != 0.0) {
                    double x = sPan <= 0 ? sPan + 1.0 : sPan;
                    double gl = Math.cos(x * Math.PI / 2), gr = Math.sin(x * Math.PI / 2);
                    for (int i = off; i < off + m; i++) {
                        float xl = l[i], xr = r[i];
                        if (sPan <= 0) {
                            l[i] = (float) (xl + xr * gl);
                            r[i] = (float) (xr * gr);
                        } else {
                            l[i] = (float) (xl * gl);
                            r[i] = (float) (xr + xl * gr);
                        }
                    }
                }

                // Echo: feedback delay, mixed with the direct signal.
                if (echoOn && echoWet > 0) echo.process(l, r, off, m, echoDelay, echoFeedback, echoWet);

                double targetWet = tWet, targetDry = tDry;
                double rt60 = REVERB_RT60, damp = 0.28, predelayMs = 0, width = 1.0;
                if (fxReverbOn) {
                    double ew = fxReverbWet * fxReverbWet * 0.72;
                    targetWet = 1.0 - (1.0 - targetWet) * (1.0 - ew);
                    targetDry = Math.min(targetDry, fxReverbDry);
                    rt60 = 0.25 + fxReverbRoom * 4.25;
                    damp = 0.04 + fxReverbDamping * 0.86;
                    predelayMs = fxReverbPreDelay;
                    width = fxReverbWidth;
                }
                reverb.setParameters(rt60, damp);
                double w0 = sWet, d0 = sDry;
                sWet += (targetWet - sWet) * aWet;
                sDry += (targetDry - sDry) * aWet;
                if (Math.abs(targetWet - sWet) < 1e-5 && targetWet == 0) sWet = 0;
                if (Math.abs(targetDry - sDry) < 1e-5) sDry = targetDry;
                boolean wetOn = targetWet > 0 || sWet > 0;
                if (wetOn) {
                    reverbRunning = true;
                    int pd = fxReverbOn ? (int) Math.round(predelayMs * fs / 1000.0) : 0;
                    if (pd <= 0) {
                        reverb.process(l, r, wl, wr, off, m);
                    } else {
                        pd = Math.min(pd, predelayL.length - 1);
                        for (int i = off; i < off + m; i++) {
                            int rp = predelayPos - pd;
                            if (rp < 0) rp += predelayL.length;
                            revInL[i] = predelayL[rp];
                            revInR[i] = predelayR[rp];
                            predelayL[predelayPos] = l[i];
                            predelayR[predelayPos] = r[i];
                            if (++predelayPos >= predelayL.length) predelayPos = 0;
                        }
                        reverb.process(revInL, revInR, wl, wr, off, m);
                    }
                    for (int i = 0; i < m; i++) {
                        int ix = off + i;
                        double f = (i + 1.0) / m;
                        double gw = w0 + (sWet - w0) * f, gd = d0 + (sDry - d0) * f;
                        float wetL = wl[ix], wetR = wr[ix];
                        if (fxReverbOn) {
                            double mid = (wetL + wetR) * 0.5, side = (wetL - wetR) * 0.5 * width;
                            wetL = (float) (mid + side); wetR = (float) (mid - side);
                        }
                        l[ix] = (float) (l[ix] * gd + wetL * gw);
                        r[ix] = (float) (r[ix] * gd + wetR * gw);
                    }
                } else {
                    if (reverbRunning) {
                        reverb.clear();
                        java.util.Arrays.fill(predelayL, 0f); java.util.Arrays.fill(predelayR, 0f);
                        predelayPos = 0;
                        reverbRunning = false;
                    }
                    if (d0 != 1.0 || sDry != 1.0) {
                        for (int i = 0; i < m; i++) {
                            double gd = d0 + (sDry - d0) * (i + 1) / m;
                            l[off + i] *= (float) gd;
                            r[off + i] *= (float) gd;
                        }
                    }
                }

                if (userLimiterOn) userLimiter.process(l, r, off, m);
            }
            safetyLimiter.process(l, r, 0, n);
        }

        void reset() {
            safetyLimiter.reset();
            userLimiter.reset();
            compressor.reset();
            echo.clear(); flanger.clear();
            reverb.clear();
            reverbRunning = false;
            java.util.Arrays.fill(vdl, 0f); java.util.Arrays.fill(vdr, 0f);
            java.util.Arrays.fill(predelayL, 0f); java.util.Arrays.fill(predelayR, 0f);
            predelayPos = 0;
            voiceHpX = voiceHpY = voiceLpY = 0;
        }

        private static final class EffectCompressor {
            private final double fs;
            private volatile double threshold = -18, ratio = 4, attack = .01, release = .12, knee = 6, makeup = 0;
            private double gain = 1;
            EffectCompressor(double fs) { this.fs = fs; }
            void set(double th, double ra, double at, double re, double kn, double ma) {
                threshold = th; ratio = ra; attack = at; release = re; knee = kn; makeup = ma;
            }
            void process(float[] l, float[] r, int off, int n) {
                double atk = 1.0 - Math.exp(-1.0 / (Math.max(.0001, attack) * fs));
                double rel = 1.0 - Math.exp(-1.0 / (Math.max(.001, release) * fs));
                final double th = threshold, ra = ratio, kn = knee;
                double mg = db2lin(makeup);
                // ниже нижней границы колена сжатия нет: логарифм и pow для таких отсчётов не нужны
                final double quietLin = db2lin(th - kn * .5);
                for (int i = off; i < off + n; i++) {
                    double amp = Math.max(Math.abs(l[i]), Math.abs(r[i]));
                    if (amp < quietLin) {
                        if (mg < gain) gain += (mg - gain) * atk; else gain += (mg - gain) * rel;
                        l[i] *= (float) gain; r[i] *= (float) gain;
                        continue;
                    }
                    double db = amp < 1e-9 ? -180 : 20.0 * Math.log10(amp);
                    double outDb = db;
                    double over = db - th;
                    if (kn > 0 && over > -kn * .5 && over < kn * .5) {
                        double x = over + kn * .5;
                        outDb = db + (1.0 / ra - 1.0) * x * x / (2.0 * kn);
                    } else if (over >= kn * .5) {
                        outDb = th + over / ra;
                    }
                    double target = db2lin(outDb - db) * mg;
                    if (target < gain) gain += (target - gain) * atk;
                    else gain += (target - gain) * rel;
                    l[i] *= (float) gain; r[i] *= (float) gain;
                }
            }
            void reset() { gain = 1; }
        }

        private static final class PeakLimiter {
            private final double fs;
            private volatile double ceiling = db2lin(-1), release = .08;
            private double gain = 1;
            PeakLimiter(double fs) { this.fs = fs; }
            void set(double ceilingDb, double releaseSec) {
                ceiling = db2lin(clamp(ceilingDb, -18, -.05));
                release = clamp(releaseSec, .005, 1.0);
            }
            void process(float[] l, float[] r, int off, int n) {
                double rel = 1.0 - Math.exp(-1.0 / (release * fs));
                for (int i = off; i < off + n; i++) {
                    double peak = Math.max(Math.abs(l[i]), Math.abs(r[i]));
                    double target = peak > ceiling ? ceiling / Math.max(peak, 1e-12) : 1.0;
                    if (target < gain) gain = target;
                    else gain += (target - gain) * rel;
                    l[i] *= (float) gain; r[i] *= (float) gain;
                }
            }
            void reset() { gain = 1; }
            private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
        }

        private static final class Echo {
            private final float[] left, right;
            private final int size;
            private int pos;
            Echo(double fs) {
                size = Math.max(4, (int) Math.ceil(fs * 1.55) + 4);
                left = new float[size]; right = new float[size];
            }
            void process(float[] l, float[] r, int off, int n, double delayMs, double feedback, double wet) {
                int d = Math.max(1, Math.min(size - 2, (int) Math.round(delayMs * (size - 4) / 1550.0)));
                double dry = 1.0 - wet * 0.55;
                for (int i = off; i < off + n; i++) {
                    int rd = pos - d; if (rd < 0) rd += size;
                    float dl = left[rd], dr = right[rd];
                    float inL = l[i], inR = r[i];
                    left[pos] = clampF(inL + dl * (float) feedback, -4f, 4f);
                    right[pos] = clampF(inR + dr * (float) feedback, -4f, 4f);
                    l[i] = (float) (inL * dry + dl * wet);
                    r[i] = (float) (inR * dry + dr * wet);
                    if (++pos >= size) pos = 0;
                }
            }
            void clear() { java.util.Arrays.fill(left, 0f); java.util.Arrays.fill(right, 0f); pos = 0; }
        }

        private static final class Flanger {
            private final float[] left, right;
            private final double fs;
            private int pos;
            private double phase;
            Flanger(double fs) {
                this.fs = fs;
                int size = Math.max(16, (int) Math.ceil(fs * .025) + 4);
                left = new float[size]; right = new float[size];
            }
            private float tap(float[] b, double delay) {
                double x = pos - delay;
                while (x < 0) x += b.length;
                while (x >= b.length) x -= b.length;
                int a = (int) x, z = a + 1; if (z >= b.length) z = 0;
                double f = x - a;
                return (float) (b[a] + (b[z] - b[a]) * f);
            }
            void process(float[] l, float[] r, int off, int n, double rate, double depthMs, double baseMs, double feedback, double wet) {
                double inc = rate / fs;
                for (int i = off; i < off + n; i++) {
                    float inL = l[i], inR = r[i];
                    double modulation = .5 + .5 * Math.sin(phase * Math.PI * 2.0);
                    double delay = Math.max(1, (baseMs + depthMs * modulation) * fs / 1000.0);
                    float dl = tap(left, delay), dr = tap(right, delay);
                    left[pos] = clampF(inL + dl * (float) feedback, -4f, 4f);
                    right[pos] = clampF(inR + dr * (float) feedback, -4f, 4f);
                    l[i] = (float) (inL * (1.0 - wet * .7) + dl * wet * .7);
                    r[i] = (float) (inR * (1.0 - wet * .7) + dr * wet * .7);
                    if (++pos >= left.length) pos = 0;
                    phase += inc; if (phase >= 1) phase -= Math.floor(phase);
                }
            }
            void clear() { java.util.Arrays.fill(left, 0f); java.util.Arrays.fill(right, 0f); pos = 0; phase = 0; }
        }

        private static float clampF(float x, float min, float max) { return x < min ? min : (x > max ? max : x); }
    }

}

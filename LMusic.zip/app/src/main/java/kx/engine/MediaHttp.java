package kx.engine;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * Мини-HTTP-сервер трансляции: телевизор или колонка (DLNA/UPnP) сами скачивают трек с телефона по ссылке вида
 * http://IP:порт/t/случайный_токен.mp3. Поддерживает Range (перемотка на устройстве) и HEAD.
 * Отдаёт только то, что зарегистрировано через addFile/addBytes; адреса содержат случайный токен.
 */
final class MediaHttp {
    private static final String TAG = "KX";
    private static final int MAX_TRACK_ROUTES = 6;

    private static final class Entry {
        File file;
        byte[] bytes;
        String mime;
    }

    private final ConcurrentHashMap<String, Entry> routes = new ConcurrentHashMap<String, Entry>();
    private final ArrayList<String> trackOrder = new ArrayList<String>();
    private final SecureRandom rnd = new SecureRandom();
    private ServerSocket ss;
    private ExecutorService pool;
    private volatile boolean running;
    private String artPath;

    /** Запускает сервер (повторный вызов безопасен). Возвращает порт. */
    synchronized int start() throws IOException {
        if (running && ss != null && !ss.isClosed()) return ss.getLocalPort();
        ss = new ServerSocket(0, 16);
        running = true;
        pool = Executors.newCachedThreadPool(new ThreadFactory() {
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "kx-http");
                t.setDaemon(true);
                return t;
            }
        });
        final ServerSocket sock = ss;
        final ExecutorService ex = pool;
        Thread acceptor = new Thread(new Runnable() {
            public void run() {
                while (running && !sock.isClosed()) {
                    try {
                        final Socket s = sock.accept();
                        ex.execute(new Runnable() {
                            public void run() {
                                handle(s);
                            }
                        });
                    } catch (Throwable t) {
                        if (running) Log.w(TAG, "http accept: " + t);
                        if (sock.isClosed()) break;
                    }
                }
            }
        }, "kx-http-accept");
        acceptor.setDaemon(true);
        acceptor.start();
        return ss.getLocalPort();
    }

    synchronized void stop() {
        running = false;
        try {
            if (ss != null) ss.close();
        } catch (Throwable ignored) {
            // уже закрыт
        }
        ss = null;
        if (pool != null) pool.shutdownNow();
        pool = null;
        routes.clear();
        trackOrder.clear();
        artPath = null;
    }

    synchronized int port() {
        return ss == null ? -1 : ss.getLocalPort();
    }

    private String token() {
        byte[] b = new byte[12];
        rnd.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < b.length; i++) sb.append(String.format("%02x", b[i] & 0xff));
        return sb.toString();
    }

    /** Регистрирует файл трека; возвращает путь (например /t/ab12.mp3). */
    synchronized String addFile(File f, String mime, String ext) {
        String path = "/t/" + token() + "." + ext;
        Entry e = new Entry();
        e.file = f;
        e.mime = mime;
        routes.put(path, e);
        trackOrder.add(path);
        while (trackOrder.size() > MAX_TRACK_ROUTES) routes.remove(trackOrder.remove(0));
        return path;
    }

    /** Регистрирует картинку (обложку), прежняя обложка снимается. Возвращает путь. */
    synchronized String addArt(byte[] data, String mime, String ext) {
        if (artPath != null) routes.remove(artPath);
        String path = "/a/" + token() + "." + ext;
        Entry e = new Entry();
        e.bytes = data;
        e.mime = mime;
        routes.put(path, e);
        artPath = path;
        return path;
    }

    synchronized String currentArt() {
        return artPath;
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 8192) throw new IOException("line too long");
        }
        if (c == -1 && sb.length() == 0) return null;
        return sb.toString();
    }

    private static void status(OutputStream out, int code, String text, String extra) throws IOException {
        String body = code + " " + text;
        String h = "HTTP/1.1 " + code + " " + text + "\r\nContent-Type: text/plain\r\nContent-Length: " + body.length()
                + "\r\nConnection: close\r\n" + (extra == null ? "" : extra) + "\r\n" + body;
        out.write(h.getBytes("UTF-8"));
        out.flush();
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(25000);
            s.setTcpNoDelay(true);
            InputStream in = new BufferedInputStream(s.getInputStream(), 4096);
            OutputStream out = s.getOutputStream();
            String req = readLine(in);
            if (req == null) return;
            String[] p = req.split(" ");
            if (p.length < 2) return;
            String method = p[0];
            String path = p[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            String range = null;
            String line;
            int guard = 0;
            while ((line = readLine(in)) != null && line.length() > 0 && guard++ < 80) {
                if (line.regionMatches(true, 0, "range:", 0, 6)) range = line.substring(6).trim();
            }
            if (!"GET".equals(method) && !"HEAD".equals(method)) {
                status(out, 405, "Method Not Allowed", null);
                return;
            }
            Entry e = routes.get(path);
            if (e == null) {
                status(out, 404, "Not Found", null);
                return;
            }
            long total = e.bytes != null ? e.bytes.length : e.file.length();
            if (e.bytes == null && (!e.file.isFile() || total <= 0)) {
                status(out, 404, "Not Found", null);
                return;
            }
            long start = 0, end = total - 1;
            boolean partial = false;
            if (range != null && range.startsWith("bytes=")) {
                String spec = range.substring(6);
                int comma = spec.indexOf(',');
                if (comma >= 0) spec = spec.substring(0, comma);
                int dash = spec.indexOf('-');
                try {
                    if (dash >= 0) {
                        String a = spec.substring(0, dash).trim();
                        String b = spec.substring(dash + 1).trim();
                        if (a.length() == 0 && b.length() > 0) {
                            long n = Long.parseLong(b);
                            start = Math.max(0, total - n);
                            end = total - 1;
                            partial = true;
                        } else if (a.length() > 0) {
                            start = Long.parseLong(a);
                            end = b.length() == 0 ? total - 1 : Math.min(Long.parseLong(b), total - 1);
                            partial = true;
                        }
                    }
                } catch (NumberFormatException ignored) {
                    start = 0;
                    end = total - 1;
                    partial = false;
                }
                if (partial && (start >= total || start > end)) {
                    status(out, 416, "Range Not Satisfiable", "Content-Range: bytes */" + total + "\r\n");
                    return;
                }
            }
            long len = end - start + 1;
            StringBuilder h = new StringBuilder();
            h.append(partial ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
            h.append("Content-Type: ").append(e.mime).append("\r\n");
            h.append("Content-Length: ").append(len).append("\r\n");
            h.append("Accept-Ranges: bytes\r\n");
            if (partial) h.append("Content-Range: bytes ").append(start).append('-').append(end).append('/').append(total).append("\r\n");
            if (e.bytes == null) {
                h.append("transferMode.dlna.org: Streaming\r\n");
                h.append("contentFeatures.dlna.org: DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000\r\n");
            }
            h.append("Connection: close\r\n\r\n");
            out.write(h.toString().getBytes("UTF-8"));
            if ("HEAD".equals(method)) {
                out.flush();
                return;
            }
            if (e.bytes != null) {
                out.write(e.bytes, (int) start, (int) len);
            } else {
                RandomAccessFile raf = new RandomAccessFile(e.file, "r");
                try {
                    raf.seek(start);
                    byte[] buf = new byte[65536];
                    long left = len;
                    while (left > 0) {
                        int n = raf.read(buf, 0, (int) Math.min(buf.length, left));
                        if (n <= 0) break;
                        out.write(buf, 0, n);
                        left -= n;
                    }
                } finally {
                    raf.close();
                }
            }
            out.flush();
        } catch (IOException ignored) {
            // устройство закрыло соединение (перемотка, смена трека) — это нормально
        } catch (Throwable t) {
            Log.w(TAG, "http handle: " + t);
        } finally {
            try {
                s.close();
            } catch (Throwable ignored) {
                // уже закрыт
            }
        }
    }
}

package kx.engine;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import com.lmusic.app.WebViewActivity;

/** Foreground media-playback service. A restarted process restores a usable notification instead of
 * dropping straight back out with START_NOT_STICKY and leaving dead controls in the shade. */
public class MediaService extends Service {
    private static final String TAG = "KX";
    private static final int TYPE_MEDIA_PLAYBACK = 2;
    private static final long PAUSE_GRACE_MS = 60L * 60L * 1000L;
    private static final String PREFS = "kx_media_recovery";
    private static final String KEY_ACTIVE = "active";
    private static volatile MediaService inst;
    private static volatile Notification pending;
    private static volatile boolean pendingPlaying;

    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private boolean fg;

    private final Runnable giveUp = new Runnable() {
        @Override public void run() {
            try {
                releaseWake();
                fg = false;
                if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
                else stopForeground(false);
            } catch (Throwable t) {
                Log.w(TAG, "giveUp failed", t);
            }
            stopSelf();
        }
    };

    public MediaService() { }

    /** Save only small, non-sensitive metadata needed to reconstruct controls after process death. */
    static void saveMetadata(Context c, String title, String artist, String album, boolean playing, boolean fav) {
        try {
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean(KEY_ACTIVE, true)
                    .putString("title", title == null ? "" : title)
                    .putString("artist", artist == null ? "" : artist)
                    .putString("album", album == null ? "" : album)
                    .putBoolean("playing", playing)
                    .putBoolean("fav", fav)
                    .apply();
        } catch (Throwable t) { Log.w(TAG, "save metadata failed", t); }
    }

    static void clearMetadata(Context c) {
        try { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply(); }
        catch (Throwable t) { Log.w(TAG, "clear metadata failed", t); }
    }

    /** Shows/updates the media notification while the page/engine is alive. */
    static boolean show(Context app, Notification n, boolean playing) {
        pending = n;
        pendingPlaying = playing;
        MediaService s = inst;
        if (s != null) {
            s.apply();
            return true;
        }
        try {
            Intent i = new Intent(app, MediaService.class);
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i);
            else app.startService(i);
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "media service start failed", t);
            return false;
        }
    }

    /** Stops playback protection and clears stale recovery metadata when the user clears the player. */
    static void stop(Context app) {
        pending = null;
        pendingPlaying = false;
        clearMetadata(app);
        MediaService s = inst;
        if (s != null) { s.finish(); return; }
        try { app.stopService(new Intent(app, MediaService.class)); }
        catch (Throwable ignored) { }
    }

    @Override public void onCreate() {
        super.onCreate();
        inst = this;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = pending;
        if (n == null) {
            // START_STICKY restarts have no in-memory Notification/MediaSession. Recreate a simple
            // notification with working broadcast buttons; the tap reopens the UI and restores the
            // saved track/position. We intentionally do not claim that audio survived process death.
            n = buildRecoveryNotification();
            if (n == null) {
                stopSelfResult(startId);
                return START_NOT_STICKY;
            }
            startFg(n);
            if (fg) {
                try {
                    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
                    else stopForeground(false);
                } catch (Throwable ignored) { }
                fg = false;
            }
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }
        startFg(n);
        if (!fg) return START_NOT_STICKY;
        apply();
        return START_STICKY;
    }

    private void startFg(Notification n) {
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(MediaNotif.ID, n, TYPE_MEDIA_PLAYBACK);
            else startForeground(MediaNotif.ID, n);
            fg = true;
        } catch (Throwable t) {
            Log.w(TAG, "startForeground failed", t);
            fg = false;
            try {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && n != null) nm.notify(MediaNotif.ID, n);
            } catch (Throwable ignored) { }
            stopSelf();
        }
    }

    private void apply() {
        Notification n = pending;
        if (n == null) return;
        try {
            if (!fg) startFg(n);
            else {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.notify(MediaNotif.ID, n);
            }
            wake(pendingPlaying);
            h.removeCallbacks(giveUp);
            if (!pendingPlaying) h.postDelayed(giveUp, PAUSE_GRACE_MS);
        } catch (Throwable t) { Log.w(TAG, "media service apply failed", t); }
    }

    private Notification buildRecoveryNotification() {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            if (!p.getBoolean(KEY_ACTIVE, false)) return null;
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm != null && nm.getNotificationChannel(MediaNotif.CHANNEL) == null) {
                nm.createNotificationChannel(new NotificationChannel(MediaNotif.CHANNEL, "Воспроизведение", NotificationManager.IMPORTANCE_LOW));
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, MediaNotif.CHANNEL) : new Notification.Builder(this);
            Intent open = new Intent(this, WebViewActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            b.setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentTitle(nonEmpty(p.getString("title", ""), "LMusic"))
                    .setContentText(nonEmpty(p.getString("artist", ""), "Нажмите «Играть», чтобы продолжить"))
                    .setSubText(p.getString("album", ""))
                    .setCategory(Notification.CATEGORY_TRANSPORT)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setOnlyAlertOnce(true)
                    .setOngoing(false)
                    .setAutoCancel(false)
                    .setContentIntent(PendingIntent.getActivity(this, 7309, open, flags));
            b.addAction(android.R.drawable.ic_media_previous, "Назад", actionPending("prev", flags));
            b.addAction(android.R.drawable.ic_media_play, "Играть", actionPending("play", flags));
            b.addAction(android.R.drawable.ic_media_next, "Вперёд", actionPending("next", flags));
            b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Закрыть", actionPending("close", flags));
            return b.build();
        } catch (Throwable t) {
            Log.w(TAG, "build recovery notification failed", t);
            return null;
        }
    }

    private PendingIntent actionPending(String action, int flags) {
        Intent i = new Intent(this, MediaActionReceiver.class).setAction("kx.engine.MEDIA." + action);
        return PendingIntent.getBroadcast(this, action.hashCode() & 0xffff, i, flags);
    }

    private static String nonEmpty(String s, String fallback) {
        return s == null || s.trim().isEmpty() ? fallback : s;
    }

    private void wake(boolean on) {
        try {
            if (on) {
                if (wl == null) {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    if (pm == null) return;
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kx:media");
                    wl.setReferenceCounted(false);
                }
                if (!wl.isHeld()) wl.acquire(4L * 60L * 60L * 1000L);
            } else releaseWake();
        } catch (Throwable t) { Log.w(TAG, "wake lock failed", t); }
    }

    private void releaseWake() {
        try { if (wl != null && wl.isHeld()) wl.release(); }
        catch (Throwable ignored) { }
    }

    private void finish() {
        h.removeCallbacksAndMessages(null);
        releaseWake();
        try { stopForeground(true); } catch (Throwable ignored) { }
        fg = false;
        stopSelf();
    }

    @Override public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        releaseWake();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

package com.lmusic.app.floria;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Built-in, offline domain lists used to cut ads, trackers and crypto-miners at the request level. */
final class Blocklist {
    static final int NONE = 0;
    static final int AD = 1;
    static final int TRACKER = 2;
    static final int MALICIOUS = 3;

    private static final Set<String> AD_DOMAINS = set(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "pagead2.googlesyndication.com", "2mdn.net", "adnxs.com", "adsrvr.org", "advertising.com",
            "adform.net", "criteo.com", "criteo.net", "taboola.com", "outbrain.com", "revcontent.com",
            "mgid.com", "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com", "indexww.com",
            "smartadserver.com", "moatads.com", "amazon-adsystem.com", "media.net", "bidswitch.net",
            "contextweb.com", "yieldmo.com", "sharethrough.com", "tapad.com", "teads.tv", "adcolony.com",
            "applovin.com", "unityads.unity3d.com", "mopub.com", "inmobi.com", "smaato.net", "chartboost.com",
            "vungle.com", "ironsrc.com", "supersonicads.com", "startappservice.com", "adsafeprotected.com",
            "serving-sys.com", "zedo.com", "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
            "trafficjunky.net", "juicyads.com", "adsterra.com", "hilltopads.net", "clickadu.com",
            "onclickads.net", "adskeeper.com", "lijit.com", "33across.com", "sovrn.com", "gumgum.com",
            "triplelift.com", "adition.com", "improvedigital.com", "richaudience.com", "adtelligent.com",
            "undertone.com", "districtm.io", "360yield.com", "yahoo-ads.com", "adtech.com", "ads.yahoo.com",
            "an.yandex.ru", "awaps.yandex.net", "yabs.yandex.ru", "adfox.ru", "begun.ru", "adriver.ru",
            "ad.mail.ru", "ads.vk.com", "target.my.com", "ads.linkedin.com", "ads.pinterest.com",
            "ads.tiktok.com", "ads.twitter.com", "static.ads-twitter.com", "ads-twitter.com",
            "adserver.snapads.com", "ads.reddit.com", "adsymptotic.com", "carbonads.net", "buysellads.com",
            "adbrite.com", "admob.com", "adcash.com", "bidvertiser.com", "revenuehits.com", "yllix.com",
            "a-ads.com", "coinzilla.com", "mediavine.com", "adthrive.com", "ezoic.net", "monetag.com",
            "tynt.com", "adblade.com", "nativeads.com", "plugrush.com", "tradedoubler.com", "awin1.com",
            "zanox.com", "impact.com", "cj.com", "dpbolvw.net", "jdoqocy.com", "tkqlhce.com", "anrdoezrs.net",
            "linksynergy.com", "shareasale.com", "admitad.com", "actionpay.ru");

    private static final Set<String> TRACKER_DOMAINS = set(
            "google-analytics.com", "googletagmanager.com", "googletagservices.com", "analytics.google.com",
            "stats.g.doubleclick.net", "connect.facebook.net", "pixel.facebook.com", "analytics.twitter.com",
            "analytics.tiktok.com", "px.ads.linkedin.com", "snap.licdn.com", "bat.bing.com", "clarity.ms",
            "hotjar.com", "hotjar.io", "fullstory.com", "mouseflow.com", "crazyegg.com", "luckyorange.com",
            "inspectlet.com", "heapanalytics.com", "mixpanel.com", "mxpnl.com", "segment.io", "segment.com",
            "amplitude.com", "optimizely.com", "newrelic.com", "nr-data.net", "scorecardresearch.com",
            "quantserve.com", "quantcast.com", "chartbeat.com", "chartbeat.net", "parsely.com", "comscore.com",
            "demdex.net", "omtrdc.net", "everesttech.net", "2o7.net", "adobedtm.com", "krxd.net",
            "bluekai.com", "bkrtx.com", "exelator.com", "eyeota.net", "rlcdn.com", "liadm.com", "pippio.com",
            "crwdcntrl.net", "agkn.com", "mathtag.com", "turn.com", "tiqcdn.com", "appsflyer.com",
            "adjust.com", "app-measurement.com", "kochava.com", "singular.net", "hs-analytics.net",
            "hsadspixel.net", "pardot.com", "marketo.net", "mktoresp.com", "mc.yandex.ru", "mc.yandex.com",
            "mc.yandex.by", "mc.yandex.kz", "top-fwz1.mail.ru", "counter.yadro.ru", "tns-counter.ru",
            "top.mail.ru", "stats.wp.com", "pixel.wp.com", "tr.snapchat.com", "sc-static.net",
            "ct.pinterest.com", "log.pinterest.com", "trk.pinterest.com", "bat.r.msn.com",
            "pixel.quantserve.com", "sessioncam.com", "smartlook.com", "logrocket.com", "logrocket.io",
            "lr-ingest.io", "browser-intake-datadoghq.com", "rum.hlx.page", "statcounter.com", "histats.com",
            "liveinternet.ru", "openstat.net", "adobe.demdex.net", "dpm.demdex.net",
            "sitescout.com", "tapad.net", "id5-sync.com", "uidapi.com", "permutive.com", "permutive.app",
            "zemanta.com", "yieldlab.net", "bttrack.com", "adjust.io",
            "tags.tiqcdn.com", "trackjs.com", "usabilla.com",
            "survicate.com", "vwo.com", "visualwebsiteoptimizer.com", "abtasty.com", "kameleoon.eu",
            "braze.com", "appboy.com", "leanplum.com", "clevertap.com",
            "pushwoosh.com", "ptengine.com", "gemius.pl", "gemius.com", "hit.gemius.pl", "ioam.de", "xiti.com", "atinternet.com",
            "at-o.net", "webtrekk.net", "etracker.com", "ivwbox.de", "wt-safetag.com");

    private static final Set<String> MALICIOUS_DOMAINS = set(
            "coinhive.com", "coin-hive.com", "authedmine.com", "jsecoin.com", "crypto-loot.com",
            "cryptoloot.pro", "webmine.pro", "minero.cc", "minergate.com", "coinimp.com", "coinerra.com",
            "mineralt.io", "webminepool.com", "monerominer.rocks", "ppoi.org", "coin-have.com",
            "minemytraffic.com", "cryptonoter.com", "papoto.com", "hashforcash.us", "miner.pr0gramm.com");

    /** host -> path prefixes that are tracking endpoints on otherwise legitimate hosts. */
    private static final Map<String, String[]> PATH_RULES = new HashMap<>();

    static {
        PATH_RULES.put("facebook.com", new String[]{"/tr", "/plugins/like.php/tracking"});
        PATH_RULES.put("google.com", new String[]{"/pagead/", "/gen_204", "/ads/"});
        PATH_RULES.put("youtube.com", new String[]{"/api/stats/ads", "/ptracking", "/pagead/", "/api/stats/atr"});
        PATH_RULES.put("twitter.com", new String[]{"/i/jot", "/i/adsct"});
        PATH_RULES.put("x.com", new String[]{"/i/jot", "/i/adsct"});
        PATH_RULES.put("linkedin.com", new String[]{"/li/track", "/px/"});
        PATH_RULES.put("reddit.com", new String[]{"/api/v1/pixel"});
        PATH_RULES.put("yandex.ru", new String[]{"/clck/", "/metrika/"});
        PATH_RULES.put("vk.com", new String[]{"/rtrg"});
    }

    /** CDNs that serve shared libraries; never treated as "third-party scripts" in strict mode. */
    private static final Set<String> COMMON_CDNS = set(
            "cdnjs.cloudflare.com", "cdn.jsdelivr.net", "unpkg.com", "ajax.googleapis.com", "code.jquery.com",
            "gstatic.com", "fonts.googleapis.com", "bootstrapcdn.com", "stackpath.bootstrapcdn.com",
            "maxcdn.bootstrapcdn.com", "cloudflare.com", "jquery.com", "fastly.net", "akamaized.net",
            "cloudfront.net", "azureedge.net", "polyfill-fastly.io", "fontawesome.com", "recaptcha.net",
            "hcaptcha.com", "challenges.cloudflare.com");

    private Blocklist() {}

    private static Set<String> set(String... values) {
        return new HashSet<>(Arrays.asList(values));
    }

    /** Classifies a request by host and path; returns one of NONE/AD/TRACKER/MALICIOUS. */
    static int classify(String host, String path) {
        if (host == null || host.isEmpty()) return NONE;
        String h = host.toLowerCase(Locale.ROOT);
        String p = path == null ? "" : path;
        String candidate = h;
        while (true) {
            if (MALICIOUS_DOMAINS.contains(candidate)) return MALICIOUS;
            if (AD_DOMAINS.contains(candidate)) return AD;
            if (TRACKER_DOMAINS.contains(candidate)) return TRACKER;
            String[] rules = PATH_RULES.get(candidate);
            if (rules != null) {
                for (String prefix : rules) {
                    if (p.startsWith(prefix)) return TRACKER;
                }
            }
            int dot = candidate.indexOf('.');
            if (dot < 0 || candidate.indexOf('.', dot + 1) < 0) break; // keep at least "name.tld"
            candidate = candidate.substring(dot + 1);
        }
        return NONE;
    }

    static boolean isCommonCdn(String host) {
        if (host == null) return false;
        String candidate = host.toLowerCase(Locale.ROOT);
        while (true) {
            if (COMMON_CDNS.contains(candidate)) return true;
            int dot = candidate.indexOf('.');
            if (dot < 0 || candidate.indexOf('.', dot + 1) < 0) return COMMON_CDNS.contains(candidate);
            candidate = candidate.substring(dot + 1);
        }
    }

    static int size() {
        return AD_DOMAINS.size() + TRACKER_DOMAINS.size() + MALICIOUS_DOMAINS.size();
    }
}

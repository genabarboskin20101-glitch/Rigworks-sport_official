package com.lmusic.app.floria;

import android.content.Intent;
import android.net.Uri;
import android.net.http.SslCertificate;
import android.os.Build;
import android.os.Bundle;

import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/** Stateless security helpers: URL analysis, intent sanitising, download safety, certificate details. */
final class SecurityGuard {
    private SecurityGuard() {}

    // ---- Session statistics (lifetime totals are flushed into Prefs) -------------------------

    static final AtomicInteger ADS = new AtomicInteger();
    static final AtomicInteger TRACKERS = new AtomicInteger();
    static final AtomicInteger MALICIOUS = new AtomicInteger();
    static final AtomicInteger THIRD_PARTY = new AtomicInteger();
    static final AtomicInteger HTTPS_UPGRADES = new AtomicInteger();
    static final AtomicInteger TLS_BLOCKED = new AtomicInteger();
    static final AtomicInteger THREATS = new AtomicInteger();
    static final AtomicInteger POPUPS = new AtomicInteger();
    static final AtomicInteger EXTERNAL_BLOCKED = new AtomicInteger();
    static final AtomicInteger LOOKALIKES = new AtomicInteger();
    static final AtomicInteger DOWNLOADS_BLOCKED = new AtomicInteger();

    private static final String[] STAT_KEYS = {"ads", "trackers", "malicious", "third_party", "https_upgrades",
            "tls_blocked", "threats", "popups", "external_blocked", "lookalikes", "downloads_blocked"};

    private static AtomicInteger[] counters() {
        return new AtomicInteger[]{ADS, TRACKERS, MALICIOUS, THIRD_PARTY, HTTPS_UPGRADES, TLS_BLOCKED, THREATS,
                POPUPS, EXTERNAL_BLOCKED, LOOKALIKES, DOWNLOADS_BLOCKED};
    }

    /** Moves the session counters into the persistent lifetime totals. */
    static void flushStats(Prefs prefs) {
        AtomicInteger[] c = counters();
        for (int i = 0; i < c.length; i++) {
            int value = c[i].getAndSet(0);
            if (value > 0) prefs.addStat(STAT_KEYS[i], value);
        }
    }

    static long sessionStat(String key) {
        AtomicInteger[] c = counters();
        for (int i = 0; i < STAT_KEYS.length; i++) if (STAT_KEYS[i].equals(key)) return c[i].get();
        return 0;
    }

    static String[] statKeys() {
        return STAT_KEYS.clone();
    }

    // ---- Domains ------------------------------------------------------------------------------

    private static final Set<String> SECOND_LEVEL = new HashSet<>(Arrays.asList(
            "co", "com", "org", "net", "gov", "edu", "ac", "ne", "or", "go", "mil", "nom", "sch"));

    /** Approximate eTLD+1 (no full Public Suffix List on device; handles the common co.uk / com.au shapes). */
    static String registrableDomain(String host) {
        if (host == null) return "";
        String h = host.toLowerCase(Locale.ROOT);
        if (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        if (isIpLiteral(h)) return h;
        String[] labels = h.split("\\.");
        int n = labels.length;
        if (n <= 2) return h;
        String last = labels[n - 1];
        String second = labels[n - 2];
        if (last.length() == 2 && SECOND_LEVEL.contains(second)) {
            return labels[n - 3] + "." + second + "." + last;
        }
        return second + "." + last;
    }

    static boolean isSameSite(String pageHost, String requestHost) {
        if (pageHost == null || requestHost == null) return true;
        return registrableDomain(pageHost).equals(registrableDomain(requestHost));
    }

    static boolean isIpLiteral(String host) {
        if (host == null) return false;
        if (host.indexOf(':') >= 0 || host.startsWith("[")) return true;
        if (host.matches("\\d{1,3}(\\.\\d{1,3}){3}")) return true;
        return host.matches("\\d{6,}") || host.matches("0[xX][0-9a-fA-F]+");
    }

    // ---- Look-alike / phishing heuristics -----------------------------------------------------

    static final int OK = 0;
    static final int WARN = 1;
    static final int BLOCK = 2;

    static final class Verdict {
        final int level;
        final String reason;

        Verdict(int level, String reason) {
            this.level = level;
            this.reason = reason;
        }

        static final Verdict SAFE = new Verdict(OK, null);
    }

    private static final String[][] BRANDS = {
            // keyword, legit registrable domains (comma separated), exact-token-only flag
            {"paypal", "paypal.com,paypal.me,paypalobjects.com,paypal.cn", "0"},
            {"microsoft", "microsoft.com,microsoftonline.com,live.com,office.com,office365.com,windows.com,msn.com,bing.com,azure.com,windowsazure.com,microsoft365.com,sharepoint.com,xbox.com,skype.com,outlook.com,azurewebsites.net", "0"},
            {"apple", "apple.com,icloud.com,mzstatic.com,apple.news", "1"},
            {"facebook", "facebook.com,fb.com,fbcdn.net,facebook.net,messenger.com,fb.me", "0"},
            {"instagram", "instagram.com,cdninstagram.com,instagr.am", "0"},
            {"whatsapp", "whatsapp.com,whatsapp.net,wa.me", "0"},
            {"telegram", "telegram.org,t.me,telegram.me,telegra.ph,telesco.pe", "0"},
            {"netflix", "netflix.com,nflxvideo.net,nflximg.net,nflxext.com,nflxso.net", "0"},
            {"binance", "binance.com,binance.us,bnbstatic.com,binance.org", "0"},
            {"coinbase", "coinbase.com", "0"},
            {"metamask", "metamask.io", "0"},
            {"sberbank", "sberbank.ru,sberbank.com,sber.ru", "0"},
            {"tinkoff", "tinkoff.ru,tbank.ru,tinkoff.com", "0"},
            {"gosuslugi", "gosuslugi.ru", "0"},
            {"alfabank", "alfabank.ru,alfabank.com", "0"},
    };

    /** Inspects a top-level navigation target for homograph / credential-in-URL / look-alike tricks. */
    static Verdict inspect(Uri uri) {
        if (uri == null) return Verdict.SAFE;
        String host = uri.getHost();
        if (host == null || host.isEmpty()) return Verdict.SAFE;
        String lower = host.toLowerCase(Locale.ROOT);

        if (uri.getUserInfo() != null && !uri.getUserInfo().isEmpty()) {
            return new Verdict(BLOCK, "Адрес содержит имя пользователя перед доменом («логин@сайт»). "
                    + "Это типичный приём фишинга: реальный сайт — «" + host + "».");
        }

        boolean nonAscii = false;
        Set<Character.UnicodeScript> scripts = new LinkedHashSet<>();
        for (int i = 0; i < lower.length(); ) {
            int cp = lower.codePointAt(i);
            i += Character.charCount(cp);
            if (cp > 127) nonAscii = true;
            if (Character.isLetter(cp)) {
                Character.UnicodeScript script = Character.UnicodeScript.of(cp);
                if (script != Character.UnicodeScript.COMMON && script != Character.UnicodeScript.INHERITED) {
                    scripts.add(script);
                }
            }
        }
        if (scripts.size() > 1) {
            return new Verdict(WARN, "Домен «" + host + "» смешивает символы разных алфавитов "
                    + "(например, кириллицу и латиницу). Так маскируют поддельные сайты.");
        }
        if (lower.startsWith("xn--") || lower.contains(".xn--") || nonAscii) {
            String shown = nonAscii ? host : decodePunycodeHint(lower);
            return new Verdict(WARN, "Домен «" + shown + "» записан не латиницей (IDN). "
                    + "Убедитесь, что это тот сайт, который вы ожидали.");
        }
        if (isIpLiteral(lower)) {
            return new Verdict(WARN, "Вы переходите по IP-адресу, а не по имени сайта. "
                    + "Настоящие сервисы почти никогда так не работают.");
        }

        String registrable = registrableDomain(lower);
        String[] tokens = lower.split("[.\\-]");
        for (String[] brand : BRANDS) {
            boolean hit = false;
            for (String token : tokens) {
                if ("1".equals(brand[2]) ? token.equals(brand[0]) : token.contains(brand[0])) {
                    hit = true;
                    break;
                }
            }
            if (!hit) continue;
            boolean legit = false;
            for (String domain : brand[1].split(",")) {
                if (registrable.equals(domain)) {
                    legit = true;
                    break;
                }
            }
            if (!legit) {
                return new Verdict(WARN, "Адрес «" + host + "» напоминает «" + brand[0]
                        + "», но не принадлежит этому сервису. Возможна фишинговая копия.");
            }
        }
        return Verdict.SAFE;
    }

    private static String decodePunycodeHint(String host) {
        try {
            return java.net.IDN.toUnicode(host);
        } catch (Exception e) {
            return host;
        }
    }

    // ---- Intent handling ------------------------------------------------------------------------

    /**
     * Turns an {@code intent:} URI into a harmless implicit VIEW/DIAL/SENDTO intent: explicit components,
     * selectors, flags and file/content data (the classic WebView intent-scheme attack surface) are removed.
     */
    static Intent sanitizeIntentUri(String raw) {
        try {
            Intent intent = Intent.parseUri(raw, Intent.URI_INTENT_SCHEME);
            String action = intent.getAction();
            if (action == null) action = Intent.ACTION_VIEW;
            if (!Intent.ACTION_VIEW.equals(action) && !Intent.ACTION_DIAL.equals(action)
                    && !Intent.ACTION_SENDTO.equals(action)) {
                return null;
            }
            intent.setAction(action);
            Uri data = intent.getData();
            if (data != null && data.getScheme() != null) {
                String scheme = data.getScheme().toLowerCase(Locale.ROOT);
                if (scheme.equals("file") || scheme.equals("content") || scheme.equals("javascript")
                        || scheme.equals("intent") || scheme.equals("android-app")) {
                    return null;
                }
            }
            intent.setComponent(null);
            intent.setSelector(null);
            intent.setClipData(null);
            intent.setFlags(0);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            return intent;
        } catch (Exception e) {
            return null;
        }
    }

    static boolean isSafeExternalScheme(String scheme) {
        if (scheme == null) return false;
        switch (scheme.toLowerCase(Locale.ROOT)) {
            case "mailto":
            case "tel":
            case "sms":
            case "smsto":
            case "geo":
                return true;
            default:
                return false;
        }
    }

    // ---- Downloads -------------------------------------------------------------------------------

    private static final Set<String> DANGEROUS_EXT = new HashSet<>(Arrays.asList(
            "apk", "apks", "xapk", "aab", "exe", "msi", "bat", "cmd", "com", "scr", "pif", "jar", "js", "jse",
            "vbs", "vbe", "wsf", "wsh", "ps1", "psm1", "sh", "bash", "run", "bin", "dmg", "pkg", "deb", "rpm",
            "appimage", "lnk", "hta", "reg", "cpl", "dll", "sys", "docm", "xlsm", "pptm", "dotm", "xlam",
            "iso", "img", "vhd", "crx", "xpi", "elf", "so"));

    static String sanitizeFileName(String name) {
        String n = name == null ? "" : name;
        n = n.replaceAll("[\\\\/:*?\"<>|\\u0000-\\u001f]", "_").trim();
        while (n.startsWith(".")) n = n.substring(1);
        if (n.length() > 120) {
            int dot = n.lastIndexOf('.');
            String ext = dot > 0 && n.length() - dot <= 12 ? n.substring(dot) : "";
            n = n.substring(0, 120 - ext.length()) + ext;
        }
        return n.isEmpty() ? "download" : n;
    }

    static boolean isDangerousFile(String fileName) {
        if (fileName == null) return false;
        String lower = fileName.toLowerCase(Locale.ROOT);
        int dot = lower.lastIndexOf('.');
        if (dot < 0 || dot == lower.length() - 1) return false;
        return DANGEROUS_EXT.contains(lower.substring(dot + 1));
    }

    // ---- Certificates ----------------------------------------------------------------------------

    /** Human-readable summary of the TLS certificate presented by the current page. */
    static String describeCertificate(SslCertificate certificate) {
        if (certificate == null) return "Сертификат недоступен.";
        StringBuilder sb = new StringBuilder();
        SslCertificate.DName to = certificate.getIssuedTo();
        SslCertificate.DName by = certificate.getIssuedBy();
        DateFormat fmt = DateFormat.getDateInstance(DateFormat.MEDIUM);
        if (to != null) sb.append("Выдан для: ").append(nonEmpty(to.getCName())).append('\n');
        if (to != null && !to.getOName().isEmpty()) sb.append("Организация: ").append(to.getOName()).append('\n');
        if (by != null) sb.append("Выдан центром: ").append(nonEmpty(by.getCName())).append('\n');
        if (by != null && !by.getOName().isEmpty()) sb.append("Организация ЦС: ").append(by.getOName()).append('\n');
        if (certificate.getValidNotBeforeDate() != null) {
            sb.append("Действует с: ").append(fmt.format(certificate.getValidNotBeforeDate())).append('\n');
        }
        if (certificate.getValidNotAfterDate() != null) {
            sb.append("Действует до: ").append(fmt.format(certificate.getValidNotAfterDate())).append('\n');
        }
        String fp = fingerprint(certificate);
        if (fp != null) sb.append("SHA-256: ").append(fp);
        return sb.toString().trim();
    }

    private static String nonEmpty(String value) {
        return value == null || value.isEmpty() ? "—" : value;
    }

    private static String fingerprint(SslCertificate certificate) {
        try {
            byte[] encoded = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                X509Certificate x509 = certificate.getX509Certificate();
                if (x509 != null) encoded = x509.getEncoded();
            }
            if (encoded == null) {
                Bundle bundle = SslCertificate.saveState(certificate);
                if (bundle != null) encoded = bundle.getByteArray("x509-certificate");
            }
            if (encoded == null) return null;
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(encoded);
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < digest.length; i++) {
                if (i > 0) hex.append(i % 8 == 0 ? "\n         " : ":");
                hex.append(String.format(Locale.ROOT, "%02X", digest[i]));
            }
            return hex.toString();
        } catch (Exception e) {
            return null;
        }
    }
}

package com.lmusic.app.floria;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.Build;
import android.webkit.WebView;

import java.util.ArrayList;
import java.util.List;

/** Builds the "Security dashboard": which protections are active, an overall score, and counters. */
final class SecurityReport {
    private SecurityReport() {}

    private static final class Check {
        final String label;
        final boolean ok;
        final int weight;

        Check(String label, boolean ok, int weight) {
            this.label = label;
            this.ok = ok;
            this.weight = weight;
        }
    }

    static boolean deviceSecure(Context context) {
        KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
        return km != null && km.isDeviceSecure();
    }

    static String build(Context context, Prefs prefs) {
        List<Check> checks = new ArrayList<>();
        checks.add(new Check("HTTP запрещён на уровне системы (только HTTPS)", true, 10));
        checks.add(new Check("Доверяются только системные сертификаты (пользовательские ЦС игнорируются)", true, 8));
        checks.add(new Check("Ошибки сертификатов не обходятся", true, 8));
        checks.add(new Check("Смешанный контент заблокирован", true, 5));
        checks.add(new Check("Доступ к file:// и content:// закрыт", true, 5));
        checks.add(new Check("Отладка WebView через USB выключена", true, 3));
        checks.add(new Check("Google Safe Browsing", prefs.bool(Prefs.SAFE_BROWSING), 10));
        checks.add(new Check("Автоматический переход http → https", prefs.bool(Prefs.HTTPS_UPGRADE), 6));
        checks.add(new Check("Блокировка трекеров", prefs.bool(Prefs.BLOCK_TRACKERS), 7));
        checks.add(new Check("Блокировка рекламы", prefs.bool(Prefs.BLOCK_ADS), 4));
        checks.add(new Check("Блокировка майнеров и вредоносных доменов", prefs.bool(Prefs.BLOCK_MALICIOUS), 5));
        checks.add(new Check("Сторонние cookie отключены", prefs.bool(Prefs.BLOCK_3P_COOKIES)
                || prefs.bool(Prefs.BLOCK_ALL_COOKIES), 7));
        checks.add(new Check("Защита от фингерпринтинга", prefs.bool(Prefs.FP_MASTER), 9));
        checks.add(new Check("Сигнал Global Privacy Control", prefs.bool(Prefs.SEND_GPC), 2));
        checks.add(new Check("Урезанный Referer", !"default".equals(prefs.str(Prefs.REFERRER)), 2));
        checks.add(new Check("Уменьшенный User-Agent", "reduced".equals(prefs.str(Prefs.UA_MODE)), 2));
        checks.add(new Check("Предупреждения о фишинге и подмене доменов", prefs.bool(Prefs.WARN_LOOKALIKE), 6));
        checks.add(new Check("Всплывающие окна заблокированы", prefs.bool(Prefs.BLOCK_POPUPS), 3));
        checks.add(new Check("Внешние приложения не открываются без запроса/блокируются", true, 4));
        checks.add(new Check("Проверка опасных загрузок", !"allow".equals(prefs.str(Prefs.DANGEROUS_DL)), 4));
        checks.add(new Check("Автозаполнение и сохранение форм отключены",
                prefs.bool(Prefs.NO_FORM_SAVE) && prefs.bool(Prefs.NO_AUTOFILL), 3));
        checks.add(new Check("Блокировка экрана на устройстве", deviceSecure(context), 6));
        checks.add(new Check("Блокировка приложения Floria", prefs.bool(Prefs.APP_LOCK), 3));
        checks.add(new Check("Очистка данных при выходе или приватный режим",
                prefs.bool(Prefs.CLEAR_ON_EXIT) || prefs.bool(Prefs.PRIVATE_MODE), 3));

        int total = 0;
        int earned = 0;
        for (Check c : checks) {
            total += c.weight;
            if (c.ok) earned += c.weight;
        }
        int score = Math.round(100f * earned / total);

        StringBuilder sb = new StringBuilder();
        sb.append("Уровень защиты: ").append(score).append(" / 100\n\n");
        for (Check c : checks) sb.append(c.ok ? "✓  " : "✕  ").append(c.label).append('\n');

        sb.append("\nСреда\n");
        sb.append("Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("Патч безопасности: ").append(Build.VERSION.SECURITY_PATCH).append('\n');
        sb.append("WebView: ").append(webViewVersion()).append('\n');
        sb.append("Правил блокировки в базе: ").append(Blocklist.size()).append('\n');
        int exceptions = prefs.allowlist().size();
        sb.append("Сайтов с отключённой защитой: ").append(exceptions).append('\n');

        sb.append("\nЗаблокировано (сессия / всего)\n");
        appendStat(sb, prefs, "Реклама", "ads");
        appendStat(sb, prefs, "Трекеры", "trackers");
        appendStat(sb, prefs, "Майнеры и вредоносные домены", "malicious");
        appendStat(sb, prefs, "Сторонние скрипты/фреймы", "third_party");
        appendStat(sb, prefs, "Переходов http → https", "https_upgrades");
        appendStat(sb, prefs, "Остановлено из-за сертификата", "tls_blocked");
        appendStat(sb, prefs, "Угроз Safe Browsing", "threats");
        appendStat(sb, prefs, "Всплывающих окон", "popups");
        appendStat(sb, prefs, "Запусков внешних приложений", "external_blocked");
        appendStat(sb, prefs, "Подозрительных адресов", "lookalikes");
        appendStat(sb, prefs, "Опасных загрузок", "downloads_blocked");

        sb.append("\nЗамечание: Floria использует системный WebView — его обновления приходят через Google Play. "
                + "Поддерживайте WebView/Chrome в актуальном состоянии: это самая важная мера безопасности.");
        return sb.toString();
    }

    private static void appendStat(StringBuilder sb, Prefs prefs, String label, String key) {
        long session = SecurityGuard.sessionStat(key);
        long total = prefs.stat(key) + session;
        sb.append(label).append(": ").append(session).append(" / ").append(total).append('\n');
    }

    private static String webViewVersion() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                android.content.pm.PackageInfo info = WebView.getCurrentWebViewPackage();
                if (info != null) return info.packageName + " " + info.versionName;
            }
        } catch (Exception ignored) {
            // fall through
        }
        return "неизвестно";
    }
}

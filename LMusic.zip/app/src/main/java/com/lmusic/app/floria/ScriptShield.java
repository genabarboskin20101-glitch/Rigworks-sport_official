package com.lmusic.app.floria;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;

/**
 * Builds the JavaScript that runs at document start in every frame and reduces browser fingerprinting
 * surface (canvas / WebGL / audio noise, hardware and screen normalisation, WebRTC IP-leak protection,
 * sensor and battery APIs, Global Privacy Control, referrer policy).
 */
final class ScriptShield {
    private ScriptShield() {}

    /** @return the script, or null when every protection it provides is switched off. */
    static String build(Prefs prefs, Set<String> allowlist) {
        boolean fp = prefs.bool(Prefs.FP_MASTER);
        JSONObject flags = new JSONObject();
        boolean any = false;
        try {
            any |= put(flags, "canvas", fp && prefs.bool(Prefs.FP_CANVAS));
            any |= put(flags, "webgl", fp && prefs.bool(Prefs.FP_WEBGL));
            any |= put(flags, "audio", fp && prefs.bool(Prefs.FP_AUDIO));
            any |= put(flags, "hardware", fp && prefs.bool(Prefs.FP_HARDWARE));
            any |= put(flags, "screen", fp && prefs.bool(Prefs.FP_SCREEN));
            any |= put(flags, "battery", fp && prefs.bool(Prefs.FP_BATTERY));
            any |= put(flags, "network", fp && prefs.bool(Prefs.FP_NETWORK));
            any |= put(flags, "webrtc", fp && prefs.bool(Prefs.FP_WEBRTC));
            any |= put(flags, "sensors", fp && prefs.bool(Prefs.FP_SENSORS));
            any |= put(flags, "timing", fp && prefs.bool(Prefs.FP_TIMING));
            any |= put(flags, "gpc", prefs.bool(Prefs.SEND_GPC));
            String referrer = prefs.str(Prefs.REFERRER);
            if ("same-origin".equals(referrer) || "no-referrer".equals(referrer)) {
                flags.put("referrer", referrer);
                any = true;
            } else {
                flags.put("referrer", "");
            }
        } catch (JSONException e) {
            return null;
        }
        if (!any) return null;
        JSONArray allow = new JSONArray();
        for (String host : allowlist) allow.put(host);
        return SCRIPT.replace("__FLAGS__", flags.toString()).replace("__ALLOW__", allow.toString());
    }

    private static boolean put(JSONObject o, String key, boolean value) throws JSONException {
        o.put(key, value);
        return value;
    }

    private static final String SCRIPT = """
(function () {
  'use strict';
  var F = __FLAGS__, ALLOW = __ALLOW__;
  try {
    var host = location.hostname;
    for (var a = 0; a < ALLOW.length; a++) {
      if (host === ALLOW[a] || host.endsWith('.' + ALLOW[a])) return;
    }
  } catch (e) {}
  try {
    if (window.__flr) return;
    Object.defineProperty(window, '__flr', { value: 1 });
  } catch (e) {}

  // --- keep patched functions looking native -------------------------------------------------
  var origTS = Function.prototype.toString;
  var spoofed = new WeakMap();
  function fakeTS() { return spoofed.has(this) ? spoofed.get(this) : origTS.call(this); }
  spoofed.set(fakeTS, 'function toString() { [native code] }');
  try {
    Object.defineProperty(Function.prototype, 'toString', { value: fakeTS, writable: true, configurable: true });
  } catch (e) {}
  function nm(fn, name) {
    try { spoofed.set(fn, 'function ' + name + '() { [native code] }'); } catch (e) {}
    return fn;
  }
  function hook(obj, prop, make) {
    try {
      if (!obj) return;
      var d = Object.getOwnPropertyDescriptor(obj, prop);
      if (!d || typeof d.value !== 'function') return;
      var fn = make(d.value);
      try { Object.defineProperty(fn, 'name', { value: prop, configurable: true }); } catch (e) {}
      nm(fn, prop);
      d.value = fn;
      Object.defineProperty(obj, prop, d);
    } catch (e) {}
  }
  function getter(obj, prop, value) {
    try {
      if (!obj) return;
      var d = Object.getOwnPropertyDescriptor(obj, prop);
      var g = function () { return typeof value === 'function' ? value.call(this) : value; };
      try { Object.defineProperty(g, 'name', { value: 'get ' + prop, configurable: true }); } catch (e) {}
      nm(g, 'get ' + prop);
      Object.defineProperty(obj, prop, {
        get: g, set: undefined, enumerable: d ? d.enumerable : true, configurable: true
      });
    } catch (e) {}
  }

  // --- deterministic per-document noise (same input -> same output within one page load) -------
  var seed = ((Math.random() * 4294967296) >>> 0) || 1;
  function mkr(s) {
    return function () {
      s ^= s << 13; s ^= s >>> 17; s ^= s << 5;
      return (s >>> 0) / 4294967296;
    };
  }

  // --- canvas -------------------------------------------------------------------------------------
  if (F.canvas) {
    var C2D = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
    var origGet = C2D && C2D.getImageData;
    var noiseData = function (img) {
      var d = img.data, n = d.length;
      if (!n) return img;
      var r = mkr(seed), cnt = Math.max(4, (n / 4096) | 0);
      for (var i = 0; i < cnt; i++) {
        var p = ((r() * (n / 4)) | 0) * 4 + ((r() * 3) | 0);
        d[p] = d[p] ^ 1;
      }
      return img;
    };
    var noisyCopy = function (c) {
      try {
        if (!c.width || !c.height || !origGet) return null;
        var t = document.createElement('canvas');
        t.width = c.width; t.height = c.height;
        var x = t.getContext('2d');
        if (!x) return null;
        x.drawImage(c, 0, 0);
        var img = origGet.call(x, 0, 0, t.width, t.height);
        noiseData(img);
        x.putImageData(img, 0, 0);
        return t;
      } catch (e) { return null; }
    };
    hook(C2D, 'getImageData', function (o) {
      return function () {
        var img = o.apply(this, arguments);
        try { return noiseData(img); } catch (e) { return img; }
      };
    });
    if (window.HTMLCanvasElement) {
      hook(HTMLCanvasElement.prototype, 'toDataURL', function (o) {
        return function () { var t = noisyCopy(this); return o.apply(t || this, arguments); };
      });
      hook(HTMLCanvasElement.prototype, 'toBlob', function (o) {
        return function () { var t = noisyCopy(this); return o.apply(t || this, arguments); };
      });
    }
  }

  // --- WebGL ----------------------------------------------------------------------------------------
  if (F.webgl) {
    [window.WebGLRenderingContext, window.WebGL2RenderingContext].forEach(function (G) {
      if (!G) return;
      hook(G.prototype, 'getParameter', function (o) {
        return function (p) {
          if (p === 37445) return 'Google Inc.';
          if (p === 37446) return 'ANGLE (Generic GPU)';
          return o.apply(this, arguments);
        };
      });
    });
  }

  // --- audio ---------------------------------------------------------------------------------------
  if (F.audio) {
    if (window.AudioBuffer) {
      var seen = new WeakSet();
      hook(AudioBuffer.prototype, 'getChannelData', function (o) {
        return function () {
          var arr = o.apply(this, arguments);
          try {
            if (!seen.has(arr)) {
              seen.add(arr);
              var r = mkr(seed), step = Math.max(1, (arr.length / 64) | 0);
              for (var i = 0; i < arr.length; i += step) arr[i] += (r() - 0.5) * 1e-7;
            }
          } catch (e) {}
          return arr;
        };
      });
    }
    if (window.AnalyserNode) {
      ['getFloatFrequencyData', 'getFloatTimeDomainData'].forEach(function (m) {
        hook(AnalyserNode.prototype, m, function (o) {
          return function (arr) {
            var res = o.apply(this, arguments);
            try {
              var r = mkr(seed);
              for (var i = 0; i < arr.length; i += 7) arr[i] += (r() - 0.5) * 1e-5;
            } catch (e) {}
            return res;
          };
        });
      });
    }
  }

  // --- hardware / locale ----------------------------------------------------------------------------
  if (F.hardware && window.Navigator) {
    var NP = Navigator.prototype;
    getter(NP, 'hardwareConcurrency', 4);
    if ('deviceMemory' in NP) getter(NP, 'deviceMemory', 4);
    var firstLang = navigator.language, langs = null;
    getter(NP, 'languages', function () { return langs || (langs = Object.freeze([firstLang])); });
  }

  // --- screen ----------------------------------------------------------------------------------------
  if (F.screen && window.Screen) {
    var SP = Screen.prototype;
    var round100 = function (v) { return Math.round(v / 100) * 100 || 100; };
    ['width', 'height', 'availWidth', 'availHeight'].forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(SP, k);
      if (d && d.get) { var og = d.get; getter(SP, k, function () { return round100(og.call(this)); }); }
    });
    getter(SP, 'colorDepth', 24);
    getter(SP, 'pixelDepth', 24);
  }

  // --- battery / network information -----------------------------------------------------------------
  if (F.battery && window.Navigator) {
    try { delete Navigator.prototype.getBattery; } catch (e) {}
  }
  if (F.network && window.Navigator) {
    ['connection', 'mozConnection', 'webkitConnection'].forEach(function (k) {
      if (k in Navigator.prototype) getter(Navigator.prototype, k, undefined);
    });
  }

  // --- WebRTC: never reveal local / LAN addresses (forces relay candidates only) ---------------------
  if (F.webrtc) {
    ['RTCPeerConnection', 'webkitRTCPeerConnection'].forEach(function (k) {
      var T = window[k];
      if (!T) return;
      try {
        var P = new Proxy(T, {
          construct: function (target, args, newTarget) {
            var cfg = Object.assign({}, args[0] || {});
            cfg.iceTransportPolicy = 'relay';
            return Reflect.construct(target, [cfg].concat(Array.prototype.slice.call(args, 1)), newTarget);
          }
        });
        Object.defineProperty(window, k, { value: P, writable: true, configurable: true });
      } catch (e) {}
    });
  }

  // --- motion / orientation sensors -------------------------------------------------------------------
  if (F.sensors) {
    var BLOCKED = { devicemotion: 1, deviceorientation: 1, deviceorientationabsolute: 1 };
    if (window.EventTarget) {
      hook(EventTarget.prototype, 'addEventListener', function (o) {
        return function (type) {
          if (BLOCKED[String(type)] === 1 && (this === window || this === document)) return;
          return o.apply(this, arguments);
        };
      });
    }
    ['Accelerometer', 'Gyroscope', 'Magnetometer', 'AbsoluteOrientationSensor', 'RelativeOrientationSensor',
     'LinearAccelerationSensor', 'GravitySensor', 'AmbientLightSensor'].forEach(function (k) {
      try { delete window[k]; } catch (e) {}
    });
  }

  // --- timers ------------------------------------------------------------------------------------------
  if (F.timing && window.Performance) {
    hook(Performance.prototype, 'now', function (o) {
      return function () { return Math.floor(o.call(this)); };
    });
  }

  // --- Global Privacy Control / Do-Not-Track -------------------------------------------------------------
  if (F.gpc && window.Navigator) {
    getter(Navigator.prototype, 'globalPrivacyControl', true);
    getter(Navigator.prototype, 'doNotTrack', '1');
  }

  // --- referrer policy -------------------------------------------------------------------------------------
  if (F.referrer) {
    var addMeta = function () {
      var root = document.head || document.documentElement;
      if (!root) return false;
      var m = document.createElement('meta');
      m.name = 'referrer';
      m.content = F.referrer;
      root.insertBefore(m, root.firstChild);
      return true;
    };
    try {
      if (!addMeta()) {
        var mo = new MutationObserver(function () { if (addMeta()) mo.disconnect(); });
        mo.observe(document, { childList: true, subtree: true });
      }
    } catch (e) {}
  }
})();
""";
}

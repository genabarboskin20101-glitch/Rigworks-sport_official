package com.lmusic.app.floria;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Search providers selectable in settings. Private-by-design engines come first. */
final class SearchEngines {
    private SearchEngines() {}

    /** id, label, form action, query parameter. */
    static final String[][] LIST = {
            {"ddg", "DuckDuckGo", "https://duckduckgo.com/", "q"},
            {"brave", "Brave Search", "https://search.brave.com/search", "q"},
            {"startpage", "Startpage", "https://www.startpage.com/do/search", "query"},
            {"qwant", "Qwant", "https://www.qwant.com/", "q"},
            {"ecosia", "Ecosia", "https://www.ecosia.org/search", "q"},
            {"mojeek", "Mojeek", "https://www.mojeek.com/search", "q"},
            {"yandex", "Яндекс", "https://yandex.com/search/", "text"},
            {"google", "Google", "https://www.google.com/search", "q"},
    };

    static String[] get(String id) {
        for (String[] e : LIST) if (e[0].equals(id)) return e;
        return LIST[0];
    }

    static String[] ids() {
        String[] out = new String[LIST.length];
        for (int i = 0; i < LIST.length; i++) out[i] = LIST[i][0];
        return out;
    }

    static String[] labels() {
        String[] out = new String[LIST.length];
        for (int i = 0; i < LIST.length; i++) out[i] = LIST[i][1];
        return out;
    }

    static String searchUrl(String id, String query) {
        String[] e = get(id);
        try {
            return e[2] + "?" + e[3] + "=" + URLEncoder.encode(query, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
            return e[2];
        }
    }
}

package com.lmusic.app.floria;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Typed access to every Floria setting, with the secure-by-default values defined in one place. */
final class Prefs {
    // ---- Security ---------------------------------------------------------------------------
    static final String SAFE_BROWSING = "safe_browsing";
    static final String HTTPS_UPGRADE = "https_upgrade";
    static final String WARN_LOOKALIKE = "warn_lookalike";
    static final String BLOCK_POPUPS = "block_popups";
    static final String EXTERNAL_LINKS = "external_links";      // ask | block
    static final String CONFIRM_DOWNLOADS = "confirm_downloads";
    static final String DANGEROUS_DL = "dangerous_dl";          // warn | block | allow

    // ---- Content blocking -------------------------------------------------------------------
    static final String BLOCK_ADS = "block_ads";
    static final String BLOCK_TRACKERS = "block_trackers";
    static final String BLOCK_MALICIOUS = "block_malicious";
    static final String BLOCK_3P_SCRIPTS = "block_3p_scripts";
    static final String BLOCK_3P_FRAMES = "block_3p_frames";
    static final String BLOCK_3P_COOKIES = "block_3p_cookies";
    static final String BLOCK_ALL_COOKIES = "block_all_cookies";

    // ---- Privacy ----------------------------------------------------------------------------
    static final String SEND_GPC = "send_gpc";
    static final String REFERRER = "referrer";                  // default | same-origin | no-referrer
    static final String UA_MODE = "ua_mode";                    // reduced | default | desktop
    static final String FP_MASTER = "fp_master";
    static final String FP_CANVAS = "fp_canvas";
    static final String FP_WEBGL = "fp_webgl";
    static final String FP_AUDIO = "fp_audio";
    static final String FP_HARDWARE = "fp_hardware";
    static final String FP_SCREEN = "fp_screen";
    static final String FP_BATTERY = "fp_battery";
    static final String FP_NETWORK = "fp_network";
    static final String FP_WEBRTC = "fp_webrtc";
    static final String FP_SENSORS = "fp_sensors";
    static final String FP_TIMING = "fp_timing";
    static final String PRIVATE_MODE = "private_mode";
    static final String SAVE_HISTORY = "save_history";
    static final String HISTORY_LIMIT = "history_limit";
    static final String NO_FORM_SAVE = "no_form_save";
    static final String NO_AUTOFILL = "no_autofill";
    static final String IME_INCOGNITO = "ime_incognito";

    // ---- Clear on exit ----------------------------------------------------------------------
    static final String CLEAR_ON_EXIT = "clear_on_exit";
    static final String CLEAR_HISTORY_EXIT = "clear_history_exit";
    static final String CLEAR_COOKIES_EXIT = "clear_cookies_exit";
    static final String CLEAR_CACHE_EXIT = "clear_cache_exit";
    static final String CLEAR_STORAGE_EXIT = "clear_storage_exit";

    // ---- App protection ---------------------------------------------------------------------
    static final String APP_LOCK = "app_lock";
    static final String LOCK_TIMEOUT = "lock_timeout";          // seconds
    static final String BLOCK_SCREENSHOTS = "block_screenshots";

    // ---- Site permissions -------------------------------------------------------------------
    static final String PERM_LOCATION = "perm_location";        // ask | block
    static final String PERM_CAMERA = "perm_camera";
    static final String PERM_MIC = "perm_mic";

    // ---- Web content ------------------------------------------------------------------------
    static final String JS_ENABLED = "js_enabled";
    static final String DOM_STORAGE = "dom_storage";
    static final String LOAD_IMAGES = "load_images";
    static final String BLOCK_AUTOPLAY = "block_autoplay";
    static final String CACHE_MODE = "cache_mode";              // default | none | offline
    static final String ZOOM_ENABLED = "zoom_enabled";

    // ---- Appearance / behaviour -------------------------------------------------------------
    static final String SEARCH_ENGINE = "search_engine";
    static final String TEXT_ZOOM = "text_zoom";
    static final String FORCE_DARK = "force_dark";
    static final String KEEP_SCREEN_ON = "keep_screen_on";

    private static final String ALLOWLIST = "site_allowlist";
    private static final Map<String, Object> DEFAULTS = new HashMap<>();

    static {
        // security
        d(SAFE_BROWSING, true);
        d(HTTPS_UPGRADE, true);
        d(WARN_LOOKALIKE, true);
        d(BLOCK_POPUPS, true);
        d(EXTERNAL_LINKS, "ask");
        d(CONFIRM_DOWNLOADS, true);
        d(DANGEROUS_DL, "warn");
        // blocking
        d(BLOCK_ADS, true);
        d(BLOCK_TRACKERS, true);
        d(BLOCK_MALICIOUS, true);
        d(BLOCK_3P_SCRIPTS, false);
        d(BLOCK_3P_FRAMES, false);
        d(BLOCK_3P_COOKIES, true);
        d(BLOCK_ALL_COOKIES, false);
        // privacy
        d(SEND_GPC, true);
        d(REFERRER, "default");
        d(UA_MODE, "reduced");
        d(FP_MASTER, true);
        d(FP_CANVAS, true);
        d(FP_WEBGL, true);
        d(FP_AUDIO, true);
        d(FP_HARDWARE, true);
        d(FP_SCREEN, true);
        d(FP_BATTERY, true);
        d(FP_NETWORK, true);
        d(FP_WEBRTC, true);
        d(FP_SENSORS, true);
        d(FP_TIMING, false);
        d(PRIVATE_MODE, false);
        d(SAVE_HISTORY, true);
        d(HISTORY_LIMIT, "150");
        d(NO_FORM_SAVE, true);
        d(NO_AUTOFILL, true);
        d(IME_INCOGNITO, true);
        // clear on exit
        d(CLEAR_ON_EXIT, false);
        d(CLEAR_HISTORY_EXIT, true);
        d(CLEAR_COOKIES_EXIT, true);
        d(CLEAR_CACHE_EXIT, true);
        d(CLEAR_STORAGE_EXIT, true);
        // app protection
        d(APP_LOCK, false);
        d(LOCK_TIMEOUT, "60");
        d(BLOCK_SCREENSHOTS, false);
        // permissions
        d(PERM_LOCATION, "ask");
        d(PERM_CAMERA, "ask");
        d(PERM_MIC, "ask");
        // web content
        d(JS_ENABLED, true);
        d(DOM_STORAGE, true);
        d(LOAD_IMAGES, true);
        d(BLOCK_AUTOPLAY, true);
        d(CACHE_MODE, "default");
        d(ZOOM_ENABLED, true);
        // appearance
        d(SEARCH_ENGINE, "ddg");
        d(TEXT_ZOOM, "100");
        d(FORCE_DARK, false);
        d(KEEP_SCREEN_ON, false);
    }

    private static void d(String key, Object value) {
        DEFAULTS.put(key, value);
    }

    private final SharedPreferences sp;

    Prefs(Context context) {
        sp = context.getApplicationContext().getSharedPreferences("floria_settings", Context.MODE_PRIVATE);
    }

    boolean bool(String key) {
        Object def = DEFAULTS.get(key);
        return sp.getBoolean(key, def instanceof Boolean && (Boolean) def);
    }

    String str(String key) {
        Object def = DEFAULTS.get(key);
        String value;
        try {
            value = sp.getString(key, def instanceof String ? (String) def : "");
        } catch (ClassCastException e) {
            value = def instanceof String ? (String) def : "";
        }
        return value;
    }

    int integer(String key, int fallback) {
        try {
            return Integer.parseInt(str(key));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    void setBool(String key, boolean value) {
        sp.edit().putBoolean(key, value).apply();
    }

    void setStr(String key, String value) {
        sp.edit().putString(key, value).apply();
    }

    /** Resets every setting (and per-site exceptions) to the secure defaults. */
    void reset() {
        sp.edit().clear().apply();
    }

    // ---- Per-site exceptions ------------------------------------------------------------------

    Set<String> allowlist() {
        return new HashSet<>(sp.getStringSet(ALLOWLIST, new HashSet<String>()));
    }

    boolean isAllowlisted(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        Set<String> list = sp.getStringSet(ALLOWLIST, null);
        if (list == null || list.isEmpty()) return false;
        for (String entry : list) {
            if (h.equals(entry) || h.endsWith("." + entry)) return true;
        }
        return false;
    }

    /** Adds or removes the registrable domain of {@code host} from the exceptions; returns the new state. */
    boolean toggleAllowlist(String host) {
        if (host == null) return false;
        String domain = SecurityGuard.registrableDomain(host.toLowerCase(Locale.ROOT));
        Set<String> list = allowlist();
        boolean nowAllowed;
        if (list.contains(domain)) {
            list.remove(domain);
            nowAllowed = false;
        } else {
            list.add(domain);
            nowAllowed = true;
        }
        sp.edit().putStringSet(ALLOWLIST, list).apply();
        return nowAllowed;
    }

    void clearAllowlist() {
        sp.edit().remove(ALLOWLIST).apply();
    }

    // ---- Lifetime statistics ------------------------------------------------------------------

    long stat(String key) {
        return sp.getLong("stat_" + key, 0L);
    }

    void addStat(String key, long delta) {
        if (delta <= 0) return;
        sp.edit().putLong("stat_" + key, stat(key) + delta).apply();
    }
}

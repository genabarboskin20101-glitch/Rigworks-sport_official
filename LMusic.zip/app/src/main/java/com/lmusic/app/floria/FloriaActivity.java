package com.lmusic.app.floria;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SafeBrowsingResponse;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class FloriaActivity extends Activity {
    private static final int BG = Color.rgb(16, 16, 16);
    private static final int PANEL = Color.rgb(24, 24, 24);
    private static final int CONTROL = Color.rgb(37, 37, 37);
    private static final int BORDER = Color.rgb(58, 58, 58);
    private static final int TEXT = Color.rgb(239, 239, 239);
    private static final int MUTED = Color.rgb(166, 166, 166);
    private static final int SECURE_GREEN = Color.rgb(129, 199, 132);
    private static final int WARN_AMBER = Color.rgb(255, 183, 77);

    private static final String HOME_URL = "floria://home";
    private static final String INTERNAL_HOST = "floria.invalid";
    private static final String PREFS = "floria_preferences";
    private static final String HISTORY_KEY = DataCleaner.HISTORY_KEY;
    private static final String BOOKMARKS_KEY = "bookmarks_json";

    private static final int REQ_STORAGE = 410;
    private static final int REQ_MEDIA = 411;
    private static final int REQ_GEO = 412;
    private static final int REQ_UNLOCK = 4101;
    private static final int MAX_TABS = 30;

    private final ArrayList<BrowserTab> tabs = new ArrayList<>();
    private final Set<String> approvedHosts = new HashSet<>();
    private SharedPreferences preferences;
    private Prefs prefs;
    private LinearLayout root;
    private FrameLayout webHost;
    private EditText addressInput;
    private ProgressBar progressBar;
    private TextView tabsButton;
    private TextView siteGlyph;
    private LinearLayout lockOverlay;
    private int currentTab = -1;
    private PendingDownload pendingDownload;
    private String cachedDefaultUa;

    // pending runtime-permission flows
    private PermissionRequest pendingMediaRequest;
    private String[] pendingMediaResources;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    // app lock state
    private boolean locked;
    private boolean authInFlight;
    private boolean authCancelled;
    private boolean internalLaunch;
    private long backgroundedAt;

    /** Immutable snapshot of the blocking rules, read from the WebView's IO thread. */
    private static final class Policy {
        final boolean ads;
        final boolean trackers;
        final boolean malicious;
        final boolean scripts3p;
        final boolean frames3p;

        Policy(boolean ads, boolean trackers, boolean malicious, boolean scripts3p, boolean frames3p) {
            this.ads = ads;
            this.trackers = trackers;
            this.malicious = malicious;
            this.scripts3p = scripts3p;
            this.frames3p = frames3p;
        }
    }

    private volatile Policy policy = new Policy(true, true, true, false, false);

    private static final class BrowserTab {
        final WebView webView;
        String url = HOME_URL;
        String title = "Новая вкладка";
        String failedUrl;
        volatile String pageHost;
        final AtomicInteger blockedAds = new AtomicInteger();
        final AtomicInteger blockedTrackers = new AtomicInteger();
        final AtomicInteger blockedOther = new AtomicInteger();
        ScriptHandler shield;
        String shieldScript;
        String shieldSource;
        boolean shieldInstalled;

        BrowserTab(WebView webView) {
            this.webView = webView;
        }
    }

    private static final class PendingDownload {
        final String url;
        final String userAgent;
        final String fileName;
        final String mimeType;

        PendingDownload(String url, String userAgent, String fileName, String mimeType) {
            this.url = url;
            this.userAgent = userAgent;
            this.fileName = fileName;
            this.mimeType = mimeType;
        }
    }

    // =============================================================================================
    // Lifecycle
    // =============================================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setNavigationBarDividerColor(BORDER);
        }
        applyWindowFlags();
        buildUi();
        refreshPolicy();

        if (prefs.bool(Prefs.APP_LOCK) && SecurityReport.deviceSecure(this)) {
            lockNow();
        }
        if (savedInstanceState == null) {
            int flags = 0;
            if (prefs.bool(Prefs.CLEAR_ON_EXIT)) flags |= DataCleaner.exitFlags(prefs);
            if (prefs.bool(Prefs.PRIVATE_MODE)) {
                flags |= DataCleaner.COOKIES | DataCleaner.CACHE | DataCleaner.STORAGE | DataCleaner.FORMS;
            }
            if (flags != 0) DataCleaner.clear(this, prefs, flags);
        }

        if (savedInstanceState != null) {
            ArrayList<String> restoredUrls = savedInstanceState.getStringArrayList("tab_urls");
            if (restoredUrls != null && !restoredUrls.isEmpty()) {
                for (String url : restoredUrls) addTab(url, false);
                int savedIndex = savedInstanceState.getInt("current_tab", 0);
                showTab(Math.max(0, Math.min(savedIndex, tabs.size() - 1)));
                return;
            }
        }
        String external = extractExternalTarget(getIntent());
        addTab(external != null ? external : HOME_URL, true);
    }

    /** Запрос из LMusic или другого приложения: веб-поиск (ACTION_WEB_SEARCH) или ссылка (ACTION_VIEW http/https). */
    private String extractExternalTarget(Intent intent) {
        if (intent == null) return null;
        String action = intent.getAction();
        if (Intent.ACTION_WEB_SEARCH.equals(action)) {
            String query = intent.getStringExtra(android.app.SearchManager.QUERY);
            if (query == null || query.trim().isEmpty()) return null;
            return resolveInput(query);
        }
        if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
            String url = intent.getData().toString();
            return isHttpUrl(url) ? url : null;
        }
        return null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String target = extractExternalTarget(intent);
        if (target != null) addTab(target, true);
    }

    @Override
    protected void onStart() {
        super.onStart();
        boolean skipRelock = internalLaunch;
        internalLaunch = false;
        if (prefs.bool(Prefs.APP_LOCK) && SecurityReport.deviceSecure(this)) {
            if (!locked && !skipRelock && backgroundedAt > 0) {
                long away = SystemClock.elapsedRealtime() - backgroundedAt;
                if (away >= prefs.integer(Prefs.LOCK_TIMEOUT, 60) * 1000L) lockNow();
            }
            if (locked && !authInFlight && !authCancelled) promptUnlock();
        } else if (locked) {
            unlock();
        }
    }

    @Override
    protected void onStop() {
        backgroundedAt = SystemClock.elapsedRealtime();
        authCancelled = false;
        SecurityGuard.flushStats(prefs);
        super.onStop();
    }

    @Override
    protected void onPause() {
        for (BrowserTab tab : tabs) {
            tab.webView.onPause();
            tab.webView.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyAll();
        for (BrowserTab tab : tabs) {
            tab.webView.onResume();
            tab.webView.resumeTimers();
        }
    }

    @Override
    protected void onDestroy() {
        if (isFinishing() && prefs != null) {
            int flags = 0;
            if (prefs.bool(Prefs.CLEAR_ON_EXIT)) flags |= DataCleaner.exitFlags(prefs);
            if (prefs.bool(Prefs.PRIVATE_MODE)) {
                flags |= DataCleaner.COOKIES | DataCleaner.CACHE | DataCleaner.STORAGE | DataCleaner.FORMS;
            }
            if (flags != 0) DataCleaner.clear(this, prefs, flags);
            SecurityGuard.flushStats(prefs);
        }
        for (BrowserTab tab : tabs) {
            try {
                tab.webView.destroy();
            } catch (Exception ignored) {
                // already gone
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        ArrayList<String> urls = new ArrayList<>();
        if (!prefs.bool(Prefs.PRIVATE_MODE)) {
            for (BrowserTab tab : tabs) urls.add(tab.url == null ? HOME_URL : tab.url);
        }
        outState.putStringArrayList("tab_urls", urls);
        outState.putInt("current_tab", Math.max(currentTab, 0));
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (locked) {
            moveTaskToBack(true);
            return;
        }
        BrowserTab tab = current();
        if (tab != null && tab.webView.canGoBack()) {
            tab.webView.goBack();
        } else if (tabs.size() > 1) {
            closeTab(currentTab);
        } else {
            super.onBackPressed();
        }
    }

    // =============================================================================================
    // App lock
    // =============================================================================================

    private void lockNow() {
        locked = true;
        authCancelled = false;
        if (lockOverlay != null) lockOverlay.setVisibility(View.VISIBLE);
        if (addressInput != null) hideKeyboard();
    }

    private void unlock() {
        locked = false;
        if (lockOverlay != null) lockOverlay.setVisibility(View.GONE);
    }

    private void promptUnlock() {
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        Intent intent = km == null ? null
                : km.createConfirmDeviceCredentialIntent("Floria", "Подтвердите личность, чтобы продолжить");
        if (intent == null) {
            unlock();
            return;
        }
        authInFlight = true;
        internalLaunch = true;
        try {
            startActivityForResult(intent, REQ_UNLOCK);
        } catch (Exception e) {
            authInFlight = false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_UNLOCK) {
            authInFlight = false;
            if (resultCode == RESULT_OK) {
                authCancelled = false;
                unlock();
            } else {
                authCancelled = true;
            }
        }
    }

    // =============================================================================================
    // UI construction
    // =============================================================================================

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFilterTouchesWhenObscured(true); // tapjacking protection

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets systemBars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                view.setPadding(0, systemBars.top, 0, systemBars.bottom);
                return insets;
            });
        }

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(dp(10), dp(8), dp(8), dp(7));
        top.setBackgroundColor(PANEL);

        TextView logo = new TextView(this);
        logo.setText("F");
        logo.setTextColor(TEXT);
        logo.setTextSize(24);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(rounded(CONTROL, BORDER, 12));
        logo.setContentDescription("Floria browser");
        top.addView(logo, new LinearLayout.LayoutParams(dp(42), dp(42)));

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(dp(9), 1));

        LinearLayout addressBox = new LinearLayout(this);
        addressBox.setGravity(Gravity.CENTER_VERTICAL);
        addressBox.setOrientation(LinearLayout.HORIZONTAL);
        addressBox.setPadding(dp(4), 0, dp(10), 0);
        addressBox.setBackground(rounded(CONTROL, BORDER, 13));

        siteGlyph = new TextView(this);
        siteGlyph.setText("⌕");
        siteGlyph.setTextSize(19);
        siteGlyph.setTextColor(MUTED);
        siteGlyph.setGravity(Gravity.CENTER);
        siteGlyph.setContentDescription("Информация о сайте и защите");
        siteGlyph.setOnClickListener(v -> showSiteInfo());
        addressBox.addView(siteGlyph, new LinearLayout.LayoutParams(dp(34), -1));

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextSize(14);
        addressInput.setTextColor(TEXT);
        addressInput.setHintTextColor(MUTED);
        addressInput.setHint("Поиск или адрес сайта");
        addressInput.setSelectAllOnFocus(true);
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressInput.setBackgroundColor(Color.TRANSPARENT);
        addressInput.setPadding(dp(3), 0, 0, 0);
        addressBox.addView(addressInput, new LinearLayout.LayoutParams(0, -1, 1f));
        addressInput.setOnEditorActionListener((view, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                navigateFromAddress();
                return true;
            }
            return false;
        });
        top.addView(addressBox, new LinearLayout.LayoutParams(0, dp(42), 1f));

        TextView menu = iconButton("⋮", "Меню браузера", 27);
        LinearLayout.LayoutParams menuParams = new LinearLayout.LayoutParams(dp(38), dp(42));
        menuParams.leftMargin = dp(5);
        top.addView(menu, menuParams);
        menu.setOnClickListener(this::showOverflowMenu);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(58)));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(ColorStateList.valueOf(MUTED));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(BG));
        progressBar.setVisibility(View.INVISIBLE);
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(2)));

        webHost = new FrameLayout(this);
        webHost.setBackgroundColor(Color.WHITE);
        root.addView(webHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        View divider = new View(this);
        divider.setBackgroundColor(BORDER);
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(dp(7), dp(3), dp(7), dp(3));
        bottom.setBackgroundColor(PANEL);

        addBottomButton(bottom, "‹", "Назад", v -> goBack(), 25);
        addBottomButton(bottom, "›", "Вперёд", v -> goForward(), 25);
        addBottomButton(bottom, "⌂", "Домой", v -> goHome(), 23);
        addBottomButton(bottom, "↻", "Перезагрузить", v -> reloadCurrent(), 22);

        tabsButton = iconButton("1", "Показать вкладки", 15);
        tabsButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bottom.addView(tabsButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        tabsButton.setOnClickListener(v -> showTabsDialog());

        addBottomButton(bottom, "+", "Новая вкладка", v -> addTab(HOME_URL, true), 26);
        root.addView(bottom, new LinearLayout.LayoutParams(-1, dp(54)));

        // The lock screen covers everything (including the first frame) while the app is locked.
        lockOverlay = new LinearLayout(this);
        lockOverlay.setOrientation(LinearLayout.VERTICAL);
        lockOverlay.setGravity(Gravity.CENTER);
        lockOverlay.setBackgroundColor(BG);
        lockOverlay.setClickable(true);
        lockOverlay.setFocusable(true);
        lockOverlay.setVisibility(View.GONE);
        TextView lockTitle = new TextView(this);
        lockTitle.setText("Floria заблокирован");
        lockTitle.setTextColor(TEXT);
        lockTitle.setTextSize(22);
        lockTitle.setGravity(Gravity.CENTER);
        lockOverlay.addView(lockTitle, new LinearLayout.LayoutParams(-2, -2));
        TextView unlockButton = new TextView(this);
        unlockButton.setText("Разблокировать");
        unlockButton.setTextColor(TEXT);
        unlockButton.setTextSize(16);
        unlockButton.setGravity(Gravity.CENTER);
        unlockButton.setBackground(rounded(CONTROL, BORDER, 13));
        unlockButton.setOnClickListener(v -> {
            authCancelled = false;
            if (!authInFlight) promptUnlock();
        });
        LinearLayout.LayoutParams unlockParams = new LinearLayout.LayoutParams(dp(220), dp(48));
        unlockParams.topMargin = dp(24);
        lockOverlay.addView(unlockButton, unlockParams);

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        frame.addView(lockOverlay, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
    }

    private void addBottomButton(LinearLayout parent, String glyph, String description, View.OnClickListener listener, int size) {
        TextView button = iconButton(glyph, description, size);
        parent.addView(button, new LinearLayout.LayoutParams(0, dp(44), 1f));
        button.setOnClickListener(listener);
    }

    private TextView iconButton(String glyph, String description, int textSize) {
        TextView button = new TextView(this);
        button.setText(glyph);
        button.setTextColor(TEXT);
        button.setTextSize(textSize);
        button.setGravity(Gravity.CENTER);
        button.setBackground(rounded(PANEL, PANEL, 11));
        button.setContentDescription(description);
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private GradientDrawable rounded(int fillColor, int strokeColor, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeColor != fillColor) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    // =============================================================================================
    // Settings application
    // =============================================================================================

    private void refreshPolicy() {
        policy = new Policy(
                prefs.bool(Prefs.BLOCK_ADS),
                prefs.bool(Prefs.BLOCK_TRACKERS),
                prefs.bool(Prefs.BLOCK_MALICIOUS),
                prefs.bool(Prefs.BLOCK_3P_SCRIPTS),
                prefs.bool(Prefs.BLOCK_3P_FRAMES));
    }

    private void applyWindowFlags() {
        boolean secure = prefs.bool(Prefs.BLOCK_SCREENSHOTS) || prefs.bool(Prefs.APP_LOCK)
                || prefs.bool(Prefs.PRIVATE_MODE);
        if (secure) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if (prefs.bool(Prefs.KEEP_SCREEN_ON)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** Re-reads every setting and pushes it into all open tabs (called on start and after Settings). */
    private void applyAll() {
        refreshPolicy();
        applyWindowFlags();
        CookieManager.getInstance().setAcceptCookie(!prefs.bool(Prefs.BLOCK_ALL_COOKIES));
        int ime = EditorInfo.IME_ACTION_GO;
        int type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI;
        if (prefs.bool(Prefs.IME_INCOGNITO)) {
            ime |= EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING;
            type |= InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        }
        addressInput.setImeOptions(ime);
        addressInput.setInputType(type);
        for (BrowserTab tab : tabs) applySettings(tab);
        BrowserTab tab = current();
        if (tab != null) updateAddressBar(tab);
    }

    @SuppressWarnings("deprecation")
    private void applySettings(BrowserTab tab) {
        WebView webView = tab.webView;
        WebSettings s = webView.getSettings();
        boolean priv = prefs.bool(Prefs.PRIVATE_MODE);

        s.setJavaScriptEnabled(prefs.bool(Prefs.JS_ENABLED));
        s.setDomStorageEnabled(prefs.bool(Prefs.DOM_STORAGE));
        s.setDatabaseEnabled(prefs.bool(Prefs.DOM_STORAGE));
        boolean images = prefs.bool(Prefs.LOAD_IMAGES);
        s.setLoadsImagesAutomatically(images);
        s.setBlockNetworkImage(!images);
        boolean zoom = prefs.bool(Prefs.ZOOM_ENABLED);
        s.setSupportZoom(zoom);
        s.setBuiltInZoomControls(zoom);
        s.setDisplayZoomControls(false);
        s.setTextZoom(prefs.integer(Prefs.TEXT_ZOOM, 100));
        s.setMediaPlaybackRequiresUserGesture(prefs.bool(Prefs.BLOCK_AUTOPLAY));
        s.setJavaScriptCanOpenWindowsAutomatically(!prefs.bool(Prefs.BLOCK_POPUPS));
        s.setGeolocationEnabled(!"block".equals(prefs.str(Prefs.PERM_LOCATION)));
        s.setSaveFormData(!prefs.bool(Prefs.NO_FORM_SAVE));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(prefs.bool(Prefs.SAFE_BROWSING));
            webView.setImportantForAutofill(prefs.bool(Prefs.NO_AUTOFILL)
                    ? View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
                    : View.IMPORTANT_FOR_AUTOFILL_AUTO);
        }

        String cache = prefs.str(Prefs.CACHE_MODE);
        if (priv || "none".equals(cache)) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        else if ("offline".equals(cache)) s.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        else s.setCacheMode(WebSettings.LOAD_DEFAULT);

        String uaMode = prefs.str(Prefs.UA_MODE);
        if ("default".equals(uaMode)) s.setUserAgentString(null);
        else s.setUserAgentString(userAgentFor(uaMode));
        boolean desktop = "desktop".equals(uaMode);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptThirdPartyCookies(webView,
                !(prefs.bool(Prefs.BLOCK_3P_COOKIES) || prefs.bool(Prefs.BLOCK_ALL_COOKIES)));

        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, prefs.bool(Prefs.FORCE_DARK));
        }
        installShield(tab);
    }

    private String userAgentFor(String mode) {
        if (cachedDefaultUa == null) cachedDefaultUa = WebSettings.getDefaultUserAgent(this);
        Matcher m = Pattern.compile("Chrome/(\\d+)").matcher(cachedDefaultUa);
        String major = m.find() ? m.group(1) : "120";
        if ("desktop".equals(mode)) {
            return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                    + major + ".0.0.0 Safari/537.36";
        }
        return "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + major + ".0.0.0 Mobile Safari/537.36";
    }

    /** (Re)installs the fingerprinting shield so it runs before any page script in every frame. */
    private void installShield(BrowserTab tab) {
        String script = ScriptShield.build(prefs, prefs.allowlist());
        if (tab.shieldInstalled && java.util.Objects.equals(script, tab.shieldSource)) return;
        tab.shieldInstalled = true;
        tab.shieldSource = script;
        if (tab.shield != null) {
            try {
                tab.shield.remove();
            } catch (Exception ignored) {
                // WebView already torn down
            }
            tab.shield = null;
        }
        tab.shieldScript = script;
        if (script == null) return;
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                tab.shield = WebViewCompat.addDocumentStartJavaScript(tab.webView, script,
                        Collections.singleton("*"));
                tab.shieldScript = null; // no fallback injection needed
            } catch (Exception ignored) {
                // fall back to onPageStarted injection
            }
        }
    }

    // =============================================================================================
    // Tabs and WebView
    // =============================================================================================

    private BrowserTab createTab() {
        WebView webView = new WebView(this);
        BrowserTab tab = new BrowserTab(webView);
        tabs.add(tab);
        webHost.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        configureWebView(tab);
        updateTabsButton();
        return tab;
    }

    private void addTab(String initialUrl, boolean switchToTab) {
        BrowserTab tab = createTab();
        if (switchToTab || currentTab < 0) showTab(tabs.size() - 1);
        if (initialUrl == null || HOME_URL.equals(initialUrl) || initialUrl.isEmpty()) {
            loadHome(tab);
        } else if (isHttpUrl(initialUrl)) {
            loadChecked(tab, initialUrl);
        } else {
            loadHome(tab);
        }
        updateTabsButton();
    }

    @SuppressWarnings("deprecation")
    private void configureWebView(BrowserTab tab) {
        WebView webView = tab.webView;
        WebSettings settings = webView.getSettings();

        // Fixed hardening that no setting can relax.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(true);
        webView.setFilterTouchesWhenObscured(true);
        webView.setBackgroundColor(Color.WHITE);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(tab, request.getUrl().toString(), request.isForMainFrame(),
                        request.hasGesture());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return interceptRequest(tab, request);
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (isInternalHomeUrl(url)) {
                    tab.url = url != null && url.contains("/error") && tab.failedUrl != null ? tab.failedUrl : HOME_URL;
                } else {
                    tab.url = url;
                    tab.failedUrl = null;
                }
                tab.blockedAds.set(0);
                tab.blockedTrackers.set(0);
                tab.blockedOther.set(0);
                if (tab.shieldScript != null) {
                    view.evaluateJavascript(tab.shieldScript, null); // older WebView without document-start scripts
                }
                if (isCurrent(tab)) {
                    updateAddressBar(tab);
                    progressBar.setProgress(5);
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (isInternalHomeUrl(url)) {
                    tab.url = url != null && url.contains("/error") && tab.failedUrl != null ? tab.failedUrl : HOME_URL;
                } else {
                    tab.url = url;
                }
                if (isHttpUrl(tab.url) && !isInternalHomeUrl(url)
                        && !prefs.bool(Prefs.PRIVATE_MODE) && prefs.bool(Prefs.SAVE_HISTORY)) {
                    String title = tab.title;
                    if (title == null || title.trim().isEmpty() || "Новая вкладка".equals(title)) {
                        title = Uri.parse(tab.url).getHost();
                    }
                    addHistory(title, tab.url);
                }
                if (isCurrent(tab)) {
                    updateAddressBar(tab);
                    if (progressBar.getProgress() >= 100) progressBar.setVisibility(View.INVISIBLE);
                }
                updateTabsButton();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    String description = error.getDescription() == null ? "" : error.getDescription().toString();
                    showErrorPage(tab, request.getUrl().toString(), "Не удалось загрузить страницу", description);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); // never allow bypassing certificate errors
                SecurityGuard.TLS_BLOCKED.incrementAndGet();
                String failing = error.getUrl();
                String failingHost = failing == null ? null : Uri.parse(failing).getHost();
                boolean mainFrame = failingHost != null && failingHost.equalsIgnoreCase(tab.pageHost);
                if (mainFrame) {
                    showErrorPage(tab, failing, "Соединение не защищено",
                            describeSslError(error) + "\n\nFloria не позволяет обходить ошибки сертификатов — "
                                    + "иначе ваши данные могли бы перехватить.");
                } else if (isCurrent(tab)) {
                    Toast.makeText(FloriaActivity.this, "Ошибка сертификата — соединение остановлено",
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onSafeBrowsingHit(WebView view, WebResourceRequest request, int threatType,
                                          SafeBrowsingResponse callback) {
                SecurityGuard.THREATS.incrementAndGet();
                callback.showInterstitial(true);
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                int index = tabs.indexOf(tab);
                if (index >= 0) {
                    if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view);
                    tabs.remove(index);
                    view.destroy();
                    if (tabs.isEmpty()) {
                        currentTab = -1;
                        addTab(HOME_URL, true);
                    } else {
                        currentTab = Math.min(Math.max(0, currentTab), tabs.size() - 1);
                        showTab(currentTab);
                    }
                    Toast.makeText(FloriaActivity.this, "Вкладка была перезапущена после сбоя движка", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (isCurrent(tab)) {
                    progressBar.setProgress(newProgress);
                    progressBar.setVisibility(newProgress >= 100 ? View.INVISIBLE : View.VISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (title != null && !title.trim().isEmpty() && !isInternalHomeUrl(view.getUrl())) {
                    tab.title = title;
                } else {
                    tab.title = "Новая вкладка";
                }
                updateTabsButton();
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (prefs.bool(Prefs.BLOCK_POPUPS) && !isUserGesture) {
                    SecurityGuard.POPUPS.incrementAndGet();
                    if (isCurrent(tab)) {
                        Toast.makeText(FloriaActivity.this, "Всплывающее окно заблокировано", Toast.LENGTH_SHORT).show();
                    }
                    return false;
                }
                if (tabs.size() >= MAX_TABS || resultMsg == null || !(resultMsg.obj instanceof WebView.WebViewTransport)) {
                    return false;
                }
                BrowserTab popup = createTab();
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup.webView);
                resultMsg.sendToTarget();
                showTab(tabs.indexOf(popup));
                return true;
            }

            @Override
            public void onCloseWindow(WebView window) {
                for (int i = 0; i < tabs.size(); i++) {
                    if (tabs.get(i).webView == window && tabs.size() > 1) {
                        closeTab(i);
                        return;
                    }
                }
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                handleGeolocationRequest(origin, callback);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleMediaRequest(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingMediaRequest == request) {
                    pendingMediaRequest = null;
                    pendingMediaResources = null;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                onDownloadRequested(url, userAgent, contentDisposition, mimeType));
        applySettings(tab);
    }

    private String describeSslError(SslError error) {
        switch (error.getPrimaryError()) {
            case SslError.SSL_EXPIRED:
                return "Срок действия сертификата сайта истёк.";
            case SslError.SSL_IDMISMATCH:
                return "Сертификат выдан для другого имени сайта.";
            case SslError.SSL_UNTRUSTED:
                return "Сертификат выдан неизвестным или недоверенным центром.";
            case SslError.SSL_NOTYETVALID:
                return "Сертификат ещё не вступил в силу (проверьте дату на устройстве).";
            case SslError.SSL_DATE_INVALID:
                return "Дата сертификата недействительна.";
            default:
                return "Сертификат сайта не прошёл проверку.";
        }
    }

    // =============================================================================================
    // Request filtering (runs on the WebView IO thread)
    // =============================================================================================

    private WebResourceResponse interceptRequest(BrowserTab tab, WebResourceRequest request) {
        Uri uri = request.getUrl();
        String host = uri.getHost();
        if (request.isForMainFrame()) {
            if (host != null) tab.pageHost = host;
            return null;
        }
        String scheme = uri.getScheme();
        if (host == null || scheme == null) return null;
        String pageHost = tab.pageHost;
        if (pageHost == null || INTERNAL_HOST.equalsIgnoreCase(pageHost)) return null;
        if (prefs.isAllowlisted(pageHost)) return null;
        if (SecurityGuard.isSameSite(pageHost, host)) return null;

        Policy p = policy;
        int kind = Blocklist.classify(host, uri.getPath());
        if (kind == Blocklist.MALICIOUS && p.malicious) {
            SecurityGuard.MALICIOUS.incrementAndGet();
            tab.blockedOther.incrementAndGet();
            return blocked();
        }
        if (kind == Blocklist.AD && p.ads) {
            SecurityGuard.ADS.incrementAndGet();
            tab.blockedAds.incrementAndGet();
            return blocked();
        }
        if (kind == Blocklist.TRACKER && p.trackers) {
            SecurityGuard.TRACKERS.incrementAndGet();
            tab.blockedTrackers.incrementAndGet();
            return blocked();
        }
        if (p.scripts3p || p.frames3p) {
            if (Blocklist.isCommonCdn(host)) return null;
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            Map<String, String> headers = request.getRequestHeaders();
            String accept = headers == null ? null : headers.get("Accept");
            boolean script = path.endsWith(".js") || path.endsWith(".mjs");
            boolean frame = accept != null && accept.contains("text/html");
            if ((p.scripts3p && script) || (p.frames3p && frame)) {
                SecurityGuard.THIRD_PARTY.incrementAndGet();
                tab.blockedOther.incrementAndGet();
                return blocked();
            }
        }
        return null;
    }

    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked by Floria",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    // =============================================================================================
    // Navigation and URL security
    // =============================================================================================

    /** WebViewClient hook for link clicks, redirects and script navigations. */
    private boolean handleNavigation(BrowserTab tab, String rawUrl, boolean mainFrame, boolean gesture) {
        Uri uri;
        try {
            uri = Uri.parse(rawUrl);
        } catch (Exception ignored) {
            return true;
        }
        String scheme = uri.getScheme();
        if (scheme == null) return false;
        String lower = scheme.toLowerCase(Locale.ROOT);
        if ("http".equals(lower) || "https".equals(lower)) {
            if (!mainFrame) return false;
            return checkWebNavigation(tab, rawUrl, uri);
        }
        if ("about".equals(lower) || "blob".equals(lower)) return false;
        if ("data".equals(lower)) return mainFrame; // top-level data: pages are a phishing vector
        if ("javascript".equals(lower) || "file".equals(lower) || "content".equals(lower)
                || "android-app".equals(lower) || "view-source".equals(lower)) {
            return true;
        }
        if ("intent".equals(lower)) {
            Intent intent = SecurityGuard.sanitizeIntentUri(rawUrl);
            if (intent == null) {
                Toast.makeText(this, "Небезопасная ссылка заблокирована", Toast.LENGTH_SHORT).show();
            } else {
                openExternal(intent, intent.getDataString() != null ? intent.getDataString() : rawUrl, gesture, false);
            }
            return true;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setComponent(null);
        intent.setSelector(null);
        openExternal(intent, rawUrl, gesture, SecurityGuard.isSafeExternalScheme(lower));
        return true;
    }

    /**
     * Applies HTTPS upgrade and look-alike checks to a top-level web navigation.
     *
     * @return true when the navigation was handled (blocked, upgraded or waiting for confirmation)
     */
    private boolean checkWebNavigation(BrowserTab tab, String rawUrl, Uri uri) {
        String lowerUrl = rawUrl.toLowerCase(Locale.ROOT);
        if (lowerUrl.startsWith("http://")) {
            if (prefs.bool(Prefs.HTTPS_UPGRADE)) {
                SecurityGuard.HTTPS_UPGRADES.incrementAndGet();
                loadChecked(tab, "https://" + rawUrl.substring(7));
            } else {
                Toast.makeText(this, "Небезопасное соединение (HTTP) заблокировано", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        if (prefs.bool(Prefs.WARN_LOOKALIKE)) {
            SecurityGuard.Verdict verdict = SecurityGuard.inspect(uri);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (verdict.level == SecurityGuard.BLOCK) {
                SecurityGuard.LOOKALIKES.incrementAndGet();
                new AlertDialog.Builder(this)
                        .setTitle("Переход заблокирован")
                        .setMessage(verdict.reason)
                        .setPositiveButton("OK", null)
                        .show();
                return true;
            }
            if (verdict.level == SecurityGuard.WARN && !approvedHosts.contains(host)) {
                SecurityGuard.LOOKALIKES.incrementAndGet();
                new AlertDialog.Builder(this)
                        .setTitle("Подозрительный адрес")
                        .setMessage(verdict.reason + "\n\n" + rawUrl)
                        .setNegativeButton("Не открывать", null)
                        .setPositiveButton("Всё равно открыть", (dialog, which) -> {
                            approvedHosts.add(host);
                            loadNow(tab, rawUrl);
                        })
                        .show();
                return true;
            }
        }
        return false;
    }

    /** Loads a URL typed or chosen inside Floria after all security checks. */
    private void loadChecked(BrowserTab tab, String url) {
        Uri uri;
        try {
            uri = Uri.parse(url);
        } catch (Exception ignored) {
            return;
        }
        if (!checkWebNavigation(tab, url, uri)) loadNow(tab, url);
    }

    private void loadNow(BrowserTab tab, String url) {
        tab.title = "Загрузка…";
        tab.url = url;
        Map<String, String> headers = new HashMap<>();
        if (prefs.bool(Prefs.SEND_GPC)) {
            headers.put("Sec-GPC", "1");
            headers.put("DNT", "1");
        }
        tab.webView.loadUrl(url, headers);
        if (isCurrent(tab)) updateAddressBar(tab);
    }

    private void openExternal(Intent intent, String display, boolean gesture, boolean safeScheme) {
        if (!gesture) {
            SecurityGuard.EXTERNAL_BLOCKED.incrementAndGet();
            Toast.makeText(this, "Страница пыталась открыть приложение без вашего действия — заблокировано",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if ("block".equals(prefs.str(Prefs.EXTERNAL_LINKS))) {
            SecurityGuard.EXTERNAL_BLOCKED.incrementAndGet();
            Toast.makeText(this, "Открытие внешних приложений отключено в настройках", Toast.LENGTH_SHORT).show();
            return;
        }
        Runnable launch = () -> {
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException | SecurityException ignored) {
                Toast.makeText(this, "Нет приложения для этой ссылки", Toast.LENGTH_SHORT).show();
            }
        };
        if (safeScheme) {
            launch.run();
            return;
        }
        String shown = display == null ? "" : display;
        if (shown.length() > 200) shown = shown.substring(0, 200) + "…";
        new AlertDialog.Builder(this)
                .setTitle("Открыть в другом приложении?")
                .setMessage(shown)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Открыть", (dialog, which) -> launch.run())
                .show();
    }

    private void showErrorPage(BrowserTab tab, String failingUrl, String title, String details) {
        tab.failedUrl = failingUrl;
        String html = "<!doctype html><html lang='ru'><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; style-src 'unsafe-inline'\">"
                + "<style>body{margin:0;background:#101010;color:#ededed;font-family:Arial,sans-serif;padding:32px 22px}"
                + "h1{font-size:22px;font-weight:500;margin:40px 0 12px}p{color:#aaa;line-height:1.5;font-size:14px;white-space:pre-wrap}"
                + ".u{color:#777;font-size:12px;word-break:break-all;margin-top:24px}</style></head><body>"
                + "<h1>" + escapeHtml(title) + "</h1><p>" + escapeHtml(details) + "</p>"
                + "<div class='u'>" + escapeHtml(failingUrl) + "</div></body></html>";
        tab.webView.loadDataWithBaseURL("https://" + INTERNAL_HOST + "/error", html, "text/html", "UTF-8", null);
        tab.title = title;
        updateTabsButton();
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private String homeHtml() {
        String[] engine = SearchEngines.get(prefs.str(Prefs.SEARCH_ENGINE));
        boolean priv = prefs.bool(Prefs.PRIVATE_MODE);
        return "<!doctype html><html lang='ru'><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>"
                + "<meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; style-src 'unsafe-inline'; form-action https:\">"
                + "<style>"
                + "*{box-sizing:border-box}body{margin:0;background:#101010;color:#ededed;font-family:Arial,Helvetica,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:28px 20px}"
                + ".wrap{width:100%;max-width:560px;text-align:center;margin-top:-7vh}.mark{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border:1px solid #505050;border-radius:13px;color:#eee;font-weight:700;font-size:25px;margin-bottom:16px;background:#191919}"
                + "h1{font-size:40px;font-weight:500;letter-spacing:8px;margin:0 0 10px 8px}p{color:#999;font-size:14px;margin:0 0 30px}form{display:flex;gap:8px;background:#1a1a1a;border:1px solid #3d3d3d;border-radius:15px;padding:7px;box-shadow:0 8px 28px #0004}"
                + "input{flex:1;min-width:0;border:0;outline:0;background:transparent;color:#f0f0f0;padding:12px;font-size:15px}button{border:1px solid #555;background:#303030;color:#f2f2f2;border-radius:10px;padding:0 15px;font-size:14px}"
                + ".links{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:27px}.links a{color:#b7b7b7;text-decoration:none;border:1px solid #343434;background:#171717;border-radius:11px;padding:10px 13px;font-size:12px}.foot{margin-top:42px;font-size:11px;color:#626262}"
                + ".priv{display:inline-block;margin-bottom:18px;border:1px solid #555;border-radius:20px;padding:5px 12px;font-size:12px;color:#c9c9c9}"
                + "</style></head><body><main class='wrap'><div class='mark'>F</div><h1>FLORIA</h1>"
                + (priv ? "<div class='priv'>Приватный режим</div>" : "")
                + "<p>Спокойное пространство для интернета.</p>"
                + "<form action='" + escapeHtml(engine[2]) + "' method='get'><input name='" + escapeHtml(engine[3])
                + "' type='search' placeholder='Поиск или адрес сайта' aria-label='Поиск'><button type='submit'>Искать ↗</button></form>"
                + "<nav class='links'><a href='https://duckduckgo.com/'>DuckDuckGo</a><a href='https://wikipedia.org/'>Wikipedia</a><a href='https://github.com/'>GitHub</a><a href='https://youtube.com/'>YouTube</a></nav>"
                + "<div class='foot'>LESS NOISE. MORE WEB.</div></main></body></html>";
    }

    private void loadHome(BrowserTab tab) {
        tab.url = HOME_URL;
        tab.title = "Новая вкладка";
        tab.failedUrl = null;
        tab.pageHost = INTERNAL_HOST;
        tab.webView.loadDataWithBaseURL("https://" + INTERNAL_HOST + "/home", homeHtml(), "text/html", "UTF-8", null);
        if (isCurrent(tab)) {
            addressInput.setText("");
            progressBar.setVisibility(View.INVISIBLE);
            updateSiteGlyph(tab);
        }
        updateTabsButton();
    }

    private boolean isInternalHomeUrl(String url) {
        if (url == null) return false;
        try {
            Uri uri = Uri.parse(url);
            return INTERNAL_HOST.equalsIgnoreCase(uri.getHost());
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isCurrent(BrowserTab tab) {
        return currentTab >= 0 && currentTab < tabs.size() && tabs.get(currentTab) == tab;
    }

    private BrowserTab current() {
        if (currentTab < 0 || currentTab >= tabs.size()) return null;
        return tabs.get(currentTab);
    }

    private void showTab(int index) {
        if (tabs.isEmpty()) return;
        currentTab = Math.max(0, Math.min(index, tabs.size() - 1));
        for (int i = 0; i < tabs.size(); i++) {
            tabs.get(i).webView.setVisibility(i == currentTab ? View.VISIBLE : View.GONE);
        }
        if (addressInput != null) addressInput.clearFocus();
        updateAddressBar(tabs.get(currentTab));
        updateTabsButton();
        progressBar.setVisibility(View.INVISIBLE);
    }

    private void updateAddressBar(BrowserTab tab) {
        String shown = (tab.url == null || HOME_URL.equals(tab.url)) ? "" : tab.url;
        if (!addressInput.hasFocus()) {
            addressInput.setText(shown);
            if (shown.isEmpty()) addressInput.setSelection(0);
            else addressInput.setSelection(addressInput.length());
        }
        updateSiteGlyph(tab);
    }

    private void updateSiteGlyph(BrowserTab tab) {
        if (siteGlyph == null) return;
        String url = tab.url;
        if (url == null || HOME_URL.equals(url)) {
            siteGlyph.setText("⌕");
            siteGlyph.setTextColor(MUTED);
        } else if (url.toLowerCase(Locale.ROOT).startsWith("https://") && tab.failedUrl == null) {
            siteGlyph.setText("●");
            siteGlyph.setTextColor(SECURE_GREEN);
            siteGlyph.setContentDescription("Соединение защищено. Нажмите для сведений о сайте");
        } else {
            siteGlyph.setText("▲");
            siteGlyph.setTextColor(WARN_AMBER);
            siteGlyph.setContentDescription("Соединение не защищено. Нажмите для сведений о сайте");
        }
    }

    private void updateTabsButton() {
        if (tabsButton == null) return;
        tabsButton.setText(String.valueOf(Math.max(1, tabs.size())));
        String title = current() == null ? "Вкладки" : current().title;
        tabsButton.setContentDescription("Вкладки: " + title + "; открыто " + tabs.size());
    }

    private void navigateFromAddress() {
        String input = addressInput.getText().toString().trim();
        if (input.isEmpty()) return;
        hideKeyboard();
        String target = resolveInput(input);
        BrowserTab tab = current();
        if (tab == null) addTab(target, true);
        else loadChecked(tab, target);
    }

    private String resolveInput(String input) {
        String value = input.trim();
        String lower = value.toLowerCase(Locale.ROOT);
        if (lower.startsWith("https://") || lower.startsWith("http://")) return value;
        if (!value.matches(".*\\s+.*") && (lower.startsWith("www.") || lower.matches("[a-z0-9-]+(\\.[a-z0-9-]+)+(\\:[0-9]{1,5})?(/.*)?"))) {
            return "https://" + value;
        }
        return SearchEngines.searchUrl(prefs.str(Prefs.SEARCH_ENGINE), value);
    }

    private boolean isHttpUrl(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        return lower.startsWith("https://") || lower.startsWith("http://");
    }

    private void goBack() {
        BrowserTab tab = current();
        if (tab != null && tab.webView.canGoBack()) tab.webView.goBack();
        else if (tabs.size() > 1) closeTab(currentTab);
        else goHome();
    }

    private void goForward() {
        BrowserTab tab = current();
        if (tab != null && tab.webView.canGoForward()) tab.webView.goForward();
    }

    private void goHome() {
        BrowserTab tab = current();
        if (tab != null) loadHome(tab);
    }

    private void reloadCurrent() {
        BrowserTab tab = current();
        if (tab == null) return;
        if (HOME_URL.equals(tab.url)) {
            loadHome(tab);
        } else if (tab.failedUrl != null) {
            loadChecked(tab, tab.failedUrl);
        } else {
            tab.webView.reload();
        }
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        BrowserTab tab = tabs.remove(index);
        if (tab.webView.getParent() instanceof ViewGroup) ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
        tab.webView.stopLoading();
        if (prefs.bool(Prefs.PRIVATE_MODE)) tab.webView.clearCache(true);
        tab.webView.destroy();
        if (tabs.isEmpty()) {
            currentTab = -1;
            addTab(HOME_URL, true);
        } else {
            if (index < currentTab) currentTab--;
            currentTab = Math.min(Math.max(0, currentTab), tabs.size() - 1);
            showTab(currentTab);
        }
        updateTabsButton();
    }

    // =============================================================================================
    // Menu, dialogs
    // =============================================================================================

    private void showOverflowMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        boolean priv = prefs.bool(Prefs.PRIVATE_MODE);
        boolean desktop = "desktop".equals(prefs.str(Prefs.UA_MODE));
        menu.getMenu().add("Новая вкладка").setOnMenuItemClickListener(item -> {
            addTab(HOME_URL, true);
            return true;
        });
        menu.getMenu().add("Вкладки").setOnMenuItemClickListener(item -> {
            showTabsDialog();
            return true;
        });
        menu.getMenu().add("Информация о сайте и защита").setOnMenuItemClickListener(item -> {
            showSiteInfo();
            return true;
        });
        menu.getMenu().add("Панель безопасности").setOnMenuItemClickListener(item -> {
            new AlertDialog.Builder(this)
                    .setTitle("Панель безопасности")
                    .setMessage(SecurityReport.build(this, prefs))
                    .setPositiveButton("OK", null)
                    .show();
            return true;
        });
        menu.getMenu().add(priv ? "Приватный режим: включён" : "Приватный режим: выключен").setOnMenuItemClickListener(item -> {
            prefs.setBool(Prefs.PRIVATE_MODE, !priv);
            applyAll();
            for (BrowserTab t : tabs) {
                if (HOME_URL.equals(t.url)) loadHome(t);
            }
            Toast.makeText(this, !priv
                    ? "Приватный режим: без истории и кэша, данные стираются при выходе"
                    : "Приватный режим выключен", Toast.LENGTH_LONG).show();
            return true;
        });
        menu.getMenu().add(desktop ? "Мобильная версия сайта" : "Версия для компьютера").setOnMenuItemClickListener(item -> {
            prefs.setStr(Prefs.UA_MODE, desktop ? "reduced" : "desktop");
            applyAll();
            reloadCurrent();
            return true;
        });
        menu.getMenu().add("Добавить в закладки").setOnMenuItemClickListener(item -> {
            addCurrentBookmark();
            return true;
        });
        menu.getMenu().add("Закладки").setOnMenuItemClickListener(item -> {
            showSavedItems(BOOKMARKS_KEY, "Закладки", false);
            return true;
        });
        menu.getMenu().add("История").setOnMenuItemClickListener(item -> {
            showSavedItems(HISTORY_KEY, "История", true);
            return true;
        });
        menu.getMenu().add("Поделиться страницей").setOnMenuItemClickListener(item -> {
            shareCurrentPage();
            return true;
        });
        menu.getMenu().add("Перезагрузить").setOnMenuItemClickListener(item -> {
            reloadCurrent();
            return true;
        });
        menu.getMenu().add("Закрыть вкладку").setOnMenuItemClickListener(item -> {
            closeTab(currentTab);
            return true;
        });
        menu.getMenu().add("Очистить данные браузера…").setOnMenuItemClickListener(item -> {
            DataCleaner.showDialog(this, prefs, null);
            return true;
        });
        menu.getMenu().add("Настройки").setOnMenuItemClickListener(item -> {
            internalLaunch = true;
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        });
        menu.show();
    }

    private void showSiteInfo() {
        BrowserTab tab = current();
        if (tab == null) return;
        if (tab.url == null || HOME_URL.equals(tab.url)) {
            new AlertDialog.Builder(this)
                    .setTitle("Стартовая страница Floria")
                    .setMessage("Это локальная страница браузера. Она не отправляет данные в сеть, "
                            + "пока вы не выполните поиск.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        Uri uri = Uri.parse(tab.url);
        String host = uri.getHost() == null ? tab.url : uri.getHost();
        boolean https = tab.url.toLowerCase(Locale.ROOT).startsWith("https://") && tab.failedUrl == null;
        boolean exempt = prefs.isAllowlisted(host);
        StringBuilder sb = new StringBuilder();
        sb.append("Сайт: ").append(host).append("\n");
        sb.append("Соединение: ").append(https ? "защищено (HTTPS)" : "НЕ защищено или недоступно").append("\n");
        if (https) {
            sb.append("\n").append(SecurityGuard.describeCertificate(tab.webView.getCertificate())).append("\n");
        }
        sb.append("\nЗаблокировано на этой странице\n");
        sb.append("Реклама: ").append(tab.blockedAds.get()).append("\n");
        sb.append("Трекеры: ").append(tab.blockedTrackers.get()).append("\n");
        sb.append("Прочее (майнеры, сторонние элементы): ").append(tab.blockedOther.get()).append("\n");
        sb.append("\nЗащита для этого сайта: ").append(exempt ? "ОТКЛЮЧЕНА (исключение)" : "включена");
        new AlertDialog.Builder(this)
                .setTitle("Сведения о сайте")
                .setMessage(sb.toString())
                .setNegativeButton("Закрыть", null)
                .setPositiveButton(exempt ? "Включить защиту" : "Отключить защиту для сайта", (dialog, which) -> {
                    prefs.toggleAllowlist(host);
                    applyAll();
                    tab.webView.reload();
                })
                .show();
    }

    private void showTabsDialog() {
        if (tabs.isEmpty()) return;
        String[] names = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) {
            BrowserTab tab = tabs.get(i);
            String title = (tab.title == null || tab.title.trim().isEmpty()) ? "Новая вкладка" : tab.title;
            String address = HOME_URL.equals(tab.url) ? "Стартовая страница" : tab.url;
            names[i] = (i == currentTab ? "●  " : "○  ") + title + "\n" + address;
        }
        new AlertDialog.Builder(this)
                .setTitle("Вкладки · " + tabs.size())
                .setItems(names, (dialog, which) -> showTab(which))
                .setPositiveButton("Новая вкладка", (dialog, which) -> addTab(HOME_URL, true))
                .setNegativeButton("Закрыть", null)
                .show();
    }

    // =============================================================================================
    // History and bookmarks
    // =============================================================================================

    private JSONArray readArray(String key) {
        try {
            return new JSONArray(preferences.getString(key, "[]"));
        } catch (JSONException | ClassCastException ignored) {
            return new JSONArray();
        }
    }

    private void addHistory(String title, String url) {
        if (!isHttpUrl(url)) return;
        JSONArray old = readArray(HISTORY_KEY);
        JSONArray updated = new JSONArray();
        try {
            JSONObject mostRecent = old.length() > 0 ? old.optJSONObject(old.length() - 1) : null;
            if (mostRecent != null && url.equals(mostRecent.optString("url"))) return;
            JSONObject item = new JSONObject();
            item.put("title", (title == null || title.trim().isEmpty()) ? url : title);
            item.put("url", url);
            item.put("time", System.currentTimeMillis());
            int limit = Math.max(10, prefs.integer(Prefs.HISTORY_LIMIT, 150));
            int start = Math.max(0, old.length() - (limit - 1));
            for (int i = start; i < old.length(); i++) {
                JSONObject existing = old.optJSONObject(i);
                if (existing != null) updated.put(existing);
            }
            updated.put(item);
            preferences.edit().putString(HISTORY_KEY, updated.toString()).apply();
        } catch (JSONException ignored) {
            // Ignore malformed entry; browsing should continue.
        }
    }

    private void addCurrentBookmark() {
        BrowserTab tab = current();
        if (tab == null || !isHttpUrl(tab.url)) {
            Toast.makeText(this, "Открытая страница не подходит для закладки", Toast.LENGTH_SHORT).show();
            return;
        }
        JSONArray old = readArray(BOOKMARKS_KEY);
        for (int i = 0; i < old.length(); i++) {
            JSONObject item = old.optJSONObject(i);
            if (item != null && tab.url.equals(item.optString("url"))) {
                Toast.makeText(this, "Уже в закладках", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        try {
            JSONObject item = new JSONObject();
            item.put("title", tab.title == null ? tab.url : tab.title);
            item.put("url", tab.url);
            old.put(item);
            preferences.edit().putString(BOOKMARKS_KEY, old.toString()).apply();
            Toast.makeText(this, "Добавлено в закладки", Toast.LENGTH_SHORT).show();
        } catch (JSONException ignored) {
            Toast.makeText(this, "Не удалось сохранить закладку", Toast.LENGTH_SHORT).show();
        }
    }

    private void showSavedItems(String key, String title, boolean newestFirst) {
        JSONArray array = readArray(key);
        ArrayList<JSONObject> items = new ArrayList<>();
        if (newestFirst) {
            for (int i = array.length() - 1; i >= 0; i--) {
                JSONObject item = array.optJSONObject(i);
                if (item != null) items.add(item);
            }
        } else {
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item != null) items.add(item);
            }
        }
        if (items.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(title).setMessage("Здесь пока пусто.").setPositiveButton("OK", null).show();
            return;
        }
        int limit = Math.min(items.size(), 80);
        String[] labels = new String[limit];
        for (int i = 0; i < limit; i++) {
            JSONObject item = items.get(i);
            String itemTitle = item.optString("title", item.optString("url", "Страница"));
            String url = item.optString("url", "");
            labels[i] = itemTitle + "\n" + url;
        }
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(labels, (dialog, which) -> {
                    String url = items.get(which).optString("url", "");
                    if (isHttpUrl(url)) {
                        BrowserTab tab = current();
                        if (tab == null) addTab(url, true);
                        else loadChecked(tab, url);
                    }
                })
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private void shareCurrentPage() {
        BrowserTab tab = current();
        if (tab == null || !isHttpUrl(tab.url)) {
            Toast.makeText(this, "Сначала откройте страницу", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, tab.url);
        internalLaunch = true;
        startActivity(Intent.createChooser(intent, "Поделиться страницей"));
    }

    // =============================================================================================
    // Downloads
    // =============================================================================================

    private void onDownloadRequested(String url, String userAgent, String disposition, String mimeType) {
        if (url == null || !url.toLowerCase(Locale.ROOT).startsWith("https://")) {
            Toast.makeText(this, "Небезопасная или неподдерживаемая загрузка заблокирована", Toast.LENGTH_LONG).show();
            SecurityGuard.DOWNLOADS_BLOCKED.incrementAndGet();
            return;
        }
        String name = SecurityGuard.sanitizeFileName(URLUtil.guessFileName(url, disposition, mimeType));
        boolean dangerous = SecurityGuard.isDangerousFile(name);
        String policyValue = prefs.str(Prefs.DANGEROUS_DL);
        if (dangerous && "block".equals(policyValue)) {
            SecurityGuard.DOWNLOADS_BLOCKED.incrementAndGet();
            Toast.makeText(this, "Загрузка исполняемого файла заблокирована настройками", Toast.LENGTH_LONG).show();
            return;
        }
        PendingDownload download = new PendingDownload(url, userAgent, name, mimeType);
        boolean ask = prefs.bool(Prefs.CONFIRM_DOWNLOADS) || (dangerous && "warn".equals(policyValue));
        if (!ask) {
            requestDownload(download);
            return;
        }
        String host = Uri.parse(url).getHost();
        String message = "Файл: " + name + "\nСайт: " + host
                + (dangerous ? "\n\n⚠ Этот тип файла может содержать вредоносный код. Скачивайте его только если полностью "
                + "доверяете источнику." : "");
        new AlertDialog.Builder(this)
                .setTitle(dangerous ? "Опасный файл. Скачать?" : "Скачать файл?")
                .setMessage(message)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Скачать", (dialog, which) -> requestDownload(download))
                .show();
    }

    private void requestDownload(PendingDownload download) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDownload = download;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        enqueueDownload(download);
    }

    private void enqueueDownload(PendingDownload download) {
        try {
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(download.url));
            String cookie = CookieManager.getInstance().getCookie(download.url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            if (download.userAgent != null && !download.userAgent.isEmpty()) request.addRequestHeader("User-Agent", download.userAgent);
            request.setTitle(download.fileName);
            request.setDescription("Загрузка через Floria");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, download.fileName);
            manager.enqueue(request);
            Toast.makeText(this, "Загрузка началась", Toast.LENGTH_SHORT).show();
        } catch (Exception error) {
            Toast.makeText(this, "Не удалось начать загрузку", Toast.LENGTH_SHORT).show();
        }
    }

    // =============================================================================================
    // Site permissions
    // =============================================================================================

    private String originHost(String origin) {
        try {
            String host = Uri.parse(origin).getHost();
            return host == null ? origin : host;
        } catch (Exception ignored) {
            return origin;
        }
    }

    private void handleGeolocationRequest(String origin, GeolocationPermissions.Callback callback) {
        if ("block".equals(prefs.str(Prefs.PERM_LOCATION))) {
            callback.invoke(origin, false, false);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Доступ к местоположению")
                .setMessage("Сайт " + originHost(origin) + " запрашивает ваше местоположение.")
                .setOnCancelListener(d -> callback.invoke(origin, false, false))
                .setNegativeButton("Запретить", (d, w) -> callback.invoke(origin, false, false))
                .setPositiveButton("Разрешить один раз", (d, w) -> {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        callback.invoke(origin, true, false); // retain=false: asked again next time
                    } else {
                        pendingGeoOrigin = origin;
                        pendingGeoCallback = callback;
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
                    }
                })
                .show();
    }

    private void handleMediaRequest(PermissionRequest request) {
        ArrayList<String> allowed = new ArrayList<>();
        ArrayList<String> androidPerms = new ArrayList<>();
        StringBuilder what = new StringBuilder();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && !"block".equals(prefs.str(Prefs.PERM_CAMERA))) {
                allowed.add(resource);
                androidPerms.add(Manifest.permission.CAMERA);
                what.append(what.length() > 0 ? " и " : "").append("камеру");
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && !"block".equals(prefs.str(Prefs.PERM_MIC))) {
                allowed.add(resource);
                androidPerms.add(Manifest.permission.RECORD_AUDIO);
                what.append(what.length() > 0 ? " и " : "").append("микрофон");
            }
            // protected-media ID, MIDI SysEx and everything else are always denied
        }
        if (allowed.isEmpty()) {
            request.deny();
            return;
        }
        String[] resources = allowed.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Запрос разрешения")
                .setMessage("Сайт " + originHost(request.getOrigin().toString()) + " хочет использовать " + what + ".")
                .setOnCancelListener(d -> request.deny())
                .setNegativeButton("Запретить", (d, w) -> request.deny())
                .setPositiveButton("Разрешить один раз", (d, w) -> {
                    ArrayList<String> missing = new ArrayList<>();
                    for (String perm : androidPerms) {
                        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) missing.add(perm);
                    }
                    if (missing.isEmpty()) {
                        request.grant(resources);
                    } else {
                        pendingMediaRequest = request;
                        pendingMediaResources = resources;
                        requestPermissions(missing.toArray(new String[0]), REQ_MEDIA);
                    }
                })
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean allGranted = grantResults.length > 0;
        for (int result : grantResults) if (result != PackageManager.PERMISSION_GRANTED) allGranted = false;

        if (requestCode == REQ_STORAGE && pendingDownload != null) {
            PendingDownload download = pendingDownload;
            pendingDownload = null;
            if (allGranted) enqueueDownload(download);
            else Toast.makeText(this, "Для загрузки файла нужно разрешение на сохранение", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQ_MEDIA && pendingMediaRequest != null) {
            PermissionRequest request = pendingMediaRequest;
            String[] resources = pendingMediaResources;
            pendingMediaRequest = null;
            pendingMediaResources = null;
            if (allGranted && resources != null) request.grant(resources);
            else request.deny();
        } else if (requestCode == REQ_GEO && pendingGeoCallback != null) {
            GeolocationPermissions.Callback callback = pendingGeoCallback;
            String origin = pendingGeoOrigin;
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            callback.invoke(origin, granted, false);
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(addressInput.getWindowToken(), 0);
            addressInput.clearFocus();
        } catch (Exception ignored) {
            // keyboard service unavailable
        }
    }
}

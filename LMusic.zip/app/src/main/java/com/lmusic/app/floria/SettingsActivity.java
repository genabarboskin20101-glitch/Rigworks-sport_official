package com.lmusic.app.floria;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** All Floria settings, grouped in sections. Every change is stored immediately and applied on return. */
public final class SettingsActivity extends Activity {
    private static final int BG = Color.rgb(16, 16, 16);
    private static final int PANEL = Color.rgb(24, 24, 24);
    private static final int BORDER = Color.rgb(58, 58, 58);
    private static final int TEXT = Color.rgb(239, 239, 239);
    private static final int MUTED = Color.rgb(166, 166, 166);

    private static final class Dependent {
        final View row;
        final String parentKey;

        Dependent(View row, String parentKey) {
            this.row = row;
            this.parentKey = parentKey;
        }
    }

    private Prefs prefs;
    private LinearLayout list;
    private final List<Dependent> dependents = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (prefs.bool(Prefs.BLOCK_SCREENSHOTS) || prefs.bool(Prefs.APP_LOCK)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
        buildUi();
        populate();
        refreshDependencies();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFilterTouchesWhenObscured(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(PANEL);
        bar.setPadding(dp(6), dp(6), dp(16), dp(6));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(30);
        back.setTextColor(TEXT);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Назад");
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = new TextView(this);
        title.setText("Настройки и безопасность");
        title.setTextSize(19);
        title.setTextColor(TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, 0, 0, dp(32));
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private void populate() {
        // ------------------------------------------------------------------------------------
        header("Обзор");
        action("Панель безопасности", "Уровень защиты, активные механизмы и счётчики блокировок", this::showReport);
        action("Очистить данные браузера", "История, cookie, кэш, данные сайтов, формы",
                () -> DataCleaner.showDialog(this, prefs, null));

        // ------------------------------------------------------------------------------------
        header("Безопасность соединения");
        info("HTTPS-only и строгая проверка сертификатов",
                "HTTP запрещён на уровне ОС, ошибки сертификатов не обходятся, пользовательские корневые "
                        + "сертификаты не принимаются, смешанный контент блокируется. Это нельзя отключить.");
        toggle(Prefs.HTTPS_UPGRADE, "Автоматически переходить с http:// на https://",
                "Адреса вида http://сайт открываются по HTTPS", null);
        toggle(Prefs.SAFE_BROWSING, "Google Safe Browsing",
                "Блокировка фишинговых, вредоносных и нежелательных сайтов", null);
        toggle(Prefs.WARN_LOOKALIKE, "Предупреждать о подозрительных адресах",
                "IDN-домены, смесь алфавитов, IP вместо имени, «логин@сайт», копии известных брендов", null);
        toggle(Prefs.BLOCK_POPUPS, "Блокировать всплывающие окна",
                "Окна, открытые скриптом без вашего касания, не появляются", null);
        choice(Prefs.EXTERNAL_LINKS, "Ссылки во внешние приложения",
                new String[]{"ask", "block"},
                new String[]{"Спрашивать каждый раз", "Всегда блокировать"});
        toggle(Prefs.CONFIRM_DOWNLOADS, "Подтверждать загрузки",
                "Показывать имя файла и сайт до начала скачивания", null);
        choice(Prefs.DANGEROUS_DL, "Опасные типы файлов (apk, exe, jar, sh…)",
                new String[]{"warn", "block", "allow"},
                new String[]{"Предупреждать", "Блокировать", "Разрешать без предупреждения"});

        // ------------------------------------------------------------------------------------
        header("Блокировка рекламы и трекеров");
        toggle(Prefs.BLOCK_TRACKERS, "Блокировать трекеры и аналитику",
                "Google Analytics, пиксели соцсетей, Метрика, heatmap-сервисы и т. п.", null);
        toggle(Prefs.BLOCK_ADS, "Блокировать рекламные сети",
                "Рекламные запросы не отправляются вообще", null);
        toggle(Prefs.BLOCK_MALICIOUS, "Блокировать майнеры и вредоносные домены",
                "Скрытый майнинг криптовалют в браузере", null);
        toggle(Prefs.BLOCK_3P_SCRIPTS, "Строго: блокировать сторонние скрипты",
                "Скрипты с чужих доменов (кроме популярных CDN). Может ломать сайты", null);
        toggle(Prefs.BLOCK_3P_FRAMES, "Строго: блокировать сторонние фреймы",
                "Встраиваемые чужие страницы — видео, карты, виджеты. Может ломать сайты", null);
        toggle(Prefs.BLOCK_3P_COOKIES, "Блокировать сторонние cookie",
                "Основа межсайтовой слежки", null);
        toggle(Prefs.BLOCK_ALL_COOKIES, "Блокировать все cookie",
                "Вход на сайты работать не будет", null);

        // ------------------------------------------------------------------------------------
        header("Защита от фингерпринтинга");
        toggle(Prefs.FP_MASTER, "Включить защиту от слежки по отпечатку браузера",
                "Скрипт запускается до скриптов страницы в каждом фрейме", null);
        toggle(Prefs.FP_CANVAS, "Canvas", "Добавляет незаметный шум к изображениям canvas", Prefs.FP_MASTER);
        toggle(Prefs.FP_WEBGL, "WebGL", "Скрывает модель видеокарты", Prefs.FP_MASTER);
        toggle(Prefs.FP_AUDIO, "AudioContext", "Шум в аудио-отпечатке", Prefs.FP_MASTER);
        toggle(Prefs.FP_HARDWARE, "Железо и язык",
                "Число ядер и память — типовые значения, один язык вместо списка", Prefs.FP_MASTER);
        toggle(Prefs.FP_SCREEN, "Размер экрана", "Округляет размеры экрана, глубина цвета 24", Prefs.FP_MASTER);
        toggle(Prefs.FP_BATTERY, "Батарея", "Скрывает Battery API", Prefs.FP_MASTER);
        toggle(Prefs.FP_NETWORK, "Сетевая информация", "Скрывает navigator.connection", Prefs.FP_MASTER);
        toggle(Prefs.FP_WEBRTC, "WebRTC без утечки IP",
                "Только relay-кандидаты: сайты не увидят локальный адрес. Может мешать звонкам без TURN",
                Prefs.FP_MASTER);
        toggle(Prefs.FP_SENSORS, "Датчики движения",
                "Блокирует акселерометр, гироскоп и события ориентации", Prefs.FP_MASTER);
        toggle(Prefs.FP_TIMING, "Таймеры пониженной точности",
                "performance.now() с шагом 1 мс. Может влиять на плавность игр", Prefs.FP_MASTER);

        // ------------------------------------------------------------------------------------
        header("Приватность");
        toggle(Prefs.SEND_GPC, "Global Privacy Control и Do Not Track",
                "Отправлять сайтам сигнал «не отслеживать и не продавать данные»", null);
        choice(Prefs.REFERRER, "Политика Referer",
                new String[]{"default", "same-origin", "no-referrer"},
                new String[]{"Стандартная (только домен на другие сайты)", "Только внутри сайта", "Никогда не передавать"});
        choice(Prefs.UA_MODE, "User-Agent",
                new String[]{"reduced", "default", "desktop"},
                new String[]{"Уменьшенный (меньше уникальности)", "Стандартный WebView", "Версия для компьютера"});
        toggle(Prefs.PRIVATE_MODE, "Приватный режим",
                "Без истории и кэша; cookie и данные сайтов стираются при выходе", null);
        toggle(Prefs.SAVE_HISTORY, "Сохранять историю", "Локальный список посещённых страниц", null);
        choice(Prefs.HISTORY_LIMIT, "Размер истории",
                new String[]{"50", "150", "500"}, new String[]{"50 записей", "150 записей", "500 записей"});
        toggle(Prefs.NO_FORM_SAVE, "Не сохранять данные форм", "WebView не запоминает введённое в формы", null);
        toggle(Prefs.NO_AUTOFILL, "Отключить автозаполнение Android",
                "Сторонние сервисы автозаполнения не видят содержимое страниц", null);
        toggle(Prefs.IME_INCOGNITO, "Клавиатура без обучения",
                "Просит клавиатуру не запоминать вводимые адреса и запросы", null);

        // ------------------------------------------------------------------------------------
        header("Очистка при выходе");
        toggle(Prefs.CLEAR_ON_EXIT, "Очищать данные при закрытии Floria",
                "Также выполняется при следующем запуске, если приложение было завершено принудительно", null);
        toggle(Prefs.CLEAR_HISTORY_EXIT, "История", null, Prefs.CLEAR_ON_EXIT);
        toggle(Prefs.CLEAR_COOKIES_EXIT, "Cookie", null, Prefs.CLEAR_ON_EXIT);
        toggle(Prefs.CLEAR_CACHE_EXIT, "Кэш", null, Prefs.CLEAR_ON_EXIT);
        toggle(Prefs.CLEAR_STORAGE_EXIT, "Данные сайтов и формы", null, Prefs.CLEAR_ON_EXIT);

        // ------------------------------------------------------------------------------------
        header("Защита приложения");
        toggle(Prefs.APP_LOCK, "Блокировка Floria",
                "Разблокировка PIN-кодом, паттерном, паролем или биометрией устройства", null);
        choice(Prefs.LOCK_TIMEOUT, "Блокировать через",
                new String[]{"0", "30", "60", "300", "900"},
                new String[]{"Сразу при выходе", "30 секунд", "1 минуту", "5 минут", "15 минут"});
        toggle(Prefs.BLOCK_SCREENSHOTS, "Запретить скриншоты и превью в списке приложений",
                "Экран Floria скрыт на скриншотах, записи экрана и в «недавних»", null);

        // ------------------------------------------------------------------------------------
        header("Разрешения сайтов");
        choice(Prefs.PERM_LOCATION, "Геолокация",
                new String[]{"ask", "block"}, new String[]{"Спрашивать", "Блокировать"});
        choice(Prefs.PERM_CAMERA, "Камера",
                new String[]{"ask", "block"}, new String[]{"Спрашивать", "Блокировать"});
        choice(Prefs.PERM_MIC, "Микрофон",
                new String[]{"ask", "block"}, new String[]{"Спрашивать", "Блокировать"});
        info("Защищённый контент и MIDI", "Идентификатор защищённых медиа и MIDI SysEx всегда отклоняются.");

        // ------------------------------------------------------------------------------------
        header("Содержимое страниц");
        toggle(Prefs.JS_ENABLED, "JavaScript", "Отключение резко повышает защиту, но многие сайты перестанут работать", null);
        toggle(Prefs.DOM_STORAGE, "Хранилище сайтов (localStorage)", "Нужно для большинства веб-приложений", null);
        toggle(Prefs.LOAD_IMAGES, "Загружать изображения", "Выключите для экономии трафика", null);
        toggle(Prefs.BLOCK_AUTOPLAY, "Запретить автовоспроизведение медиа", "Звук и видео стартуют только по касанию", null);
        choice(Prefs.CACHE_MODE, "Кэш",
                new String[]{"default", "none", "offline"},
                new String[]{"Стандартный", "Не использовать", "Предпочитать сохранённое"});
        toggle(Prefs.ZOOM_ENABLED, "Масштабирование жестами", null, null);

        // ------------------------------------------------------------------------------------
        header("Внешний вид и поведение");
        choice(Prefs.SEARCH_ENGINE, "Поисковая система", SearchEngines.ids(), SearchEngines.labels());
        choice(Prefs.TEXT_ZOOM, "Размер текста на страницах",
                new String[]{"80", "90", "100", "110", "125", "150", "175"},
                new String[]{"80 %", "90 %", "100 %", "110 %", "125 %", "150 %", "175 %"});
        toggle(Prefs.FORCE_DARK, "Принудительная тёмная тема сайтов", "Алгоритмическое затемнение страниц", null);
        toggle(Prefs.KEEP_SCREEN_ON, "Не выключать экран во время работы", null, null);

        // ------------------------------------------------------------------------------------
        header("Сброс");
        action("Сбросить все настройки", "Вернуть безопасные значения по умолчанию и убрать исключения для сайтов",
                this::confirmReset);
        info("Floria", "Версия 1.1.0 · WebView-браузер с усиленной защитой. Движок и его обновления — "
                + "системный Android System WebView.");
    }

    // ---- Row builders -------------------------------------------------------------------------

    private void header(String text) {
        TextView t = new TextView(this);
        t.setText(text.toUpperCase());
        t.setTextSize(12);
        t.setLetterSpacing(0.08f);
        t.setTextColor(MUTED);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(18), dp(24), dp(18), dp(8));
        list.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    private LinearLayout baseRow(String title, String summary) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), dp(12), dp(14), dp(12));
        row.setBackground(rowBackground());
        row.setClickable(true);
        row.setFocusable(true);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(15);
        t.setTextColor(TEXT);
        texts.addView(t);
        if (summary != null && !summary.isEmpty()) {
            TextView s = new TextView(this);
            s.setText(summary);
            s.setTextSize(12);
            s.setTextColor(MUTED);
            s.setPadding(0, dp(2), 0, 0);
            s.setTag("summary");
            texts.addView(s);
        }
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        list.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return row;
    }

    private GradientDrawable rowBackground() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(BG);
        d.setStroke(0, BG);
        return d;
    }

    private void toggle(String key, String title, String summary, String parentKey) {
        LinearLayout row = baseRow(title, summary);
        Switch sw = new Switch(this);
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{TEXT, MUTED}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{Color.rgb(110, 110, 110), Color.rgb(48, 48, 48)}));
        sw.setChecked(prefs.bool(key));
        sw.setClickable(false); // the whole row handles the tap
        sw.setFocusable(false);
        row.addView(sw, new LinearLayout.LayoutParams(-2, -2));
        row.setOnClickListener(v -> {
            if (!row.isEnabled()) return;
            boolean target = !sw.isChecked();
            if (target && Prefs.APP_LOCK.equals(key) && !SecurityReport.deviceSecure(this)) {
                Toast.makeText(this, "Сначала включите блокировку экрана Android (PIN, пароль или биометрия)",
                        Toast.LENGTH_LONG).show();
                return;
            }
            if (target && Prefs.BLOCK_ALL_COOKIES.equals(key)) {
                Toast.makeText(this, "Вход на многие сайты перестанет работать", Toast.LENGTH_SHORT).show();
            }
            sw.setChecked(target);
            prefs.setBool(key, target);
            refreshDependencies();
        });
        if (parentKey != null) dependents.add(new Dependent(row, parentKey));
    }

    private void choice(String key, String title, String[] values, String[] labels) {
        LinearLayout row = baseRow(title, null);
        TextView value = new TextView(this);
        value.setTextSize(13);
        value.setTextColor(MUTED);
        value.setGravity(Gravity.END);
        value.setMaxWidth(dp(170));
        value.setText(labelFor(key, values, labels));
        row.addView(value, new LinearLayout.LayoutParams(-2, -2));
        row.setOnClickListener(v -> {
            String current = prefs.str(key);
            int checked = 0;
            for (int i = 0; i < values.length; i++) if (values[i].equals(current)) checked = i;
            new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                        prefs.setStr(key, values[which]);
                        value.setText(labels[which]);
                        dialog.dismiss();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
        });
    }

    private String labelFor(String key, String[] values, String[] labels) {
        String current = prefs.str(key);
        for (int i = 0; i < values.length; i++) if (values[i].equals(current)) return labels[i];
        return labels[0];
    }

    private void action(String title, String summary, Runnable run) {
        LinearLayout row = baseRow(title, summary);
        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(22);
        arrow.setTextColor(MUTED);
        row.addView(arrow, new LinearLayout.LayoutParams(-2, -2));
        row.setOnClickListener(v -> run.run());
    }

    private void info(String title, String body) {
        LinearLayout row = baseRow(title, body);
        row.setClickable(false);
        row.setFocusable(false);
    }

    private void refreshDependencies() {
        for (Dependent d : dependents) {
            boolean enabled = prefs.bool(d.parentKey);
            d.row.setEnabled(enabled);
            d.row.setAlpha(enabled ? 1f : 0.4f);
        }
    }

    // ---- Dialogs --------------------------------------------------------------------------------

    private void showReport() {
        new AlertDialog.Builder(this)
                .setTitle("Панель безопасности")
                .setMessage(SecurityReport.build(this, prefs))
                .setPositiveButton("OK", null)
                .show();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
                .setTitle("Сбросить настройки?")
                .setMessage("Все параметры вернутся к безопасным значениям по умолчанию. История и закладки останутся.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сбросить", (dialog, which) -> {
                    prefs.reset();
                    dependents.clear();
                    recreate();
                })
                .show();
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}

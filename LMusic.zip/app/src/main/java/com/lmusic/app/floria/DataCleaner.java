package com.lmusic.app.floria;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewDatabase;
import android.widget.Toast;

/** Wipes browsing data; shared by the menu, the settings screen and the "clear on exit" logic. */
final class DataCleaner {
    static final int HISTORY = 1;
    static final int COOKIES = 2;
    static final int CACHE = 4;
    static final int STORAGE = 8;
    static final int FORMS = 16;
    static final int EXCEPTIONS = 32;

    /** Same file/key FloriaActivity uses for the visited-pages list. */
    static final String HISTORY_PREFS = "floria_preferences";
    static final String HISTORY_KEY = "history_json";

    private DataCleaner() {}

    @SuppressWarnings("deprecation")
    static void clear(Context context, Prefs prefs, int flags) {
        if ((flags & HISTORY) != 0) {
            context.getSharedPreferences(HISTORY_PREFS, Context.MODE_PRIVATE).edit().remove(HISTORY_KEY).apply();
        }
        if ((flags & COOKIES) != 0) {
            CookieManager cookies = CookieManager.getInstance();
            cookies.removeAllCookies(null);
            cookies.flush();
        }
        if ((flags & STORAGE) != 0) {
            // WebStorage общий для всего приложения: интерфейс LMusic живёт в origin file:// (localStorage с медиатекой,
            // настройками и историей), поэтому стираем только данные сайтов из сети и оставляем file://.
            final WebStorage storage = WebStorage.getInstance();
            storage.getOrigins(origins -> {
                if (origins == null) return;
                for (Object key : origins.keySet()) {
                    String origin = String.valueOf(key);
                    if (origin.startsWith("file:")) continue;
                    storage.deleteOrigin(origin);
                }
            });
        }
        if ((flags & FORMS) != 0) {
            WebViewDatabase db = WebViewDatabase.getInstance(context);
            db.clearFormData();
            db.clearHttpAuthUsernamePassword();
        }
        if ((flags & CACHE) != 0) {
            try {
                WebView temp = new WebView(context);
                temp.clearCache(true);
                temp.clearFormData();
                temp.destroy();
            } catch (Exception ignored) {
                // A missing WebView implementation must not crash a cleanup.
            }
        }
        if ((flags & EXCEPTIONS) != 0) {
            prefs.clearAllowlist();
        }
    }

    /** Flags selected by the user's "clear on exit" settings. */
    static int exitFlags(Prefs prefs) {
        int flags = 0;
        if (prefs.bool(Prefs.CLEAR_HISTORY_EXIT)) flags |= HISTORY;
        if (prefs.bool(Prefs.CLEAR_COOKIES_EXIT)) flags |= COOKIES;
        if (prefs.bool(Prefs.CLEAR_CACHE_EXIT)) flags |= CACHE;
        if (prefs.bool(Prefs.CLEAR_STORAGE_EXIT)) flags |= STORAGE | FORMS;
        return flags;
    }

    /** Interactive "Clear browsing data" dialog. */
    static void showDialog(Activity activity, Prefs prefs, Runnable afterClear) {
        final String[] labels = {
                "История посещений",
                "Cookie и входы на сайтах",
                "Кэш страниц и изображений",
                "Данные сайтов (localStorage, IndexedDB)",
                "Сохранённые формы и HTTP-пароли",
                "Исключения защиты для сайтов"
        };
        final int[] masks = {HISTORY, COOKIES, CACHE, STORAGE, FORMS, EXCEPTIONS};
        final boolean[] checked = {true, true, true, true, true, false};
        new AlertDialog.Builder(activity)
                .setTitle("Очистить данные браузера")
                .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Очистить", (dialog, which) -> {
                    int flags = 0;
                    for (int i = 0; i < masks.length; i++) if (checked[i]) flags |= masks[i];
                    clear(activity, prefs, flags);
                    Toast.makeText(activity, "Данные очищены", Toast.LENGTH_SHORT).show();
                    if (afterClear != null) afterClear.run();
                })
                .show();
    }
}

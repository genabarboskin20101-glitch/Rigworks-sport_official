# LMusic — сборка APK через GitHub Actions

## Быстрый запуск

1. Создайте GitHub-репозиторий. Поскольку в проекте есть ключ подписи `signing/lmusic.keystore`, рекомендуется сделать репозиторий приватным.
2. Загрузите **содержимое этого архива** в корень репозитория (папки `app/`, `signing/` и файлы `build.gradle`, `settings.gradle` должны быть в корне).
3. Файл workflow уже находится по пути `.github/workflows/build-apk.yml`.
4. Откройте вкладку **Actions** и запустите **Build LMusic APK** либо отправьте коммит.
5. Скачайте APK из артефактов запуска **LMusic-apk** или из **Releases → lmusic-latest**.

Если вы добавляете в репозиторий только `LMusic-project.zip` и workflow, workflow автоматически распакует архив перед сборкой.

## Где что

- `app/src/main/assets/www/index.html` — страница приложения.
- `app/src/main/java/kx/engine/` — нативный мост.
- `app/src/main/java/com/lmusic/app/WebViewActivity.java` — WebView-оболочка.
- `app/build.gradle` — идентификатор приложения, версия и параметры подписи.
- `signing/lmusic.keystore` — ключ подписи; не публикуйте его в открытом репозитории.

## Автопауза и трансляция (новое)

- **Настройки → Автопауза**: пауза при звонке, просмотре видео (другое приложение запросило аудиофокус), записи видео/звука, отключении Bluetooth/наушников; опция автоматического продолжения. Код: `kx/engine/SysWatch.java`, `NativeAudio` (фокус), `index.html` (`autoPausePrefs`, `__kxSys`).
- **Настройки → Трансляция** (или кнопка в полноэкранном плеере): поиск DLNA/UPnP-устройств в Wi-Fi (телевизоры, колонки), воспроизведение на них, громкость устройства. Звук телефона глушится, управление остаётся в LMusic. Код: `Cast.java`, `MediaHttp.java`. Кнопки «Дублировать экран» (Miracast), «Вывод звука системы» и Bluetooth открывают системные экраны.
- Устройства только с Google Cast без DLNA в списке не появятся. В манифест добавлены ACCESS_WIFI_STATE, ACCESS_NETWORK_STATE, CHANGE_WIFI_MULTICAST_STATE и usesCleartextTraffic (HTTP в локальной сети).

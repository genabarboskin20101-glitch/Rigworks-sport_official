# LMusic — сборка APK через GitHub Actions

## Быстрый запуск

1. Создайте GitHub-репозиторий. Поскольку в проекте есть ключ подписи `signing/lmusic.keystore`, рекомендуется сделать репозиторий приватным.
2. Загрузите **содержимое этого архива** в корень репозитория (папки `app/`, `signing/` и файлы `build.gradle`, `settings.gradle` должны быть в корне).
3. Файл workflow уже находится по пути `.github/workflows/build-apk.yml`.
4. Откройте вкладку **Actions** и запустите **Build LMusic APK** либо отправьте коммит.
5. Скачайте APK из артефактов запуска **LMusic-apk** или из **Releases → lmusic-latest**.

Если вы добавляете в репозиторий только `LMusic-project.zip` и workflow, workflow автоматически распакует архив перед сборкой.

## Где что

- `app/src/main/assets/www/index.html` — страница приложения.
- `app/src/main/java/kx/engine/` — нативный мост.
- `app/src/main/java/com/lmusic/app/WebViewActivity.java` — WebView-оболочка.
- `app/build.gradle` — идентификатор приложения, версия и параметры подписи.
- `signing/lmusic.keystore` — ключ подписи; не публикуйте его в открытом репозитории.

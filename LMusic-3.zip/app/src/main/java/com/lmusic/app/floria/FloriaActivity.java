package com.lmusic.app.floria;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.RenderProcessGoneDetail;
import android.net.http.SslError;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class FloriaActivity extends Activity {
    private static final int BG = Color.rgb(16, 16, 16);
    private static final int PANEL = Color.rgb(24, 24, 24);
    private static final int CONTROL = Color.rgb(37, 37, 37);
    private static final int BORDER = Color.rgb(58, 58, 58);
    private static final int TEXT = Color.rgb(239, 239, 239);
    private static final int MUTED = Color.rgb(166, 166, 166);
    private static final String HOME_URL = "floria://home";
    private static final String INTERNAL_HOST = "floria.invalid";
    private static final String PREFS = "floria_preferences";
    private static final String HISTORY_KEY = "history_json";
    private static final String BOOKMARKS_KEY = "bookmarks_json";
    private static final int HISTORY_LIMIT = 150;
    private static final String HOME_HTML = "<!doctype html><html lang='ru'><head><meta charset='utf-8'>"
            + "<meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>"
            + "<style>"
            + "*{box-sizing:border-box}body{margin:0;background:#101010;color:#ededed;font-family:Arial,Helvetica,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:28px 20px}"
            + ".wrap{width:100%;max-width:560px;text-align:center;margin-top:-7vh}.mark{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border:1px solid #505050;border-radius:13px;color:#eee;font-weight:700;font-size:25px;margin-bottom:16px;background:#191919}"
            + "h1{font-size:40px;font-weight:500;letter-spacing:8px;margin:0 0 10px 8px}p{color:#999;font-size:14px;margin:0 0 30px}form{display:flex;gap:8px;background:#1a1a1a;border:1px solid #3d3d3d;border-radius:15px;padding:7px;box-shadow:0 8px 28px #0004}"
            + "input{flex:1;min-width:0;border:0;outline:0;background:transparent;color:#f0f0f0;padding:12px;font-size:15px}button{border:1px solid #555;background:#303030;color:#f2f2f2;border-radius:10px;padding:0 15px;font-size:14px}"
            + ".links{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:27px}.links a{color:#b7b7b7;text-decoration:none;border:1px solid #343434;background:#171717;border-radius:11px;padding:10px 13px;font-size:12px}.foot{margin-top:42px;font-size:11px;color:#626262}"
            + "</style></head><body><main class='wrap'><div class='mark'>F</div><h1>FLORIA</h1><p>Спокойное пространство для интернета.</p>"
            + "<form action='https://duckduckgo.com/' method='get'><input name='q' type='search' placeholder='Поиск или адрес сайта' aria-label='Поиск'><button type='submit'>Искать ↗</button></form>"
            + "<nav class='links'><a href='https://duckduckgo.com/'>DuckDuckGo</a><a href='https://wikipedia.org/'>Wikipedia</a><a href='https://github.com/'>GitHub</a><a href='https://youtube.com/'>YouTube</a></nav>"
            + "<div class='foot'>LESS NOISE. MORE WEB.</div></main></body></html>";

    private final ArrayList<BrowserTab> tabs = new ArrayList<>();
    private SharedPreferences preferences;
    private LinearLayout root;
    private FrameLayout webHost;
    private EditText addressInput;
    private ProgressBar progressBar;
    private TextView tabsButton;
    private int currentTab = -1;
    private boolean ignoreAddressChange;
    private PendingDownload pendingDownload;

    private static final class BrowserTab {
        final WebView webView;
        String url = HOME_URL;
        String title = "Новая вкладка";

        BrowserTab(WebView webView) {
            this.webView = webView;
        }
    }

    private static final class PendingDownload {
        final String url;
        final String userAgent;
        final String contentDisposition;
        final String mimeType;

        PendingDownload(String url, String userAgent, String contentDisposition, String mimeType) {
            this.url = url;
            this.userAgent = userAgent;
            this.contentDisposition = contentDisposition;
            this.mimeType = mimeType;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setNavigationBarDividerColor(BORDER);
        }
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();

        if (savedInstanceState != null) {
            ArrayList<String> restoredUrls = savedInstanceState.getStringArrayList("tab_urls");
            if (restoredUrls != null && !restoredUrls.isEmpty()) {
                for (String url : restoredUrls) addTab(url, false);
                int savedIndex = savedInstanceState.getInt("current_tab", 0);
                showTab(Math.max(0, Math.min(savedIndex, tabs.size() - 1)));
                return;
            }
        }
        String external = extractExternalTarget(getIntent());
        addTab(external != null ? external : HOME_URL, true);
    }

    /** Запрос из другого приложения: веб-поиск (ACTION_WEB_SEARCH) или ссылка (ACTION_VIEW http/https). */
    private String extractExternalTarget(Intent intent) {
        if (intent == null) return null;
        String action = intent.getAction();
        if (Intent.ACTION_WEB_SEARCH.equals(action)) {
            String query = intent.getStringExtra(android.app.SearchManager.QUERY);
            if (query == null || query.trim().isEmpty()) return null;
            return resolveInput(query);
        }
        if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
            String url = intent.getData().toString();
            return isHttpUrl(url) ? url : null;
        }
        return null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String target = extractExternalTarget(intent);
        if (target != null) addTab(target, true);
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets systemBars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                view.setPadding(0, systemBars.top, 0, systemBars.bottom);
                return insets;
            });
        }

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(dp(10), dp(8), dp(8), dp(7));
        top.setBackgroundColor(PANEL);

        TextView logo = new TextView(this);
        logo.setText("F");
        logo.setTextColor(TEXT);
        logo.setTextSize(24);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(rounded(CONTROL, BORDER, 12));
        logo.setContentDescription("Floria browser");
        top.addView(logo, new LinearLayout.LayoutParams(dp(42), dp(42)));

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(dp(9), 1));

        LinearLayout addressBox = new LinearLayout(this);
        addressBox.setGravity(Gravity.CENTER_VERTICAL);
        addressBox.setOrientation(LinearLayout.HORIZONTAL);
        addressBox.setPadding(dp(12), 0, dp(10), 0);
        addressBox.setBackground(rounded(CONTROL, BORDER, 13));

        TextView secureGlyph = new TextView(this);
        secureGlyph.setText("⌕");
        secureGlyph.setTextSize(19);
        secureGlyph.setTextColor(MUTED);
        secureGlyph.setGravity(Gravity.CENTER);
        addressBox.addView(secureGlyph, new LinearLayout.LayoutParams(dp(22), -1));

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextSize(14);
        addressInput.setTextColor(TEXT);
        addressInput.setHintTextColor(MUTED);
        addressInput.setHint("Поиск или адрес сайта");
        addressInput.setSelectAllOnFocus(true);
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressInput.setBackgroundColor(Color.TRANSPARENT);
        addressInput.setPadding(dp(3), 0, 0, 0);
        addressBox.addView(addressInput, new LinearLayout.LayoutParams(0, -1, 1f));
        addressInput.setOnEditorActionListener((view, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                navigateFromAddress();
                return true;
            }
            return false;
        });
        top.addView(addressBox, new LinearLayout.LayoutParams(0, dp(42), 1f));

        TextView menu = iconButton("⋮", "Меню браузера", 27);
        LinearLayout.LayoutParams menuParams = new LinearLayout.LayoutParams(dp(38), dp(42));
        menuParams.leftMargin = dp(5);
        top.addView(menu, menuParams);
        menu.setOnClickListener(this::showOverflowMenu);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(58)));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(ColorStateList.valueOf(MUTED));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(BG));
        progressBar.setVisibility(View.INVISIBLE);
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(2)));

        webHost = new FrameLayout(this);
        webHost.setBackgroundColor(Color.WHITE);
        root.addView(webHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        View divider = new View(this);
        divider.setBackgroundColor(BORDER);
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(dp(7), dp(3), dp(7), dp(3));
        bottom.setBackgroundColor(PANEL);

        addBottomButton(bottom, "‹", "Назад", v -> goBack(), 25);
        addBottomButton(bottom, "›", "Вперёд", v -> goForward(), 25);
        addBottomButton(bottom, "⌂", "Домой", v -> goHome(), 23);
        addBottomButton(bottom, "↻", "Перезагрузить", v -> reloadCurrent(), 22);

        tabsButton = iconButton("1", "Показать вкладки", 15);
        tabsButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bottom.addView(tabsButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        tabsButton.setOnClickListener(v -> showTabsDialog());

        addBottomButton(bottom, "+", "Новая вкладка", v -> addTab(HOME_URL, true), 26);
        root.addView(bottom, new LinearLayout.LayoutParams(-1, dp(54)));
        setContentView(root);
    }

    private void addBottomButton(LinearLayout parent, String glyph, String description, View.OnClickListener listener, int size) {
        TextView button = iconButton(glyph, description, size);
        parent.addView(button, new LinearLayout.LayoutParams(0, dp(44), 1f));
        button.setOnClickListener(listener);
    }

    private TextView iconButton(String glyph, String description, int textSize) {
        TextView button = new TextView(this);
        button.setText(glyph);
        button.setTextColor(TEXT);
        button.setTextSize(textSize);
        button.setGravity(Gravity.CENTER);
        button.setBackground(rounded(PANEL, PANEL, 11));
        button.setContentDescription(description);
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private GradientDrawable rounded(int fillColor, int strokeColor, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeColor != fillColor) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void addTab(String initialUrl, boolean switchToTab) {
        WebView webView = new WebView(this);
        BrowserTab tab = new BrowserTab(webView);
        tabs.add(tab);
        webHost.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        configureWebView(tab);
        if (switchToTab || currentTab < 0) showTab(tabs.size() - 1);
        if (initialUrl == null || HOME_URL.equals(initialUrl) || initialUrl.isEmpty()) {
            loadHome(tab);
        } else if (isHttpUrl(initialUrl)) {
            tab.url = initialUrl;
            webView.loadUrl(initialUrl);
        } else {
            loadHome(tab);
        }
        updateTabsButton();
    }

    private void configureWebView(BrowserTab tab) {
        WebView webView = tab.webView;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        webView.setBackgroundColor(Color.WHITE);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrlScheme(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrlScheme(url);
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                tab.url = isInternalHomeUrl(url) ? HOME_URL : url;
                if (isCurrent(tab)) {
                    updateAddressBar(tab);
                    progressBar.setProgress(5);
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                tab.url = isInternalHomeUrl(url) ? HOME_URL : url;
                if (isHttpUrl(tab.url)) {
                    String title = tab.title;
                    if (title == null || title.trim().isEmpty() || "Новая вкладка".equals(title)) {
                        title = Uri.parse(tab.url).getHost();
                    }
                    addHistory(title, tab.url);
                }
                if (isCurrent(tab)) {
                    updateAddressBar(tab);
                    if (progressBar.getProgress() >= 100) progressBar.setVisibility(View.INVISIBLE);
                }
                updateTabsButton();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && isCurrent(tab)) {
                    Toast.makeText(FloriaActivity.this, "Не удалось загрузить страницу", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                if (isCurrent(tab)) Toast.makeText(FloriaActivity.this, "Ошибка сертификата — соединение остановлено", Toast.LENGTH_LONG).show();
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                int index = tabs.indexOf(tab);
                if (index >= 0) {
                    if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view);
                    tabs.remove(index);
                    view.destroy();
                    if (tabs.isEmpty()) {
                        currentTab = -1;
                        addTab(HOME_URL, true);
                    } else {
                        currentTab = Math.min(Math.max(0, currentTab), tabs.size() - 1);
                        showTab(currentTab);
                    }
                    Toast.makeText(FloriaActivity.this, "Вкладка была перезапущена после сбоя движка", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (isCurrent(tab)) {
                    progressBar.setProgress(newProgress);
                    progressBar.setVisibility(newProgress >= 100 ? View.INVISIBLE : View.VISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (title != null && !title.trim().isEmpty() && !isInternalHomeUrl(view.getUrl())) {
                    tab.title = title;
                } else {
                    tab.title = "Новая вкладка";
                }
                updateTabsButton();
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                requestDownload(url, userAgent, contentDisposition, mimeType));
    }

    private boolean handleUrlScheme(String rawUrl) {
        Uri uri;
        try {
            uri = Uri.parse(rawUrl);
        } catch (Exception ignored) {
            return true;
        }
        String scheme = uri.getScheme();
        if (scheme == null) return false;
        String lower = scheme.toLowerCase(Locale.ROOT);
        if ("http".equals(lower) || "https".equals(lower) || "about".equals(lower) || "data".equals(lower)) return false;
        if ("javascript".equals(lower) || "file".equals(lower) || "content".equals(lower)) return true;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException ignored) {
            Toast.makeText(this, "Нет приложения для этой ссылки", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void loadHome(BrowserTab tab) {
        tab.url = HOME_URL;
        tab.title = "Новая вкладка";
        tab.webView.loadDataWithBaseURL("https://" + INTERNAL_HOST + "/home", HOME_HTML, "text/html", "UTF-8", null);
        if (isCurrent(tab)) {
            addressInput.setText("");
            progressBar.setVisibility(View.INVISIBLE);
        }
        updateTabsButton();
    }

    private boolean isInternalHomeUrl(String url) {
        if (url == null) return false;
        try {
            Uri uri = Uri.parse(url);
            return INTERNAL_HOST.equalsIgnoreCase(uri.getHost());
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isCurrent(BrowserTab tab) {
        return currentTab >= 0 && currentTab < tabs.size() && tabs.get(currentTab) == tab;
    }

    private BrowserTab current() {
        if (currentTab < 0 || currentTab >= tabs.size()) return null;
        return tabs.get(currentTab);
    }

    private void showTab(int index) {
        if (tabs.isEmpty()) return;
        currentTab = Math.max(0, Math.min(index, tabs.size() - 1));
        for (int i = 0; i < tabs.size(); i++) {
            tabs.get(i).webView.setVisibility(i == currentTab ? View.VISIBLE : View.GONE);
        }
        updateAddressBar(tabs.get(currentTab));
        updateTabsButton();
        progressBar.setVisibility(View.INVISIBLE);
    }

    private void updateAddressBar(BrowserTab tab) {
        ignoreAddressChange = true;
        String shown = (tab.url == null || HOME_URL.equals(tab.url)) ? "" : tab.url;
        addressInput.setText(shown);
        if (shown.isEmpty()) addressInput.setSelection(0);
        else addressInput.setSelection(addressInput.length());
        ignoreAddressChange = false;
    }

    private void updateTabsButton() {
        if (tabsButton == null) return;
        tabsButton.setText(String.valueOf(Math.max(1, tabs.size())));
        String title = current() == null ? "Вкладки" : current().title;
        tabsButton.setContentDescription("Вкладки: " + title + "; открыто " + tabs.size());
    }

    private void navigateFromAddress() {
        String input = addressInput.getText().toString().trim();
        if (input.isEmpty()) return;
        hideKeyboard();
        String target = resolveInput(input);
        BrowserTab tab = current();
        if (tab == null) {
            addTab(target, true);
        } else {
            tab.title = "Загрузка…";
            tab.url = target;
            tab.webView.loadUrl(target);
        }
    }

    private String resolveInput(String input) {
        String value = input.trim();
        String lower = value.toLowerCase(Locale.ROOT);
        if (lower.startsWith("https://") || lower.startsWith("http://")) return value;
        if (!value.matches(".*\\s+.*") && (lower.startsWith("www.") || lower.matches("[a-z0-9-]+(\\.[a-z0-9-]+)+(\\:[0-9]{1,5})?(/.*)?"))) {
            return "https://" + value;
        }
        try {
            return "https://duckduckgo.com/?q=" + URLEncoder.encode(value, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
            return "https://duckduckgo.com/";
        }
    }

    private boolean isHttpUrl(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        return lower.startsWith("https://") || lower.startsWith("http://");
    }

    private void goBack() {
        BrowserTab tab = current();
        if (tab != null && tab.webView.canGoBack()) tab.webView.goBack();
        else if (tabs.size() > 1) closeCurrentTab();
        else goHome();
    }

    private void goForward() {
        BrowserTab tab = current();
        if (tab != null && tab.webView.canGoForward()) tab.webView.goForward();
    }

    private void goHome() {
        BrowserTab tab = current();
        if (tab != null) loadHome(tab);
    }

    private void reloadCurrent() {
        BrowserTab tab = current();
        if (tab == null) return;
        if (HOME_URL.equals(tab.url)) loadHome(tab);
        else tab.webView.reload();
    }

    private void showOverflowMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Новая вкладка").setOnMenuItemClickListener(item -> {
            addTab(HOME_URL, true);
            return true;
        });
        menu.getMenu().add("Вкладки").setOnMenuItemClickListener(item -> {
            showTabsDialog();
            return true;
        });
        menu.getMenu().add("Добавить в закладки").setOnMenuItemClickListener(item -> {
            addCurrentBookmark();
            return true;
        });
        menu.getMenu().add("Закладки").setOnMenuItemClickListener(item -> {
            showSavedItems(BOOKMARKS_KEY, "Закладки", false);
            return true;
        });
        menu.getMenu().add("История").setOnMenuItemClickListener(item -> {
            showSavedItems(HISTORY_KEY, "История", true);
            return true;
        });
        menu.getMenu().add("Поделиться страницей").setOnMenuItemClickListener(item -> {
            shareCurrentPage();
            return true;
        });
        menu.getMenu().add("Перезагрузить").setOnMenuItemClickListener(item -> {
            reloadCurrent();
            return true;
        });
        menu.getMenu().add("Закрыть вкладку").setOnMenuItemClickListener(item -> {
            closeCurrentTab();
            return true;
        });
        menu.getMenu().add("Очистить историю").setOnMenuItemClickListener(item -> {
            new AlertDialog.Builder(this)
                    .setTitle("Очистить историю?")
                    .setMessage("Список посещённых страниц будет удалён с этого устройства.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Очистить", (dialog, which) -> {
                        preferences.edit().remove(HISTORY_KEY).apply();
                        Toast.makeText(this, "История очищена", Toast.LENGTH_SHORT).show();
                    }).show();
            return true;
        });
        menu.show();
    }

    private void showTabsDialog() {
        if (tabs.isEmpty()) return;
        String[] names = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) {
            BrowserTab tab = tabs.get(i);
            String title = (tab.title == null || tab.title.trim().isEmpty()) ? "Новая вкладка" : tab.title;
            String address = HOME_URL.equals(tab.url) ? "Стартовая страница" : tab.url;
            names[i] = (i == currentTab ? "●  " : "○  ") + title + "\n" + address;
        }
        new AlertDialog.Builder(this)
                .setTitle("Вкладки · " + tabs.size())
                .setItems(names, (dialog, which) -> showTab(which))
                .setPositiveButton("Новая вкладка", (dialog, which) -> addTab(HOME_URL, true))
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private void closeCurrentTab() {
        if (tabs.isEmpty()) return;
        int index = currentTab;
        BrowserTab tab = tabs.remove(index);
        if (tab.webView.getParent() instanceof ViewGroup) ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
        tab.webView.stopLoading();
        tab.webView.destroy();
        if (tabs.isEmpty()) {
            currentTab = -1;
            addTab(HOME_URL, true);
        } else {
            currentTab = Math.min(index, tabs.size() - 1);
            showTab(currentTab);
        }
        updateTabsButton();
    }

    private JSONArray readArray(String key) {
        try {
            return new JSONArray(preferences.getString(key, "[]"));
        } catch (JSONException | ClassCastException ignored) {
            return new JSONArray();
        }
    }

    private void addHistory(String title, String url) {
        if (!isHttpUrl(url)) return;
        JSONArray old = readArray(HISTORY_KEY);
        JSONArray updated = new JSONArray();
        try {
            JSONObject mostRecent = old.length() > 0 ? old.optJSONObject(old.length() - 1) : null;
            if (mostRecent != null && url.equals(mostRecent.optString("url"))) return;
            JSONObject item = new JSONObject();
            item.put("title", (title == null || title.trim().isEmpty()) ? url : title);
            item.put("url", url);
            item.put("time", System.currentTimeMillis());
            int start = Math.max(0, old.length() - (HISTORY_LIMIT - 1));
            for (int i = start; i < old.length(); i++) {
                JSONObject existing = old.optJSONObject(i);
                if (existing != null) updated.put(existing);
            }
            updated.put(item);
            preferences.edit().putString(HISTORY_KEY, updated.toString()).apply();
        } catch (JSONException ignored) {
            // Ignore malformed entry; browsing should continue.
        }
    }

    private void addCurrentBookmark() {
        BrowserTab tab = current();
        if (tab == null || !isHttpUrl(tab.url)) {
            Toast.makeText(this, "Открытая страница не подходит для закладки", Toast.LENGTH_SHORT).show();
            return;
        }
        JSONArray old = readArray(BOOKMARKS_KEY);
        for (int i = 0; i < old.length(); i++) {
            JSONObject item = old.optJSONObject(i);
            if (item != null && tab.url.equals(item.optString("url"))) {
                Toast.makeText(this, "Уже в закладках", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        try {
            JSONObject item = new JSONObject();
            item.put("title", tab.title == null ? tab.url : tab.title);
            item.put("url", tab.url);
            old.put(item);
            preferences.edit().putString(BOOKMARKS_KEY, old.toString()).apply();
            Toast.makeText(this, "Добавлено в закладки", Toast.LENGTH_SHORT).show();
        } catch (JSONException ignored) {
            Toast.makeText(this, "Не удалось сохранить закладку", Toast.LENGTH_SHORT).show();
        }
    }

    private void showSavedItems(String key, String title, boolean newestFirst) {
        JSONArray array = readArray(key);
        ArrayList<JSONObject> items = new ArrayList<>();
        if (newestFirst) {
            for (int i = array.length() - 1; i >= 0; i--) {
                JSONObject item = array.optJSONObject(i);
                if (item != null) items.add(item);
            }
        } else {
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item != null) items.add(item);
            }
        }
        if (items.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(title).setMessage("Здесь пока пусто.").setPositiveButton("OK", null).show();
            return;
        }
        int limit = Math.min(items.size(), 80);
        String[] labels = new String[limit];
        for (int i = 0; i < limit; i++) {
            JSONObject item = items.get(i);
            String itemTitle = item.optString("title", item.optString("url", "Страница"));
            String url = item.optString("url", "");
            labels[i] = itemTitle + "\n" + url;
        }
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(labels, (dialog, which) -> {
                    String url = items.get(which).optString("url", "");
                    if (isHttpUrl(url)) {
                        BrowserTab tab = current();
                        if (tab == null) addTab(url, true);
                        else {
                            tab.url = url;
                            tab.webView.loadUrl(url);
                        }
                    }
                })
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private void shareCurrentPage() {
        BrowserTab tab = current();
        if (tab == null || !isHttpUrl(tab.url)) {
            Toast.makeText(this, "Сначала откройте страницу", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, tab.url);
        startActivity(Intent.createChooser(intent, "Поделиться страницей"));
    }

    private void requestDownload(String url, String userAgent, String disposition, String mimeType) {
        PendingDownload download = new PendingDownload(url, userAgent, disposition, mimeType);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDownload = download;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 410);
            return;
        }
        enqueueDownload(download);
    }

    private void enqueueDownload(PendingDownload download) {
        try {
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(download.url));
            String cookie = CookieManager.getInstance().getCookie(download.url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            if (download.userAgent != null && !download.userAgent.isEmpty()) request.addRequestHeader("User-Agent", download.userAgent);
            request.setTitle(URLUtil.guessFileName(download.url, download.contentDisposition, download.mimeType));
            request.setDescription("Загрузка через Floria");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(download.url, download.contentDisposition, download.mimeType));
            manager.enqueue(request);
            Toast.makeText(this, "Загрузка началась", Toast.LENGTH_SHORT).show();
        } catch (Exception error) {
            Toast.makeText(this, "Не удалось начать загрузку", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 410 && pendingDownload != null) {
            PendingDownload download = pendingDownload;
            pendingDownload = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) enqueueDownload(download);
            else Toast.makeText(this, "Для загрузки файла нужно разрешение на сохранение", Toast.LENGTH_LONG).show();
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(addressInput.getWindowToken(), 0);
            addressInput.clearFocus();
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        ArrayList<String> urls = new ArrayList<>();
        for (BrowserTab tab : tabs) urls.add(tab.url == null ? HOME_URL : tab.url);
        outState.putStringArrayList("tab_urls", urls);
        outState.putInt("current_tab", Math.max(currentTab, 0));
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        for (BrowserTab tab : tabs) {
            tab.webView.onPause();
            tab.webView.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (BrowserTab tab : tabs) {
            tab.webView.onResume();
            tab.webView.resumeTimers();
        }
    }

    @Override
    public void onBackPressed() {
        BrowserTab tab = current();
        if (tab != null && tab.webView.canGoBack()) {
            tab.webView.goBack();
        } else if (tabs.size() > 1) {
            closeCurrentTab();
        } else {
            super.onBackPressed();
        }
    }
}

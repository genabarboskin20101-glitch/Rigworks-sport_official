package kx.engine;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.lmusic.app.WebViewActivity;

/**
 * Manifest receiver for notification controls. Unlike an Activity-registered receiver, it can be
 * recreated by Android when a media notification action is tapped after the Activity was removed.
 */
public final class MediaActionReceiver extends BroadcastReceiver {
    private static final String TAG = "KX";
    public static final String EXTRA_ACTION = "kx.engine.EXTRA_MEDIA_ACTION";
    public static final String EXTRA_POSITION = "kx.engine.EXTRA_MEDIA_POSITION";
    private static final String PFX = "kx.engine.MEDIA.";

    @Override
    public void onReceive(Context context, Intent intent) {
        String raw = intent == null ? null : intent.getAction();
        if (raw == null || !raw.startsWith(PFX)) return;
        String action = raw.substring(PFX.length());
        long position = intent.getLongExtra(EXTRA_POSITION, 0L);

        if (Boot.dispatchMediaAction(action, position)) return;

        // Nothing is playing in-process any longer. A close tap should still clear the stale notification.
        if ("close".equals(action)) {
            try { MediaService.stop(context.getApplicationContext()); } catch (Throwable ignored) { }
            try {
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(MediaNotif.ID);
            } catch (Throwable ignored) { }
            return;
        }

        // Process/bridge was lost (for example, OEM task cleanup). Restore the Activity and deliver
        // the requested action only after the WebView page has finished loading.
        try {
            Intent launch = new Intent(context, WebViewActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(EXTRA_ACTION, action)
                    .putExtra(EXTRA_POSITION, position);
            context.startActivity(launch);
        } catch (Throwable t) {
            Log.w(TAG, "Unable to restore player for media action: " + action, t);
        }
    }
}

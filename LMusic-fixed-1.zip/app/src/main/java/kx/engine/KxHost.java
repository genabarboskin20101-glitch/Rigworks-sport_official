package kx.engine;

import android.app.Activity;

/** Точка входа для Activity оболочки: сохранение и повторное использование живой страницы между запусками. */
public final class KxHost {
    private KxHost() { }

    /** Activity закрывается во время воспроизведения — WebView нужно не уничтожать, а сохранить. Вызывать до super.onDestroy(). */
    public static boolean shouldRetain(Activity a) { return Boot.shouldRetain(a); }

    /** От прошлой Activity осталась живая страница. */
    public static boolean hasRetained() { return Boot.hasSurvivor(); }

    /** Новая Activity подхватывает живую страницу (true — мост перепривязан, страницу не перезагружаем). */
    public static boolean adopt(Activity a) { return Boot.adopt(a); }

    /** Процесс отрисовки убит системой, когда Activity нет: освобождаем сохранённую страницу, звук и уведомление. */
    public static void pageDied() { Boot.pageDied(); }

    /** Процесс отрисовки убит, а Activity ещё есть (её сейчас пересоздадут). Вызывать до recreate(). */
    public static void renderGone(Activity a) { Boot.renderGone(a); }
}

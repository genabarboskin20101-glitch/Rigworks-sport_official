package kx.engine;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaRouter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Set;

/**
 * Устройства поблизости для экрана «Трансляция»:
 *  - Bluetooth: сопряжённые и найденные поиском аудиоустройства (колонки, наушники, телевизоры), отметка «подключено»;
 *  - системные маршруты Android (android.media.MediaRouter): экраны и аудиоустройства, которые видит встроенная трансляция.
 * Для Bluetooth нужны разрешения «Устройства поблизости» (Android 12+) или «Местоположение» (Android 11 и ниже); они
 * запрашиваются при первом открытии экрана. Состояние уходит странице вызовом window.__kxNear({...}).
 */
final class Near {
    private static final String TAG = "KX";

    interface Sink {
        void js(String code);
    }

    private static final class Bt {
        String id, name;
        boolean paired, connected;
    }

    private final Activity act;
    private final Sink sink;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String, Bt> bt = new LinkedHashMap<String, Bt>();
    private final LinkedHashMap<String, String[]> routes = new LinkedHashMap<String, String[]>();
    private BluetoothAdapter ad;
    private MediaRouter mr;
    private MediaRouter.Callback mrCb;
    private BroadcastReceiver rc;
    private volatile boolean running, asked;
    private volatile String perm = "ok";
    private String lastJson = "";

    Near(Activity a, Sink s) {
        act = a;
        sink = s;
    }

    private boolean has(String p) {
        return Build.VERSION.SDK_INT < 23 || act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private String[] missing() {
        ArrayList<String> m = new ArrayList<String>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (!has("android.permission.BLUETOOTH_CONNECT")) m.add("android.permission.BLUETOOTH_CONNECT");
            if (!has("android.permission.BLUETOOTH_SCAN")) m.add("android.permission.BLUETOOTH_SCAN");
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (!has("android.permission.ACCESS_FINE_LOCATION")) m.add("android.permission.ACCESS_FINE_LOCATION");
        }
        return m.toArray(new String[0]);
    }

    void start() {
        h.post(new Runnable() {
            public void run() {
                if (running) {
                    emit(true);
                    return;
                }
                running = true;
                startRoutes();
                initBt();
                h.postDelayed(tick, 3000);
            }
        });
    }

    void stop() {
        h.post(new Runnable() {
            public void run() {
                running = false;
                asked = false;
                h.removeCallbacksAndMessages(null);
                try {
                    if (ad != null && ad.isDiscovering()) ad.cancelDiscovery();
                } catch (Throwable ignored) {
                    // нет разрешения или адаптер выключен
                }
                try {
                    if (rc != null) act.unregisterReceiver(rc);
                } catch (Throwable ignored) {
                    // уже снят
                }
                rc = null;
                try {
                    if (mr != null && mrCb != null) mr.removeCallback(mrCb);
                } catch (Throwable ignored) {
                    // уже снят
                }
                mrCb = null;
            }
        });
    }

    private final Runnable tick = new Runnable() {
        public void run() {
            if (!running) return;
            markConnected();
            emit(false);
            h.postDelayed(this, 3000);
        }
    };

    private final Runnable permPoll = new Runnable() {
        int n;

        public void run() {
            if (!running || !"need".equals(perm)) return;
            if (missing().length == 0) {
                n = 0;
                initBt();
                return;
            }
            if (++n < 120) h.postDelayed(this, 800);
        }
    };

    // ------------------------------------------------------------------------------------------ Bluetooth
    private void initBt() {
        try {
            BluetoothManager bm = (BluetoothManager) act.getSystemService(Context.BLUETOOTH_SERVICE);
            ad = bm == null ? null : bm.getAdapter();
            if (ad == null) {
                perm = "nobt";
                emit(true);
                return;
            }
            String[] miss = missing();
            if (miss.length > 0) {
                perm = "need";
                emit(true);
                if (!asked && Build.VERSION.SDK_INT >= 23) {
                    asked = true;
                    act.requestPermissions(miss, 7431);
                }
                h.postDelayed(permPoll, 800);
                return;
            }
            if (!ad.isEnabled()) {
                perm = "off";
                emit(true);
                h.postDelayed(new Runnable() {
                    public void run() {
                        if (running && "off".equals(perm)) initBt();
                    }
                }, 2000);
                return;
            }
            perm = "ok";
            loadBonded();
            registerReceiver();
            startDiscovery();
            emit(true);
        } catch (Throwable t) {
            Log.w(TAG, "near bt init failed: " + t);
        }
    }

    private static boolean isAudio(BluetoothDevice d) {
        try {
            BluetoothClass c = d.getBluetoothClass();
            return c != null && c.getMajorDeviceClass() == BluetoothClass.Device.Major.AUDIO_VIDEO;
        } catch (Throwable t) {
            return false;
        }
    }

    private void put(BluetoothDevice d, boolean paired) {
        try {
            String name = d.getName();
            if (name == null || name.length() == 0 || !isAudio(d)) return;
            Bt b = bt.get(d.getAddress());
            if (b == null) {
                b = new Bt();
                b.id = d.getAddress();
                bt.put(b.id, b);
            }
            b.name = name;
            b.paired = paired || d.getBondState() == BluetoothDevice.BOND_BONDED;
        } catch (Throwable ignored) {
            // нет разрешения на чтение имени
        }
    }

    private void loadBonded() {
        try {
            Set<BluetoothDevice> set = ad.getBondedDevices();
            if (set == null) return;
            for (BluetoothDevice d : set) put(d, true);
            markConnected();
        } catch (Throwable t) {
            Log.w(TAG, "bonded failed: " + t);
        }
    }

    /** Имена выходных Bluetooth-устройств, на которые сейчас идёт звук (без разрешений: AudioManager). */
    private void markConnected() {
        try {
            AudioManager am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
            AudioDeviceInfo[] outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
            Set<String> names = new HashSet<String>();
            for (AudioDeviceInfo i : outs) {
                int t = i.getType();
                if (t == 8 || t == 26 || t == 27 || t == 30 || t == 7) {
                    CharSequence n = i.getProductName();
                    if (n != null) names.add(n.toString().toLowerCase(Locale.ROOT));
                }
            }
            for (Bt b : bt.values()) b.connected = b.name != null && names.contains(b.name.toLowerCase(Locale.ROOT));
        } catch (Throwable ignored) {
            // нет данных о выходах
        }
    }

    private void registerReceiver() {
        if (rc != null) return;
        rc = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                String a = i.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(a)) {
                    BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d != null) {
                        put(d, false);
                        emit(false);
                    }
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(a)) {
                    if (running) {
                        h.postDelayed(new Runnable() {
                            public void run() {
                                if (running) startDiscovery();
                            }
                        }, 4000);
                    }
                } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(a)) {
                    loadBonded();
                    emit(false);
                }
            }
        };
        IntentFilter f = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        act.registerReceiver(rc, f);
    }

    private void startDiscovery() {
        try {
            if (ad != null && ad.isEnabled() && !ad.isDiscovering()) ad.startDiscovery();
        } catch (Throwable t) {
            Log.w(TAG, "bt discovery failed: " + t);
        }
    }

    /** Сопряжение с найденным устройством. Подключение звука после этого — через системные настройки Bluetooth. */
    void pair(final String addr) {
        h.post(new Runnable() {
            public void run() {
                try {
                    if (ad != null) ad.getRemoteDevice(addr).createBond();
                } catch (Throwable t) {
                    Log.w(TAG, "pair failed: " + t);
                }
            }
        });
    }

    // ------------------------------------------------------------------------------------------ системные маршруты
    private void startRoutes() {
        try {
            mr = (MediaRouter) act.getSystemService(Context.MEDIA_ROUTER_SERVICE);
            if (mr == null) return;
            mrCb = new MediaRouter.SimpleCallback() {
                @Override
                public void onRouteAdded(MediaRouter r, MediaRouter.RouteInfo i) {
                    refreshRoutes();
                }

                @Override
                public void onRouteRemoved(MediaRouter r, MediaRouter.RouteInfo i) {
                    refreshRoutes();
                }

                @Override
                public void onRouteChanged(MediaRouter r, MediaRouter.RouteInfo i) {
                    refreshRoutes();
                }
            };
            // 1 = активное сканирование, 4 = запрос обнаружения; типы: 1 = аудио, 2 = видео/экраны
            mr.addCallback(1 | 2, mrCb, 1 | 4);
            refreshRoutes();
        } catch (Throwable t) {
            Log.w(TAG, "media router failed: " + t);
        }
    }

    private void refreshRoutes() {
        try {
            if (mr == null) return;
            routes.clear();
            MediaRouter.RouteInfo def = mr.getDefaultRoute();
            int n = mr.getRouteCount();
            for (int k = 0; k < n; k++) {
                MediaRouter.RouteInfo ri = mr.getRouteAt(k);
                if (ri == null || ri == def || !ri.isEnabled()) continue;
                CharSequence nm = ri.getName(act);
                if (nm == null || nm.length() == 0) continue;
                CharSequence ds = ri.getDescription();
                boolean video = (ri.getSupportedTypes() & 2) != 0;
                routes.put(nm.toString(), new String[] { nm.toString(), ds == null ? "" : ds.toString(), video ? "screen" : "audio" });
            }
            emit(false);
        } catch (Throwable t) {
            Log.w(TAG, "routes refresh failed: " + t);
        }
    }

    // ------------------------------------------------------------------------------------------ состояние
    String json() {
        StringBuilder sb = new StringBuilder("{\"e\":\"near\",\"perm\":").append(Cast.q(perm));
        sb.append(",\"bt\":[");
        boolean first = true;
        for (Bt b : bt.values()) {
            if (!first) sb.append(',');
            first = false;
            sb.append("{\"id\":").append(Cast.q(b.id)).append(",\"name\":").append(Cast.q(b.name)).append(",\"paired\":").append(b.paired)
                    .append(",\"connected\":").append(b.connected).append('}');
        }
        sb.append("],\"routes\":[");
        first = true;
        for (String[] r : routes.values()) {
            // маршруты Bluetooth уже показаны в списке Bluetooth
            boolean dup = false;
            for (Bt b : bt.values()) {
                if (b.name != null && b.name.equalsIgnoreCase(r[0])) dup = true;
            }
            if (dup) continue;
            if (!first) sb.append(',');
            first = false;
            sb.append("{\"name\":").append(Cast.q(r[0])).append(",\"desc\":").append(Cast.q(r[1])).append(",\"kind\":").append(Cast.q(r[2])).append('}');
        }
        return sb.append("]}").toString();
    }

    private void emit(boolean force) {
        String j = json();
        if (!force && j.equals(lastJson)) return;
        lastJson = j;
        sink.js("window.__kxNear&&window.__kxNear(" + j + ")");
    }
}

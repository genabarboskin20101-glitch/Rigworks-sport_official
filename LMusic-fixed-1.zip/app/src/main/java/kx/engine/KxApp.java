package kx.engine;

import android.app.Application;
import android.util.Log;

/**
 * Application приложения: подключает мост KExport к WebView (Boot следит за жизненным циклом Activity).
 * Заменяет KxFactory из прежней dex-сборки: работает на любом API (24+), а не только на 28+.
 */
public class KxApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        try {
            Boot.install(this);
        } catch (Throwable t) {
            Log.w("KX", "Boot.install failed", t);
        }
    }
}

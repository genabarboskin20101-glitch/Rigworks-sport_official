package kx.engine;

import java.util.ArrayList;

/**
 * Чистая DSP-часть нативного аудио-движка LMusic (без Android API, чтобы её можно было тестировать на обычной JVM).
 * Повторяет цепочку страницы: preamp -> 10-полосный эквалайзер -> бас -> виртуализатор -> громкость -> баланс -> реверб -> лимитер -> анализатор,
 * а также автоматизацию параметров (AudioParam) для кросс-фейда.
 */
final class AudioDsp {
    private AudioDsp() {
    }

    static double db2lin(double db) {
        return Math.pow(10.0, db / 20.0);
    }

    static double lin2db(double x) {
        return 20.0 * Math.log10(x);
    }

    // ------------------------------------------------------------------------------------------------
    // Автоматизация параметра (подмножество Web Audio AudioParam). Время — секунды часов микшера.
    // ------------------------------------------------------------------------------------------------
    static final class AutoParam {
        private static final int NONE = 0, RAMP = 1, CURVE = 2, TARGET = 3;
        private static final int EV_SET = 0, EV_LINEAR = 1, EV_CURVE = 2, EV_TARGET = 3;

        private static final class Ev {
            int type;
            double start, time, v, extra;
            float[] curve;
        }

        private double cur;
        private int seg = NONE;
        private double t0, t1, v0, v1, tc;
        private float[] curve;
        private double lastT = 0;
        private final ArrayList<Ev> q = new ArrayList<Ev>();

        AutoParam(double initial) {
            cur = initial;
        }

        /** Значение в момент t (t не должно убывать между вызовами; меньшее значение приравнивается к предыдущему). */
        synchronized double valueAt(double t) {
            if (t < lastT) t = lastT;
            lastT = t;
            while (!q.isEmpty()) {
                Ev e = q.get(0);
                if (e.start > t) break;
                q.remove(0);
                double v = evalSeg(e.start);
                switch (e.type) {
                    case EV_SET:
                        seg = NONE;
                        cur = e.v;
                        break;
                    case EV_LINEAR:
                        if (e.time <= e.start) {
                            seg = NONE;
                            cur = e.v;
                        } else {
                            seg = RAMP;
                            t0 = e.start;
                            t1 = e.time;
                            v0 = v;
                            v1 = e.v;
                        }
                        break;
                    case EV_CURVE:
                        seg = CURVE;
                        t0 = e.time;
                        t1 = e.time + e.extra;
                        v0 = v;
                        curve = e.curve;
                        break;
                    default:
                        seg = TARGET;
                        t0 = e.time;
                        v0 = v;
                        v1 = e.v;
                        tc = e.extra;
                        break;
                }
            }
            return evalSeg(t);
        }

        private double evalSeg(double t) {
            switch (seg) {
                case RAMP:
                    if (t >= t1) {
                        seg = NONE;
                        cur = v1;
                        return cur;
                    }
                    if (t <= t0) return v0;
                    return v0 + (v1 - v0) * (t - t0) / (t1 - t0);
                case CURVE: {
                    if (t >= t1) {
                        seg = NONE;
                        cur = curve[curve.length - 1];
                        return cur;
                    }
                    if (t <= t0) return curve[0];
                    double pos = (t - t0) / (t1 - t0) * (curve.length - 1);
                    int i = (int) pos;
                    if (i >= curve.length - 1) return curve[curve.length - 1];
                    double f = pos - i;
                    return curve[i] + (curve[i + 1] - curve[i]) * f;
                }
                case TARGET: {
                    if (t <= t0) return v0;
                    double v = v1 + (v0 - v1) * Math.exp(-(t - t0) / tc);
                    if (Math.abs(v - v1) < 1e-7) {
                        seg = NONE;
                        cur = v1;
                        return cur;
                    }
                    return v;
                }
                default:
                    return cur;
            }
        }

        private void insert(Ev e) {
            int i = q.size();
            while (i > 0 && q.get(i - 1).start > e.start) i--;
            q.add(i, e);
        }

        private double lastEventTime() {
            if (!q.isEmpty()) return q.get(q.size() - 1).time;
            return lastT;
        }

        synchronized void setValueAt(double v, double time) {
            Ev e = new Ev();
            e.type = EV_SET;
            e.start = time;
            e.time = time;
            e.v = v;
            insert(e);
        }

        synchronized void linearRampTo(double v, double time) {
            Ev e = new Ev();
            e.type = EV_LINEAR;
            e.start = Math.max(lastEventTime(), lastT);
            e.time = time;
            e.v = v;
            insert(e);
        }

        synchronized void curveAt(float[] c, double time, double dur) {
            if (c == null || c.length < 2 || dur <= 0) {
                setValueAt(c != null && c.length > 0 ? c[c.length - 1] : cur, time);
                return;
            }
            Ev e = new Ev();
            e.type = EV_CURVE;
            e.start = time;
            e.time = time;
            e.extra = dur;
            e.curve = c;
            insert(e);
        }

        synchronized void targetAt(double v, double time, double tconst) {
            if (tconst <= 1e-6) {
                setValueAt(v, time);
                return;
            }
            Ev e = new Ev();
            e.type = EV_TARGET;
            e.start = time;
            e.time = time;
            e.v = v;
            e.extra = tconst;
            insert(e);
        }

        /** cancelScheduledValues / cancelAndHoldAtTime: убирает события с временем >= time; активный участок замораживается на текущем значении. */
        synchronized void cancel(double time) {
            for (int i = q.size() - 1; i >= 0; i--) {
                if (q.get(i).time >= time) q.remove(i);
            }
            if (seg != NONE && time <= lastT + 1e-9) {
                double v = evalSeg(lastT);
                if (seg != NONE) {
                    seg = NONE;
                    cur = v;
                }
            }
        }

        synchronized double current() {
            return evalSeg(lastT);
        }

        synchronized boolean idle() {
            return q.isEmpty() && seg == NONE;
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Биквад (формулы Web Audio: peaking с линейной Q; шельфы без Q, S = 1).
    // ------------------------------------------------------------------------------------------------
    static final class Biquad {
        static final int PEAK = 0, LOW = 1, HIGH = 2;
        final int type;
        final double freq, q, fs;
        double gain, target;
        private double b0 = 1, b1, b2, a1, a2;
        private double lastGain = Double.NaN;
        private final double[] z = new double[4];
        boolean bypass = true;

        Biquad(int type, double freq, double q, double fs) {
            this.type = type;
            this.freq = freq;
            this.q = q;
            this.fs = fs;
        }

        void step(double alpha) {
            gain += (target - gain) * alpha;
            if (Math.abs(target - gain) < 1e-3) gain = target;
            if (gain == 0.0) {
                if (!bypass) {
                    bypass = true;
                    z[0] = z[1] = z[2] = z[3] = 0;
                }
                lastGain = Double.NaN;
                return;
            }
            bypass = false;
            if (gain != lastGain) {
                lastGain = gain;
                coefs(gain);
            }
        }

        private void coefs(double db) {
            double A = Math.pow(10.0, db / 40.0);
            double w0 = 2.0 * Math.PI * freq / fs;
            double cosw = Math.cos(w0), sinw = Math.sin(w0);
            double nb0, nb1, nb2, na0, na1, na2;
            if (type == PEAK) {
                double alpha = sinw / (2.0 * q);
                nb0 = 1 + alpha * A;
                nb1 = -2 * cosw;
                nb2 = 1 - alpha * A;
                na0 = 1 + alpha / A;
                na1 = -2 * cosw;
                na2 = 1 - alpha / A;
            } else {
                double alpha = sinw / 2.0 * Math.sqrt(2.0);
                double k = cosw, k2 = 2.0 * Math.sqrt(A) * alpha;
                double ap = A + 1, am = A - 1;
                if (type == LOW) {
                    nb0 = A * (ap - am * k + k2);
                    nb1 = 2 * A * (am - ap * k);
                    nb2 = A * (ap - am * k - k2);
                    na0 = ap + am * k + k2;
                    na1 = -2 * (am + ap * k);
                    na2 = ap + am * k - k2;
                } else {
                    nb0 = A * (ap + am * k + k2);
                    nb1 = -2 * A * (am + ap * k);
                    nb2 = A * (ap + am * k - k2);
                    na0 = ap - am * k + k2;
                    na1 = 2 * (am - ap * k);
                    na2 = ap - am * k - k2;
                }
            }
            double inv = 1.0 / na0;
            b0 = nb0 * inv;
            b1 = nb1 * inv;
            b2 = nb2 * inv;
            a1 = na1 * inv;
            a2 = na2 * inv;
        }

        void process(float[] l, float[] r, int off, int n) {
            if (bypass) return;
            double z0 = z[0], z1 = z[1], z2 = z[2], z3 = z[3];
            for (int i = off; i < off + n; i++) {
                double x = l[i];
                double y = b0 * x + z0;
                z0 = b1 * x - a1 * y + z1;
                z1 = b2 * x - a2 * y;
                l[i] = (float) y;
                x = r[i];
                y = b0 * x + z2;
                z2 = b1 * x - a1 * y + z3;
                z3 = b2 * x - a2 * y;
                r[i] = (float) y;
            }
            z[0] = Math.abs(z0) < 1e-30 ? 0 : z0;
            z[1] = Math.abs(z1) < 1e-30 ? 0 : z1;
            z[2] = Math.abs(z2) < 1e-30 ? 0 : z2;
            z[3] = Math.abs(z3) < 1e-30 ? 0 : z3;
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Реверберация (Freeverb-подобная, вместо свёртки со случайным импульсом 1.65 с).
    // Уровень выровнен под нормализованную свёртку Web Audio (энергия импульса -> усиление ~0.34 для некоррелированного шума).
    // ------------------------------------------------------------------------------------------------
    static final class Reverb {
        private static final int[] COMB = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
        private static final int[] APF = {556, 441, 341, 225};
        private static final int SPREAD = 23;

        private final float[][] cb = new float[16][];
        private final int[] ci = new int[16];
        private final float[] cs = new float[16];
        private final float[] cfb = new float[16];
        private final float[][] ab = new float[8][];
        private final int[] ai = new int[8];
        private final double damp = 0.28;
        private final double scale;

        Reverb(double fs, double rt60, double scale) {
            this.scale = scale;
            double k = fs / 44100.0;
            for (int ch = 0; ch < 2; ch++) {
                for (int i = 0; i < 8; i++) {
                    int d = (int) Math.round((COMB[i] + ch * SPREAD) * k);
                    cb[ch * 8 + i] = new float[d];
                    cfb[ch * 8 + i] = (float) Math.pow(10.0, -3.0 * d / (rt60 * fs));
                }
                for (int i = 0; i < 4; i++) {
                    int d = (int) Math.round((APF[i] + ch * SPREAD) * k);
                    ab[ch * 4 + i] = new float[d];
                }
            }
        }

        void clear() {
            for (int i = 0; i < 16; i++) {
                java.util.Arrays.fill(cb[i], 0f);
                ci[i] = 0;
                cs[i] = 0f;
            }
            for (int i = 0; i < 8; i++) {
                java.util.Arrays.fill(ab[i], 0f);
                ai[i] = 0;
            }
        }

        /** Вход: l, r. Результат (только мокрый сигнал, с учётом масштаба) пишется в wl, wr. */
        void process(float[] l, float[] r, float[] wl, float[] wr, int off, int n) {
            final float d1 = (float) (damp), d2 = (float) (1.0 - damp);
            for (int i = off; i < off + n; i++) {
                float in = (l[i] + r[i]) * 0.5f;
                float outL = 0f, outR = 0f;
                for (int c = 0; c < 8; c++) {
                    float[] b = cb[c];
                    int p = ci[c];
                    float y = b[p];
                    cs[c] = y * d2 + cs[c] * d1;
                    b[p] = in + cs[c] * cfb[c];
                    if (++p >= b.length) p = 0;
                    ci[c] = p;
                    outL += y;
                    b = cb[8 + c];
                    p = ci[8 + c];
                    y = b[p];
                    cs[8 + c] = y * d2 + cs[8 + c] * d1;
                    b[p] = in + cs[8 + c] * cfb[8 + c];
                    if (++p >= b.length) p = 0;
                    ci[8 + c] = p;
                    outR += y;
                }
                for (int a = 0; a < 4; a++) {
                    float[] b = ab[a];
                    int p = ai[a];
                    float bo = b[p];
                    float o = -outL + bo;
                    b[p] = outL + bo * 0.5f;
                    if (++p >= b.length) p = 0;
                    ai[a] = p;
                    outL = o;
                    b = ab[4 + a];
                    p = ai[4 + a];
                    bo = b[p];
                    o = -outR + bo;
                    b[p] = outR + bo * 0.5f;
                    if (++p >= b.length) p = 0;
                    ai[4 + a] = p;
                    outR = o;
                }
                wl[i] = (float) (outL * scale);
                wr[i] = (float) (outR * scale);
            }
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Лимитер: DynamicsCompressor из Web Audio (threshold -16 дБ, knee 20, ratio 10, attack 3 мс, release 120 мс)
    // со статической кривой и автоматической компенсацией громкости, как в Chromium; огибающая упрощена.
    // ------------------------------------------------------------------------------------------------
    static final class Limiter {
        private final double linThr, kneeThrDb, linKneeThr, slope, k, makeup;
        private final double atk, rel;
        private final float[] dl, dr;
        private int dp = 0;
        private double gain = 1.0;
        private final int look;

        Limiter(double fs, double thrDb, double kneeDb, double ratio, double attack, double release) {
            linThr = db2lin(thrDb);
            kneeThrDb = thrDb + kneeDb;
            linKneeThr = db2lin(kneeThrDb);
            slope = 1.0 / ratio;
            double minK = 0.1, maxK = 10000, kk = 5;
            for (int i = 0; i < 15; i++) {
                if (slopeAt(linKneeThr, kk) < slope) maxK = kk;
                else minK = kk;
                kk = Math.sqrt(minK * maxK);
            }
            k = kk;
            double full = saturate(1.0);
            makeup = Math.pow(1.0 / full, 0.6);
            atk = 1.0 - Math.exp(-1.0 / (attack * fs));
            rel = 1.0 - Math.exp(-1.0 / (release * fs));
            look = Math.max(1, (int) Math.round(0.006 * fs));
            dl = new float[look];
            dr = new float[look];
        }

        private double kneeCurve(double x, double kk) {
            if (x < linThr) return x;
            return linThr + (1.0 - Math.exp(-kk * (x - linThr))) / kk;
        }

        private double slopeAt(double x, double kk) {
            if (x < linThr) return 1.0;
            double x2 = x * 1.001;
            double xd = lin2db(x), x2d = lin2db(x2);
            double y = kneeCurve(x, kk), y2 = kneeCurve(x2, kk);
            return (lin2db(y2) - lin2db(y)) / (x2d - xd);
        }

        double saturate(double x) {
            if (x < linThr) return x;
            if (x < linKneeThr) return kneeCurve(x, k);
            double yKneeDb = lin2db(kneeCurve(linKneeThr, k));
            double yDb = yKneeDb + slope * (lin2db(x) - kneeThrDb);
            return db2lin(yDb);
        }

        double makeupGain() {
            return makeup;
        }

        void process(float[] l, float[] r, int off, int n) {
            for (int i = off; i < off + n; i++) {
                float xl = l[i], xr = r[i];
                double a = Math.max(Math.abs(xl), Math.abs(xr));
                double desired = a <= 1e-4 ? 1.0 : Math.min(1.0, saturate(a) / a);
                if (desired < gain) gain += (desired - gain) * atk;
                else gain += (desired - gain) * rel;
                float ol = dl[dp], or = dr[dp];
                dl[dp] = xl;
                dr[dp] = xr;
                if (++dp >= look) dp = 0;
                double g = gain * makeup;
                l[i] = (float) (ol * g);
                r[i] = (float) (or * g);
            }
        }

        void reset() {
            java.util.Arrays.fill(dl, 0f);
            java.util.Arrays.fill(dr, 0f);
            gain = 1.0;
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Анализатор: БПФ 256 точек, окно Блэкмана, сглаживание 0.3, -100..-30 дБ -> байты 0..255 (как AnalyserNode).
    // ------------------------------------------------------------------------------------------------
    static final class Spectrum {
        static final int N = 256;
        private final float[] ring = new float[N];
        private int rp = 0;
        private final double[] win = new double[N];
        private final double[] re = new double[N], im = new double[N];
        private final double[] smooth = new double[N / 2];
        final byte[] out = new byte[N / 2];

        Spectrum() {
            double a = 0.16, a0 = (1 - a) / 2, a1 = 0.5, a2 = a / 2;
            for (int i = 0; i < N; i++) {
                win[i] = a0 - a1 * Math.cos(2 * Math.PI * i / N) + a2 * Math.cos(4 * Math.PI * i / N);
            }
        }

        void push(float[] l, float[] r, int n) {
            for (int i = 0; i < n; i++) {
                ring[rp] = (l[i] + r[i]) * 0.5f;
                if (++rp >= N) rp = 0;
            }
        }

        void compute() {
            for (int i = 0; i < N; i++) {
                re[i] = ring[(rp + i) % N] * win[i];
                im[i] = 0;
            }
            fft(re, im);
            for (int k = 0; k < N / 2; k++) {
                double mag = Math.sqrt(re[k] * re[k] + im[k] * im[k]) / N;
                smooth[k] = 0.3 * smooth[k] + 0.7 * mag;
                double db = smooth[k] <= 1e-12 ? -200 : 20 * Math.log10(smooth[k]);
                double v = 255.0 * (db + 100.0) / 70.0;
                out[k] = (byte) (v < 0 ? 0 : (v > 255 ? 255 : (int) v));
            }
        }

        private static void fft(double[] re, double[] im) {
            int n = re.length;
            for (int i = 1, j = 0; i < n; i++) {
                int bit = n >> 1;
                for (; (j & bit) != 0; bit >>= 1) j ^= bit;
                j ^= bit;
                if (i < j) {
                    double t = re[i];
                    re[i] = re[j];
                    re[j] = t;
                    t = im[i];
                    im[i] = im[j];
                    im[j] = t;
                }
            }
            for (int len = 2; len <= n; len <<= 1) {
                double ang = -2 * Math.PI / len;
                double wr = Math.cos(ang), wi = Math.sin(ang);
                for (int i = 0; i < n; i += len) {
                    double cr = 1, ci = 0;
                    for (int j = 0; j < len / 2; j++) {
                        int a = i + j, b = i + j + len / 2;
                        double tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
                        re[b] = re[a] - tr;
                        im[b] = im[a] - ti;
                        re[a] += tr;
                        im[a] += ti;
                        double ncr = cr * wr - ci * wi;
                        ci = cr * wi + ci * wr;
                        cr = ncr;
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Вся цепочка эффектов.
    // ------------------------------------------------------------------------------------------------
    /** Сдвиг высоты тона без изменения длительности: две линии задержки с перекрёстным затуханием (Хэнн). ratio>1 — выше, <1 — ниже. */
    static final class PitchShifter {
        private static final int N = 8192, MASK = N - 1, W = 2048;
        private final float[] bl = new float[N], br = new float[N];
        private int w = 0;
        private double ph = 0;

        void reset() {
            java.util.Arrays.fill(bl, 0f);
            java.util.Arrays.fill(br, 0f);
            w = 0;
            ph = 0;
        }

        private static float tap(float[] b, int w, double delay) {
            double pos = w - delay;
            double fl = Math.floor(pos);
            float f = (float) (pos - fl);
            int i0 = ((int) fl) & MASK, i1 = (i0 + 1) & MASK;
            return b[i0] + (b[i1] - b[i0]) * f;
        }

        void process(float[] l, float[] r, int n, double ratio) {
            final double inc = (1.0 - ratio) / W;
            for (int i = 0; i < n; i++) {
                bl[w] = l[i];
                br[w] = r[i];
                double p0 = ph, p1 = ph + 0.5;
                if (p1 >= 1.0) p1 -= 1.0;
                double g0 = Math.sin(Math.PI * p0), g1 = Math.sin(Math.PI * p1);
                g0 *= g0;
                g1 *= g1;
                double d0 = p0 * W + 2, d1 = p1 * W + 2;
                l[i] = (float) (tap(bl, w, d0) * g0 + tap(bl, w, d1) * g1);
                r[i] = (float) (tap(br, w, d0) * g0 + tap(br, w, d1) * g1);
                w = (w + 1) & MASK;
                ph += inc;
                if (ph >= 1.0) ph -= 1.0;
                else if (ph < 0.0) ph += 1.0;
            }
        }
    }

    static final class Fx {
        static final int SB = 128;
        private final double fs;
        private final Biquad[] eq = new Biquad[10];
        private final Biquad bass;
        private final Reverb reverb;
        private final Limiter limiter;
        private float[] wl = new float[4096], wr = new float[4096];

        // целевые значения (пишет поток команд, читает поток микшера)
        private final double[] tEq = new double[10];
        private volatile double tBass, tVol = 1, tPan, tVirt, tWet, tDry = 1, tPre = 1;

        // сглаженные значения
        private double sVol = 1, sPan = 0, sVirt = 0, sWet = 0, sDry = 1, sPre = 1;
        private final float[] vdl, vdr;
        private int vp = 0;
        private final double aEq, aVol, aPan, aVirt, aWet, aPre;
        boolean reverbRunning = false;

        Fx(double fs, double[] freqs) {
            this.fs = fs;
            for (int i = 0; i < 10; i++) {
                int type = i == 0 ? Biquad.LOW : (i == 9 ? Biquad.HIGH : Biquad.PEAK);
                eq[i] = new Biquad(type, freqs[i], (i == 0 || i == 9) ? 0.8 : 1.05, fs);
            }
            bass = new Biquad(Biquad.LOW, 90, 0.72, fs);
            reverb = new Reverb(fs, REVERB_RT60, REVERB_SCALE);
            limiter = new Limiter(fs, -16, 20, 10, 0.003, 0.12);
            int d = (int) Math.round(0.012 * fs);
            vdl = new float[d];
            vdr = new float[d];
            double dt = SB / fs;
            aEq = 1 - Math.exp(-dt / 0.05);
            aVol = 1 - Math.exp(-dt / 0.05);
            aPan = 1 - Math.exp(-dt / 0.05);
            aVirt = 1 - Math.exp(-dt / 0.03);
            aWet = 1 - Math.exp(-dt / 0.04);
            aPre = 1 - Math.exp(-dt / 0.02);
        }

        static final double REVERB_RT60 = 2.0;
        static final double REVERB_SCALE = 0.0211;   // калибровка: усиление мокрого сигнала ~0.34 (как у нормализованной свёртки Web Audio)

        synchronized void set(double[] eqDb, double bassDb, double vol, double pan, double virtAmount, double wet, double dry, double pre) {
            for (int i = 0; i < 10; i++) tEq[i] = eqDb[i];
            tBass = bassDb;
            tVol = vol;
            tPan = pan;
            double a = Math.max(0, Math.min(1, virtAmount));
            tVirt = Math.max(0, Math.min(1, a * 5.0));
            tWet = wet;
            tDry = dry;
            tPre = pre;
        }

        /** Можно ли считать цепочку «пустой» (хвосты реверба и лимитера затухли) — для засыпания. */
        boolean tailQuiet() {
            return !reverbRunning;
        }

        void process(float[] l, float[] r, int n) {
            synchronized (this) {
                for (int i = 0; i < 10; i++) eq[i].target = tEq[i];
            }
            bass.target = tBass;
            if (wl.length < n) {
                wl = new float[n];
                wr = new float[n];
            }
            for (int off = 0; off < n; off += SB) {
                int m = Math.min(SB, n - off);
                // preamp
                double p0 = sPre;
                sPre += (tPre - sPre) * aPre;
                if (p0 != 1.0 || sPre != 1.0) {
                    for (int i = 0; i < m; i++) {
                        double g = p0 + (sPre - p0) * (i + 1) / m;
                        l[off + i] *= (float) g;
                        r[off + i] *= (float) g;
                    }
                }
                for (int b = 0; b < 10; b++) {
                    eq[b].step(aEq);
                    eq[b].process(l, r, off, m);
                }
                bass.step(aEq);
                bass.process(l, r, off, m);
                // виртуализатор
                sVirt += (tVirt - sVirt) * aVirt;
                if (Math.abs(tVirt - sVirt) < 1e-4) sVirt = tVirt;
                if (sVirt > 0) {
                    double direct = 1.0 - sVirt * 0.34, cross = sVirt * 0.34;
                    int dlen = vdl.length;
                    for (int i = 0; i < m; i++) {
                        float xl = l[off + i], xr = r[off + i];
                        float dly = vdl[vp], dry2 = vdr[vp];
                        vdl[vp] = xl;
                        vdr[vp] = xr;
                        if (++vp >= dlen) vp = 0;
                        l[off + i] = (float) (direct * xl + cross * dry2);
                        r[off + i] = (float) (direct * xr + cross * dly);
                    }
                } else if (vdl[0] != 0f || vdl[vdl.length / 2] != 0f) {
                    java.util.Arrays.fill(vdl, 0f);
                    java.util.Arrays.fill(vdr, 0f);
                }
                // громкость
                double v0 = sVol;
                sVol += (tVol - sVol) * aVol;
                if (v0 != 1.0 || sVol != 1.0) {
                    for (int i = 0; i < m; i++) {
                        double g = v0 + (sVol - v0) * (i + 1) / m;
                        l[off + i] *= (float) g;
                        r[off + i] *= (float) g;
                    }
                }
                // баланс (StereoPanner, равная мощность)
                sPan += (tPan - sPan) * aPan;
                if (Math.abs(tPan - sPan) < 1e-4) sPan = tPan;
                if (sPan != 0.0) {
                    double x = sPan <= 0 ? sPan + 1.0 : sPan;
                    double gl = Math.cos(x * Math.PI / 2), gr = Math.sin(x * Math.PI / 2);
                    for (int i = 0; i < m; i++) {
                        float xl = l[off + i], xr = r[off + i];
                        if (sPan <= 0) {
                            l[off + i] = (float) (xl + xr * gl);
                            r[off + i] = (float) (xr * gr);
                        } else {
                            l[off + i] = (float) (xl * gl);
                            r[off + i] = (float) (xr + xl * gr);
                        }
                    }
                }
                // реверб + сухой сигнал
                double w0 = sWet, d0 = sDry;
                sWet += (tWet - sWet) * aWet;
                sDry += (tDry - sDry) * aWet;
                if (Math.abs(tWet - sWet) < 1e-5 && tWet == 0) sWet = 0;
                if (Math.abs(tDry - sDry) < 1e-5) sDry = tDry;
                boolean wetOn = tWet > 0 || sWet > 0;
                if (wetOn) {
                    reverbRunning = true;
                    reverb.process(l, r, wl, wr, off, m);
                    for (int i = 0; i < m; i++) {
                        double f = (i + 1.0) / m;
                        double gw = w0 + (sWet - w0) * f, gd = d0 + (sDry - d0) * f;
                        l[off + i] = (float) (l[off + i] * gd + wl[off + i] * gw);
                        r[off + i] = (float) (r[off + i] * gd + wr[off + i] * gw);
                    }
                } else {
                    if (reverbRunning) {
                        reverb.clear();
                        reverbRunning = false;
                    }
                    if (d0 != 1.0 || sDry != 1.0) {
                        for (int i = 0; i < m; i++) {
                            double gd = d0 + (sDry - d0) * (i + 1) / m;
                            l[off + i] *= (float) gd;
                            r[off + i] *= (float) gd;
                        }
                    }
                }
            }
            limiter.process(l, r, 0, n);
        }

        void reset() {
            limiter.reset();
            reverb.clear();
            reverbRunning = false;
            java.util.Arrays.fill(vdl, 0f);
            java.util.Arrays.fill(vdr, 0f);
        }
    }
}

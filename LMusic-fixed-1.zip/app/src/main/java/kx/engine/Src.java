package kx.engine;

import android.content.Context;
import android.media.MediaExtractor;
import android.net.Uri;

import java.io.File;
import java.io.IOException;

/** Источник медиа: файл в кэше приложения (после ingest) или content:// URI из системного выбора файла (без копирования). */
final class Src {
    final File file;
    final Uri uri;

    Src(File f) {
        file = f;
        uri = null;
    }

    Src(Uri u) {
        file = null;
        uri = u;
    }

    void open(MediaExtractor ex, Context c) throws IOException {
        if (uri != null) ex.setDataSource(c, uri, null);
        else ex.setDataSource(file.getPath());
    }
}

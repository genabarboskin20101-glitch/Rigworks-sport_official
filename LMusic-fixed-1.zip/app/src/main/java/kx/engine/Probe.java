package kx.engine;

import android.content.Context;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Build;
import android.util.Range;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

/** caps() и probe(): возможности кодеков устройства и сведения об исходном файле. */
final class Probe {
    private Probe() { }

    static boolean isHw(MediaCodecInfo ci) {
        if (Build.VERSION.SDK_INT >= 29) return ci.isHardwareAccelerated();
        String n = ci.getName();
        return !(n.startsWith("OMX.google.") || n.startsWith("c2.android.") || n.startsWith("c2.google."));
    }

    static JSONObject caps() throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 1);
        o.put("build", "p0.28-naudio");
        o.put("api", Build.VERSION.SDK_INT);
        o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
        o.put("hardware", Build.HARDWARE);
        JSONArray feats = new JSONArray();
        feats.put("gl");
        feats.put("probe");
        feats.put("ingest-chunk");
        feats.put("audio-copy");
        feats.put("overlay-image");
        feats.put("overlay-fade");
        feats.put("overlay-tail");
        feats.put("overlay-raw");
        feats.put("ingest-has");
        feats.put("timing-v2");
        feats.put("transition-dip");
        feats.put("color-fx");
        feats.put("anim-v1");
        feats.put("anim-color");
        feats.put("anim-shape");
        feats.put("fs-all");
        feats.put("share-file");
        feats.put("audio-library");
        feats.put("edge-insets");
        feats.put("media-notif");
        feats.put("media-service");
        feats.put("haptics");
        feats.put("media-actions");
        feats.put("native-audio");
        if (Build.VERSION.SDK_INT >= 29) {
            feats.put("export");
            feats.put("mediastore");
        }
        JSONArray enc = new JSONArray();
        JSONArray dec = new JSONArray();
        boolean hevc = false;
        MediaCodecInfo[] infos = new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos();
        for (MediaCodecInfo ci : infos) {
            for (String t : ci.getSupportedTypes()) {
                boolean avc = t.equalsIgnoreCase("video/avc");
                boolean hv = t.equalsIgnoreCase("video/hevc");
                if (!avc && !hv) continue;
                if (hv && ci.isEncoder()) hevc = true;
                JSONObject c = new JSONObject();
                c.put("name", ci.getName());
                c.put("mime", t);
                c.put("hw", isHw(ci));
                try {
                    MediaCodecInfo.CodecCapabilities cc = ci.getCapabilitiesForType(t);
                    MediaCodecInfo.VideoCapabilities vc = cc.getVideoCapabilities();
                    if (vc != null) {
                        c.put("maxW", vc.getSupportedWidths().getUpper().intValue());
                        c.put("maxH", vc.getSupportedHeights().getUpper().intValue());
                        c.put("bitrateMax", vc.getBitrateRange().getUpper().intValue());
                        c.put("wAlign", vc.getWidthAlignment());
                        c.put("hAlign", vc.getHeightAlignment());
                        try {
                            Range<Double> r = vc.getSupportedFrameRatesFor(1920, 1080);
                            c.put("fps1080", r.getUpper().intValue());
                        } catch (Throwable ignored) {
                            // 1080p не поддерживается этим кодеком
                        }
                    }
                    c.put("inst", cc.getMaxSupportedInstances());
                    if (avc && ci.isEncoder()) {
                        boolean high = false;
                        for (MediaCodecInfo.CodecProfileLevel pl : cc.profileLevels) {
                            if (pl.profile == MediaCodecInfo.CodecProfileLevel.AVCProfileHigh) high = true;
                        }
                        c.put("high", high);
                    }
                } catch (Throwable ignored) {
                    // сведения о возможностях необязательны
                }
                if (ci.isEncoder()) enc.put(c); else dec.put(c);
            }
        }
        if (hevc) feats.put("hevc");
        o.put("features", feats);
        o.put("encoders", enc);
        o.put("decoders", dec);
        return o;
    }

    private static double num(MediaFormat f, String key) {
        try {
            return f.getInteger(key);
        } catch (Throwable t) {
            try {
                return f.getFloat(key);
            } catch (Throwable t2) {
                return 0;
            }
        }
    }

    static JSONObject info(Context ctx, Src src) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        try {
            src.open(ex, ctx);
            int vi = -1;
            int ai = -1;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (m == null) continue;
                if (vi < 0 && m.startsWith("video/")) vi = i;
                else if (ai < 0 && m.startsWith("audio/")) ai = i;
            }
            JSONObject o = new JSONObject();
            long dur = 0;
            if (vi >= 0) {
                MediaFormat f = ex.getTrackFormat(vi);
                o.put("vcodec", f.getString(MediaFormat.KEY_MIME));
                o.put("w", f.getInteger(MediaFormat.KEY_WIDTH));
                o.put("h", f.getInteger(MediaFormat.KEY_HEIGHT));
                o.put("rotation", f.containsKey(MediaFormat.KEY_ROTATION) ? f.getInteger(MediaFormat.KEY_ROTATION) : 0);
                if (f.containsKey(MediaFormat.KEY_DURATION)) dur = f.getLong(MediaFormat.KEY_DURATION);
                o.put("fpsMeta", num(f, MediaFormat.KEY_FRAME_RATE));
                o.put("bitrateMeta", num(f, MediaFormat.KEY_BIT_RATE));
                o.put("profile", num(f, MediaFormat.KEY_PROFILE));
                o.put("level", num(f, MediaFormat.KEY_LEVEL));
                o.put("colorStd", num(f, MediaFormat.KEY_COLOR_STANDARD));
                o.put("colorTransfer", num(f, MediaFormat.KEY_COLOR_TRANSFER));
                o.put("colorRange", num(f, MediaFormat.KEY_COLOR_RANGE));
                // реальный fps и признак VFR - по меткам времени первых кадров (только демукс, без декодирования)
                ex.selectTrack(vi);
                ArrayList<Long> ts = new ArrayList<Long>();
                for (int i = 0; i < 300; i++) {
                    long t = ex.getSampleTime();
                    if (t < 0) break;
                    ts.add(t);
                    if (!ex.advance()) break;
                }
                Collections.sort(ts);
                if (ts.size() > 2) {
                    ArrayList<Long> d = new ArrayList<Long>();
                    for (int i = 1; i < ts.size(); i++) d.add(ts.get(i) - ts.get(i - 1));
                    Collections.sort(d);
                    long med = d.get(d.size() / 2);
                    long max = d.get(d.size() - 1);
                    if (med > 0) o.put("fps", Math.round(1e8 / med) / 100.0);
                    o.put("vfr", med > 0 && max > med * 1.6);
                }
                ex.unselectTrack(vi);
            }
            o.put("hasAudio", ai >= 0);
            if (ai >= 0) {
                MediaFormat f = ex.getTrackFormat(ai);
                o.put("acodec", f.getString(MediaFormat.KEY_MIME));
                o.put("sampleRate", f.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 0);
                o.put("channels", f.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 0);
                if (dur == 0 && f.containsKey(MediaFormat.KEY_DURATION)) dur = f.getLong(MediaFormat.KEY_DURATION);
            }
            o.put("durationUs", dur);
            return o;
        } finally {
            ex.release();
        }
    }
}

package kx.engine;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.util.Log;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Поиск устройств Google Cast (Chromecast, Google TV, телевизоры и колонки со встроенным Cast) по mDNS: _googlecast._tcp. */
final class GcDiscovery {
    private static final String TAG = "KX";

    interface Out {
        void found(String id, String name, String model, String host, int port, String kind);

        void lost(String id);
    }

    private final NsdManager nsd;
    private final Out out;
    private NsdManager.DiscoveryListener dl;
    private final ArrayDeque<NsdServiceInfo> queue = new ArrayDeque<NsdServiceInfo>();
    private final Map<String, String> idByService = new HashMap<String, String>();
    private boolean resolving;
    private volatile boolean running;

    GcDiscovery(Context c, Out o) {
        nsd = (NsdManager) c.getApplicationContext().getSystemService(Context.NSD_SERVICE);
        out = o;
    }

    synchronized void start() {
        if (running || nsd == null) return;
        running = true;
        dl = new NsdManager.DiscoveryListener() {
            @Override
            public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                Log.w(TAG, "nsd start failed " + errorCode);
                running = false;
            }

            @Override
            public void onStopDiscoveryFailed(String serviceType, int errorCode) {
                running = false;
            }

            @Override
            public void onDiscoveryStarted(String serviceType) {
            }

            @Override
            public void onDiscoveryStopped(String serviceType) {
            }

            @Override
            public void onServiceFound(NsdServiceInfo info) {
                synchronized (GcDiscovery.this) {
                    queue.add(info);
                }
                resolveNext();
            }

            @Override
            public void onServiceLost(NsdServiceInfo info) {
                String id;
                synchronized (GcDiscovery.this) {
                    id = idByService.remove(info.getServiceName());
                }
                if (id != null) out.lost(id);
            }
        };
        try {
            nsd.discoverServices("_googlecast._tcp", NsdManager.PROTOCOL_DNS_SD, dl);
        } catch (Throwable t) {
            Log.w(TAG, "nsd discover failed: " + t);
            running = false;
        }
    }

    synchronized void stop() {
        if (!running || nsd == null) return;
        running = false;
        try {
            nsd.stopServiceDiscovery(dl);
        } catch (Throwable ignored) {
            // уже остановлен
        }
        queue.clear();
    }

    private void resolveNext() {
        final NsdServiceInfo next;
        synchronized (this) {
            if (resolving || queue.isEmpty() || !running) return;
            next = queue.poll();
            resolving = true;
        }
        try {
            nsd.resolveService(next, new NsdManager.ResolveListener() {
                @Override
                public void onResolveFailed(NsdServiceInfo info, int errorCode) {
                    synchronized (GcDiscovery.this) {
                        resolving = false;
                    }
                    resolveNext();
                }

                @Override
                public void onServiceResolved(NsdServiceInfo info) {
                    synchronized (GcDiscovery.this) {
                        resolving = false;
                    }
                    try {
                        publish(info);
                    } catch (Throwable t) {
                        Log.w(TAG, "nsd publish: " + t);
                    }
                    resolveNext();
                }
            });
        } catch (Throwable t) {
            synchronized (this) {
                resolving = false;
            }
        }
    }

    private static String attr(Map<String, byte[]> a, String k) {
        try {
            byte[] v = a == null ? null : a.get(k);
            return v == null ? "" : new String(v, "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }

    private void publish(NsdServiceInfo info) {
        InetAddress h = info.getHost();
        if (!(h instanceof Inet4Address)) return; // по IPv6 link-local подключаться неудобно
        Map<String, byte[]> a = info.getAttributes();
        String id = attr(a, "id");
        if (id.length() == 0) id = info.getServiceName();
        String name = attr(a, "fn");
        if (name.length() == 0) name = info.getServiceName();
        String model = attr(a, "md");
        int caps = 0;
        try {
            caps = Integer.parseInt(attr(a, "ca").trim());
        } catch (NumberFormatException ignored) {
            // возможности неизвестны
        }
        String ml = model.toLowerCase(Locale.ROOT);
        boolean video = (caps & 1) != 0 || ml.contains("tv") || ml.contains("chromecast") && !ml.contains("audio");
        synchronized (this) {
            idByService.put(info.getServiceName(), id);
        }
        out.found(id, name, model, h.getHostAddress(), info.getPort(), video ? "tv" : "speaker");
    }
}

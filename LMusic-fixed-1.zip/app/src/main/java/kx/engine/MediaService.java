package kx.engine;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

/**
 * Foreground-сервис воспроизведения (тип mediaPlayback). Пока он работает, система считает приложение
 * «играющим плеером» и не убивает ни процесс приложения, ни процесс отрисовки WebView, когда приложение свёрнуто.
 * Без него уведомление с кнопками жило только до тех пор, пока система не выгружала процесс в фоне:
 * после этого страница переставала отвечать, и управление из шторки/с экрана блокировки пропадало.
 * Сервис объявляется в манифесте билдером (kx.engine.MediaService, foregroundServiceType=mediaPlayback).
 * Само уведомление собирает MediaNotif; здесь оно только «прикрепляется» к сервису.
 */
public class MediaService extends Service {
    private static final String TAG = "KX";
    private static final int TYPE_MEDIA_PLAYBACK = 2; // ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
    private static final long PAUSE_GRACE_MS = 60L * 60L * 1000L; // на паузе держим сервис не дольше часа
    private static volatile MediaService inst;
    private static volatile Notification pending;
    private static volatile boolean pendingPlaying;

    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private boolean fg;
    private final Runnable giveUp = new Runnable() {
        @Override
        public void run() {
            // долго на паузе: отпускаем сервис, уведомление остаётся (его можно смахнуть)
            try {
                releaseWake();
                fg = false;
                stopForeground(2); // STOP_FOREGROUND_DETACH
            } catch (Throwable t) {
                Log.w(TAG, "giveUp failed", t);
            }
            stopSelf();
        }
    };

    public MediaService() { }

    /** Показывает/обновляет уведомление в сервисе (поток UI). false — сервис запустить не удалось, показывать нужно обычным notify. */
    static boolean show(Context app, Notification n, boolean playing) {
        pending = n;
        pendingPlaying = playing;
        MediaService s = inst;
        if (s != null) {
            s.apply();
            return true;
        }
        try {
            Intent i = new Intent(app, MediaService.class);
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i);
            else app.startService(i);
            return true;
        } catch (Throwable t) {
            // например, запуск из фона на Android 12+: тогда останется обычное уведомление
            Log.w(TAG, "media service start failed", t);
            return false;
        }
    }

    /** Останавливает сервис и убирает его уведомление. */
    static void stop(Context app) {
        pending = null;
        MediaService s = inst;
        if (s != null) {
            s.finish();
            return;
        }
        try {
            app.stopService(new Intent(app, MediaService.class));
        } catch (Throwable ignored) {
            // сервис не запущен
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = pending;
        if (n == null) n = placeholder();
        startFg(n);
        if (pending == null) {
            finish();
            return START_NOT_STICKY;
        }
        apply();
        return START_NOT_STICKY;
    }

    private void startFg(Notification n) {
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(MediaNotif.ID, n, TYPE_MEDIA_PLAYBACK);
            else startForeground(MediaNotif.ID, n);
            fg = true;
        } catch (Throwable t) {
            // в манифесте нет сервиса/типа/разрешения: не падаем, показываем обычное уведомление
            Log.w(TAG, "startForeground failed", t);
            fg = false;
            try {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && pending != null) nm.notify(MediaNotif.ID, pending);
            } catch (Throwable ignored) {
                // нечего показывать
            }
            stopSelf();
        }
    }

    private void apply() {
        Notification n = pending;
        if (n == null) return;
        try {
            if (!fg) {
                startFg(n);
            } else {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.notify(MediaNotif.ID, n);
            }
            wake(pendingPlaying);
            h.removeCallbacks(giveUp);
            if (!pendingPlaying) h.postDelayed(giveUp, PAUSE_GRACE_MS);
        } catch (Throwable t) {
            Log.w(TAG, "media service apply failed", t);
        }
    }

    private void wake(boolean on) {
        try {
            if (on) {
                if (wl == null) {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    if (pm == null) return;
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kx:media");
                    wl.setReferenceCounted(false);
                }
                if (!wl.isHeld()) wl.acquire(4L * 60L * 60L * 1000L);
            } else {
                releaseWake();
            }
        } catch (Throwable t) {
            // нет разрешения WAKE_LOCK — музыка играет и без него
            Log.w(TAG, "wake lock failed", t);
        }
    }

    private void releaseWake() {
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
            // уже отпущен
        }
    }

    private Notification placeholder() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, MediaNotif.CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Воспроизведение").setOngoing(true).build();
    }

    private void finish() {
        h.removeCallbacksAndMessages(null);
        releaseWake();
        try {
            stopForeground(true);
        } catch (Throwable ignored) {
            // не был в foreground
        }
        fg = false;
        stopSelf();
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        releaseWake();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

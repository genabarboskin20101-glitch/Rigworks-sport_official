package kx.engine;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Клиент Google Cast (CASTV2) для Chromecast, Google TV и телевизоров/колонок со встроенным Cast. Без библиотек Google:
 * TLS-сокет на порт 8009, сообщения CastMessage (protobuf) и JSON. Запускает «Default Media Receiver» (CC1AD845),
 * грузит ссылку на трек (её отдаёт MediaHttp) и управляет воспроизведением. Устройства Cast используют самоподписанные
 * сертификаты, поэтому проверка сертификата отключена — соединение только с адресом, найденным в локальной сети.
 */
final class GCast {
    private static final String TAG = "KX";
    private static final String APP_ID = "CC1AD845";
    private static final String NS_CONN = "urn:x-cast:com.google.cast.tp.connection";
    private static final String NS_HB = "urn:x-cast:com.google.cast.tp.heartbeat";
    private static final String NS_RECV = "urn:x-cast:com.google.cast.receiver";
    private static final String NS_MEDIA = "urn:x-cast:com.google.cast.media";
    private static final String SENDER = "sender-0";

    private final String host;
    private final int port;
    private SSLSocket sock;
    private DataInputStream in;
    private OutputStream out;
    private volatile boolean open;
    private final AtomicInteger reqId = new AtomicInteger(1);

    // состояние, обновляется читающим потоком
    private volatile String transportId = "", sessionId = "";
    private volatile int mediaSessionId = -1;
    private volatile String playerState = "";
    private volatile String idleReason = "";
    private volatile double currentTime = -1;
    private volatile long timeAt;
    private volatile int volume = -1;
    private volatile boolean loadFailed;
    private volatile long lastRx;

    GCast(String h, int p) {
        host = h;
        port = p <= 0 ? 8009 : p;
    }

    // ------------------------------------------------------------------------------------------ protobuf CastMessage
    private static void varint(ByteArrayOutputStream b, long v) {
        while ((v & ~0x7FL) != 0) {
            b.write((int) ((v & 0x7F) | 0x80));
            v >>>= 7;
        }
        b.write((int) v);
    }

    private static void str(ByteArrayOutputStream b, int field, String s) throws IOException {
        byte[] d = s.getBytes("UTF-8");
        b.write((field << 3) | 2);
        varint(b, d.length);
        b.write(d);
    }

    static byte[] encode(String src, String dst, String ns, String payload) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        b.write(0x08);
        b.write(0x00); // protocol_version = CASTV2_1_0
        str(b, 2, src);
        str(b, 3, dst);
        str(b, 4, ns);
        b.write(0x28);
        b.write(0x00); // payload_type = STRING
        str(b, 6, payload);
        return b.toByteArray();
    }

    /** Возвращает {source, destination, namespace, payload}. */
    static String[] decode(byte[] m) throws IOException {
        String[] r = { "", "", "", "" };
        int i = 0;
        while (i < m.length) {
            long tag = 0;
            int shift = 0;
            while (true) {
                int c = m[i++] & 0xff;
                tag |= (long) (c & 0x7F) << shift;
                if ((c & 0x80) == 0) break;
                shift += 7;
            }
            int field = (int) (tag >>> 3), wire = (int) (tag & 7);
            if (wire == 0) {
                while ((m[i++] & 0x80) != 0) { /* пропускаем varint */ }
            } else if (wire == 2) {
                long len = 0;
                shift = 0;
                while (true) {
                    int c = m[i++] & 0xff;
                    len |= (long) (c & 0x7F) << shift;
                    if ((c & 0x80) == 0) break;
                    shift += 7;
                }
                String v = new String(m, i, (int) len, "UTF-8");
                i += (int) len;
                if (field == 2) r[0] = v;
                else if (field == 3) r[1] = v;
                else if (field == 4) r[2] = v;
                else if (field == 6) r[3] = v;
            } else if (wire == 5) {
                i += 4;
            } else if (wire == 1) {
                i += 8;
            } else {
                throw new IOException("bad wire type " + wire);
            }
        }
        return r;
    }

    private synchronized void send(String dst, String ns, String json) throws IOException {
        byte[] m = encode(SENDER, dst, ns, json);
        byte[] hdr = { (byte) (m.length >>> 24), (byte) (m.length >>> 16), (byte) (m.length >>> 8), (byte) m.length };
        out.write(hdr);
        out.write(m);
        out.flush();
    }

    // ------------------------------------------------------------------------------------------ подключение
    boolean connect() {
        try {
            TrustManager[] all = { new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) { }

                public void checkServerTrusted(X509Certificate[] c, String a) { }

                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            } };
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, all, new SecureRandom());
            java.net.Socket raw = new java.net.Socket();
            raw.connect(new InetSocketAddress(host, port), 4000);
            sock = (SSLSocket) ctx.getSocketFactory().createSocket(raw, host, port, true);
            sock.setSoTimeout(0);
            sock.startHandshake();
            in = new DataInputStream(sock.getInputStream());
            out = sock.getOutputStream();
            open = true;
            lastRx = System.currentTimeMillis();
            Thread rd = new Thread(new Runnable() {
                public void run() {
                    readLoop();
                }
            }, "kx-gcast-rx");
            rd.setDaemon(true);
            rd.start();
            send("receiver-0", NS_CONN, "{\"type\":\"CONNECT\"}");
            Thread hb = new Thread(new Runnable() {
                public void run() {
                    while (open) {
                        try {
                            Thread.sleep(5000);
                            send("receiver-0", NS_HB, "{\"type\":\"PING\"}");
                        } catch (Throwable t) {
                            close();
                        }
                    }
                }
            }, "kx-gcast-hb");
            hb.setDaemon(true);
            hb.start();
            send("receiver-0", NS_RECV, "{\"type\":\"GET_STATUS\",\"requestId\":" + reqId.getAndIncrement() + "}");
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "gcast connect failed: " + t);
            close();
            return false;
        }
    }

    boolean isOpen() {
        return open;
    }

    void close() {
        open = false;
        try {
            if (sock != null) sock.close();
        } catch (Throwable ignored) {
            // уже закрыт
        }
    }

    private static final Pattern P_TRANSPORT = Pattern.compile("\"transportId\"\\s*:\\s*\"([^\"]+)\"");
    private static final Pattern P_SESSION = Pattern.compile("\"sessionId\"\\s*:\\s*\"([^\"]+)\"");
    private static final Pattern P_MSID = Pattern.compile("\"mediaSessionId\"\\s*:\\s*(\\d+)");
    private static final Pattern P_STATE = Pattern.compile("\"playerState\"\\s*:\\s*\"(\\w+)\"");
    private static final Pattern P_IDLE = Pattern.compile("\"idleReason\"\\s*:\\s*\"(\\w+)\"");
    private static final Pattern P_TIME = Pattern.compile("\"currentTime\"\\s*:\\s*([0-9.eE+-]+)");
    private static final Pattern P_VOL = Pattern.compile("\"volume\"\\s*:\\s*\\{[^}]*?\"level\"\\s*:\\s*([0-9.eE+-]+)");

    private static String grab(Pattern p, String s) {
        Matcher m = p.matcher(s);
        return m.find() ? m.group(1) : null;
    }

    private void readLoop() {
        try {
            while (open) {
                int len = in.readInt();
                if (len <= 0 || len > 4 * 1024 * 1024) throw new IOException("bad frame " + len);
                byte[] m = new byte[len];
                in.readFully(m);
                lastRx = System.currentTimeMillis();
                String[] msg = decode(m);
                handle(msg[0], msg[2], msg[3]);
            }
        } catch (Throwable t) {
            if (open) Log.w(TAG, "gcast rx ended: " + t);
        } finally {
            close();
        }
    }

    private void handle(String src, String ns, String payload) {
        try {
            if (NS_HB.equals(ns)) {
                if (payload.contains("\"PING\"")) send(src, NS_HB, "{\"type\":\"PONG\"}");
            } else if (NS_RECV.equals(ns)) {
                if (payload.contains("RECEIVER_STATUS")) {
                    String v = grab(P_VOL, payload);
                    if (v != null) volume = (int) Math.round(Double.parseDouble(v) * 100);
                    int apps = payload.indexOf("\"applications\"");
                    if (apps >= 0) {
                        String tail = payload.substring(apps);
                        if (tail.contains(APP_ID)) {
                            String tid = grab(P_TRANSPORT, tail), sid = grab(P_SESSION, tail);
                            if (tid != null && !tid.equals(transportId)) {
                                transportId = tid;
                                sessionId = sid == null ? "" : sid;
                                send(tid, NS_CONN, "{\"type\":\"CONNECT\"}");
                            }
                        }
                    } else {
                        transportId = "";
                    }
                }
            } else if (NS_MEDIA.equals(ns)) {
                if (payload.contains("MEDIA_STATUS")) {
                    String st = grab(P_STATE, payload);
                    if (st != null) {
                        playerState = st;
                        String id = grab(P_MSID, payload);
                        if (id != null) mediaSessionId = Integer.parseInt(id);
                        String t = grab(P_TIME, payload);
                        if (t != null) {
                            currentTime = Double.parseDouble(t);
                            timeAt = System.currentTimeMillis();
                        }
                        String ir = grab(P_IDLE, payload);
                        idleReason = ir == null ? "" : ir;
                    }
                } else if (payload.contains("LOAD_FAILED") || payload.contains("INVALID_REQUEST") || payload.contains("LOAD_CANCELLED")) {
                    loadFailed = true;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "gcast handle: " + t);
        }
    }

    // ------------------------------------------------------------------------------------------ команды
    private static String q(String s) {
        return Cast.q(s);
    }

    /** Запускает приёмник и ждёт его готовности (transportId). */
    private boolean ensureApp() {
        if (transportId.length() > 0) return true;
        try {
            send("receiver-0", NS_RECV, "{\"type\":\"LAUNCH\",\"appId\":\"" + APP_ID + "\",\"requestId\":" + reqId.getAndIncrement() + "}");
        } catch (IOException e) {
            return false;
        }
        for (int i = 0; i < 60 && open; i++) {
            if (transportId.length() > 0) return true;
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                return false;
            }
        }
        return transportId.length() > 0;
    }

    /** Загружает трек. Возвращает true, когда приёмник начал буферизацию/воспроизведение. */
    boolean load(String url, String mime, String title, String artist, String album, String artUrl, double dur, double start,
                 boolean autoplay) {
        try {
            if (!open || !ensureApp()) return false;
            loadFailed = false;
            playerState = "";
            mediaSessionId = -1;
            StringBuilder md = new StringBuilder("{\"metadataType\":3,\"title\":").append(q(title));
            if (artist != null && artist.length() > 0) md.append(",\"artist\":").append(q(artist));
            if (album != null && album.length() > 0) md.append(",\"albumName\":").append(q(album));
            if (artUrl != null && artUrl.length() > 0) md.append(",\"images\":[{\"url\":").append(q(artUrl)).append("}]");
            md.append('}');
            StringBuilder j = new StringBuilder("{\"type\":\"LOAD\",\"requestId\":").append(reqId.getAndIncrement());
            j.append(",\"sessionId\":").append(q(sessionId)).append(",\"autoplay\":").append(autoplay);
            j.append(",\"currentTime\":").append(String.format(Locale.US, "%.2f", Math.max(0, start)));
            j.append(",\"media\":{\"contentId\":").append(q(url)).append(",\"streamType\":\"BUFFERED\",\"contentType\":").append(q(mime));
            if (dur > 0) j.append(",\"duration\":").append(String.format(Locale.US, "%.2f", dur));
            j.append(",\"metadata\":").append(md).append("}}");
            send(transportId, NS_MEDIA, j.toString());
            for (int i = 0; i < 80 && open && !loadFailed; i++) {
                String st = playerState;
                if ("PLAYING".equals(st) || "PAUSED".equals(st) || "BUFFERING".equals(st)) return true;
                try {
                    Thread.sleep(150);
                } catch (InterruptedException e) {
                    return false;
                }
            }
            return false;
        } catch (Throwable t) {
            Log.w(TAG, "gcast load: " + t);
            return false;
        }
    }

    private boolean mediaCmd(String type, String extra) {
        try {
            if (!open || mediaSessionId < 0 || transportId.length() == 0) return false;
            send(transportId, NS_MEDIA, "{\"type\":\"" + type + "\",\"mediaSessionId\":" + mediaSessionId + ",\"requestId\":"
                    + reqId.getAndIncrement() + extra + "}");
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    boolean play() {
        return mediaCmd("PLAY", "");
    }

    boolean pause() {
        return mediaCmd("PAUSE", "");
    }

    boolean seek(double sec) {
        return mediaCmd("SEEK", ",\"currentTime\":" + String.format(Locale.US, "%.2f", Math.max(0, sec)));
    }

    boolean stop() {
        boolean ok = mediaCmd("STOP", "");
        try {
            if (open) send("receiver-0", NS_RECV, "{\"type\":\"STOP\",\"sessionId\":" + q(sessionId) + ",\"requestId\":" + reqId.getAndIncrement() + "}");
        } catch (Throwable ignored) {
            // соединение уже закрыто
        }
        transportId = "";
        mediaSessionId = -1;
        playerState = "";
        return ok;
    }

    boolean setVolume(int v) {
        try {
            if (!open) return false;
            send("receiver-0", NS_RECV, "{\"type\":\"SET_VOLUME\",\"volume\":{\"level\":" + String.format(Locale.US, "%.2f", Math.max(0, Math.min(100, v)) / 100.0)
                    + "},\"requestId\":" + reqId.getAndIncrement() + "}");
            volume = v;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    int volume() {
        return volume;
    }

    /** Состояние в терминах UPnP: PLAYING / PAUSED_PLAYBACK / TRANSITIONING / STOPPED / NO_MEDIA_PRESENT; null — связь потеряна. */
    String state() {
        if (!open || System.currentTimeMillis() - lastRx > 20000) return null;
        String s = playerState;
        if ("PLAYING".equals(s)) return "PLAYING";
        if ("PAUSED".equals(s)) return "PAUSED_PLAYBACK";
        if ("BUFFERING".equals(s)) return "TRANSITIONING";
        if ("IDLE".equals(s)) return "STOPPED";
        return "NO_MEDIA_PRESENT";
    }

    /** Позиция приёмника в секундах (с поправкой на время с последнего статуса, если идёт воспроизведение). */
    double position() {
        if (currentTime < 0) return -1;
        double t = currentTime;
        if ("PLAYING".equals(playerState)) t += (System.currentTimeMillis() - timeAt) / 1000.0;
        return t;
    }

    /** Просит приёмник прислать свежий статус (для опроса). */
    void refresh() {
        try {
            if (open && transportId.length() > 0) {
                send(transportId, NS_MEDIA, "{\"type\":\"GET_STATUS\",\"requestId\":" + reqId.getAndIncrement() + "}");
            }
        } catch (Throwable ignored) {
            // связь потеряна — state() вернёт null
        }
    }
}

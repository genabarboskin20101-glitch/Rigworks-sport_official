package kx.engine;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.util.Base64;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Трансляция звука на устройства поблизости по DLNA/UPnP (MediaRenderer) и Google Cast (Chromecast, Google TV, телевизоры со встроенным Cast): телевизоры Samsung, LG, Sony, Philips, Xiaomi,
 * Hisense, TCL и др., сетевые колонки и ресиверы. Поиск — SSDP (мультикаст по Wi-Fi), управление — SOAP AVTransport и
 * RenderingControl, файл отдаёт MediaHttp. Локальный движок при трансляции продолжает считать позицию, но молчит (Sink.mute):
 * очередь, перемотка, таймер сна и кнопки плеера работают как обычно. Состояние уходит странице вызовом window.__kxCast({...}).
 */
final class Cast {
    private static final String TAG = "KX";
    private static final String INST = "<InstanceID>0</InstanceID>";
    private static final String SSDP_ADDR = "239.255.255.250";
    private static final int SSDP_PORT = 1900;

    interface Sink {
        /** Выполнить JS в странице (из любого потока). */
        void js(String code);

        /** Заглушить/вернуть звук локального движка. */
        void mute(boolean m);

        /** Файл кэша нативного движка по ключу трека (kxa/ключ.bin) или null. */
        File fileFor(String key);
    }

    static final class Dev {
        String id = "";
        String name = "";
        String model = "";
        String manuf = "";
        String kind = "speaker";
        String host = "";
        String location = "";
        String avUrl;
        String avType;
        String rcUrl;
        String rcType;
        String proto = "dlna"; // dlna | gcast
        int port;
        GCast gc;
        volatile long lastSeen;
    }

    private final Context ctx;
    private final Sink sink;
    private final MediaHttp http = new MediaHttp();
    private final LinkedHashMap<String, Dev> devs = new LinkedHashMap<String, Dev>();
    private final HashMap<String, Long> fetched = new HashMap<String, Long>();
    private final ExecutorService ctl = Executors.newSingleThreadExecutor(new Named("kx-cast-ctl"));
    private final ExecutorService net = Executors.newCachedThreadPool(new Named("kx-cast-net"));
    private final AtomicInteger loadGen = new AtomicInteger();

    private volatile Dev sel;
    private volatile String st = "idle";
    private volatile String err = "";
    private volatile int vol = -1;
    private volatile boolean scanning;
    private volatile boolean loaded;
    private volatile boolean wantPlaying;
    private volatile long cmdAt, loadAt, lastSeekAt, localPosAt;
    private volatile double pendingSeek = -1, durSec, localPos = -1;
    private int mismatch, failPolls;
    private Thread scanThread;
    private WifiManager.MulticastLock mlock;
    private ScheduledExecutorService poller;
    private GcDiscovery gcd;

    private static final class Named implements ThreadFactory {
        private final String name;

        Named(String n) {
            name = n;
        }

        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, name);
            t.setDaemon(true);
            return t;
        }
    }

    Cast(Context c, Sink s) {
        ctx = c.getApplicationContext();
        sink = s;
    }

    // ------------------------------------------------------------------------------------------ состояние для страницы
    static String q(String s) {
        if (s == null) s = "";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\u2028': sb.append("\\u2028"); break;
                case '\u2029': sb.append("\\u2029"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    String stateJson() {
        StringBuilder sb = new StringBuilder("{\"e\":\"devs\"");
        Dev s = sel;
        sb.append(",\"sel\":").append(q(s == null ? "" : s.id));
        sb.append(",\"st\":").append(q(st));
        sb.append(",\"err\":").append(q(err));
        sb.append(",\"vol\":").append(vol);
        sb.append(",\"scan\":").append(scanning);
        sb.append(",\"devs\":[");
        synchronized (devs) {
            boolean first = true;
            for (Dev d : devs.values()) {
                if (!first) sb.append(',');
                first = false;
                sb.append("{\"id\":").append(q(d.id)).append(",\"name\":").append(q(d.name))
                        .append(",\"kind\":").append(q(d.kind)).append(",\"model\":").append(q(d.model))
                        .append(",\"proto\":").append(q(d.proto)).append('}');
            }
        }
        return sb.append("]}").toString();
    }

    private void emit() {
        try {
            sink.js("window.__kxCast&&window.__kxCast(" + stateJson() + ")");
        } catch (Throwable t) {
            Log.w(TAG, "cast emit failed", t);
        }
    }

    private void setState(String s, String e) {
        st = s;
        err = e == null ? "" : e;
        emit();
    }

    // ------------------------------------------------------------------------------------------ поиск устройств
    void scanStart() {
        synchronized (this) {
            if (scanning) {
                emit();
                return;
            }
            scanning = true;
        }
        acquireMulticast();
        try {
            if (gcd == null) {
                gcd = new GcDiscovery(ctx, new GcDiscovery.Out() {
                    public void found(String id, String name, String model, String host, int port, String kind) {
                        addGc(id, name, model, host, port, kind);
                    }

                    public void lost(String id) {
                        removeGc(id);
                    }
                });
            }
            gcd.start();
        } catch (Throwable t) {
            Log.w(TAG, "google cast discovery unavailable: " + t);
        }
        scanThread = new Thread(new Runnable() {
            public void run() {
                scanLoop();
            }
        }, "kx-ssdp");
        scanThread.setDaemon(true);
        scanThread.start();
        emit();
    }

    void scanStop() {
        scanning = false;
        if (gcd != null) gcd.stop();
        releaseMulticast();
        emit();
    }

    private void acquireMulticast() {
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return;
            if (mlock == null) {
                mlock = wm.createMulticastLock("kx-cast");
                mlock.setReferenceCounted(false);
            }
            if (!mlock.isHeld()) mlock.acquire();
        } catch (Throwable t) {
            Log.w(TAG, "multicast lock failed", t);
        }
    }

    private void releaseMulticast() {
        try {
            if (mlock != null && mlock.isHeld()) mlock.release();
        } catch (Throwable ignored) {
            // уже снят
        }
    }

    private void scanLoop() {
        while (scanning) {
            try {
                searchOnce(3600);
            } catch (Throwable t) {
                Log.w(TAG, "ssdp search failed: " + t);
            }
            prune();
            for (int i = 0; i < 12 && scanning; i++) sleep(100);
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // выходим
        }
    }

    private static NetworkInterface wifiInterface() {
        NetworkInterface best = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback() || !ni.supportsMulticast()) continue;
                boolean v4 = false;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (ia.getAddress() instanceof Inet4Address && ia.getAddress().isSiteLocalAddress()) v4 = true;
                }
                if (!v4) continue;
                String n = ni.getName().toLowerCase(Locale.ROOT);
                if (n.startsWith("wlan") || n.startsWith("swlan") || n.startsWith("ap") || n.startsWith("eth")) return ni;
                if (best == null) best = ni;
            }
        } catch (Throwable ignored) {
            // нет сетевых интерфейсов
        }
        return best;
    }

    private static String msearch(String stType) {
        return "M-SEARCH * HTTP/1.1\r\nHOST: " + SSDP_ADDR + ":" + SSDP_PORT + "\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: "
                + stType + "\r\nUSER-AGENT: Android/LMusic UPnP/1.0\r\n\r\n";
    }

    private void searchOnce(long ms) throws IOException {
        MulticastSocket ms0 = new MulticastSocket(null);
        try {
            ms0.setReuseAddress(true);
            ms0.bind(new InetSocketAddress(0));
            ms0.setTimeToLive(4);
            ms0.setSoTimeout(400);
            NetworkInterface ni = wifiInterface();
            if (ni != null) {
                try {
                    ms0.setNetworkInterface(ni);
                } catch (Throwable ignored) {
                    // отправим через интерфейс по умолчанию
                }
            }
            InetAddress group = InetAddress.getByName(SSDP_ADDR);
            String[] sts = { "urn:schemas-upnp-org:device:MediaRenderer:1", "urn:schemas-upnp-org:service:AVTransport:1" };
            long end = System.currentTimeMillis() + ms;
            long nextSend = 0;
            byte[] buf = new byte[4096];
            while (scanning && System.currentTimeMillis() < end) {
                long now = System.currentTimeMillis();
                if (now >= nextSend) {
                    nextSend = now + 1100;
                    for (int i = 0; i < sts.length; i++) {
                        byte[] data = msearch(sts[i]).getBytes("UTF-8");
                        try {
                            ms0.send(new DatagramPacket(data, data.length, group, SSDP_PORT));
                        } catch (IOException e) {
                            Log.w(TAG, "ssdp send: " + e);
                        }
                    }
                }
                DatagramPacket rp = new DatagramPacket(buf, buf.length);
                try {
                    ms0.receive(rp);
                } catch (SocketTimeoutException e) {
                    continue;
                }
                parseSsdp(new String(rp.getData(), 0, rp.getLength(), "UTF-8"));
            }
        } finally {
            ms0.close();
        }
    }

    private void parseSsdp(String text) {
        String[] lines = text.split("\r\n");
        if (lines.length == 0) return;
        String first = lines[0].toUpperCase(Locale.ROOT);
        if (!first.startsWith("HTTP/1.1 200") && !first.startsWith("NOTIFY")) return;
        String location = null, nts = null;
        for (int i = 1; i < lines.length; i++) {
            int c = lines[i].indexOf(':');
            if (c <= 0) continue;
            String k = lines[i].substring(0, c).trim().toLowerCase(Locale.ROOT);
            String v = lines[i].substring(c + 1).trim();
            if ("location".equals(k)) location = v;
            else if ("nts".equals(k)) nts = v;
        }
        if (location == null || (nts != null && nts.contains("byebye"))) return;
        announce(location);
    }

    private void announce(final String location) {
        long now = System.currentTimeMillis();
        synchronized (fetched) {
            Long t = fetched.get(location);
            if (t != null && now - t < 30000L) {
                touch(location);
                return;
            }
            fetched.put(location, now);
        }
        net.execute(new Runnable() {
            public void run() {
                try {
                    probe(location);
                } catch (Throwable t) {
                    Log.w(TAG, "probe failed: " + t);
                }
            }
        });
    }

    private void touch(String location) {
        synchronized (devs) {
            for (Dev d : devs.values()) {
                if (d.location.equals(location)) d.lastSeen = System.currentTimeMillis();
            }
        }
    }

    private void prune() {
        boolean changed = false;
        long now = System.currentTimeMillis();
        synchronized (devs) {
            Iterator<Dev> it = devs.values().iterator();
            while (it.hasNext()) {
                Dev d = it.next();
                if (d != sel && "dlna".equals(d.proto) && now - d.lastSeen > 45000L) {
                    it.remove();
                    changed = true;
                }
            }
        }
        if (changed) emit();
    }

    // ------------------------------------------------------------------------------------------ описание устройства (XML)
    private static String httpGet(String url, int maxBytes) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(2500);
            c.setReadTimeout(3500);
            c.setRequestProperty("User-Agent", "Android/LMusic UPnP/1.0");
            if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
            return readAll(c.getInputStream(), maxBytes);
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in, int max) throws IOException {
        if (in == null) return "";
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) {
                bo.write(b, 0, n);
                if (bo.size() > max) break;
            }
            return bo.toString("UTF-8");
        } finally {
            in.close();
        }
    }

    private static String localName(Node n) {
        String s = n.getNodeName();
        int i = s.indexOf(':');
        return i >= 0 ? s.substring(i + 1) : s;
    }

    private static String childText(Element parent, String tag) {
        NodeList nl = parent.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n instanceof Element && tag.equals(localName(n))) {
                String t = n.getTextContent();
                return t == null ? "" : t.trim();
            }
        }
        return "";
    }

    private static void collect(Node n, String tag, java.util.List<Element> out) {
        NodeList nl = n.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node c = nl.item(i);
            if (!(c instanceof Element)) continue;
            if (tag.equals(localName(c))) out.add((Element) c);
            collect(c, tag, out);
        }
    }

    private static final Pattern TV = Pattern.compile(
            "(\\btv\\b|телевиз|bravia|webos|tizen|samsung|\\blg\\b|vizio|hisense|tcl|philips|panasonic|sharp|toshiba|"
                    + "\\bmi tv|xiaomi|android tv|google tv|roku|fire tv|display|monitor|projector|проектор)");

    /** Загружает описание устройства по LOCATION, добавляет его в список (если это MediaRenderer с AVTransport). */
    Dev probe(String location) throws Exception {
        String xml = httpGet(location, 262144);
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(false);
        DocumentBuilder b = f.newDocumentBuilder();
        Document doc = b.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));
        Element root = doc.getDocumentElement();
        java.util.List<Element> devices = new java.util.ArrayList<Element>();
        collect(root, "device", devices);
        if (devices.isEmpty()) return null;
        Element dev = devices.get(0);
        String base = childText(root, "URLBase");
        URL baseUrl = new URL(base.length() > 0 ? base : location);
        Dev d = new Dev();
        d.location = location;
        d.name = childText(dev, "friendlyName");
        d.model = childText(dev, "modelName");
        d.manuf = childText(dev, "manufacturer");
        String udn = childText(dev, "UDN");
        if (udn.startsWith("uuid:")) udn = udn.substring(5);
        d.id = udn.length() > 0 ? udn : location;
        d.host = new URL(location).getHost();
        java.util.List<Element> services = new java.util.ArrayList<Element>();
        collect(root, "service", services);
        for (Element s : services) {
            String type = childText(s, "serviceType");
            String ctrl = childText(s, "controlURL");
            if (type.length() == 0 || ctrl.length() == 0) continue;
            String abs = new URL(baseUrl, ctrl).toString();
            if (type.contains(":AVTransport:")) {
                d.avType = type;
                d.avUrl = abs;
            } else if (type.contains(":RenderingControl:")) {
                d.rcType = type;
                d.rcUrl = abs;
            }
        }
        if (d.avUrl == null) return null; // не проигрыватель (роутер, принтер и т.п.)
        if (d.name.length() == 0) d.name = d.model.length() > 0 ? d.model : d.host;
        String all = (d.name + " " + d.model + " " + d.manuf).toLowerCase(Locale.ROOT);
        d.kind = TV.matcher(all).find() ? "tv" : "speaker";
        d.lastSeen = System.currentTimeMillis();
        boolean isNew;
        synchronized (devs) {
            Dev old = devs.get(d.id);
            isNew = old == null;
            if (old != null && old == sel) {
                // выбранное устройство: обновляем адреса управления, объект оставляем тем же
                old.avUrl = d.avUrl;
                old.avType = d.avType;
                old.rcUrl = d.rcUrl;
                old.rcType = d.rcType;
                old.lastSeen = d.lastSeen;
                d = old;
            } else {
                devs.put(d.id, d);
            }
        }
        if (isNew) emit();
        return d;
    }

    // ------------------------------------------------------------------------------------------ Google Cast (mDNS)
    /** Устройство Google Cast найдено службой NSD (_googlecast._tcp). */
    void addGc(String id, String name, String model, String host, int port, String kind) {
        long now = System.currentTimeMillis();
        boolean isNew;
        synchronized (devs) {
            Dev old = devs.get(id);
            isNew = old == null;
            if (old != null) {
                old.lastSeen = now;
                old.host = host;
                old.port = port;
            } else {
                Dev d = new Dev();
                d.id = id;
                d.name = name.length() > 0 ? name : model;
                d.model = model;
                d.kind = kind;
                d.host = host;
                d.port = port;
                d.proto = "gcast";
                d.location = "gc:" + id;
                d.lastSeen = now;
                devs.put(id, d);
            }
        }
        if (isNew) emit();
    }

    void removeGc(String id) {
        boolean changed;
        synchronized (devs) {
            Dev d = devs.get(id);
            changed = d != null && d != sel && "gcast".equals(d.proto);
            if (changed) devs.remove(id);
        }
        if (changed) emit();
    }

    // ------------------------------------------------------------------------------------------ SOAP
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String tag(String xml, String name) {
        if (xml == null) return null;
        Matcher m = Pattern.compile("<(?:\\w+:)?" + name + "[^>]*>(.*?)</(?:\\w+:)?" + name + ">", Pattern.DOTALL).matcher(xml);
        return m.find() ? m.group(1).trim() : null;
    }

    private volatile String lastSoapError = "";

    /** Выполняет SOAP-действие. Возвращает тело ответа или null при ошибке (текст ошибки — в lastSoapError). */
    private String soap(Dev d, boolean rc, String action, String args) {
        String url = rc ? d.rcUrl : d.avUrl;
        String type = rc ? d.rcType : d.avType;
        if (url == null || type == null) return null;
        String body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:" + action + " xmlns:u=\"" + type + "\">"
                + args + "</u:" + action + "></s:Body></s:Envelope>";
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(3000);
            c.setReadTimeout(7000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
            c.setRequestProperty("SOAPAction", "\"" + type + "#" + action + "\"");
            c.setRequestProperty("User-Agent", "Android/LMusic UPnP/1.0");
            byte[] bytes = body.getBytes("UTF-8");
            c.setFixedLengthStreamingMode(bytes.length);
            OutputStream o = c.getOutputStream();
            o.write(bytes);
            o.close();
            int code = c.getResponseCode();
            String resp = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream(), 65536);
            if (code >= 400) {
                String ed = tag(resp, "errorDescription");
                lastSoapError = action + ": " + (ed != null ? ed : "HTTP " + code);
                Log.w(TAG, "soap " + lastSoapError);
                return null;
            }
            lastSoapError = "";
            return resp == null ? "" : resp;
        } catch (Throwable t) {
            lastSoapError = action + ": " + t.getMessage();
            Log.w(TAG, "soap " + lastSoapError);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String transportState(Dev d) {
        if (d.gc != null) return d.gc.state();
        String r = soap(d, false, "GetTransportInfo", INST);
        return r == null ? null : tag(r, "CurrentTransportState");
    }

    private void stopRemote(Dev d) {
        if (d.gc != null) d.gc.stop();
        else soap(d, false, "Stop", INST);
    }

    private void pauseRemote(Dev d) {
        if (d.gc != null) d.gc.pause();
        else soap(d, false, "Pause", INST);
    }

    private double remotePos(Dev d) {
        if (d.gc != null) return d.gc.position();
        String pi = soap(d, false, "GetPositionInfo", INST);
        return parseTime(tag(pi, "RelTime"));
    }

    private static double parseTime(String t) {
        if (t == null) return -1;
        Matcher m = Pattern.compile("^(\\d+):(\\d+):(\\d+(?:\\.\\d+)?)").matcher(t.trim());
        if (!m.find()) return -1;
        return Integer.parseInt(m.group(1)) * 3600.0 + Integer.parseInt(m.group(2)) * 60.0 + Double.parseDouble(m.group(3));
    }

    private static String fmtTime(double sec) {
        if (sec < 0) sec = 0;
        long s = (long) sec;
        return String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }

    private boolean seek(Dev d, double sec) {
        if (d.gc != null) return d.gc.seek(sec);
        return soap(d, false, "Seek", INST + "<Unit>REL_TIME</Unit><Target>" + fmtTime(sec) + "</Target>") != null;
    }

    private void playAndSeek(Dev d, double seekTo) {
        if (d.gc != null) {
            if (d.gc.play() && seekTo > 1.5) d.gc.seek(seekTo);
            return;
        }
        if (soap(d, false, "Play", INST + "<Speed>1</Speed>") == null) return;
        if (seekTo > 1.5) {
            for (int i = 0; i < 14; i++) {
                String s = transportState(d);
                if ("PLAYING".equals(s)) break;
                sleep(350);
            }
            if (!seek(d, seekTo)) {
                sleep(900);
                seek(d, seekTo);
            }
            lastSeekAt = System.currentTimeMillis();
        }
    }

    // ------------------------------------------------------------------------------------------ адрес телефона в сети устройства
    private static boolean sameSubnet(InetAddress a, InetAddress b, int prefix) {
        byte[] x = a.getAddress(), y = b.getAddress();
        if (x.length != y.length) return false;
        int bits = prefix;
        for (int i = 0; i < x.length && bits > 0; i++, bits -= 8) {
            int mask = bits >= 8 ? 0xFF : (0xFF << (8 - bits)) & 0xFF;
            if ((x[i] & mask) != (y[i] & mask)) return false;
        }
        return true;
    }

    private static String hostFor(Dev d) {
        try {
            InetAddress remote = InetAddress.getByName(d.host);
            String fallback = null;
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (!(a instanceof Inet4Address)) continue;
                    if (sameSubnet(a, remote, ia.getNetworkPrefixLength())) return a.getHostAddress();
                    if (fallback == null && a.isSiteLocalAddress()) fallback = a.getHostAddress();
                }
            }
            if (fallback != null) return fallback;
        } catch (Throwable ignored) {
            // нет сети
        }
        return "127.0.0.1";
    }

    // ------------------------------------------------------------------------------------------ тип файла
    static String sniff(File f) {
        byte[] b = new byte[16];
        int n = 0;
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            n = in.read(b);
        } catch (IOException ignored) {
            n = 0;
        } finally {
            try {
                if (in != null) in.close();
            } catch (IOException ignored) {
                // закрыт
            }
        }
        if (n >= 4) {
            if (b[0] == 'f' && b[1] == 'L' && b[2] == 'a' && b[3] == 'C') return "audio/flac";
            if (b[0] == 'O' && b[1] == 'g' && b[2] == 'g' && b[3] == 'S') return "audio/ogg";
            if (b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F') return "audio/wav";
            if (n >= 8 && b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p') return "audio/mp4";
            if ((b[0] & 0xff) == 0x30 && (b[1] & 0xff) == 0x26 && (b[2] & 0xff) == 0xB2 && (b[3] & 0xff) == 0x75) return "audio/x-ms-wma";
            if (b[0] == 'I' && b[1] == 'D' && b[2] == '3') return "audio/mpeg";
            if ((b[0] & 0xff) == 0xFF && (b[1] & 0xF6) == 0xF0) return "audio/aac";
        }
        return "audio/mpeg";
    }

    static String extFor(String mime) {
        if ("audio/flac".equals(mime)) return "flac";
        if ("audio/ogg".equals(mime)) return "ogg";
        if ("audio/wav".equals(mime)) return "wav";
        if ("audio/mp4".equals(mime)) return "m4a";
        if ("audio/aac".equals(mime)) return "aac";
        if ("audio/x-ms-wma".equals(mime)) return "wma";
        return "mp3";
    }

    private static String didl(String title, String artist, String album, String artUrl, String url, String mime, double dur) {
        StringBuilder sb = new StringBuilder();
        sb.append("<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" ")
                .append("xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\"0\" parentID=\"-1\" restricted=\"1\">");
        sb.append("<dc:title>").append(esc(title)).append("</dc:title>");
        if (artist != null && artist.length() > 0) {
            sb.append("<upnp:artist>").append(esc(artist)).append("</upnp:artist><dc:creator>").append(esc(artist)).append("</dc:creator>");
        }
        if (album != null && album.length() > 0) sb.append("<upnp:album>").append(esc(album)).append("</upnp:album>");
        if (artUrl != null && artUrl.length() > 0) sb.append("<upnp:albumArtURI>").append(esc(artUrl)).append("</upnp:albumArtURI>");
        sb.append("<upnp:class>object.item.audioItem.musicTrack</upnp:class>");
        sb.append("<res protocolInfo=\"http-get:*:").append(mime).append(":DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000\"");
        if (dur > 0) sb.append(" duration=\"").append(fmtTime(dur)).append(".000\"");
        sb.append('>').append(esc(url)).append("</res></item></DIDL-Lite>");
        return sb.toString();
    }

    // ------------------------------------------------------------------------------------------ команды страницы
    String list() {
        return stateJson();
    }

    /** Выбрано ли устройство трансляции. */
    boolean active() {
        return sel != null;
    }

    /** Обложка текущего трека (base64 JPEG, можно с префиксом data:). Раздаётся устройству по HTTP. */
    void art(String b64) {
        try {
            if (b64 == null || b64.length() < 16) return;
            int c = b64.indexOf("base64,");
            if (c >= 0) b64 = b64.substring(c + 7);
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            if (data.length > 0) http.addArt(data, "image/jpeg", "jpg");
        } catch (Throwable t) {
            Log.w(TAG, "cast art failed", t);
        }
    }

    /** Выбрать устройство для трансляции; пустой id — отключиться и вернуть звук на телефон. */
    void select(final String id) {
        ctl.execute(new Runnable() {
            public void run() {
                try {
                    if (id == null || id.length() == 0) {
                        disconnect(true);
                        return;
                    }
                    Dev cur = sel;
                    if (cur != null && cur.id.equals(id)) return;
                    Dev d;
                    synchronized (devs) {
                        d = devs.get(id);
                    }
                    if (d == null) {
                        setState("error", "Устройство не найдено. Обновите список.");
                        return;
                    }
                    if (cur != null) disconnect(true);
                    sel = d;
                    setState("connecting", "");
                    try {
                        http.start();
                    } catch (IOException e) {
                        sel = null;
                        setState("error", "Не удалось запустить сервер трансляции");
                        return;
                    }
                    if ("gcast".equals(d.proto)) {
                        GCast g = new GCast(d.host, d.port);
                        if (!g.connect()) {
                            sel = null;
                            setState("error", "Нет связи с устройством Google Cast");
                            return;
                        }
                        d.gc = g;
                        sleep(600);
                    }
                    if (transportState(d) == null) {
                        sel = null;
                        setState("error", "Нет связи с устройством. " + lastSoapError);
                        return;
                    }
                    loaded = false;
                    failPolls = 0;
                    mismatch = 0;
                    setState("ready", "");
                    if (d.gc != null) {
                        vol = d.gc.volume();
                        emit();
                    } else if (d.rcUrl != null) {
                        String r = soap(d, true, "GetVolume", INST + "<Channel>Master</Channel>");
                        String v = tag(r, "CurrentVolume");
                        try {
                            if (v != null) {
                                vol = Integer.parseInt(v.trim());
                                emit();
                            }
                        } catch (NumberFormatException ignored) {
                            // громкость неизвестна
                        }
                    }
                    startPoll();
                } catch (Throwable t) {
                    Log.w(TAG, "cast select failed", t);
                    fail("Ошибка подключения: " + t.getMessage());
                }
            }
        });
    }

    private void disconnect(boolean stopRemote) {
        stopPoll();
        Dev d = sel;
        sel = null;
        loaded = false;
        wantPlaying = false;
        pendingSeek = -1;
        loadGen.incrementAndGet();
        if (stopRemote && d != null) stopRemote(d);
        if (d != null && d.gc != null) {
            d.gc.close();
            d.gc = null;
        }
        sink.mute(false);
        vol = -1;
        setState("idle", "");
    }

    private void fail(String msg) {
        loaded = false;
        sink.mute(false);
        setState("error", msg);
    }

    /** Передать устройству трек: key — файл в кэше движка. start — позиция в секундах, play — играть сразу. */
    void load(final String key, final String title, final String artist, final String album, final double dur,
              final double start, final boolean play) {
        final int gen = loadGen.incrementAndGet();
        ctl.execute(new Runnable() {
            public void run() {
                try {
                    Dev d = sel;
                    if (d == null || gen != loadGen.get()) return;
                    File f = sink.fileFor(key);
                    if (f == null || !f.isFile()) {
                        fail("Файл трека недоступен для трансляции");
                        return;
                    }
                    int port = http.start();
                    String host = hostFor(d);
                    String mime = sniff(f);
                    String path = http.addFile(f, mime, extFor(mime));
                    String artPath = http.currentArt();
                    String url = "http://" + host + ":" + port + path;
                    String artUrl = artPath == null ? "" : "http://" + host + ":" + port + artPath;
                    String meta = didl(title, artist, album, artUrl, url, mime, dur);
                    durSec = dur;
                    cmdAt = System.currentTimeMillis();
                    if ("gcast".equals(d.proto)) {
                        if (d.gc == null || !d.gc.isOpen()) {
                            GCast g = new GCast(d.host, d.port);
                            if (!g.connect()) {
                                fail("Нет связи с устройством Google Cast");
                                return;
                            }
                            d.gc = g;
                        }
                        boolean ok = d.gc.load(url, mime, title, artist, album, artUrl, dur, start, play);
                        if (gen != loadGen.get()) return;
                        if (!ok) {
                            fail("Устройство Google Cast не приняло трек");
                            return;
                        }
                        loadAt = System.currentTimeMillis();
                        cmdAt = loadAt;
                        wantPlaying = play;
                        pendingSeek = -1;
                        loaded = true;
                        mismatch = 0;
                        failPolls = 0;
                        sink.mute(true);
                        setState(play ? "playing" : "paused", "");
                        return;
                    }
                    stopRemote(d);
                    if (gen != loadGen.get()) return;
                    String r = soap(d, false, "SetAVTransportURI", INST + "<CurrentURI>" + esc(url) + "</CurrentURI><CurrentURIMetaData>"
                            + esc(meta) + "</CurrentURIMetaData>");
                    if (r == null) {
                        // часть устройств не принимает метаданные — пробуем без них
                        r = soap(d, false, "SetAVTransportURI", INST + "<CurrentURI>" + esc(url) + "</CurrentURI><CurrentURIMetaData></CurrentURIMetaData>");
                    }
                    if (r == null) {
                        fail("Устройство не приняло трек. " + lastSoapError);
                        return;
                    }
                    loadAt = System.currentTimeMillis();
                    cmdAt = loadAt;
                    wantPlaying = play;
                    pendingSeek = start > 1.5 ? start : -1;
                    if (play) {
                        double s = pendingSeek;
                        pendingSeek = -1;
                        playAndSeek(d, s);
                        if (gen != loadGen.get()) return;
                    }
                    loaded = true;
                    mismatch = 0;
                    failPolls = 0;
                    sink.mute(true);
                    setState(play ? "playing" : "paused", "");
                } catch (Throwable t) {
                    Log.w(TAG, "cast load failed", t);
                    fail("Ошибка трансляции: " + t.getMessage());
                }
            }
        });
    }

    /** play | pause | seek | stop. pos — позиция локального плеера в секундах. */
    void transport(final String cmd, final double pos) {
        ctl.execute(new Runnable() {
            public void run() {
                try {
                    Dev d = sel;
                    if (d == null || !loaded) return;
                    long now = System.currentTimeMillis();
                    cmdAt = now;
                    if ("play".equals(cmd)) {
                        wantPlaying = true;
                        double ps = pendingSeek;
                        pendingSeek = -1;
                        String s = transportState(d);
                        if (("STOPPED".equals(s) || "NO_MEDIA_PRESENT".equals(s)) && ps <= 1.5 && pos > 1.5) ps = pos;
                        playAndSeek(d, ps);
                        setState("playing", "");
                    } else if ("pause".equals(cmd)) {
                        wantPlaying = false;
                        pauseRemote(d);
                        setState("paused", "");
                    } else if ("seek".equals(cmd)) {
                        if (pos >= 0) {
                            localPos = pos;
                            localPosAt = now;
                            if (!seek(d, pos)) {
                                sleep(700);
                                seek(d, pos);
                            }
                            lastSeekAt = System.currentTimeMillis();
                        }
                    } else if ("stop".equals(cmd)) {
                        wantPlaying = false;
                        stopRemote(d);
                        setState("paused", "");
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "cast transport failed", t);
                }
            }
        });
    }

    /** Текущая позиция локального плеера (для сверки с устройством). Вызывается раз в пару секунд. */
    void tick(double pos) {
        localPos = pos;
        localPosAt = System.currentTimeMillis();
    }

    void volume(final int v) {
        ctl.execute(new Runnable() {
            public void run() {
                Dev d = sel;
                if (d == null) return;
                int x = Math.max(0, Math.min(100, v));
                if (d.gc != null) {
                    if (d.gc.setVolume(x)) vol = x;
                    return;
                }
                if (d.rcUrl == null) return;
                if (soap(d, true, "SetVolume", INST + "<Channel>Master</Channel><DesiredVolume>" + x + "</DesiredVolume>") != null) {
                    vol = x;
                }
            }
        });
    }

    // ------------------------------------------------------------------------------------------ опрос устройства
    private void startPoll() {
        stopPoll();
        poller = Executors.newSingleThreadScheduledExecutor(new Named("kx-cast-poll"));
        poller.scheduleWithFixedDelay(new Runnable() {
            public void run() {
                try {
                    pollOnce();
                } catch (Throwable t) {
                    Log.w(TAG, "cast poll failed", t);
                }
            }
        }, 2500, 2000, TimeUnit.MILLISECONDS);
    }

    private void stopPoll() {
        ScheduledExecutorService p = poller;
        poller = null;
        if (p != null) p.shutdownNow();
    }

    private boolean nearEnd(long now) {
        return durSec > 0 && localPos >= 0 && localPos + (now - localPosAt) / 1000.0 > durSec - 4.0;
    }

    private void pollOnce() {
        Dev d = sel;
        if (d == null || !loaded) return;
        long now = System.currentTimeMillis();
        String state = transportState(d);
        if (state == null) {
            if (++failPolls >= 4) {
                failPolls = 0;
                fail("Связь с устройством потеряна");
            }
            return;
        }
        failPolls = 0;
        if (now - cmdAt < 3500 || now - loadAt < 3500) {
            mismatch = 0;
            return;
        }
        boolean stopped = "STOPPED".equals(state) || "NO_MEDIA_PRESENT".equals(state);
        if (wantPlaying && stopped && !nearEnd(now)) {
            if (++mismatch >= 2) {
                mismatch = 0;
                fail("Устройство не смогло воспроизвести трек. Звук вернулся на телефон.");
            }
            return;
        }
        String evt = null;
        if (wantPlaying && "PAUSED_PLAYBACK".equals(state)) evt = "paused";
        else if (!wantPlaying && "PLAYING".equals(state)) evt = "playing";
        if (evt != null) {
            if (++mismatch >= 2) {
                mismatch = 0;
                wantPlaying = "playing".equals(evt);
                setState(wantPlaying ? "playing" : "paused", "");
                sink.js("window.__kxCast&&window.__kxCast({\"e\":\"remote\",\"s\":\"" + evt + "\"})");
            }
            return;
        }
        mismatch = 0;
        if (wantPlaying && "PLAYING".equals(state) && localPos >= 0 && now - localPosAt < 4500 && now - lastSeekAt > 8000) {
            double rp = remotePos(d);
            double exp = localPos + (now - localPosAt) / 1000.0;
            if (rp >= 0 && Math.abs(exp - rp) > 2.5 && (durSec <= 0 || exp < durSec - 2.0)) {
                lastSeekAt = now;
                cmdAt = now;
                seek(d, exp);
            }
        }
    }

    // ------------------------------------------------------------------------------------------ завершение
    void shutdown() {
        scanning = false;
        if (gcd != null) gcd.stop();
        releaseMulticast();
        stopPoll();
        final Dev d = sel;
        sel = null;
        loaded = false;
        if (d != null) {
            Thread t = new Thread(new Runnable() {
                public void run() {
                    stopRemote(d);
                    if (d.gc != null) d.gc.close();
                }
            }, "kx-cast-stop");
            t.setDaemon(true);
            t.start();
            try {
                t.join(1500);
            } catch (InterruptedException ignored) {
                // выходим
            }
        }
        ctl.shutdownNow();
        net.shutdownNow();
        http.stop();
    }
}

package kx.engine;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Message;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/**
 * Обёртка над WebChromeClient оболочки. Всё делегирует оригиналу; из onShowFileChooser только
 * запоминает content:// URI выбранных файлов, чтобы нативный экспорт читал их напрямую, без копирования
 * через мост (передача файла через JS шла со скоростью ~9 МБ/с).
 */
final class FileHook extends WebChromeClient {
    private final WebChromeClient orig;
    private final KxBridge br;

    FileHook(WebChromeClient orig, KxBridge br) {
        this.orig = orig;
        this.br = br;
    }

    @Override
    public boolean onShowFileChooser(WebView w, final ValueCallback<Uri[]> cb, FileChooserParams p) {
        ValueCallback<Uri[]> wrapped = new ValueCallback<Uri[]>() {
            public void onReceiveValue(Uri[] u) {
                try {
                    br.recordPicked(u);
                } catch (Throwable ignored) {
                    // запись URI не должна мешать выбору файла
                }
                cb.onReceiveValue(u);
            }
        };
        return orig.onShowFileChooser(w, wrapped, p);
    }

    @Override
    public void onProgressChanged(WebView v, int p) {
        orig.onProgressChanged(v, p);
    }

    @Override
    public void onReceivedTitle(WebView v, String t) {
        orig.onReceivedTitle(v, t);
    }

    @Override
    public void onReceivedIcon(WebView v, Bitmap i) {
        orig.onReceivedIcon(v, i);
    }

    @Override
    public void onReceivedTouchIconUrl(WebView v, String u, boolean pre) {
        orig.onReceivedTouchIconUrl(v, u, pre);
    }

    @Override
    public void onShowCustomView(View v, CustomViewCallback c) {
        orig.onShowCustomView(v, c);
    }

    @Override
    public void onHideCustomView() {
        orig.onHideCustomView();
    }

    @Override
    public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message m) {
        return orig.onCreateWindow(v, dialog, gesture, m);
    }

    @Override
    public void onRequestFocus(WebView v) {
        orig.onRequestFocus(v);
    }

    @Override
    public void onCloseWindow(WebView v) {
        orig.onCloseWindow(v);
    }

    @Override
    public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
        return orig.onJsAlert(v, url, msg, r);
    }

    @Override
    public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
        return orig.onJsConfirm(v, url, msg, r);
    }

    @Override
    public boolean onJsPrompt(WebView v, String url, String msg, String def, JsPromptResult r) {
        return orig.onJsPrompt(v, url, msg, def, r);
    }

    @Override
    public boolean onJsBeforeUnload(WebView v, String url, String msg, JsResult r) {
        return orig.onJsBeforeUnload(v, url, msg, r);
    }

    @Override
    public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback c) {
        orig.onGeolocationPermissionsShowPrompt(origin, c);
    }

    @Override
    public void onGeolocationPermissionsHidePrompt() {
        orig.onGeolocationPermissionsHidePrompt();
    }

    @Override
    public void onPermissionRequest(PermissionRequest r) {
        orig.onPermissionRequest(r);
    }

    @Override
    public void onPermissionRequestCanceled(PermissionRequest r) {
        orig.onPermissionRequestCanceled(r);
    }

    @Override
    public boolean onConsoleMessage(ConsoleMessage m) {
        return orig.onConsoleMessage(m);
    }

    @Override
    public Bitmap getDefaultVideoPoster() {
        return orig.getDefaultVideoPoster();
    }

    @Override
    public View getVideoLoadingProgressView() {
        return orig.getVideoLoadingProgressView();
    }

    @Override
    public void getVisitedHistory(ValueCallback<String[]> cb) {
        orig.getVisitedHistory(cb);
    }
}

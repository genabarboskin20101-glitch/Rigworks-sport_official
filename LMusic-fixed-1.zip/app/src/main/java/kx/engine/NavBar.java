package kx.engine;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.WeakHashMap;

/**
 * Держит системные кнопки навигации видимыми (галочка «Всегда показывать кнопки навигации» в билдере).
 * Оболочка шаблона этот ключ config.json не читает, а на ряде прошивок тема/окно «на весь экран»
 * прячет панель. Поэтому здесь явно запрашиваем показ панели при создании окна, при возврате в
 * приложение, при получении фокуса (после выхода из полноэкранного превью) и пока система
 * пытается её скрыть. Панель делаем прозрачной: интерфейс страницы остаётся на весь экран, кнопки
 * лежат поверх него. Высоту панели (CSS px) отдаём странице через KExport.navInsetBottom().
 * Включается только флагом alwaysShowNavButtons в assets/www/config.json.
 */
final class NavBar {
    private static final String TAG = "KX";
    private static final WeakHashMap<Activity, Boolean> STATE = new WeakHashMap<Activity, Boolean>();
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static volatile int navBottomCss = 0;
    private static volatile int statusTopCss = 0;

    /** Высота статус-бара/выреза сверху в CSS px (только если он сейчас виден), иначе 0. */
    static int statusTopCss() { return statusTopCss; }

    /** Высота панели навигации снизу в CSS px (0, если панели нет или функция выключена). */
    static int navBottomCss() { return navBottomCss; }

    private NavBar() { }

    static void apply(final Activity a) {
        try {
            Boolean on;
            synchronized (STATE) { on = STATE.get(a); }
            if (on == null) {
                on = Boolean.valueOf(readFlag(a));
                synchronized (STATE) { STATE.put(a, on); }
                if (on.booleanValue()) install(a);
            }
            if (on.booleanValue()) schedule(a);
        } catch (Throwable t) {
            Log.w(TAG, "NavBar.apply failed", t);
        }
    }

    private static boolean readFlag(Activity a) {
        InputStream in = null;
        try {
            in = a.getAssets().open("www/config.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONObject j = new JSONObject(new String(bo.toByteArray(), "UTF-8"));
            return j.optBoolean("alwaysShowNavButtons", false);
        } catch (Throwable t) {
            return false;
        } finally {
            if (in != null) {
                try { in.close(); } catch (Throwable ignored) { }
            }
        }
    }

    @SuppressWarnings("deprecation")
    private static void install(final Activity a) {
        Window w = a.getWindow();
        if (w == null) return;
        View d = w.getDecorView();
        // фокус вернулся (выход из полноэкранного превью, шторка, переключение приложений)
        d.getViewTreeObserver().addOnWindowFocusChangeListener(new ViewTreeObserver.OnWindowFocusChangeListener() {
            @Override
            public void onWindowFocusChanged(boolean hasFocus) {
                if (hasFocus) schedule(a);
            }
        });
        // Android 10 и ниже: система сообщает, что панель скрыли, — показываем снова
        if (Build.VERSION.SDK_INT < 30) {
            d.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
                @Override
                public void onSystemUiVisibilityChange(int visibility) {
                    if ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) != 0) schedule(a);
                }
            });
        }
    }

    private static void schedule(final Activity a) {
        show(a);
        Runnable r = new Runnable() {
            @Override
            public void run() { show(a); }
        };
        H.postDelayed(r, 250);
        H.postDelayed(r, 1000);
        H.postDelayed(r, 2500);
    }

    @SuppressWarnings("deprecation")
    private static void show(Activity a) {
        try {
            if (a.isFinishing() || a.isDestroyed()) return;
            Window w = a.getWindow();
            if (w == null) return;
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = w.getInsetsController();
                if (c != null) {
                    c.show(WindowInsets.Type.navigationBars());
                    // светлые значки (страница тёмная)
                    c.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
                }
            } else {
                View d = w.getDecorView();
                int f = d.getSystemUiVisibility();
                int n = f & ~(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                if (Build.VERSION.SDK_INT >= 26) n &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                if (n != f) d.setSystemUiVisibility(n);
            }
            // прозрачная панель без «затемняющей подложки» системы: интерфейс виден под кнопками
            if (Build.VERSION.SDK_INT < 35) w.setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);
            // то же для статус-бара: интерфейс продолжается под ним, значки остаются поверх
            if (Build.VERSION.SDK_INT < 35) w.setStatusBarColor(Color.TRANSPARENT);
            measure(a, w);
        } catch (Throwable t) {
            Log.w(TAG, "NavBar.show failed", t);
        }
    }

    @SuppressWarnings("deprecation")
    private static void measure(Activity a, Window w) {
        try {
            WindowInsets wi = w.getDecorView().getRootWindowInsets();
            if (wi == null) return;
            int px;
            if (Build.VERSION.SDK_INT >= 30) {
                px = wi.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars()).bottom;
            } else {
                px = wi.getStableInsetBottom();
            }
            float den = a.getResources().getDisplayMetrics().density;
            if (den <= 0f) den = 1f;
            navBottomCss = Math.max(0, Math.round(px / den));
            int top;
            if (Build.VERSION.SDK_INT >= 30) {
                top = wi.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.displayCutout()).top;
            } else {
                top = wi.getSystemWindowInsetTop();
            }
            statusTopCss = Math.max(0, Math.round(top / den));
        } catch (Throwable t) {
            Log.w(TAG, "NavBar.measure failed", t);
        }
    }
}

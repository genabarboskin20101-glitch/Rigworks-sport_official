package kx.engine;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.display.DisplayManager;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.AudioRecordingConfiguration;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Display;

import java.util.List;

/**
 * Следит за событиями системы, при которых музыку нужно приостановить (решает страница по настройкам «Автопауза»):
 *  call — звонок (входящий, исходящий, VoIP): режим звука AudioManager = RINGTONE / IN_CALL / IN_COMMUNICATION;
 *  rec  — другое приложение записывает видео или звук (камера, диктофон): AudioRecordingCallback;
 *  out  — отключилась гарнитура, наушники или Bluetooth-колонка (on=false), либо подключилась (on=true).
 * Ни одно из этих наблюдений не требует разрешений.
 */
final class SysWatch {
    private static final String TAG = "KX";

    interface Sink {
        void event(String kind, boolean on);
    }

    private final Context ctx;
    private final Sink sink;
    private final Handler h = new Handler(Looper.getMainLooper());
    private AudioManager am;
    private volatile boolean started;
    private volatile boolean callOn, recOn;
    private boolean devReady;
    private long lastOutOff;
    private Object recCb;
    private AudioDeviceCallback devCb;
    private BroadcastReceiver noisy;

    private final Runnable poll = new Runnable() {
        public void run() {
            if (!started) return;
            checkCall();
            h.postDelayed(this, 600);
        }
    };

    SysWatch(Context c, Sink s) {
        ctx = c.getApplicationContext();
        sink = s;
    }

    boolean callActive() {
        return callOn;
    }

    boolean recActive() {
        return recOn;
    }

    static boolean callMode(AudioManager a) {
        try {
            int m = a.getMode();
            return m == AudioManager.MODE_RINGTONE || m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION
                    || m == 6; // MODE_CALL_SCREENING (API 29)
        } catch (Throwable t) {
            return false;
        }
    }

    private void checkCall() {
        boolean on = callMode(am);
        if (on != callOn) {
            callOn = on;
            sink.event("call", on);
        }
    }

    /** Выходные устройства, отключение которых должно останавливать музыку (без SCO: он рвётся после каждого звонка). */
    private static boolean isOut(AudioDeviceInfo d) {
        try {
            if (!d.isSink()) return false;
            switch (d.getType()) {
                case 8:  // TYPE_BLUETOOTH_A2DP
                case 3:  // TYPE_WIRED_HEADSET
                case 4:  // TYPE_WIRED_HEADPHONES
                case 22: // TYPE_USB_HEADSET
                case 23: // TYPE_HEARING_AID
                case 26: // TYPE_BLE_HEADSET
                case 27: // TYPE_BLE_SPEAKER
                case 30: // TYPE_BLE_BROADCAST
                    return true;
                default:
                    return false;
            }
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Куда сейчас идёт звук: Bluetooth > проводные/USB наушники > HDMI/USB > динамик телефона.
     * Возвращает JSON {"id","name","type"}; id устойчив между подключениями (для Bluetooth — по имени устройства).
     */
    static String currentOutput(Context c) {
        String speaker = "{\"id\":\"speaker\",\"name\":\"Динамик телефона\",\"type\":\"speaker\"}";
        try {
            AudioManager a = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            AudioDeviceInfo best = null;
            int bestRank = -1;
            for (AudioDeviceInfo d : a.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType(), r;
                if (t == 8 || t == 26 || t == 27 || t == 23 || t == 30) r = 5;
                else if (t == 22 || t == 3 || t == 4) r = 4;
                else if (t == 9 || t == 11 || t == 12) r = 3;
                else if (t == 7) r = 2;
                else if (t == 2) r = 1;
                else r = 0;
                if (r > bestRank) {
                    bestRank = r;
                    best = d;
                }
            }
            if (best == null || bestRank < 2) {
                // звук идёт через телефон на внешний экран (дублирование экрана, Miracast, Cast-экран)
                String scr = externalDisplay(c);
                if (scr != null) {
                    return "{\"id\":" + Cast.q("display:" + scr.toLowerCase(java.util.Locale.ROOT)) + ",\"name\":" + Cast.q("Экран: " + scr) + ",\"type\":\"screen\"}";
                }
                return speaker;
            }
            int t = best.getType();
            CharSequence pn = best.getProductName();
            String name = pn == null ? "" : pn.toString().trim();
            String low = name.toLowerCase(java.util.Locale.ROOT);
            if (bestRank == 5 || t == 7) {
                if (name.length() == 0) name = "Bluetooth-устройство";
                return "{\"id\":" + Cast.q("bt:" + low) + ",\"name\":" + Cast.q(name) + ",\"type\":\"bt\"}";
            }
            if (t == 22) {
                if (name.length() == 0) name = "USB-наушники";
                return "{\"id\":" + Cast.q("usb:" + low) + ",\"name\":" + Cast.q(name) + ",\"type\":\"usb\"}";
            }
            if (t == 3 || t == 4) return "{\"id\":\"wired\",\"name\":\"Проводные наушники\",\"type\":\"wired\"}";
            if (name.length() == 0) name = t == 9 ? "HDMI" : "USB-аудио";
            return "{\"id\":" + Cast.q("ext:" + low) + ",\"name\":" + Cast.q(name) + ",\"type\":\"ext\"}";
        } catch (Throwable t) {
            return speaker;
        }
    }

    /** Имя внешнего экрана (телевизор, монитор по Miracast/HDMI), если он подключён как презентационный дисплей. */
    private static String externalDisplay(Context c) {
        try {
            DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
            if (dm == null) return null;
            for (Display d : dm.getDisplays()) {
                if (d.getDisplayId() != Display.DEFAULT_DISPLAY && (d.getFlags() & Display.FLAG_PRESENTATION) != 0) {
                    String n = d.getName();
                    return n == null || n.length() == 0 ? "внешний экран" : n;
                }
            }
        } catch (Throwable ignored) {
            // нет сведений о дисплеях
        }
        return null;
    }

    private DisplayManager.DisplayListener dispCb;

    private final Runnable routeR = new Runnable() {
        public void run() {
            sink.event("route", true);
        }
    };

    private void routeChanged() {
        h.removeCallbacks(routeR);
        h.postDelayed(routeR, 450);
    }

    private static boolean anyOut(AudioDeviceInfo[] list) {
        if (list == null) return false;
        for (int i = 0; i < list.length; i++) {
            if (isOut(list[i])) return true;
        }
        return false;
    }

    private void outOff() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastOutOff < 1200) return; // BECOMING_NOISY и AudioDeviceCallback приходят вместе
        lastOutOff = now;
        sink.event("out", false);
    }

    /** Источники звука, которые считаем «записью»: камера и микрофон. Голосовой помощник, hotword и звонки сюда не входят. */
    private static boolean recSource(int src) {
        return src == 5 /* CAMCORDER */ || src == 1 /* MIC */ || src == 9 /* UNPROCESSED */;
    }

    void start() {
        if (started) return;
        try {
            am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;
            started = true;
            callOn = callMode(am);
            h.postDelayed(poll, 600);

            if (Build.VERSION.SDK_INT >= 24) {
                AudioManager.AudioRecordingCallback cb = new AudioManager.AudioRecordingCallback() {
                    @Override
                    public void onRecordingConfigChanged(List<AudioRecordingConfiguration> configs) {
                        boolean on = false;
                        if (configs != null) {
                            for (AudioRecordingConfiguration c : configs) {
                                try {
                                    if (!recSource(c.getClientAudioSource())) continue;
                                    if (Build.VERSION.SDK_INT >= 29 && c.isClientSilenced()) continue;
                                    on = true;
                                    break;
                                } catch (Throwable ignored) {
                                    // конфигурация недоступна
                                }
                            }
                        }
                        if (on != recOn) {
                            recOn = on;
                            sink.event("rec", on);
                        }
                    }
                };
                recCb = cb;
                am.registerAudioRecordingCallback(cb, h);
            }

            devCb = new AudioDeviceCallback() {
                @Override
                public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
                    if (devReady) routeChanged();
                    if (devReady && anyOut(added)) sink.event("out", true);
                }

                @Override
                public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
                    if (devReady) routeChanged();
                    if (devReady && anyOut(removed)) outOff();
                }
            };
            am.registerAudioDeviceCallback(devCb, h);
            // сразу после регистрации приходит список уже подключённых устройств — его пропускаем
            h.postDelayed(new Runnable() {
                public void run() {
                    devReady = true;
                }
            }, 1500);

            try {
                DisplayManager dm = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
                dispCb = new DisplayManager.DisplayListener() {
                    public void onDisplayAdded(int id) {
                        if (devReady) routeChanged();
                    }

                    public void onDisplayRemoved(int id) {
                        if (devReady) routeChanged();
                    }

                    public void onDisplayChanged(int id) {
                    }
                };
                if (dm != null) dm.registerDisplayListener(dispCb, h);
            } catch (Throwable t) {
                Log.w(TAG, "display listener failed: " + t);
            }
            noisy = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    if (i != null && AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(i.getAction())) outOff();
                }
            };
            ctx.registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        } catch (Throwable t) {
            Log.w(TAG, "SysWatch start failed", t);
        }
    }

    void stop() {
        started = false;
        h.removeCallbacksAndMessages(null);
        try {
            if (am != null && recCb != null && Build.VERSION.SDK_INT >= 24) {
                am.unregisterAudioRecordingCallback((AudioManager.AudioRecordingCallback) recCb);
            }
        } catch (Throwable ignored) {
            // уже снят
        }
        try {
            if (am != null && devCb != null) am.unregisterAudioDeviceCallback(devCb);
        } catch (Throwable ignored) {
            // уже снят
        }
        try {
            if (noisy != null) ctx.unregisterReceiver(noisy);
        } catch (Throwable ignored) {
            // уже снят
        }
        try {
            DisplayManager dm = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
            if (dm != null && dispCb != null) dm.unregisterDisplayListener(dispCb);
        } catch (Throwable ignored) {
            // уже снят
        }
        dispCb = null;
        recCb = null;
        devCb = null;
        noisy = null;
        callOn = false;
        recOn = false;
        devReady = false;
    }
}

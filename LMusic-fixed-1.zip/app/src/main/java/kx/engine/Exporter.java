package kx.engine;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.ExifInterface;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.util.Range;
import android.view.Surface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Фаза 0: видео-конвейер без звука. MediaExtractor -> MediaCodec(decoder) -> SurfaceTexture(OES)
 * -> GLES2 -> Surface энкодера -> MediaMuxer -> MediaStore. Кадры не покидают GPU.
 * Режим bench=decodeOnly гоняет только декодер (потолок декодирования без энкодера).
 */
final class Exporter implements Runnable {
    private static final String TAG = "KX";
    private static final int EGL_RECORDABLE_ANDROID = 0x3142;
    private static final long GUARD_US = 1000000L;
    private static final long STALL_MS = 20000L;

    static final class Fail extends Exception {
        private static final long serialVersionUID = 1L;
        final String code;
        final boolean recoverable;

        Fail(String code, String msg, boolean recoverable) {
            super(msg);
            this.code = code;
            this.recoverable = recoverable;
        }
    }

    static final class Aud {
        long pts;
        int flags;
        byte[] data;
    }

    /** Статичное наложение: PNG, подготовленный страницей (текст, стикер), рисуется текстурированным квадом. */
    static final class Ovl {
        Src src;
        double t0;
        double t1;
        double x;
        double y;
        double w;
        double h;
        double rot;
        double opacity = 1;
        double fi;
        double fo;
        int tex;
        double hpx;
        boolean under;        // маска виньетки клипа: рисуется под эффектами/затемнением перехода, только пока играет её клип (см. Clip.vig)
    boolean raw;          // исходная картинка (PNG/JPEG/WebP) без перерисовки на Canvas: декод с EXIF и сэмплированием
        int vbo;              // вершины квада: считаются ОДИН раз в loadOverlays, дальше только draw
        boolean fadeNone;     // нет fi/fo: прозрачность постоянна на всё окно показа
        float alphaStatic = 1f;
    }

    /** Параметры тоновой коррекции клипа (порт vidGpu из редактора, подготовлены страницей: kxToneParams). */
    static final class Tone {
        boolean on;
        boolean masks;
        boolean wOn;
        float hi;
        float sh;
        float dyn;
        float temp;
        float black;
        float fade;
        float pur;
        float sharp;
        float grain;
        float[] hsl = new float[4];
        int gamN;
        float[] gam = new float[32];
        float[] wt = new float[16];
        float[] wl = new float[4];
        int maskMode;
        float[] mask = new float[4];
    }

    /** Вариант фрагментного шейдера цвета (только цепочка фильтров CSS или с тоновой коррекцией) и его uniform-ы. */
    static final class FxProg {
        boolean tone;
        int p;
        int uMvp;
        int uTm;
        int uTexel;
        int uSTex;
        int uOpsN;
        int uOps;
        int uGlOn;
        int uGl;
        int uSeed;
        int uSrc;
        int uSharp;
        int uGrain;
        int uOn;
        int uPur;
        int uCurOn;
        int uLut;
        int uA;
        int uB;
        int uHsl;
        int uMasks;
        int uGamOn;
        int uGN;
        int uGam;
        int uWT;
        int uWL;
        int uWOn;
        int uMask;
        int uMaskMode;
        int uVA;
        int uVB;
        int uVC;
        int uVDim;
        int uVShape;   // номер фигуры виньетки (0 = эллипс считается формулой, >0 = читаем SDF)
        int uVSdf;     // sampler2D с картой расстояний, текстурный юнит 2
    }

    static final class Clip {
        float[] ops = new float[24];   // цепочка CSS-фильтров: пары (тип, значение)
        int opsN;
        Tone tone;
        byte[] lut;                    // кривые: RGBA 256x1 (1024 байта)
        Ovl vig;                       // готовая маска виньетки клипа (не-эллипс, без анимации)
        Src vShapeSrc;                 // PNG с картой расстояний фигуры виньетки (не-эллипс), см. kxBakeShapeSdf
        String vShapeId;
        int vShapeN;                   // номер фигуры (>0)
        float[] vigC;                  // виньетка клипа (12 чисел, см. kxVignetteVec), постоянная на клип
        int aN;                        // ключевые кадры клипа, заранее посчитанные страницей по тикам (0 = анимации нет)
        float[] aZoom;
        float[] aOffX;
        float[] aOffY;
        float[] aRot;
        float[] aVig;                  // aN * 12 чисел: виньетка по тикам
        float[] aOps;                  // aN * 24 чисел: цепочка CSS-фильтров по тикам (12 пар тип/значение)
        float[] aOpsN;                 // aN чисел: длина цепочки фильтров на каждом тике
        float[] aTone;                 // aN * 15 чисел: тон по тикам (on, masks, hi, sh, dyn, temp, black, fade, pur, sharp, grain, hsl x4)
        float[] aGam;                   // aN * 59 чисел: гаммы/колёса по тикам (gamN, gam[32], wt[16], wl[4], wOn, maskMode, mask[4])
        FxProg fxp;                    // шейдер этого клипа (null = обычный прямой путь)
        String trOut;
        double trOutDur = 0.45;
        String trIn;
        double trInDur = 0.45;
        Src src;
        double in;
        double out;
        boolean cover;
        int vtrack;
        long inUs;
        long outUs;
        double startUs;
        long kStart;
        long kEnd;
    }

    private static final String VS = "uniform mat4 uMvp;uniform mat4 uTm;attribute vec4 aPos;attribute vec4 aTc;"
            + "varying vec2 vTc;void main(){gl_Position=uMvp*aPos;vTc=(uTm*aTc).xy;}";
    private static final String FS = "#extension GL_OES_EGL_image_external : require\n"
            + "precision mediump float;varying vec2 vTc;uniform samplerExternalOES sTex;"
            + "void main(){gl_FragColor=texture2D(sTex,vTc);}";

    private static final String VS2 = "attribute vec2 aPos;attribute vec2 aTc;varying vec2 vTc;"
            + "void main(){gl_Position=vec4(aPos,0.0,1.0);vTc=aTc;}";
    private static final String FS2 = "precision mediump float;varying vec2 vTc;uniform sampler2D sTex;uniform float uAlpha;"
            + "void main(){gl_FragColor=texture2D(sTex,vTc)*uAlpha;}";
    // Фрагментный шейдер цвета: порт vidGpu из редактора (тон, HSL, колёса, кривые, резкость, зерно) + цепочка CSS-фильтров
    // (яркость, контраст, насыщенность, пресеты, оттенок). Вариант с #define TONE содержит тоновую коррекцию.
    private static final String FX_HEAD = "#extension GL_OES_EGL_image_external : require\n"
            + "#ifdef GL_FRAGMENT_PRECISION_HIGH\n" + "precision highp float;\n" + "#else\n" + "precision mediump float;\n" + "#endif\n";
    private static final String FX_BODY = ""
            + "varying vec2 vTc;varying vec2 vUv;\n"
            + "uniform samplerExternalOES sTex;\n"
            + "uniform float uOpsN;uniform vec2 uOps[12];\n"
            + "uniform float uGlOn;uniform float uGl;\n"
            + "uniform float uSeed;\n"
            + "#ifdef TONE\n"
            + "varying vec2 vTcL;varying vec2 vTcR;varying vec2 vTcU;varying vec2 vTcD;\n"
            + "uniform vec2 uSrc;uniform float uSharp;uniform float uGrain;\n"
            + "uniform float uOn;uniform float uPur;uniform float uCurOn;uniform sampler2D uLut;\n"
            + "uniform vec4 uA;uniform vec4 uB;uniform vec4 uHsl;\n"
            + "uniform float uMasks;uniform float uGamOn;uniform int uGN;uniform vec4 uGam[8];\n"
            + "uniform vec4 uWT[4];uniform vec4 uWL;uniform float uWOn;uniform vec4 uMask;uniform float uMaskMode;\n"
            + "float hash12(vec2 p){vec3 p3=fract(vec3(p.xyx)*.1031);p3+=dot(p3,p3.yzx+33.33);return fract((p3.x+p3.y)*p3.z);}\n"
            + "float lm(vec3 c){return .2126*c.r+.7152*c.g+.0722*c.b;}\n"
            + "vec3 rgb2hsl(vec3 c){c/=255.;float mx=max(c.r,max(c.g,c.b)),mn=min(c.r,min(c.g,c.b)),d=mx-mn,l=(mx+mn)*.5;float h=0.,s=0.;\n"
            + " if(d>.000001){float den=1.-abs(2.*l-1.);s=abs(den)<1e-9?1.:d/den;\n"
            + "  if(mx==c.r)h=(c.g-c.b)/d;else if(mx==c.g)h=(c.b-c.r)/d+2.;else h=(c.r-c.g)/d+4.;h=fract(h/6.+1.);}\n"
            + " return vec3(h,clamp(s,0.,1.),clamp(l,0.,1.));}\n"
            + "float h2c(float p,float q,float t){t=fract(t);if(t<1./6.)return p+(q-p)*6.*t;if(t<.5)return q;if(t<2./3.)return p+(q-p)*(2./3.-t)*6.;return p;}\n"
            + "vec3 hsl2rgb(float h,float s,float l){h=fract(h);s=clamp(s,0.,1.);l=clamp(l,0.,1.);if(s<.000001)return vec3(l*255.);\n"
            + " float q=l<.5?l*(1.+s):l+s-l*s;float p=2.*l-q;return vec3(h2c(p,q,h+1./3.),h2c(p,q,h),h2c(p,q,h-1./3.))*255.;}\n"
            + "vec3 pipe(vec3 c){\n"
            + " if(uOn>.5){\n"
            + "  if(uMasks>.5){float lum=lm(c)/255.;float hb=clamp((lum-.30)/.70,0.,1.),sb=clamp((.68-lum)/.68,0.,1.);float hm=hb*hb,sm=sb*sb;vec3 d=vec3(0.);\n"
            + "   float hA=uA.x,sA=uA.y;\n"
            + "   if(hA>=0.)d+=(255.-c)*.72*hm*hA;else d-=c*.68*hm*(-hA);\n"
            + "   if(sA>=0.)d+=(255.-c)*.40*sm*sA;else d-=c*.62*sm*(-sA);\n"
            + "   c=clamp(c+d,0.,255.);}\n"
            + "  float tA=uA.w;\n"
            + "  if(tA>0.){c.r+=(255.-c.r)*.34*tA;c.b-=c.b*.34*tA;}else if(tA<0.){float cl=-tA;c.r-=c.r*.34*cl;c.b+=(255.-c.b)*.34*cl;}\n"
            + "  float bA=uB.x;\n"
            + "  if(abs(bA)>.0001){float y=lm(c)/255.;float ty=y;\n"
            + "   if(bA>0.){float th=.22*bA;ty=y<=th?0.:(y-th)/(1.-th);}else{float lf=.22*(-bA);ty=(y+lf)/(1.+lf);}\n"
            + "   if(y>.0001){c*=ty/y;}else if(ty>0.){c=vec3(ty*255.);}}\n"
            + "  float dA=uA.z;\n"
            + "  if(abs(dA)>.0001){float mx=max(c.r,max(c.g,c.b)),mn=min(c.r,min(c.g,c.b));float sat=mx>0.?(mx-mn)/mx:0.;\n"
            + "   float gain=dA>=0.?1.+dA*(1.-sat):1.+dA;float y=lm(c);c=vec3(y)+(c-vec3(y))*gain;}\n"
            + "  if(uHsl.w>.5||uGamOn>.5){\n"
            + "   vec3 hs=rgb2hsl(c);float hh=hs.x,ss=hs.y,ll=hs.z;\n"
            + "   if(uHsl.w>.5){hh=fract(hh+uHsl.x+1.);float sa=uHsl.y;ss=sa>=0.?ss+(1.-ss)*sa:ss*(1.+sa);float la=uHsl.z;ll=la>=0.?ll+(1.-ll)*la:ll*(1.+la);}\n"
            + "   if(uGamOn>.5){float hd=hh*360.;\n"
            + "    for(int k=0;k<8;k++){if(k>=uGN)break;vec4 g=uGam[k];float dist=abs(hd-g.x);dist=min(dist,360.-dist);\n"
            + "     float w=clamp(1.-dist/48.,0.,1.);w=w*w*(3.-2.*w);if(w<.0001)continue;\n"
            + "     hh=fract(hh+g.y*w+1.);float sa=g.z*w;ss=sa>=0.?ss+(1.-ss)*sa:ss*(1.+sa);float la=g.w*w;ll=la>=0.?ll+(1.-ll)*la:ll*(1.+la);}}\n"
            + "   c=hsl2rgb(hh,ss,ll);}\n"
            + "  if(uWOn>.5){\n"
            + "   float yL=lm(c)/255.;float mw=1.;\n"
            + "   if(uMaskMode>.5){float nx=vUv.x,ny=1.-vUv.y;\n"
            + "    if(uMaskMode<1.5){float dx=nx-uMask.x,dy=ny-uMask.y;float dist=sqrt(dx*dx+dy*dy);mw=1.-clamp((dist-max(0.,uMask.z-uMask.w))/uMask.w,0.,1.);}\n"
            + "    else mw=1.-clamp(abs(nx-uMask.x)/.5,0.,1.);}\n"
            + "   float shT=clamp((.72-yL)/.72,0.,1.),hiT=clamp((yL-.28)/.72,0.,1.);\n"
            + "   float ww[4];ww[0]=shT*shT;ww[1]=clamp(1.-abs(yL-.5)/.42,0.,1.);ww[2]=hiT*hiT;ww[3]=1.;\n"
            + "   vec2 hv=vec2(0.);float hw=0.,ts=0.;\n"
            + "   for(int wi=0;wi<4;wi++){float wt=ww[wi]*mw;vec4 t=uWT[wi];float st=t.z*wt*.55;\n"
            + "    if(st>.0001){hv+=t.xy*st;hw+=st;ts+=st;}\n"
            + "    float la=uWL[wi]*wt;if(abs(la)>.0001){c+=la>=0.?(255.-c)*la:c*la;}}\n"
            + "   if(hw>.0001){float th=fract(atan(hv.y,hv.x)/6.28318530718);float st=clamp(ts,0.,1.);vec3 hs=rgb2hsl(c);\n"
            + "    float dh=fract(th-hs.x+1.5)-.5;float mx2=clamp(st*(.30+.56*(1.-hs.y)),0.,.82);\n"
            + "    c=hsl2rgb(hs.x+dh*mx2+1.,clamp(hs.y+(1.-hs.y)*st*.34,0.,1.),hs.z);}}\n"
            + "  if(abs(uPur)>.0001){float mx=max(c.r,max(c.g,c.b)),mn=min(c.r,min(c.g,c.b));\n"
            + "   if(mx>1.){float s=(mx-mn)/mx;if(s>.0001){float w=clamp((s-.02)/.23,0.,1.);w=w*w*(3.-2.*w);\n"
            + "    float s2=uPur>=0.?s+(1.-s)*uPur:s*(1.+uPur);float k=(s+(s2-s)*w)/s;c=vec3(mx)-(vec3(mx)-c)*k;}}}\n"
            + "  float fd=uB.y;\n"
            + "  if(fd>.0001){float y=lm(c);float cp=.18*fd,lf=25.5*fd,ds=.12*fd;c=(c*(1.-cp)+lf)*(1.-ds)+vec3(y)*ds;}\n"
            + "  if(uCurOn>.5){vec3 cc=clamp(c,0.,255.);\n"
            + "   c=vec3(texture2D(uLut,vec2((cc.r+.5)/256.,.5)).r,texture2D(uLut,vec2((cc.g+.5)/256.,.5)).g,texture2D(uLut,vec2((cc.b+.5)/256.,.5)).b)*255.;}\n"
            + "  c=clamp(c,0.,255.);}\n"
            + " return c;}\n"
            + "#endif\n"
            + "vec3 hueRot(vec3 c,float a){float cs=cos(a),sn=sin(a);\n"
            + " return vec3(dot(c,vec3(.213+cs*.787-sn*.213,.715-cs*.715-sn*.715,.072-cs*.072+sn*.928)),\n"
            + "  dot(c,vec3(.213-cs*.213+sn*.143,.715+cs*.285+sn*.140,.072-cs*.072-sn*.283)),\n"
            + "  dot(c,vec3(.213-cs*.213-sn*.787,.715-cs*.715+sn*.715,.072+cs*.928+sn*.072)));}\n"
            + "vec3 cssOp(vec3 c,vec2 op){float t=op.x,v=op.y;\n"
            + " if(t<1.5){c=c*v;}\n"
            + " else if(t<2.5){c=(c-.5)*v+.5;}\n"
            + " else if(t<3.5){c=vec3(dot(c,vec3(.213+.787*v,.715-.715*v,.072-.072*v)),dot(c,vec3(.213-.213*v,.715+.285*v,.072-.072*v)),dot(c,vec3(.213-.213*v,.715-.715*v,.072+.928*v)));}\n"
            + " else if(t<4.5){float k=1.-v;c=vec3(dot(c,vec3(.2126+.7874*k,.7152-.7152*k,.0722-.0722*k)),dot(c,vec3(.2126-.2126*k,.7152+.2848*k,.0722-.0722*k)),dot(c,vec3(.2126-.2126*k,.7152-.7152*k,.0722+.9278*k)));}\n"
            + " else if(t<5.5){float k=1.-v;c=vec3(dot(c,vec3(.393+.607*k,.769-.769*k,.189-.189*k)),dot(c,vec3(.349-.349*k,.686+.314*k,.168-.168*k)),dot(c,vec3(.272-.272*k,.534-.534*k,.131+.869*k)));}\n"
            + " else{c=hueRot(c,v);}\n"
            + " return clamp(c,0.,1.);}\n"
            + "uniform vec4 uVA;uniform vec4 uVB;uniform vec4 uVC;uniform vec2 uVDim;uniform float uVShape;uniform sampler2D uVSdf;\n"
            + "float vdec(vec4 s){return (s.r*65280.+s.g*255.)/65535.*6.-3.;}\n"
            + "vec3 vigApply(vec3 c){\n"
            + " if(uVC.w<.5)return c;\n"
            + " vec2 p=vec2((vUv.x-.5)*uVDim.x,(.5-vUv.y)*uVDim.y);\n"
            + " vec2 ctr=vec2((uVA.z-.5)*uVDim.x,(uVA.w-.5)*uVDim.y);\n"
            + " vec2 ab=max(uVB.xy*uVDim,vec2(1.));\n"
            + " vec2 q=(p-ctr)/ab;float d;\n"
            + " if(uVShape>.5){\n"
            + "  vec2 qc=clamp(q,-2.,2.);vec2 ov=q-qc;\n"
            + "  vec2 u=(qc*.25+.5)*256.-.5;vec2 i0=floor(u);vec2 f=u-i0;\n"
            + "  vec2 a0=clamp(i0,0.,255.),a1=clamp(i0+1.,0.,255.);\n"
            + "  vec4 s00=texture2D(uVSdf,(a0+.5)/256.);vec4 s10=texture2D(uVSdf,(vec2(a1.x,a0.y)+.5)/256.);\n"
            + "  vec4 s01=texture2D(uVSdf,(vec2(a0.x,a1.y)+.5)/256.);vec4 s11=texture2D(uVSdf,(a1+.5)/256.);\n"
            + "  float dq=mix(mix(vdec(s00),vdec(s10),f.x),mix(vdec(s01),vdec(s11),f.x),f.y)+length(ov);\n"
            + "  vec4 sn=mix(mix(s00,s10,step(.5,f.x)),mix(s01,s11,step(.5,f.x)),step(.5,f.y));\n"
            + "  float an=sn.b*6.28318530718;\n"
            + "  d=dq/max(length(vec2(cos(an),sin(an))/ab),1e-6);\n"
            + " }else{\n"
            + "  float r=length(q);float grad=length(q/ab)/max(r,1e-4);\n"
            + "  d=(r-1.)/max(grad,1e-6);\n"
            + " }\n"
            + " float m=1./(1.+exp(clamp(1.702*d/max(uVB.z,.5),-30.,30.)));\n"
            + " float ao=abs(uVA.x),ai=abs(uVA.y);\n"
            + " vec3 co=uVB.w>.5?uVC.rgb:vec3(uVA.x<0.?0.:1.);\n"
            + " vec3 ci=uVB.w>.5?uVC.rgb:vec3(uVA.y<0.?0.:1.);\n"
            + " if(ao>=.001)c=mix(c,co,ao*(1.-m));\n"
            + " if(ai>=.001)c=mix(c,ci,ai*m);\n"
            + " return c;}\n"
            + "void main(){\n"
            + " vec4 s=texture2D(sTex,vTc);vec3 c=s.rgb*255.;\n"
            + "#ifdef TONE\n"
            + " c=pipe(c);\n"
            + " if(uSharp>0.){vec2 f=vUv*uSrc;\n"
            + "  if(f.x>1.&&f.y>1.&&f.x<uSrc.x-1.&&f.y<uSrc.y-1.){\n"
            + "   vec3 n=pipe(texture2D(sTex,vTcR).rgb*255.)+pipe(texture2D(sTex,vTcL).rgb*255.)+pipe(texture2D(sTex,vTcU).rgb*255.)+pipe(texture2D(sTex,vTcD).rgb*255.);\n"
            + "   c=clamp(c+uSharp*(4.*c-n),0.,255.);}}\n"
            + " if(uGrain>0.)c+=(hash12(gl_FragCoord.xy+vec2(uSeed,uSeed*1.618))*2.-1.)*uGrain;\n"
            + "#endif\n"
            + " c=clamp(c,0.,255.)/255.;\n"
            + " for(int i=0;i<12;i++){if(float(i)>=uOpsN)break;c=cssOp(c,uOps[i]);}\n"
            + " if(uGlOn>.5)c=clamp(hueRot(c,uGl),0.,1.);\n"
            + " c=vigApply(c);\n"
            + " gl_FragColor=vec4(c,1.);}\n";
    private static final String FX_VS = "uniform mat4 uMvp;uniform mat4 uTm;uniform vec2 uTexel;attribute vec4 aPos;attribute vec4 aTc;"
            + "varying vec2 vTc;varying vec2 vUv;varying vec2 vTcL;varying vec2 vTcR;varying vec2 vTcU;varying vec2 vTcD;"
            + "void main(){gl_Position=uMvp*aPos;vTc=(uTm*aTc).xy;vUv=aTc.xy;"
            + "vTcL=(uTm*(aTc-vec4(uTexel.x,0.,0.,0.))).xy;vTcR=(uTm*(aTc+vec4(uTexel.x,0.,0.,0.))).xy;"
            + "vTcD=(uTm*(aTc-vec4(0.,uTexel.y,0.,0.))).xy;vTcU=(uTm*(aTc+vec4(0.,uTexel.y,0.,0.))).xy;}";
    // Эффекты видео поверх всего кадра (как applyVideoEffect в редакторе): виньетка (радиальный градиент 0 -> 0.55) и зерно (шум, прозрачность 0.08 / 0.05).
    private static final String FS_EFF = "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
            + "uniform vec2 uRes;uniform float uVig;uniform float uGr;uniform float uSeed;"
            + "float hash12(vec2 p){vec3 p3=fract(vec3(p.xyx)*.1031);p3+=dot(p3,p3.yzx+33.33);return fract((p3.x+p3.y)*p3.z);}"
            + "void main(){float av=0.;"
            + "if(uVig>.5){vec2 d=gl_FragCoord.xy-uRes*.5;float r0=min(uRes.x,uRes.y)*.35;float r1=max(uRes.x,uRes.y)*.75;"
            + "float t=clamp((length(d)-r0)/(r1-r0),0.,1.);av=.55*t;}"
            + "float v=hash12(gl_FragCoord.xy+vec2(uSeed,uSeed*1.618));"
            + "float a=1.-(1.-av)*(1.-uGr);gl_FragColor=vec4(vec3(v*uGr),a);}";

    private static final String VS3 = "attribute vec2 aPos;void main(){gl_Position=vec4(aPos,0.0,1.0);}";
    private static final String FS3 = "precision mediump float;uniform vec4 uColor;void main(){gl_FragColor=uColor;}";

    final KxBridge br;
    final String jobId;
    final List<String> unsupported = new ArrayList<String>();
    private final List<Clip> clips = new ArrayList<Clip>();
    private double fps = 30;
    private int outW;
    private int outH;
    private int bitrate;
    private String outName = "kadr-export.mp4";
    private boolean decodeOnly;
    private boolean noEnc;
    private boolean audioCopy;
    private boolean glFinish;
    private boolean threads = true;

    private volatile boolean cancelled;
    private volatile boolean aborted;
    private volatile boolean finished;
    private volatile boolean stopFeed;
    private volatile boolean stopDrain;
    private volatile Throwable bgFail;
    private Thread drainer;
    private volatile long lastProgress;
    private final AtomicBoolean finalSent = new AtomicBoolean();
    private long t0;
    private long lastEmit;
    private double totalSec;
    private double tailSec;
    private long tailEndTick;
    private long totalTicks;
    private long k;
    private long framesOut;
    private long framesDec;
    private long feedNs;
    private long waitNs;
    private long updNs;
    private long drawNs;
    private long swapNs;
    private long encNs;
    private long muxNs;
    // детальный тайминг (production: без glFinish, значит draw-фазы = CPU-подача команд; блокировка энкодером видна в clearNs)
    private long clearNs;          // glViewport+glClear: первая GL-операция кадра ждёт свободный буфер входной Surface энкодера (backpressure)
    private long quadNs;
    private long shadeNs;
    private long ovNs;
    private long deqNs;            // dequeueOutputBuffer (в потоке-дрейнере включает ожидание, это не узкое место)
    private long muxVideoNs;
    private long muxAudioNs;
    private long copyNs;           // копия готового файла из кэша в MediaStore
    private long prepareNs;
    private long ovLoadNs;
    private long firstFrameMs;
    private long encOutFrames;     // сэмплов энкодера, записанных в muxer (= реально закодированные кадры)
    private int glFinishCalls;
    private float ovAlphaSet = -1f;
    private String outMode = "direct";
    private File tmpOut;
    private RandomAccessFile tmpRaf;
    private final MediaCodec.BufferInfo audBi = new MediaCodec.BufferInfo();
    private String decNames = "";
    private boolean decSw;
    private int decAttempt = -1;
    private int encAttempt = -1;
    private String decMime = "";
    private double srcFpsMeta;
    private String srcFmt = "";
    private String decPref = "";
    private String decCands = "";

    // звук: копирование сжатой AAC-дорожки исходника без перекодирования
    private MediaFormat aFmt;
    private boolean audioMissing;
    private int aTrack = -1;
    private int aPos;
    private long aBytes;
    private final ArrayList<Aud> aq = new ArrayList<Aud>();

    // кодеки, muxer, вывод
    private volatile MediaCodec enc;
    private volatile MediaCodec curDec;
    private Surface encSurface;
    private MediaMuxer muxer;
    private boolean muxStarted;
    private int vTrack = -1;
    private ParcelFileDescriptor pfd;
    private Uri outUri;
    private boolean outFinal;
    private long outSize;
    private String encName = "";
    private boolean encHw;
    private final MediaCodec.BufferInfo binfo = new MediaCodec.BufferInfo();

    // EGL / GL
    private EGLDisplay eglDpy;
    private EGLContext eglCtx;
    private EGLSurface eglSurf;
    private boolean eglUp;
    private int tex;
    private int prog;
    private int progOv;
    private int uOvAlpha;
    private int uOvTex;
    private int progFlat;
    private int progEff;
    private int uEffRes;
    private int uEffVig;
    private int uEffGr;
    private int uEffSeed;
    private FxProg fpCss;
    private FxProg fpTone;
    private int lutDummy;
    private int curLutTex;
    private String effect = "none";
    private float fitSx = 1f;
    private float fitSy = 1f;
    private int uFlatColor;
    private final ArrayList<Ovl> ovls = new ArrayList<Ovl>();
    private Clip curClip;
    private FloatBuffer ovBuf;
    private final float[] ovV = new float[16];
    private int uMvp;
    private int uTm;
    private SurfaceTexture st;
    private Surface decSurface;
    private HandlerThread frameThread;
    private final Object frameLock = new Object();
    private boolean frameAvail;
    private final float[] mvp = new float[16];
    private final float[] texMatrix = new float[16];
    private FloatBuffer posBuf;
    private FloatBuffer tcBuf;

    // сведения об исходнике (для диагностики и расчёта вписывания)
    private int rotation;
    private int srcW;
    private int srcH;
    private String dimsInfo = "";

    private Exporter(KxBridge br, String jobId) {
        this.br = br;
        this.jobId = jobId;
    }

    private void uns(String s) {
        if (!unsupported.contains(s)) unsupported.add(s);
    }

    // ---------- разбор задания ----------

    static Exporter parse(KxBridge br, String jobId, JSONObject job) throws Exception {
        Exporter e = new Exporter(br, jobId);
        if (job.optInt("v", 1) != 1) e.uns("v");
        JSONObject out = job.optJSONObject("output");
        if (out == null) {
            e.uns("output");
            return e;
        }
        e.outW = out.optInt("w");
        e.outH = out.optInt("h");
        e.fps = out.optDouble("fps", 30);
        if (e.outW < 16 || e.outH < 16 || e.outW > 4096 || e.outH > 4096) e.uns("size");
        if (!(e.fps >= 1 && e.fps <= 120)) e.uns("fps");
        String vc = out.optString("vcodec", "avc");
        if (!"avc".equals(vc)) e.uns("vcodec:" + vc);
        e.bitrate = out.optInt("bitrate", 0);
        String nm = out.optString("name", "kadr-export.mp4").replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        if (nm.length() == 0) nm = "kadr-export.mp4";
        if (!nm.toLowerCase().endsWith(".mp4")) nm = nm + ".mp4";
        e.outName = nm;
        String bench = job.optString("bench");
        e.decodeOnly = "decodeOnly".equals(bench);
        e.noEnc = "decodeGl".equals(bench);
        e.audioCopy = "source".equals(job.optString("audioMode"));
        e.glFinish = "finish".equals(job.optString("diag"));
        double tl = job.optDouble("tail", 0);
        e.tailSec = (tl > 0 && tl < 3600) ? tl : 0;
        e.threads = !"off".equals(job.optString("threads"));
        e.decPref = job.optString("decoder", "");
        String eff = job.optString("effect", "none");
        if ("none".equals(eff) || "glitch".equals(eff) || "vignette".equals(eff) || "film".equals(eff) || "grain".equals(eff)) e.effect = eff;
        else e.uns("effect:" + eff);
        JSONObject bg = job.optJSONObject("background");
        if (bg != null && "blur".equals(bg.optString("mode"))) e.uns("background:blur");
        JSONArray ov = job.optJSONArray("overlays");
        if (ov != null) {
            for (int i = 0; i < ov.length(); i++) {
                JSONObject m = ov.getJSONObject(i);
                String kind = m.optString("kind", "image");
                if (!"image".equals(kind)) {
                    e.uns("overlay:" + kind);
                    continue;
                }
                if (!m.isNull("anim")) {
                    e.uns("overlay:anim");
                    continue;
                }
                Src s = br.srcFor(m.optString("src", ""));
                if (s == null) {
                    e.uns("overlay-src");
                    continue;
                }
                Ovl o = new Ovl();
                o.src = s;
                o.t0 = m.optDouble("t0", 0);
                o.t1 = m.optDouble("t1", 1e9);
                o.x = m.optDouble("x", 0.5);
                o.y = m.optDouble("y", 0.5);
                o.w = m.optDouble("w", 0.3);
                o.h = m.optDouble("h", 0);
                o.raw = m.optBoolean("raw", false);
                o.rot = m.optDouble("rot", 0);
                o.opacity = m.optDouble("opacity", 1);
                double fiv = m.optDouble("fi", 0);
                double fov = m.optDouble("fo", 0);
                o.fi = fiv > 0 ? fiv : 0;
                o.fo = fov > 0 ? fov : 0;
                e.ovls.add(o);
            }
        }
        JSONArray au = job.optJSONArray("audio");
        if (au != null && au.length() > 0) e.uns("audio");
        JSONArray main = job.optJSONArray("main");
        if (main == null || main.length() == 0) {
            e.uns("main:empty");
            return e;
        }
        for (int i = 0; i < main.length(); i++) {
            JSONObject m = main.getJSONObject(i);
            String kind = m.optString("kind", "video");
            if (!"video".equals(kind)) {
                e.uns("kind:" + kind);
                continue;
            }
            if (m.optDouble("speed", 1.0) != 1.0) e.uns("speed");
            if (m.optInt("rot", 0) != 0) e.uns("rot");
            if (m.optBoolean("flipH", false)) e.uns("flipH");
            JSONObject z = m.optJSONObject("zoom");
            if (z != null && (z.optDouble("from", 1) != 1 || z.optDouble("to", 1) != 1)) e.uns("zoom");
            JSONObject f = m.optJSONObject("filter");
            if (f != null && !(f.optDouble("brightness", 0) == 0 && f.optDouble("contrast", 1) == 1
                    && f.optDouble("saturation", 1) == 1 && f.isNull("preset"))) e.uns("filter");
            String trType = null;
            double trDur = 0.45;
            JSONObject tr = m.optJSONObject("transitionOut");
            if (tr != null) {
                String ty = tr.optString("type", "none");
                if ("fade".equals(ty) || "white".equals(ty)) {
                    trDur = tr.optDouble("dur", 0.45);
                    if (trDur > 0) trType = ty;
                } else if (!"none".equals(ty)) {
                    e.uns("transition:" + ty);
                }
            }
            String src = m.optString("src", "");
            Src source = br.srcFor(src);
            if (source == null) {
                e.uns("src:" + src);
                continue;
            }
            Clip c = new Clip();
            c.src = source;
            c.in = m.optDouble("in", 0);
            c.out = m.optDouble("out", 0);
            c.cover = "cover".equals(m.optString("fit", "contain"));
            JSONObject fxj = m.optJSONObject("fx");
            if (fxj != null) e.parseFx(c, fxj);
            c.trOut = trType;
            c.trOutDur = trDur;
            e.clips.add(c);
        }
        return e;
    }

    // ---------- цвет и эффекты клипа: разбор ----------

    private static float[] farr(JSONArray a, int n) {
        float[] r = new float[n];
        if (a != null) {
            for (int i = 0; i < n && i < a.length(); i++) r[i] = (float) a.optDouble(i, 0);
        }
        return r;
    }

    private void parseFx(Clip c, JSONObject fx) {
        String css = fx.optString("css", "");
        if (css.length() > 0) parseCss(c, css);
        JSONObject t = fx.optJSONObject("tone");
        if (t != null) c.tone = parseTone(t);
        String lut = fx.optString("lut", "");
        if (lut.length() > 0) {
            try {
                c.lut = Base64.decode(lut, Base64.DEFAULT);
            } catch (Throwable ex) {
                c.lut = null;
            }
            if (c.lut == null || c.lut.length != 1024) {
                c.lut = null;
                uns("fx:lut");
            }
        }
        JSONArray ve = fx.optJSONArray("vigE");
        if (ve != null) c.vigC = farr(ve, 12);
        JSONObject an = fx.optJSONObject("anim");
        if (an != null) {
            int n = an.optInt("n", 0);
            if (n > 0 && n < 2000000) {
                c.aN = n;
                c.aZoom = an.optJSONArray("zoom") != null ? farr(an.optJSONArray("zoom"), n) : null;
                c.aOffX = an.optJSONArray("offX") != null ? farr(an.optJSONArray("offX"), n) : null;
                c.aOffY = an.optJSONArray("offY") != null ? farr(an.optJSONArray("offY"), n) : null;
                c.aRot = an.optJSONArray("rot") != null ? farr(an.optJSONArray("rot"), n) : null;
                c.aVig = an.optJSONArray("vig") != null ? farr(an.optJSONArray("vig"), n * 12) : null;
                c.aOps = an.optJSONArray("ops") != null ? farr(an.optJSONArray("ops"), n * 24) : null;
                c.aOpsN = an.optJSONArray("opsN") != null ? farr(an.optJSONArray("opsN"), n) : null;
                c.aTone = an.optJSONArray("toneT") != null ? farr(an.optJSONArray("toneT"), n * 15) : null;
                if (c.aOpsN == null) c.aOps = null;
                c.aGam = an.optJSONArray("gamT") != null ? farr(an.optJSONArray("gamT"), n * 59) : null;
                if (c.aTone == null) c.aGam = null;
                if (c.aTone != null && c.tone == null) c.tone = new Tone();   // нужен вариант шейдера с тоновой коррекцией
            } else {
                uns("fx:anim");
            }
        }
        String vsh = fx.optString("vigShape", "");
        if (vsh.length() > 0) {
            Src ss = br.srcFor(vsh);
            int sn = fx.optInt("vigShapeN", 0);
            if (ss == null || sn <= 0) {
                uns("fx:vig-shape-src");
            } else {
                c.vShapeSrc = ss;
                c.vShapeId = vsh;
                c.vShapeN = sn;
            }
        }
        String vig = fx.optString("vig", "");
        if (vig.length() > 0) {
            Src s = br.srcFor(vig);
            if (s == null) {
                uns("fx:vig-src");
            } else {
                Ovl o = new Ovl();
                o.src = s;
                o.x = 0.5;
                o.y = 0.5;
                o.w = 1;
                o.h = 1;
                o.under = true;
                o.t0 = 1e9;
                o.t1 = 1e9;
                ovls.add(o);
                c.vig = o;
            }
        }
    }

    /** Цепочка CSS-фильтров в том же порядке, как её строит редактор (buildFilterString): brightness, contrast, saturate, grayscale, sepia, hue-rotate. */
    private void parseCss(Clip c, String css) {
        ArrayList<float[]> ops = new ArrayList<float[]>();
        int i = 0;
        int n = css.length();
        while (i < n) {
            while (i < n && Character.isWhitespace(css.charAt(i))) i++;
            if (i >= n) break;
            int p = css.indexOf('(', i);
            int q = p < 0 ? -1 : css.indexOf(')', p);
            if (p < 0 || q < 0) {
                uns("css:syntax");
                return;
            }
            String name = css.substring(i, p).trim();
            String val = css.substring(p + 1, q).trim();
            i = q + 1;
            double v;
            try {
                if (val.endsWith("%")) v = Double.parseDouble(val.substring(0, val.length() - 1)) / 100.0;
                else if (val.endsWith("deg")) v = Math.toRadians(Double.parseDouble(val.substring(0, val.length() - 3)));
                else v = Double.parseDouble(val);
            } catch (NumberFormatException ex) {
                uns("css:value");
                return;
            }
            int t;
            if ("brightness".equals(name)) t = 1;
            else if ("contrast".equals(name)) t = 2;
            else if ("saturate".equals(name)) t = 3;
            else if ("grayscale".equals(name)) t = 4;
            else if ("sepia".equals(name)) t = 5;
            else if ("hue-rotate".equals(name)) t = 6;
            else {
                uns("css:" + name);
                return;
            }
            ops.add(new float[] {t, (float) v});
        }
        if (ops.size() > 12) {
            uns("css:too-many");
            return;
        }
        c.opsN = ops.size();
        for (int k = 0; k < ops.size(); k++) {
            c.ops[k * 2] = ops.get(k)[0];
            c.ops[k * 2 + 1] = ops.get(k)[1];
        }
    }

    private static Tone parseTone(JSONObject j) {
        Tone t = new Tone();
        t.on = j.optBoolean("on", false);
        t.masks = j.optBoolean("masks", false);
        t.wOn = j.optBoolean("wOn", false);
        t.hi = (float) j.optDouble("hi", 0);
        t.sh = (float) j.optDouble("sh", 0);
        t.dyn = (float) j.optDouble("dyn", 0);
        t.temp = (float) j.optDouble("temp", 0);
        t.black = (float) j.optDouble("black", 0);
        t.fade = (float) j.optDouble("fade", 0);
        t.pur = (float) j.optDouble("pur", 0);
        t.sharp = (float) j.optDouble("sharp", 0);
        t.grain = (float) j.optDouble("grain", 0);
        t.hsl = farr(j.optJSONArray("hsl"), 4);
        t.gamN = Math.max(0, Math.min(8, j.optInt("gamN", 0)));
        t.gam = farr(j.optJSONArray("gam"), 32);
        t.wt = farr(j.optJSONArray("wt"), 16);
        t.wl = farr(j.optJSONArray("wl"), 4);
        t.maskMode = j.optInt("maskMode", 0);
        t.mask = farr(j.optJSONArray("mask"), 4);
        return t;
    }

    // ---------- запуск / отмена / сторож ----------

    void start() {
        t0 = SystemClock.elapsedRealtime();
        lastProgress = t0;
        new Thread(this, "kx-export").start();
        Thread wd = new Thread(new Runnable() {
            public void run() {
                watchdog();
            }
        }, "kx-watchdog");
        wd.setDaemon(true);
        wd.start();
    }

    void cancel() {
        cancelled = true;
    }

    private void pulse() {
        lastProgress = SystemClock.elapsedRealtime();
    }

    private void check() throws Fail {
        if (cancelled) throw new Fail("cancelled", "cancelled", false);
        if (aborted) throw new Fail("timeout", "no progress for " + (STALL_MS / 1000) + " s", true);
        Throwable b = bgFail;
        if (b instanceof Fail) throw (Fail) b;
        if (b != null) throw new Fail("bg_thread", String.valueOf(b), true);
    }

    private void watchdog() {
        long abortedAt = 0;
        while (!finished) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (!aborted && now - lastProgress > STALL_MS) {
                aborted = true;
                abortedAt = now;
                Log.w(TAG, "stalled, aborting " + jobId);
            }
            if (aborted && abortedAt != 0 && now - abortedAt > 5000 && !finished) {
                abortedAt = Long.MAX_VALUE / 2;
                try {
                    MediaCodec e = enc;
                    if (e != null) e.release();
                } catch (Throwable ignored) {
                    // уже освобождён
                }
                try {
                    MediaCodec d = curDec;
                    if (d != null) d.release();
                } catch (Throwable ignored) {
                    // уже освобождён
                }
            }
        }
    }

    @Override
    public void run() {
        Throwable fail = null;
        try {
            br.keepScreenOn(true);
            if (decodeOnly) benchDecode();
            else export();
        } catch (Throwable t) {
            fail = t;
            Log.w(TAG, "job failed", t);
        }
        cleanup(fail == null);
        br.keepScreenOn(false);
        br.jobDone(jobId);
        finished = true;
        if (finalSent.getAndSet(true)) return;
        long total = SystemClock.elapsedRealtime() - t0;
        if (fail == null) {
            long frames = (decodeOnly ? framesDec : framesOut);
            JSONObject timing = KxBridge.o("totalMs", total, "decodeMs", (waitNs + updNs) / 1000000,
                    "glMs", (drawNs + swapNs) / 1000000, "encodeMs", encNs / 1000000,
                    "feedMs", feedNs / 1000000, "waitMs", waitNs / 1000000, "updMs", updNs / 1000000,
                    "drawMs", drawNs / 1000000, "swapMs", swapNs / 1000000,
                    "frames", frames, "decodedFrames", framesDec,
                    "fps", Math.round(frames * 100000.0 / Math.max(1, total)) / 100.0,
                    "codec", encName, "hw", encHw, "w", outW, "h", outH, "bitrate", bitrate,
                    "rotation", rotation, "srcW", srcW, "srcH", srcH, "dims", dimsInfo,
                    "tm", Arrays.toString(Arrays.copyOf(texMatrix, 6)),
                    "bench", decodeOnly ? "decodeOnly" : (noEnc ? "decodeGl" : "full"),
                    "audio", aFmt != null ? "copied" : (audioCopy ? "none" : "off"), "threads", threads, "overlays", ovls.size(),
                    "audioFrames", aq.size(), "audioKB", aBytes / 1024, "glFinish", glFinish,
                    "muxMs", muxNs / 1000000, "decoder", decNames, "decSw", decSw, "decAttempt", decAttempt,
                    "encAttempt", encAttempt, "decMime", decMime, "srcFpsMeta", srcFpsMeta, "srcFmt", srcFmt,
                    "decCands", decCands, "decPref", decPref,
                    "outFps", fps, "expectedOutputFrames", totalTicks, "outputEncodedFrames", encOutFrames,
                    "inputDecodedFrames", framesDec,
                    "exportDurationSec", Math.round(totalTicks / fps * 100.0) / 100.0,
                    "measuredRealtimeFactor", Math.round((totalTicks / fps) / Math.max(0.001, total / 1000.0) * 100.0) / 100.0,
                    "glFinishCalls", glFinishCalls,
                    "clearMs", clearNs / 1000000, "quadMs", quadNs / 1000000, "shadeMs", shadeNs / 1000000, "ovMs", ovNs / 1000000,
                    "deqMs", deqNs / 1000000, "muxVideoMs", muxVideoNs / 1000000, "muxAudioMs", muxAudioNs / 1000000,
                    "copyMs", copyNs / 1000000, "prepareMs", prepareNs / 1000000, "overlayLoadMs", ovLoadNs / 1000000,
                    "firstFrameMs", firstFrameMs, "outMode", outMode);
            br.emit(KxBridge.o("type", "done", "job", jobId, "uri", outUri == null ? "" : outUri.toString(),
                    "size", outSize, "ms", total, "timing", timing));
            return;
        }
        String code = "exception";
        String msg = String.valueOf(fail);
        boolean rec = true;
        if (cancelled) {
            code = "cancelled";
            msg = "cancelled";
            rec = false;
        } else if (fail instanceof Fail) {
            code = ((Fail) fail).code;
            msg = fail.getMessage();
            rec = ((Fail) fail).recoverable;
        } else if (aborted) {
            code = "timeout";
        }
        br.emit(KxBridge.o("type", "error", "job", jobId, "code", code, "message", msg, "recoverable", rec));
    }

    // ---------- подготовка ----------

    private void prepare() throws Exception {
        double acc = 0;
        for (Clip c : clips) {
            MediaExtractor ex = new MediaExtractor();
            try {
                c.src.open(ex, br.act);
                c.vtrack = -1;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("video/")) {
                        c.vtrack = i;
                        break;
                    }
                }
                if (c.vtrack < 0) throw new Fail("no_video", "no video track", true);
                MediaFormat f = ex.getTrackFormat(c.vtrack);
                long dur = f.containsKey(MediaFormat.KEY_DURATION) ? f.getLong(MediaFormat.KEY_DURATION) : 0;
                c.inUs = (long) (c.in * 1e6);
                c.outUs = c.out > 0 ? (long) (c.out * 1e6) : dur;
                if (dur > 0 && c.outUs > dur) c.outUs = dur;
                if (c.outUs <= c.inUs) throw new Fail("bad_range", "empty time range", true);
                c.startUs = acc * 1e6;
                c.kStart = Math.round(acc * fps);
                acc += (c.outUs - c.inUs) / 1e6;
                c.kEnd = Math.round(acc * fps);
                if (audioCopy && !decodeOnly && !noEnc) collectAudio(c, ex);
            } finally {
                ex.release();
            }
        }
        totalSec = acc + (decodeOnly ? 0 : tailSec);
        totalTicks = clips.get(clips.size() - 1).kEnd;
        tailEndTick = totalTicks;
        if (tailSec > 0 && !decodeOnly) {
            tailEndTick = Math.max(totalTicks, Math.round((acc + tailSec) * fps));
            totalTicks = tailEndTick;
        }
        for (int i = 0; i < clips.size(); i++) {
            if (i > 0) {
                clips.get(i).trIn = clips.get(i - 1).trOut;
                clips.get(i).trInDur = clips.get(i - 1).trOutDur;
            }
        }
        clips.get(clips.size() - 1).trOut = null;
    }

    private static MediaCodecInfo findEncoder(String mime) {
        MediaCodecInfo best = null;
        for (MediaCodecInfo ci : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            if (!ci.isEncoder()) continue;
            boolean has = false;
            for (String t : ci.getSupportedTypes()) {
                if (t.equalsIgnoreCase(mime)) has = true;
            }
            if (!has) continue;
            if (Probe.isHw(ci)) return ci;
            if (best == null) best = ci;
        }
        return best;
    }

    private int autoBitrate() {
        double effFps = fps <= 30 ? fps : 30 + (fps - 30) * 0.6;
        double b = outW * (double) outH * effFps * 0.2;
        return (int) Math.max(2000000, Math.min(45000000, b));
    }

    private MediaCodec configureEncoder(MediaCodecInfo ci, String mime) throws Fail {
        MediaCodecInfo.CodecCapabilities cc = ci.getCapabilitiesForType(mime);
        boolean high = false;
        for (MediaCodecInfo.CodecProfileLevel pl : cc.profileLevels) {
            if (pl.profile == MediaCodecInfo.CodecProfileLevel.AVCProfileHigh) high = true;
        }
        boolean vbr = cc.getEncoderCapabilities()
                .isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);
        Exception last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            MediaCodec c = null;
            try {
                c = MediaCodec.createByCodecName(ci.getName());
                MediaFormat f = MediaFormat.createVideoFormat(mime, outW, outH);
                f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                f.setInteger(MediaFormat.KEY_FRAME_RATE, (int) Math.round(fps));
                f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
                if (attempt < 2) {
                    if (vbr) f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);
                    f.setInteger(MediaFormat.KEY_PRIORITY, 1);
                    f.setInteger(MediaFormat.KEY_OPERATING_RATE, Short.MAX_VALUE);
                }
                if (attempt == 0 && high) {
                    f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh);
                }
                c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                Log.i(TAG, "encoder " + ci.getName() + " configured, attempt " + attempt);
                encAttempt = attempt;
                return c;
            } catch (Exception ex) {
                last = ex;
                Log.w(TAG, "encoder configure attempt " + attempt + " failed", ex);
                if (c != null) {
                    try {
                        c.release();
                    } catch (Throwable ignored) {
                        // не создан до конца
                    }
                }
            }
        }
        throw new Fail("encoder_configure", String.valueOf(last), true);
    }

    private MediaCodec createDec(String mime) throws Exception {
        String want = decPref;
        String pick = null;
        StringBuilder cands = new StringBuilder();
        for (MediaCodecInfo ci : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            if (ci.isEncoder() || ci.getName().endsWith(".secure")) continue;
            boolean has = false;
            for (String t : ci.getSupportedTypes()) {
                if (t.equalsIgnoreCase(mime)) has = true;
            }
            if (!has) continue;
            boolean hw = Probe.isHw(ci);
            if (cands.length() > 0) cands.append(",");
            cands.append(ci.getName()).append(hw ? "[hw]" : "[sw]");
            if (pick == null && want.length() > 0) {
                if ("hw".equals(want) && hw) pick = ci.getName();
                else if ("sw".equals(want) && !hw) pick = ci.getName();
                else if (want.equals(ci.getName())) pick = ci.getName();
            }
        }
        decCands = cands.toString();
        if (pick != null) return MediaCodec.createByCodecName(pick);
        return MediaCodec.createDecoderByType(mime);
    }

    private void noteDecoder(MediaCodec d, int attempt) {
        try {
            String n = d.getName();
            boolean sw = false;
            for (MediaCodecInfo ci : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
                if (ci.getName().equals(n)) {
                    sw = !Probe.isHw(ci);
                    break;
                }
            }
            String tag = n + (sw ? "[sw]" : "[hw]") + "#" + attempt;
            if (!decNames.contains(tag)) decNames = decNames.length() == 0 ? tag : decNames + "," + tag;
            if (sw) decSw = true;
            decAttempt = attempt;
        } catch (Throwable t) {
            Log.w(TAG, "noteDecoder failed", t);
        }
    }

    private static int geti(MediaFormat f, String k) {
        try {
            return f.containsKey(k) ? f.getInteger(k) : -1;
        } catch (Throwable t) {
            return -1;
        }
    }

    private void noteSource(String mime, MediaFormat f) {
        decMime = mime;
        double fr = 0;
        if (f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
            try {
                fr = f.getInteger(MediaFormat.KEY_FRAME_RATE);
            } catch (Throwable t) {
                try {
                    fr = f.getFloat(MediaFormat.KEY_FRAME_RATE);
                } catch (Throwable t2) {
                    fr = 0;
                }
            }
        }
        srcFpsMeta = fr;
        srcFmt = "profile=" + geti(f, MediaFormat.KEY_PROFILE) + " level=" + geti(f, MediaFormat.KEY_LEVEL)
                + " std=" + geti(f, MediaFormat.KEY_COLOR_STANDARD) + " tr=" + geti(f, MediaFormat.KEY_COLOR_TRANSFER)
                + " range=" + geti(f, MediaFormat.KEY_COLOR_RANGE) + " bitrate=" + geti(f, MediaFormat.KEY_BIT_RATE);
    }

    private MediaCodec openDecoder(String mime, MediaFormat fmt, Surface s) throws Fail {
        Exception last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            MediaCodec d = null;
            try {
                if (attempt == 0) {
                    fmt.setInteger(MediaFormat.KEY_PRIORITY, 1);
                    fmt.setInteger(MediaFormat.KEY_OPERATING_RATE, Short.MAX_VALUE);
                } else {
                    fmt.removeKey(MediaFormat.KEY_PRIORITY);
                    fmt.removeKey(MediaFormat.KEY_OPERATING_RATE);
                }
                d = createDec(mime);
                d.configure(fmt, s, null, 0);
                noteDecoder(d, attempt);
                return d;
            } catch (Exception ex) {
                last = ex;
                Log.w(TAG, "decoder configure attempt " + attempt + " failed", ex);
                if (d != null) {
                    try {
                        d.release();
                    } catch (Throwable ignored) {
                        // не создан до конца
                    }
                }
            }
        }
        throw new Fail("decoder_configure", String.valueOf(last), true);
    }

    // ---------- основной сценарий ----------

    private void export() throws Exception {
        MediaCodecInfo ci = null;
        if (!noEnc) {
            ci = findEncoder("video/avc");
            if (ci == null) throw new Fail("no_encoder", "no AVC encoder", true);
            encName = ci.getName();
            encHw = Probe.isHw(ci);
            MediaCodecInfo.VideoCapabilities vc = ci.getCapabilitiesForType("video/avc").getVideoCapabilities();
            int wa = Math.max(2, vc.getWidthAlignment());
            int ha = Math.max(2, vc.getHeightAlignment());
            outW = Math.max(wa, outW / wa * wa);
            outH = Math.max(ha, outH / ha * ha);
            if (!vc.isSizeSupported(outW, outH)) throw new Fail("size_unsupported", outW + "x" + outH, true);
            if (bitrate <= 0) bitrate = autoBitrate();
            Range<Integer> rate = vc.getBitrateRange();
            bitrate = rate.clamp(Integer.valueOf(bitrate)).intValue();
        } else {
            outW = Math.max(2, outW / 2 * 2);
            outH = Math.max(2, outH / 2 * 2);
        }
        long pr0 = System.nanoTime();
        prepare();
        prepareNs = System.nanoTime() - pr0;
        if (!noEnc) {
            long need = (long) (bitrate / 8.0 * totalSec * 1.2) + (32L << 20);
            long avail = new StatFs(Environment.getExternalStorageDirectory().getPath()).getAvailableBytes();
            if (avail < need) throw new Fail("no_space", "need " + (need >> 20) + " MB, free " + (avail >> 20) + " MB", false);
            enc = configureEncoder(ci, "video/avc");
            encSurface = enc.createInputSurface();
            enc.start();
            openOutput();
            if (threads) startDrainer();
        }
        initEgl(noEnc ? null : encSurface);
        initTexture();
        initProgram();
        long lo0 = System.nanoTime();
        loadOverlays();
        ovLoadNs = System.nanoTime() - lo0;
        for (Clip c : clips) {
            check();
            decodeClip(c);
        }
        if (!decodeOnly && tailEndTick > k) drawTail();
        if (framesOut == 0) throw new Fail("no_frames", "no frames produced", true);
        if (noEnc) return;
        enc.signalEndOfInputStream();
        if (threads) {
            while (drainer.isAlive()) {
                drainer.join(200);
                check();
            }
            check();
        } else {
            drainEncoder(true);
        }
        if (!muxStarted) throw new Fail("mux", "muxer never started", true);
        if (aTrack >= 0) flushAudio(Long.MAX_VALUE);
        muxer.stop();
        muxer.release();
        muxer = null;
        if (tmpOut != null) {
            // готовый MP4 лежит в быстром локальном кэше — переносим в галерею одним потоком крупными блоками
            long c0 = System.nanoTime();
            try {
                tmpRaf.close();
            } finally {
                tmpRaf = null;
            }
            pfd = br.act.getContentResolver().openFileDescriptor(outUri, "rw");
            if (pfd == null) throw new Fail("mediastore", "cannot open output", true);
            copyToPfd(tmpOut, pfd);
            copyNs = System.nanoTime() - c0;
            tmpOut.delete();
            tmpOut = null;
        }
        outSize = pfd.getStatSize();
        pfd.close();
        pfd = null;
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
        br.act.getContentResolver().update(outUri, cv, null, null);
        outFinal = true;
        br.registerUri(outUri.toString());
        Log.i(TAG, "[native-export] frames=" + framesOut + " expected=" + totalTicks + " wait/upd/draw/swap/drain ms="
                + waitNs / 1000000 + "/" + updNs / 1000000 + "/" + drawNs / 1000000 + "/" + swapNs / 1000000 + "/" + encNs / 1000000);
    }

    // ---------- звук: копия сжатой AAC-дорожки ----------

    /** Читает сжатые AAC-кадры клипа в память (без декодирования). Всё остальное (микс, громкость) - в следующей фазе. */
    private void collectAudio(Clip c, MediaExtractor ex) throws Exception {
        int at = -1;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if (m != null && m.startsWith("audio/")) {
                at = i;
                break;
            }
        }
        if (at < 0) {
            if (aFmt != null) throw new Fail("audio_mismatch", "clips with and without audio", true);
            audioMissing = true;
            return;
        }
        if (audioMissing) throw new Fail("audio_mismatch", "clips with and without audio", true);
        MediaFormat f = ex.getTrackFormat(at);
        String m = f.getString(MediaFormat.KEY_MIME);
        if (!"audio/mp4a-latm".equals(m)) throw new Fail("audio_codec", "audio codec " + m + " cannot be copied", true);
        if (aFmt == null) {
            aFmt = f;
        } else if (f.getInteger(MediaFormat.KEY_SAMPLE_RATE) != aFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                || f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) != aFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)) {
            throw new Fail("audio_mismatch", "audio parameters differ between clips", true);
        }
        int cap = f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE) ? f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) : 0;
        ByteBuffer buf = ByteBuffer.allocate(Math.max(cap, 65536));
        ex.selectTrack(at);
        ex.seekTo(c.inUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        while (true) {
            long t = ex.getSampleTime();
            if (t < 0 || t >= c.outUs) break;
            buf.clear();
            int n = ex.readSampleData(buf, 0);
            if (n < 0) break;
            if (t >= c.inUs) {
                Aud a = new Aud();
                a.pts = (long) c.startUs + (t - c.inUs);
                a.flags = MediaCodec.BUFFER_FLAG_KEY_FRAME;
                a.data = new byte[n];
                buf.position(0);
                buf.get(a.data, 0, n);
                aq.add(a);
                aBytes += n;
                if (aBytes > (96L << 20)) throw new Fail("audio_big", "audio too large to buffer", true);
            }
            ex.advance();
        }
        ex.unselectTrack(at);
    }

    /** Пишет в muxer накопленные аудиокадры с метками времени до upToUs (чередование с видео). */
    private void flushAudio(long upToUs) {
        MediaCodec.BufferInfo bi = audBi;   // без new на каждый видео-сэмпл
        while (aPos < aq.size() && aq.get(aPos).pts <= upToUs) {
            Aud a = aq.get(aPos);
            aq.set(aPos, null);
            aPos++;
            bi.set(0, a.data.length, a.pts, a.flags);
            muxer.writeSampleData(aTrack, ByteBuffer.wrap(a.data), bi);
        }
    }

    private void benchDecode() throws Exception {
        prepare();
        initEgl(null);
        initTexture();
        for (Clip c : clips) {
            check();
            decodeClip(c);
        }
        if (framesDec == 0) throw new Fail("no_frames", "no frames decoded", true);
    }

    private void openOutput() throws Exception {
        ContentResolver cr = br.act.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, outName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Kadr");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        outUri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
        if (outUri == null) throw new Fail("mediastore", "insert returned null", true);
        // MediaMuxer пишет в рабочий файл во внутреннем кэше (быстрый локальный диск), а не прямо в MediaStore:
        // через FUSE каждая запись сэмпла дорога (muxMs ~4 мс/кадр на длинных роликах). Нет места в кэше — старый прямой путь.
        File cdir = br.act.getCacheDir();
        long need = (long) (bitrate / 8.0 * totalSec * 1.2) + (16L << 20);
        boolean useTmp = false;
        try {
            File[] old = cdir.listFiles();
            if (old != null) {
                for (File f : old) {
                    if (f.getName().startsWith("kx-out-") && System.currentTimeMillis() - f.lastModified() > 3600000L) f.delete();
                }
            }
            useTmp = new StatFs(cdir.getPath()).getAvailableBytes() > need;
        } catch (Throwable ignored) {
            useTmp = false;
        }
        if (useTmp) {
            tmpOut = new File(cdir, "kx-out-" + System.nanoTime() + ".mp4");
            tmpRaf = new RandomAccessFile(tmpOut, "rw");
            tmpRaf.setLength(0);
            muxer = new MediaMuxer(tmpRaf.getFD(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            outMode = "cache+copy";
        } else {
            pfd = cr.openFileDescriptor(outUri, "rw");
            if (pfd == null) throw new Fail("mediastore", "cannot open output", true);
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            outMode = "direct";
        }
        muxer.setOrientationHint(0);
    }

    private void copyToPfd(File src, ParcelFileDescriptor dst) throws Exception {
        FileInputStream in = new FileInputStream(src);
        try {
            FileOutputStream out = new FileOutputStream(dst.getFileDescriptor());   // дескриптором владеет pfd, out его не закрывает
            byte[] buf = new byte[4 << 20];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                check();
            }
            out.flush();
        } finally {
            in.close();
        }
    }

    // ---------- EGL / GL ----------

    private void checkEgl(String what) throws Fail {
        int e = EGL14.eglGetError();
        if (e != EGL14.EGL_SUCCESS) throw new Fail("egl", what + " err=0x" + Integer.toHexString(e), true);
    }

    private void initEgl(Surface win) throws Fail {
        eglDpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] ver = new int[2];
        if (!EGL14.eglInitialize(eglDpy, ver, 0, ver, 1)) throw new Fail("egl", "eglInitialize failed", true);
        eglUp = true;
        int[] attr;
        if (win != null) {
            attr = new int[] {EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                    EGL_RECORDABLE_ANDROID, 1, EGL14.EGL_NONE};
        } else {
            attr = new int[] {EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE};
        }
        EGLConfig[] cfg = new EGLConfig[1];
        int[] n = new int[1];
        if (!EGL14.eglChooseConfig(eglDpy, attr, 0, cfg, 0, 1, n, 0) || n[0] < 1) {
            throw new Fail("egl", "no suitable EGL config", true);
        }
        int[] ca = {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
        eglCtx = EGL14.eglCreateContext(eglDpy, cfg[0], EGL14.EGL_NO_CONTEXT, ca, 0);
        checkEgl("eglCreateContext");
        if (win != null) {
            eglSurf = EGL14.eglCreateWindowSurface(eglDpy, cfg[0], win, new int[] {EGL14.EGL_NONE}, 0);
        } else {
            eglSurf = EGL14.eglCreatePbufferSurface(eglDpy, cfg[0],
                    new int[] {EGL14.EGL_WIDTH, noEnc ? outW : 16, EGL14.EGL_HEIGHT, noEnc ? outH : 16, EGL14.EGL_NONE}, 0);
        }
        checkEgl("eglCreateSurface");
        if (!EGL14.eglMakeCurrent(eglDpy, eglSurf, eglSurf, eglCtx)) throw new Fail("egl", "eglMakeCurrent failed", true);
    }

    private void initTexture() {
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        tex = t[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        frameThread = new HandlerThread("kx-frames");
        frameThread.start();
        st = new SurfaceTexture(tex);
        st.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener() {
            public void onFrameAvailable(SurfaceTexture s) {
                synchronized (frameLock) {
                    frameAvail = true;
                    frameLock.notifyAll();
                }
            }
        }, new Handler(frameThread.getLooper()));
        decSurface = new Surface(st);
    }

    private static int compile(int type, String src) throws Fail {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES20.glGetShaderInfoLog(s);
            GLES20.glDeleteShader(s);
            throw new Fail("shader", log, true);
        }
        return s;
    }

    private int link(String vsSrc, String fsSrc) throws Fail {
        int vs = compile(GLES20.GL_VERTEX_SHADER, vsSrc);
        int fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSrc);
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, vs);
        GLES20.glAttachShader(p, fs);
        GLES20.glBindAttribLocation(p, 0, "aPos");
        GLES20.glBindAttribLocation(p, 1, "aTc");
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new Fail("shader", "link: " + GLES20.glGetProgramInfoLog(p), true);
        return p;
    }

    private void initProgram() throws Fail {
        prog = link(VS, FS);
        uMvp = GLES20.glGetUniformLocation(prog, "uMvp");
        uTm = GLES20.glGetUniformLocation(prog, "uTm");
        progOv = link(VS2, FS2);
        uOvAlpha = GLES20.glGetUniformLocation(progOv, "uAlpha");
        uOvTex = GLES20.glGetUniformLocation(progOv, "sTex");
        progFlat = link(VS3, FS3);
        uFlatColor = GLES20.glGetUniformLocation(progFlat, "uColor");
        if (!"none".equals(effect) && !"glitch".equals(effect)) {
            progEff = link(VS3, FS_EFF);
            uEffRes = GLES20.glGetUniformLocation(progEff, "uRes");
            uEffVig = GLES20.glGetUniformLocation(progEff, "uVig");
            uEffGr = GLES20.glGetUniformLocation(progEff, "uGr");
            uEffSeed = GLES20.glGetUniformLocation(progEff, "uSeed");
        }
        float[] pos = {-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f};
        float[] tc = {0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f};
        posBuf = ByteBuffer.allocateDirect(pos.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        posBuf.put(pos).position(0);
        tcBuf = ByteBuffer.allocateDirect(tc.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        tcBuf.put(tc).position(0);
        ovBuf = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        Arrays.fill(mvp, 0f);
        mvp[0] = 1f;
        mvp[5] = 1f;
        mvp[10] = 1f;
        mvp[15] = 1f;
        Arrays.fill(texMatrix, 0f);
        texMatrix[0] = 1f;
        texMatrix[5] = 1f;
        texMatrix[10] = 1f;
        texMatrix[15] = 1f;
    }

    private FxProg buildFx(boolean tone) throws Fail {
        FxProg f = new FxProg();
        f.tone = tone;
        f.p = link(FX_VS, FX_HEAD + (tone ? "#define TONE\n" : "") + FX_BODY);
        f.uMvp = GLES20.glGetUniformLocation(f.p, "uMvp");
        f.uTm = GLES20.glGetUniformLocation(f.p, "uTm");
        f.uTexel = GLES20.glGetUniformLocation(f.p, "uTexel");
        f.uSTex = GLES20.glGetUniformLocation(f.p, "sTex");
        f.uOpsN = GLES20.glGetUniformLocation(f.p, "uOpsN");
        f.uOps = GLES20.glGetUniformLocation(f.p, "uOps");
        f.uGlOn = GLES20.glGetUniformLocation(f.p, "uGlOn");
        f.uGl = GLES20.glGetUniformLocation(f.p, "uGl");
        f.uSeed = GLES20.glGetUniformLocation(f.p, "uSeed");
        f.uVA = GLES20.glGetUniformLocation(f.p, "uVA");
        f.uVB = GLES20.glGetUniformLocation(f.p, "uVB");
        f.uVC = GLES20.glGetUniformLocation(f.p, "uVC");
        f.uVDim = GLES20.glGetUniformLocation(f.p, "uVDim");
        f.uVShape = GLES20.glGetUniformLocation(f.p, "uVShape");
        f.uVSdf = GLES20.glGetUniformLocation(f.p, "uVSdf");
        // sampler2D виньетки ВСЕГДА на юнит 2: иначе он по умолчанию сядет на юнит 0 вместе с samplerExternalOES и draw упадёт с INVALID_OPERATION
        GLES20.glUseProgram(f.p);
        GLES20.glUniform1i(f.uVSdf, 2);
        GLES20.glUniform1f(f.uVShape, 0f);
        if (tone) {
            f.uSrc = GLES20.glGetUniformLocation(f.p, "uSrc");
            f.uSharp = GLES20.glGetUniformLocation(f.p, "uSharp");
            f.uGrain = GLES20.glGetUniformLocation(f.p, "uGrain");
            f.uOn = GLES20.glGetUniformLocation(f.p, "uOn");
            f.uPur = GLES20.glGetUniformLocation(f.p, "uPur");
            f.uCurOn = GLES20.glGetUniformLocation(f.p, "uCurOn");
            f.uLut = GLES20.glGetUniformLocation(f.p, "uLut");
            f.uA = GLES20.glGetUniformLocation(f.p, "uA");
            f.uB = GLES20.glGetUniformLocation(f.p, "uB");
            f.uHsl = GLES20.glGetUniformLocation(f.p, "uHsl");
            f.uMasks = GLES20.glGetUniformLocation(f.p, "uMasks");
            f.uGamOn = GLES20.glGetUniformLocation(f.p, "uGamOn");
            f.uGN = GLES20.glGetUniformLocation(f.p, "uGN");
            f.uGam = GLES20.glGetUniformLocation(f.p, "uGam");
            f.uWT = GLES20.glGetUniformLocation(f.p, "uWT");
            f.uWL = GLES20.glGetUniformLocation(f.p, "uWL");
            f.uWOn = GLES20.glGetUniformLocation(f.p, "uWOn");
            f.uMask = GLES20.glGetUniformLocation(f.p, "uMask");
            f.uMaskMode = GLES20.glGetUniformLocation(f.p, "uMaskMode");
        }
        return f;
    }

    /** Карта расстояний фигуры виньетки (RGBA 256x256: R,G = расстояние 16 бит, B = угол градиента) на текстурном юните 2.
     *  Юниты 0 (видео OES) и 1 (кривые) заняты. Фильтр NEAREST: билинейную выборку делает шейдер сам, чтобы 16-битная пара R/G не портилась. */
    private final java.util.HashMap<String, Integer> sdfTex = new java.util.HashMap<String, Integer>();

    private void bindVigShape(FxProg f, Clip c) throws Fail {
        if (c.vShapeSrc == null || c.vShapeId == null || c.vShapeN <= 0) {
            GLES20.glUniform1f(f.uVShape, 0f);
            return;
        }
        Integer t = sdfTex.get(c.vShapeId);
        if (t == null) {
            t = Integer.valueOf(makeSdfTex(c.vShapeSrc));
            sdfTex.put(c.vShapeId, t);
        }
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t.intValue());
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glUniform1f(f.uVShape, (float) c.vShapeN);
    }

    private int makeSdfTex(Src src) throws Fail {
        Bitmap bmp = null;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPremultiplied = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            if (src.uri != null) {
                InputStream in = br.act.getContentResolver().openInputStream(src.uri);
                try {
                    bmp = BitmapFactory.decodeStream(in, null, o);
                } finally {
                    if (in != null) in.close();
                }
            } else {
                bmp = BitmapFactory.decodeFile(src.file.getPath(), o);
            }
        } catch (Exception e) {
            throw new Fail("overlay_decode", "vignette sdf: " + e, true);
        }
        if (bmp == null || bmp.getWidth() != 256 || bmp.getHeight() != 256) {
            if (bmp != null) bmp.recycle();
            throw new Fail("overlay_decode", "vignette sdf: bad image", true);
        }
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        bmp.recycle();
        return t[0];
    }

    private int makeLutTex(byte[] rgba) {
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 256, 1, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE,
                ByteBuffer.wrap(rgba));
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        return t[0];
    }

    /** Выбор шейдера и постоянных uniform-ов клипа: вызывается один раз, на первом декодированном кадре клипа (размеры источника уже известны). */
    private void setupClipFx(Clip c) throws Fail {
        c.fxp = null;
        boolean glitch = "glitch".equals(effect);
        if (c.opsN == 0 && c.tone == null && !glitch && c.vigC == null && c.aVig == null && c.aOps == null && c.aTone == null) return;
        FxProg f;
        if (c.tone != null) {
            if (fpTone == null) fpTone = buildFx(true);
            f = fpTone;
        } else {
            if (fpCss == null) fpCss = buildFx(false);
            f = fpCss;
        }
        c.fxp = f;
        GLES20.glUseProgram(f.p);
        GLES20.glUniform1i(f.uSTex, 0);
        GLES20.glUniform1f(f.uOpsN, c.opsN);
        GLES20.glUniform2fv(f.uOps, 12, c.ops, 0);
        GLES20.glUniform1f(f.uGlOn, glitch ? 1f : 0f);
        GLES20.glUniform1f(f.uGl, 0f);
        GLES20.glUniform2f(f.uTexel, 1f / Math.max(1, srcW), 1f / Math.max(1, srcH));
        if (c.vigC != null) setVignette(f, c.vigC, 0, 1f);
        bindVigShape(f, c);
        if (!f.tone) return;
        Tone t = c.tone;
        // таблица кривых на текстурном юните 1 (юнит 0 занят видеотекстурой OES)
        if (curLutTex != 0) {
            GLES20.glDeleteTextures(1, new int[] {curLutTex}, 0);
            curLutTex = 0;
        }
        if (c.lut != null) {
            curLutTex = makeLutTex(c.lut);
        } else {
            if (lutDummy == 0) {
                byte[] id = new byte[1024];
                for (int i = 0; i < 256; i++) {
                    id[i * 4] = (byte) i;
                    id[i * 4 + 1] = (byte) i;
                    id[i * 4 + 2] = (byte) i;
                    id[i * 4 + 3] = (byte) 255;
                }
                lutDummy = makeLutTex(id);
            }
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lutDummy);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        }
        GLES20.glUniform1i(f.uLut, 1);
        GLES20.glUniform1f(f.uCurOn, c.lut != null ? 1f : 0f);
        GLES20.glUniform2f(f.uSrc, Math.max(1, srcW), Math.max(1, srcH));
        GLES20.glUniform1f(f.uSharp, t.sharp);
        GLES20.glUniform1f(f.uGrain, t.grain);
        GLES20.glUniform1f(f.uOn, t.on ? 1f : 0f);
        GLES20.glUniform1f(f.uPur, t.pur);
        GLES20.glUniform4f(f.uA, t.hi, t.sh, t.dyn, t.temp);
        GLES20.glUniform4f(f.uB, t.black, t.fade, 0f, 0f);
        GLES20.glUniform4f(f.uHsl, t.hsl[0], t.hsl[1], t.hsl[2], t.hsl[3]);
        GLES20.glUniform1f(f.uMasks, t.masks ? 1f : 0f);
        GLES20.glUniform1f(f.uGamOn, t.gamN > 0 ? 1f : 0f);
        GLES20.glUniform1i(f.uGN, t.gamN);
        GLES20.glUniform4fv(f.uGam, 8, t.gam, 0);
        GLES20.glUniform4fv(f.uWT, 4, t.wt, 0);
        GLES20.glUniform4f(f.uWL, t.wl[0], t.wl[1], t.wl[2], t.wl[3]);
        GLES20.glUniform1f(f.uWOn, t.wOn ? 1f : 0f);
        GLES20.glUniform4f(f.uMask, t.mask[0], t.mask[1], t.mask[2], t.mask[3]);
        GLES20.glUniform1f(f.uMaskMode, (float) t.maskMode);
    }

    /** Эллиптическая виньетка клипа: 12 чисел (внеш., внутр., x, y, rx, ry, размытие px, режим, r, g, b, вкл) + размер кадра клипа в px. */
    private void setVignette(FxProg f, float[] v, int off, float zoom) {
        GLES20.glUniform4f(f.uVA, v[off], v[off + 1], v[off + 2], v[off + 3]);
        GLES20.glUniform4f(f.uVB, v[off + 4], v[off + 5], v[off + 6], v[off + 7]);
        GLES20.glUniform4f(f.uVC, v[off + 8], v[off + 9], v[off + 10], v[off + 11]);
        GLES20.glUniform2f(f.uVDim, outW * fitSx * zoom, outH * fitSy * zoom);
    }

    /** Ключевые кадры клипа на тике kk: зум, сдвиг (% кадра), поворот (градусы) и виньетка. Матрица считается как в renderCanvas редактора:
     *  кадр вписан, умножен на зум, повёрнут вокруг центра, сдвинут. Вызывается после glUseProgram, до загрузки mvp. */
    private void applyAnim(Clip c, long kk, FxProg fp) {
        int j = (int) Math.max(0, Math.min(c.aN - 1, kk - c.kStart));
        float zoom = c.aZoom != null ? c.aZoom[j] : 1f;
        float ox = c.aOffX != null ? c.aOffX[j] : 0f;
        float oy = c.aOffY != null ? c.aOffY[j] : 0f;
        double rot = Math.toRadians(c.aRot != null ? c.aRot[j] : 0f);
        double cs = Math.cos(rot);
        double sn = Math.sin(rot);
        double dw = outW * fitSx * zoom;
        double dh = outH * fitSy * zoom;
        Arrays.fill(mvp, 0f);
        mvp[0] = (float) (dw / outW * cs);
        mvp[1] = (float) (-dw / outH * sn);
        mvp[4] = (float) (dh / outW * sn);
        mvp[5] = (float) (dh / outH * cs);
        mvp[10] = 1f;
        mvp[12] = ox / 100f * 2f;
        mvp[13] = -oy / 100f * 2f;
        mvp[15] = 1f;
        if (fp != null && c.aOps != null) {
            GLES20.glUniform1f(fp.uOpsN, Math.round(c.aOpsN[j]));
            GLES20.glUniform2fv(fp.uOps, 12, c.aOps, j * 24);
        }
        if (fp != null && fp.tone && c.aTone != null) {
            float[] a = c.aTone;
            int o = j * 15;
            GLES20.glUniform1f(fp.uOn, a[o]);
            GLES20.glUniform1f(fp.uMasks, a[o + 1]);
            GLES20.glUniform4f(fp.uA, a[o + 2], a[o + 3], a[o + 4], a[o + 5]);
            GLES20.glUniform4f(fp.uB, a[o + 6], a[o + 7], 0f, 0f);
            GLES20.glUniform1f(fp.uPur, a[o + 8]);
            GLES20.glUniform1f(fp.uSharp, a[o + 9]);
            GLES20.glUniform1f(fp.uGrain, a[o + 10]);
            GLES20.glUniform4f(fp.uHsl, a[o + 11], a[o + 12], a[o + 13], a[o + 14]);
            if (c.aGam != null) {
                float[] g = c.aGam;
                int q = j * 59;
                int gn = Math.round(g[q]);
                GLES20.glUniform1f(fp.uGamOn, gn > 0 ? 1f : 0f);
                GLES20.glUniform1i(fp.uGN, gn);
                GLES20.glUniform4fv(fp.uGam, 8, g, q + 1);
                GLES20.glUniform4fv(fp.uWT, 4, g, q + 33);
                GLES20.glUniform4f(fp.uWL, g[q + 49], g[q + 50], g[q + 51], g[q + 52]);
                GLES20.glUniform1f(fp.uWOn, g[q + 53]);
                GLES20.glUniform1f(fp.uMaskMode, g[q + 54]);
                GLES20.glUniform4f(fp.uMask, g[q + 55], g[q + 56], g[q + 57], g[q + 58]);
            }
        }
        if (fp != null && c.aVig != null) setVignette(fp, c.aVig, j * 12, zoom);
        else if (fp != null && c.vigC != null) setVignette(fp, c.vigC, 0, zoom);
    }

    /** Эффект видео на весь кадр (виньетка / плёнка / зерно): после видео и маски виньетки клипа, до затемнения перехода и наложений. */
    private void drawEffect(long kk) {
        if (progEff == 0) return;
        boolean vig = "vignette".equals(effect) || "film".equals(effect);
        float gr = "film".equals(effect) ? 0.05f : ("grain".equals(effect) ? 0.08f : 0f);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glUseProgram(progEff);
        GLES20.glUniform2f(uEffRes, outW, outH);
        GLES20.glUniform1f(uEffVig, vig ? 1f : 0f);
        GLES20.glUniform1f(uEffGr, gr);
        GLES20.glUniform1f(uEffSeed, (float) ((kk * 37L) % 997L) * 0.1f + 1f);
        posBuf.position(0);
        GLES20.glEnableVertexAttribArray(0);
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 8, posBuf);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    /** Маска виньетки клипа (PNG на весь кадр, готовит страница) поверх видео клипа, ниже всего остального. */
    private void drawUnder(Ovl o) {
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glUseProgram(progOv);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glEnableVertexAttribArray(0);
        GLES20.glEnableVertexAttribArray(1);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, o.vbo);
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 16, 0);
        GLES20.glVertexAttribPointer(1, 2, GLES20.GL_FLOAT, false, 16, 8);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, o.tex);
        if (ovAlphaSet != 1f) {
            GLES20.glUniform1f(uOvAlpha, 1f);
            ovAlphaSet = 1f;
        }
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    /** Декодирует PNG наложений и загружает в GL-текстуры (один раз на весь экспорт). */
    /** Декод и загрузка в GL — ОДИН раз на экспорт: bitmap → текстура → VBO с готовой геометрией; дальше только draw. */
    private void loadOverlays() throws Fail {
        if (ovls.isEmpty()) return;
        int[] mt = new int[1];
        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, mt, 0);
        int maxTex = Math.max(1024, Math.min(mt[0], 4096));
        GLES20.glUseProgram(progOv);
        GLES20.glUniform1i(uOvTex, 0);
        for (Ovl o : ovls) {
            double wpx = o.w * outW;
            double hbox = o.h > 0 ? o.h * outH : 0;
            Bitmap bmp = null;
            try {
                if (o.raw) {
                    bmp = decodeRaw(o, wpx, hbox > 0 ? hbox : wpx, maxTex);
                } else if (o.src.uri != null) {
                    InputStream in = br.act.getContentResolver().openInputStream(o.src.uri);
                    try {
                        bmp = BitmapFactory.decodeStream(in);
                    } finally {
                        if (in != null) in.close();
                    }
                } else {
                    bmp = BitmapFactory.decodeFile(o.src.file.getPath());
                }
            } catch (Fail f) {
                throw f;
            } catch (Exception e) {
                throw new Fail("overlay_decode", String.valueOf(e), true);
            }
            if (bmp == null) throw new Fail("overlay_decode", "cannot decode overlay image", true);
            int[] t = new int[1];
            GLES20.glGenTextures(1, t, 0);
            o.tex = t[0];
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, o.tex);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0);
            o.hpx = hbox > 0 ? hbox : wpx * bmp.getHeight() / Math.max(1, bmp.getWidth());
            bmp.recycle();
            buildOverlayGeometry(o);
            o.fadeNone = !(o.fi > 0 || o.fo > 0);
            o.alphaStatic = (float) Math.min(1.0, o.opacity);
        }
        ovAlphaSet = -1f;
    }

    /** Вершины квада наложения (позиция, поворот по часовой, UV) считаются здесь один раз и уходят в статический VBO. */
    private void buildOverlayGeometry(Ovl o) {
        double cx = o.x * outW;
        double cy = o.y * outH;
        double hw = o.w * outW / 2;
        double hh = o.hpx / 2;
        double r = Math.toRadians(o.rot);
        double cs = Math.cos(r);
        double sn = Math.sin(r);
        // углы (экранные координаты, y вниз): левый верх, правый верх, левый низ, правый низ
        double[] dx = {-hw, hw, -hw, hw};
        double[] dy = {-hh, -hh, hh, hh};
        float[] u = {0f, 1f, 0f, 1f};
        float[] v = {0f, 0f, 1f, 1f};
        float[] vert = new float[16];
        for (int i = 0; i < 4; i++) {
            double px = cx + dx[i] * cs - dy[i] * sn;
            double py = cy + dx[i] * sn + dy[i] * cs;
            vert[i * 4] = (float) (px / outW * 2.0 - 1.0);
            vert[i * 4 + 1] = (float) (1.0 - py / outH * 2.0);
            vert[i * 4 + 2] = u[i];
            vert[i * 4 + 3] = v[i];
        }
        FloatBuffer fb = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(vert);
        fb.position(0);
        int[] vb = new int[1];
        GLES20.glGenBuffers(1, vb, 0);
        o.vbo = vb[0];
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, o.vbo);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, 16 * 4, fb, GLES20.GL_STATIC_DRAW);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
    }

    private Bitmap openOvBitmap(Ovl o, BitmapFactory.Options opts) throws Exception {
        if (o.src.uri != null) {
            InputStream in = br.act.getContentResolver().openInputStream(o.src.uri);
            try {
                return BitmapFactory.decodeStream(in, null, opts);
            } finally {
                if (in != null) in.close();
            }
        }
        return BitmapFactory.decodeFile(o.src.file.getPath(), opts);
    }

    private int readExifOrientation(Ovl o) {
        try {
            InputStream in = o.src.uri != null ? br.act.getContentResolver().openInputStream(o.src.uri) : new FileInputStream(o.src.file);
            try {
                return new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            } finally {
                if (in != null) in.close();
            }
        } catch (Throwable t) {
            return ExifInterface.ORIENTATION_NORMAL;
        }
    }

    private static Matrix exifMatrix(int orientation) {
        Matrix m = new Matrix();
        switch (orientation) {
            case 2: m.postScale(-1f, 1f); break;
            case 3: m.postRotate(180f); break;
            case 4: m.postScale(1f, -1f); break;
            case 5: m.postRotate(90f); m.postScale(-1f, 1f); break;
            case 6: m.postRotate(90f); break;
            case 7: m.postRotate(-90f); m.postScale(-1f, 1f); break;
            case 8: m.postRotate(-90f); break;
            default: break;
        }
        return m;
    }

    /** Исходная картинка наложения: декод с сэмплированием до размера не меньше рамки на кадре (и не больше GL-лимита) + поворот по EXIF
     *  (как делает браузер при drawImage в превью). Перекодирования в PNG и Base64-пересчёта в странице больше нет. */
    private Bitmap decodeRaw(Ovl o, double wpx, double hpx, int maxTex) throws Exception {
        BitmapFactory.Options bo = new BitmapFactory.Options();
        bo.inJustDecodeBounds = true;
        openOvBitmap(o, bo);
        int sw = bo.outWidth;
        int sh = bo.outHeight;
        if (sw <= 0 || sh <= 0) throw new Fail("overlay_decode", "cannot read overlay image bounds", true);
        int orient = readExifOrientation(o);
        boolean transposed = orient >= 5 && orient <= 8;
        int dw = transposed ? sh : sw;
        int dh = transposed ? sw : sh;
        int sample = 1;
        while (dw / (sample * 2) >= Math.max(1.0, wpx) && dh / (sample * 2) >= Math.max(1.0, hpx)) sample *= 2;
        while (dw / sample > maxTex || dh / sample > maxTex) sample *= 2;
        BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = sample;
        d.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bmp = openOvBitmap(o, d);
        if (bmp == null) throw new Fail("overlay_decode", "cannot decode overlay image", true);
        if (orient != ExifInterface.ORIENTATION_NORMAL && orient != ExifInterface.ORIENTATION_UNDEFINED) {
            Bitmap rot = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), exifMatrix(orient), true);
            if (rot != bmp) bmp.recycle();
            bmp = rot;
        }
        return bmp;
    }

    private void computeMvp(Clip c) {
        double a = (double) srcW / srcH;
        double b = (double) outW / outH;
        float sx;
        float sy;
        if (c.cover) {
            if (a > b) {
                sy = 1f;
                sx = (float) (a / b);
            } else {
                sx = 1f;
                sy = (float) (b / a);
            }
        } else if (a > b) {
            sx = 1f;
            sy = (float) (b / a);
        } else {
            sy = 1f;
            sx = (float) (a / b);
        }
        fitSx = sx;
        fitSy = sy;
        Arrays.fill(mvp, 0f);
        mvp[0] = sx;
        mvp[5] = sy;
        mvp[10] = 1f;
        mvp[15] = 1f;
    }

    // ---------- декодирование и кадровая сетка ----------

    private void readDims(MediaFormat of) {
        int w = of.getInteger(MediaFormat.KEY_WIDTH);
        int h = of.getInteger(MediaFormat.KEY_HEIGHT);
        if (of.containsKey("crop-left") && of.containsKey("crop-right")
                && of.containsKey("crop-top") && of.containsKey("crop-bottom")) {
            w = of.getInteger("crop-right") - of.getInteger("crop-left") + 1;
            h = of.getInteger("crop-bottom") - of.getInteger("crop-top") + 1;
        }
        // декодер с Surface сам применяет поворот (в матрицу SurfaceTexture), размеры меняем местами сами
        if (rotation == 90 || rotation == 270) {
            int t = w;
            w = h;
            h = t;
        }
        srcW = w;
        srcH = h;
        dimsInfo = of.toString();
    }

    private void awaitFrame() throws Fail {
        long deadline = SystemClock.elapsedRealtime() + 3000;
        synchronized (frameLock) {
            while (!frameAvail) {
                long left = deadline - SystemClock.elapsedRealtime();
                if (left <= 0) throw new Fail("frame_timeout", "decoder frame did not arrive", true);
                try {
                    frameLock.wait(left);
                } catch (InterruptedException e) {
                    throw new Fail("interrupted", "interrupted", true);
                }
            }
            frameAvail = false;
        }
    }

    private void decodeClip(Clip c) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec dec = null;
        Thread feed = null;
        try {
            c.src.open(ex, br.act);
            ex.selectTrack(c.vtrack);
            MediaFormat fmt = ex.getTrackFormat(c.vtrack);
            String mime = fmt.getString(MediaFormat.KEY_MIME);
            rotation = fmt.containsKey(MediaFormat.KEY_ROTATION) ? fmt.getInteger(MediaFormat.KEY_ROTATION) : 0;
            noteSource(mime, fmt);
            ex.seekTo(c.inUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            curClip = c;
            dec = openDecoder(mime, fmt, decSurface);
            curDec = dec;
            dec.start();
            srcW = 0;
            srcH = 0;
            k = c.kStart;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = threads;
            boolean outDone = false;
            boolean have = false;
            long prevLocal = 0;
            if (threads) {
                stopFeed = false;
                final MediaCodec fdec = dec;
                final MediaExtractor fex = ex;
                final long fout = c.outUs;
                feed = new Thread(new Runnable() {
                    public void run() {
                        feedLoop(fdec, fex, fout);
                    }
                }, "kx-feed");
                feed.start();
            }
            while (!outDone) {
                check();
                long f0 = System.nanoTime();
                while (!inDone) {
                    int ii = dec.dequeueInputBuffer(0);
                    if (ii < 0) break;
                    ByteBuffer ib = dec.getInputBuffer(ii);
                    int n = ex.readSampleData(ib, 0);
                    long sampleUs = ex.getSampleTime();
                    if (n < 0 || sampleUs < 0 || sampleUs > c.outUs + GUARD_US) {
                        dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inDone = true;
                    } else {
                        dec.queueInputBuffer(ii, 0, n, sampleUs, 0);
                        ex.advance();
                    }
                }
                long a = System.nanoTime();
                if (!threads) feedNs += a - f0;
                int oi = dec.dequeueOutputBuffer(info, threads ? 2000 : (inDone ? 10000 : 2000));
                waitNs += System.nanoTime() - a;
                if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) continue;
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    readDims(dec.getOutputFormat());
                    continue;
                }
                if (oi < 0) continue;
                pulse();
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                long pts = info.presentationTimeUs;
                boolean use = info.size > 0 && pts >= c.inUs && pts < c.outUs;
                if (!use) {
                    dec.releaseOutputBuffer(oi, false);
                    if (eos || (info.size > 0 && pts >= c.outUs)) outDone = true;
                    continue;
                }
                long local = pts - c.inUs;
                if (!decodeOnly && have) emitTicksBefore(c, (prevLocal + local) / 2);
                a = System.nanoTime();
                dec.releaseOutputBuffer(oi, true);
                awaitFrame();
                st.updateTexImage();
                st.getTransformMatrix(texMatrix);
                updNs += System.nanoTime() - a;
                if (srcW == 0) readDims(dec.getOutputFormat());
                if (!have && !decodeOnly) {
                    computeMvp(c);
                    setupClipFx(c);
                }
                prevLocal = local;
                have = true;
                framesDec++;
                if (decodeOnly) progress((c.startUs + local) / (totalSec * 1e6), "decode", framesDec);
                if (eos) outDone = true;
            }
            if (!have) throw new Fail("no_frames", "no decodable frames in range", true);
            if (!decodeOnly) emitTicksBefore(c, Long.MAX_VALUE);
        } finally {
            stopFeed = true;
            if (feed != null) {
                try {
                    feed.join(5000);
                } catch (InterruptedException ignored) {
                    // прервано при отмене
                }
            }
            curDec = null;
            if (dec != null) {
                try {
                    dec.stop();
                } catch (Throwable ignored) {
                    // уже остановлен или освобождён сторожем
                }
                try {
                    dec.release();
                } catch (Throwable ignored) {
                    // уже освобождён
                }
            }
            ex.release();
        }
    }

    /** Выдаёт кадры сетки выходного видео, для которых ближайшим исходным кадром является текущий в текстуре. */
    private void emitTicksBefore(Clip c, long limitUs) throws Exception {
        while (k < c.kEnd) {
            double lt = k * 1e6 / fps - c.startUs;
            if (lt >= limitUs) break;
            drawTick(k);
            k++;
        }
    }

    private void drawTick(long kk) throws Exception {
        long a = System.nanoTime();
        GLES20.glViewport(0, 0, outW, outH);
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        long a1 = System.nanoTime();
        clearNs += a1 - a;
        FxProg fp = curClip != null ? curClip.fxp : null;
        GLES20.glUseProgram(fp != null ? fp.p : prog);
        if (curClip != null && curClip.aN > 0) applyAnim(curClip, kk, fp);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glUniformMatrix4fv(fp != null ? fp.uMvp : uMvp, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(fp != null ? fp.uTm : uTm, 1, false, texMatrix, 0);
        if (fp != null) {
            // зерно меняется от кадра к кадру; glitch — оттенок как в редакторе: round(sin(t_мс / 90) * 38) градусов
            GLES20.glUniform1f(fp.uSeed, (float) ((kk * 37L) % 997L) * 0.1f + 1f);
            if ("glitch".equals(effect)) {
                double deg = Math.round(Math.sin(kk / fps * 1000.0 / 90.0) * 38.0);
                GLES20.glUniform1f(fp.uGl, (float) Math.toRadians(deg));
            }
        }
        posBuf.position(0);
        tcBuf.position(0);
        GLES20.glEnableVertexAttribArray(0);
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 8, posBuf);
        GLES20.glEnableVertexAttribArray(1);
        GLES20.glVertexAttribPointer(1, 2, GLES20.GL_FLOAT, false, 8, tcBuf);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        long a2 = System.nanoTime();
        quadNs += a2 - a1;
        double t = kk / fps;
        if (curClip != null && curClip.vig != null) drawUnder(curClip.vig);
        drawEffect(kk);
        drawShade(t);
        long a3 = System.nanoTime();
        shadeNs += a3 - a2;
        drawOverlays(t);
        long a4 = System.nanoTime();
        ovNs += a4 - a3;
        if (glFinish) {            // только диагностика (diag:"finish"); в обычном экспорте glFinish не вызывается
            GLES20.glFinish();
            glFinishCalls++;
        }
        long b = System.nanoTime();
        drawNs += b - a;
        if (noEnc) {
            GLES20.glFinish();
            glFinishCalls++;
        } else {
            EGLExt.eglPresentationTimeANDROID(eglDpy, eglSurf, Math.round(kk * 1e9 / fps));
            if (!EGL14.eglSwapBuffers(eglDpy, eglSurf)) throw new Fail("egl_swap", "eglSwapBuffers failed", true);
        }
        swapNs += System.nanoTime() - b;
        framesOut++;
        if (framesOut == 1) firstFrameMs = SystemClock.elapsedRealtime() - t0;
        if (!noEnc && !threads) drainEncoder(false);
        pulse();
        progress(totalTicks > 0 ? (double) framesOut / totalTicks : 0, "encode", framesOut);
    }

    /** Чёрный хвост после основы: наложения живут и за её концом (как «чёрный хвост» в редакторе). */
    private void drawTail() throws Exception {
        while (k < tailEndTick) {
            check();
            long a = System.nanoTime();
            GLES20.glViewport(0, 0, outW, outH);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            long a1 = System.nanoTime();
            clearNs += a1 - a;
            drawEffect(k);
            drawOverlays(k / fps);
            ovNs += System.nanoTime() - a1;
            if (glFinish) {
                GLES20.glFinish();
                glFinishCalls++;
            }
            long b = System.nanoTime();
            drawNs += b - a;
            if (noEnc) {
                GLES20.glFinish();
                glFinishCalls++;
            } else {
                EGLExt.eglPresentationTimeANDROID(eglDpy, eglSurf, Math.round(k * 1e9 / fps));
                if (!EGL14.eglSwapBuffers(eglDpy, eglSurf)) throw new Fail("egl_swap", "eglSwapBuffers failed", true);
            }
            swapNs += System.nanoTime() - b;
            framesOut++;
            if (!noEnc && !threads) drainEncoder(false);
            pulse();
            progress(totalTicks > 0 ? (double) framesOut / totalTicks : 0, "encode", framesOut);
            k++;
        }
    }

    /** Переход Kadr: затемнение (или осветление) к концу клипа и из цвета в начале следующего. Формула как в drawTransitionShade. */
    private void drawShade(double t) {
        Clip c = curClip;
        if (c == null || (c.trOut == null && c.trIn == null)) return;
        double start = c.startUs / 1e6;
        double len = (c.outUs - c.inUs) / 1e6;
        double alpha = 0;
        boolean white = false;
        if (c.trOut != null) {
            double remain = start + len - t;
            if (remain > 0 && remain < c.trOutDur) {
                alpha = Math.max(alpha, 1 - remain / c.trOutDur);
                white = "white".equals(c.trOut);
            }
        }
        if (c.trIn != null) {
            double el = t - start;
            if (el > 0 && el < c.trInDur) {
                double al = 1 - el / c.trInDur;
                if (al > alpha) {
                    alpha = al;
                    white = "white".equals(c.trIn);
                }
            }
        }
        if (alpha <= 0.01) return;
        float al = (float) Math.min(1.0, alpha);
        float col = white ? al : 0f;
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glUseProgram(progFlat);
        GLES20.glUniform4f(uFlatColor, col, col, col, al);
        posBuf.position(0);
        GLES20.glEnableVertexAttribArray(0);
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 8, posBuf);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    /** Наложения поверх кадра. Геометрия (углы, поворот, UV) посчитана один раз в loadOverlays и лежит в VBO;
     *  на кадре меняются только видимость и alpha (fade) — ни аллокаций, ни sin/cos, ни пересборки вершин. */
    private void drawOverlays(double t) {
        boolean any = false;
        for (int i = 0, n = ovls.size(); i < n; i++) {
            Ovl o = ovls.get(i);
            if (o.under) continue;
            if (t < o.t0 - 0.001 || t > o.t1 + 0.001) continue;
            float alpha = o.alphaStatic;
            if (!o.fadeNone) {
                double fade = 1;
                if (o.fi > 0) fade = Math.min(fade, (t - o.t0) / o.fi);
                if (o.fo > 0) fade = Math.min(fade, (o.t1 - t) / o.fo);
                alpha = (float) Math.min(1.0, o.opacity * Math.max(0, Math.min(1, fade)));
            }
            if (alpha <= 0.01f) continue;
            if (!any) {
                any = true;
                GLES20.glEnable(GLES20.GL_BLEND);
                GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
                GLES20.glUseProgram(progOv);
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
                GLES20.glEnableVertexAttribArray(0);
                GLES20.glEnableVertexAttribArray(1);
            }
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, o.vbo);
            GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 16, 0);
            GLES20.glVertexAttribPointer(1, 2, GLES20.GL_FLOAT, false, 16, 8);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, o.tex);
            if (alpha != ovAlphaSet) {
                GLES20.glUniform1f(uOvAlpha, alpha);
                ovAlphaSet = alpha;
            }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        }
        if (any) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);   // остальные программы берут вершины из client-side массивов
            GLES20.glDisable(GLES20.GL_BLEND);
        }
    }

    private void progress(double p, String stage, long frames) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastEmit < 100) return;
        lastEmit = now;
        br.emit(KxBridge.o("type", "progress", "job", jobId, "p", Math.min(1.0, p), "stage", stage,
                "fps", Math.round(frames * 10000.0 / Math.max(1, now - t0)) / 10.0));
    }

    private void drainEncoder(boolean endOfStream) throws Exception {
        long waitStart = SystemClock.elapsedRealtime();
        while (true) {
            long dq0 = System.nanoTime();
            int idx = enc.dequeueOutputBuffer(binfo, endOfStream ? 10000 : 0);
            deqNs += System.nanoTime() - dq0;
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break;
                if (stopDrain) return;
                check();
                if (SystemClock.elapsedRealtime() - waitStart > STALL_MS) throw new Fail("timeout", "encoder EOS timeout", true);
                continue;
            }
            long a = System.nanoTime();
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                vTrack = muxer.addTrack(enc.getOutputFormat());
                if (aFmt != null) aTrack = muxer.addTrack(aFmt);
                muxer.start();
                muxStarted = true;
            } else if (idx >= 0) {
                ByteBuffer buf = enc.getOutputBuffer(idx);
                if ((binfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) binfo.size = 0;
                if (binfo.size > 0 && muxStarted && buf != null) {
                    buf.position(binfo.offset);
                    buf.limit(binfo.offset + binfo.size);
                    long mx0 = System.nanoTime();
                    muxer.writeSampleData(vTrack, buf, binfo);
                    long mx1 = System.nanoTime();
                    muxVideoNs += mx1 - mx0;
                    encOutFrames++;
                    if (aTrack >= 0) {
                        flushAudio(binfo.presentationTimeUs + 700000L);
                        muxAudioNs += System.nanoTime() - mx1;
                    }
                    muxNs = muxVideoNs + muxAudioNs;
                }
                enc.releaseOutputBuffer(idx, false);
                waitStart = SystemClock.elapsedRealtime();
                pulse();
                if ((binfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    encNs += System.nanoTime() - a;
                    break;
                }
            }
            encNs += System.nanoTime() - a;
        }
    }

    private void startDrainer() {
        stopDrain = false;
        drainer = new Thread(new Runnable() {
            public void run() {
                try {
                    drainEncoder(true);
                } catch (Throwable t) {
                    if (!stopDrain) bgFail = t;
                }
            }
        }, "kx-drain");
        drainer.start();
    }

    /** Поток подачи входа декодера: чтение сэмплов и queueInputBuffer не мешают отрисовке и энкодеру. */
    private void feedLoop(MediaCodec dec, MediaExtractor ex, long outUs) {
        try {
            while (!stopFeed && !cancelled && !aborted) {
                int ii = dec.dequeueInputBuffer(2000);
                if (ii < 0) continue;
                long a = System.nanoTime();
                ByteBuffer ib = dec.getInputBuffer(ii);
                int n = ex.readSampleData(ib, 0);
                long sampleUs = ex.getSampleTime();
                if (n < 0 || sampleUs < 0 || sampleUs > outUs + GUARD_US) {
                    dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    feedNs += System.nanoTime() - a;
                    break;
                }
                dec.queueInputBuffer(ii, 0, n, sampleUs, 0);
                ex.advance();
                feedNs += System.nanoTime() - a;
            }
        } catch (Throwable t) {
            if (!stopFeed) bgFail = t;
        }
    }

    // ---------- освобождение ресурсов ----------

    private void cleanup(boolean ok) {
        stopDrain = true;
        stopFeed = true;
        if (drainer != null) {
            try {
                drainer.join(3000);
            } catch (InterruptedException ignored) {
                // прервано
            }
        }
        if (eglUp) {
            try {
                // текстуры и буферы наложений освобождаем явно, пока контекст ещё текущий (успех/отмена/ошибка/повторный экспорт)
                for (Ovl o : ovls) {
                    if (o.tex != 0) {
                        GLES20.glDeleteTextures(1, new int[]{o.tex}, 0);
                        o.tex = 0;
                    }
                    if (o.vbo != 0) {
                        GLES20.glDeleteBuffers(1, new int[]{o.vbo}, 0);
                        o.vbo = 0;
                    }
                }
            } catch (Throwable t) {
                Log.w(TAG, "overlay gl cleanup", t);
            }
            try {
                EGL14.eglMakeCurrent(eglDpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                if (eglSurf != null) EGL14.eglDestroySurface(eglDpy, eglSurf);
                if (eglCtx != null) EGL14.eglDestroyContext(eglDpy, eglCtx);
                EGL14.eglReleaseThread();
                EGL14.eglTerminate(eglDpy);
            } catch (Throwable t) {
                Log.w(TAG, "egl cleanup", t);
            }
            eglUp = false;
        }
        try {
            if (decSurface != null) decSurface.release();
            if (st != null) st.release();
        } catch (Throwable t) {
            Log.w(TAG, "surface cleanup", t);
        }
        try {
            if (encSurface != null) encSurface.release();
        } catch (Throwable ignored) {
            // уже освобождён
        }
        MediaCodec e = enc;
        enc = null;
        if (e != null) {
            try {
                e.stop();
            } catch (Throwable ignored) {
                // не запущен
            }
            try {
                e.release();
            } catch (Throwable ignored) {
                // уже освобождён
            }
        }
        try {
            if (muxer != null) muxer.release();
        } catch (Throwable t) {
            Log.w(TAG, "muxer cleanup", t);
        }
        try {
            if (pfd != null) pfd.close();
        } catch (Throwable ignored) {
            // уже закрыт
        }
        try {
            if (tmpRaf != null) tmpRaf.close();
        } catch (Throwable ignored) {
            // уже закрыт
        }
        tmpRaf = null;
        if (tmpOut != null) {
            try {
                tmpOut.delete();
            } catch (Throwable ignored) {
                // не критично: старые kx-out-* вычищаются при следующем экспорте
            }
            tmpOut = null;
        }
        if (!outFinal && outUri != null) {
            try {
                br.act.getContentResolver().delete(outUri, null, null);
            } catch (Throwable t) {
                Log.w(TAG, "mediastore cleanup", t);
            }
            outUri = null;
        }
        if (frameThread != null) frameThread.quitSafely();
    }
}

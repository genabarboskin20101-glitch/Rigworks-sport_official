package com.lmusic.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.MutableContextWrapper;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;

import java.lang.ref.WeakReference;

import kx.engine.KxHost;

/**
 * Единственная Activity: полноэкранный WebView со страницей assets/www/index.html.
 * Имя класса (WebViewActivity) и метод getWebView() важны: по ним мост kx.engine.Boot находит WebView
 * и регистрирует window.KExport.
 */
public class WebViewActivity extends Activity {
    private static final String START_URL = "file:///android_asset/www/index.html";
    private static final int REQ_FILE = 4711;

    /** WebView, пережившая закрытие Activity (музыка играла): следующая Activity берёт её, и воспроизведение не прерывается. */
    private static WebView retained;
    private static WeakReference<WebViewActivity> current;

    private WebView web;
    private FrameLayout root;
    private ValueCallback<Uri[]> fileCb;

    private static WebViewActivity cur() { return current == null ? null : current.get(); }

    public WebView getWebView() { return web; }

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupEdgeToEdge();

        current = new WeakReference<WebViewActivity>(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#171717"));

        boolean reuse = false;
        if (retained != null) {
            // прошлая Activity закрыта при играющей музыке: берём её живую страницу вместо новой
            WebView old = retained;
            retained = null;
            if (KxHost.hasRetained()) {
                try {
                    ((MutableContextWrapper) old.getContext()).setBaseContext(this);
                    web = old;
                    reuse = true;
                } catch (Throwable ignored) {
                    reuse = false;
                }
            }
            if (!reuse) {
                try { old.destroy(); } catch (Throwable ignored) { /* уже уничтожен */ }
            }
        }
        if (!reuse) web = new WebView(new MutableContextWrapper(this));
        web.setBackgroundColor(Color.parseColor("#171717"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER); // упор прокрутки рисует сама страница (одинаково сверху и снизу)
        if (web.getParent() instanceof ViewGroup) ((ViewGroup) web.getParent()).removeView(web);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        applyKeyboardInset(root);

        if (reuse && KxHost.adopt(this)) return; // страница уже загружена и играет — ничего не перезагружаем
        if (reuse) {
            // мост не принял страницу: начинаем с нуля
            ViewGroup pg = (ViewGroup) web.getParent();
            if (pg != null) pg.removeView(web);
            try { web.destroy(); } catch (Throwable ignored) { /* уже уничтожен */ }
            web = new WebView(new MutableContextWrapper(this));
            web.setBackgroundColor(Color.parseColor("#171717"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER); // упор прокрутки рисует сама страница (одинаково сверху и снизу)
            root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        WebView.setWebContentsDebuggingEnabled(true); // chrome://inspect

        // клиенты не держат ссылку на конкретную Activity: WebView может пережить её и перейти к следующей
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if ("file".equals(sc) || "blob".equals(sc) || "data".equals(sc) || "about".equals(sc)) return false;
                WebViewActivity a = cur();
                if (a == null) return true;
                try {
                    a.startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                    // нечем открыть
                }
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                // процесс отрисовки убит системой: пересоздаём Activity вместо падения всего приложения
                WebViewActivity a = cur();
                if (a != null) {
                    try { KxHost.renderGone(a); } catch (Throwable ignored) { /* позиция не сохранится — не критично */ }
                    a.recreate();
                } else {
                    // приложение закрыто, а страница играла в фоне: она мертва, новая загрузится при следующем запуске
                    retained = null;
                    KxHost.pageDied();
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                WebViewActivity a = cur();
                if (a == null) return false;
                if (a.fileCb != null) a.fileCb.onReceiveValue(null);
                a.fileCb = cb;
                try {
                    a.startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Throwable t) {
                    a.fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                WebViewActivity a = cur();
                if (a == null) { r.cancel(); return true; }
                new AlertDialog.Builder(a).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.confirm(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            public void onCancel(DialogInterface d) { r.cancel(); }
                        }).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                WebViewActivity a = cur();
                if (a == null) { r.cancel(); return true; }
                new AlertDialog.Builder(a).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.confirm(); }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.cancel(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            public void onCancel(DialogInterface d) { r.cancel(); }
                        }).show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                WebViewActivity a = cur();
                if (a == null) { r.cancel(); return true; }
                final EditText et = new EditText(a);
                et.setText(def);
                new AlertDialog.Builder(a).setMessage(msg).setView(et)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.confirm(et.getText().toString()); }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.cancel(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            public void onCancel(DialogInterface d) { r.cancel(); }
                        }).show();
                return true;
            }
        });

        web.loadUrl(START_URL);
    }

    /** Интерфейс рисуется под прозрачными статус-баром и панелью навигации; их высоту отдаёт странице мост (NavBar). */
    @SuppressWarnings("deprecation")
    private void setupEdgeToEdge() {
        Window w = getWindow();
        w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        if (Build.VERSION.SDK_INT < 35) {
            w.setStatusBarColor(Color.TRANSPARENT);
            w.setNavigationBarColor(Color.TRANSPARENT);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    /** При полноэкранном режиме система сама не сжимает окно под клавиатуру: делаем отступ снизу на высоту клавиатуры. */
    @SuppressWarnings("deprecation")
    private void applyKeyboardInset(final View root) {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int kb;
                if (Build.VERSION.SDK_INT >= 30) {
                    int ime = in.getInsets(WindowInsets.Type.ime()).bottom;
                    int nav = in.getInsets(WindowInsets.Type.navigationBars()).bottom;
                    kb = in.isVisible(WindowInsets.Type.ime()) ? Math.max(0, ime - nav) + nav : 0;
                } else {
                    kb = Math.max(0, in.getSystemWindowInsetBottom() - in.getStableInsetBottom());
                    if (kb > 0) kb += in.getStableInsetBottom();
                }
                v.setPadding(0, 0, 0, kb);
                return in;
            }
        });
        root.requestApplyInsets();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == KxHost.REQ_DELETE) { // окно подтверждения удаления трека с устройства
            KxHost.deleteResult(this, res);
            return;
        }
        if (req == REQ_FILE) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        final WebView w = web;
        if (w == null) { super.onBackPressed(); return; }
        // Страница сама закрывает верхний слой (окно, меню, плейлисты…) и отвечает 1; если слоёв нет — выходим.
        final boolean[] done = { false };
        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable exit = new Runnable() {
            @Override public void run() {
                if (done[0]) return;
                done[0] = true;
                WebViewActivity.super.onBackPressed();
            }
        };
        try {
            w.evaluateJavascript("(function(){try{return window.__lmBackStep&&window.__lmBackStep()?'1':'0'}catch(e){return '0'}})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String v) {
                        if (done[0]) return;
                        h.removeCallbacks(exit);
                        if (v != null && v.contains("1")) { done[0] = true; return; }
                        exit.run();
                    }
                });
            h.postDelayed(exit, 800); // страница не ответила — не оставляем пользователя без «назад»
        } catch (Throwable t) {
            exit.run();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause(); // при играющей музыке мост сразу возобновляет WebView (KxBridge.keepAlive)
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
    }

    @Override
    protected void onDestroy() {
        // Музыка играет — закрытие Activity не должно прерывать её: WebView отсоединяем и оставляем для следующего запуска
        // (мост kx.engine решает это сам: KxHost.shouldRetain). Решение принимается до super.onDestroy().
        boolean keep = false;
        try {
            keep = web != null && !isChangingConfigurations() && KxHost.shouldRetain(this);
        } catch (Throwable ignored) {
            keep = false;
        }
        WebView w = web;
        if (w != null) {
            if (root != null) root.removeView(w);
            if (keep) {
                try {
                    ((MutableContextWrapper) w.getContext()).setBaseContext(getApplicationContext());
                } catch (Throwable ignored) {
                    // контекст не подменяется — всё равно сохраняем
                }
                retained = w;
            }
        }
        if (fileCb != null) {
            fileCb.onReceiveValue(null);
            fileCb = null;
        }
        super.onDestroy();
        if (w != null && !keep) {
            try { w.destroy(); } catch (Throwable ignored) { /* уже уничтожен */ }
        }
        if (cur() == this) current = null;
    }
}

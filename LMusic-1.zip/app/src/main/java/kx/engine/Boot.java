package kx.engine;

import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;

/**
 * Находит WebView у WebViewActivity шаблона и регистрирует мост window.KExport.
 * onActivityPostCreated (API 29+) срабатывает сразу после onCreate, до коммита страницы;
 * onActivityStarted/Resumed - запасные точки (API 28 и случай поздней инициализации).
 */
final class Boot implements Application.ActivityLifecycleCallbacks, ComponentCallbacks {
    private static final String TAG = "KX";
    private static boolean installed;
    private final WeakHashMap<Activity, KxBridge> bridges = new WeakHashMap<Activity, KxBridge>();
    /** Мост уничтоженной Activity, чья страница продолжает играть в фоне (выход из приложения во время воспроизведения). */
    private static volatile KxBridge survivor;

    static void retireSurvivor(Activity now) {
        KxBridge old = survivor;
        if (old == null || old.act == now) return;
        survivor = null;
        try {
            old.retire();
        } catch (Throwable t) {
            Log.w(TAG, "retire failed", t);
        }
    }

    static void forgetSurvivor() { survivor = null; }

    /** Итог системного окна подтверждения удаления файла трека: передаём мосту этой Activity. */
    static void deleteResult(Activity a, int res) {
        try {
            Boot b = inst;
            KxBridge br = b == null ? null : b.bridges.get(a);
            if (br == null) br = survivor;
            if (br != null) br.deleteResult(res);
        } catch (Throwable t) {
            Log.w(TAG, "deleteResult failed", t);
        }
    }

    /** Процесс отрисовки убит, пока Activity жива (будет пересоздана): запоминаем позицию играющего трека до того, как движок остановится. */
    static void renderGone(Activity a) {
        try {
            Boot b = inst;
            KxBridge br = b == null ? null : b.bridges.get(a);
            if (br == null) return;
            br.dead = true;
            br.markCrash();
        } catch (Throwable t) {
            Log.w(TAG, "renderGone failed", t);
        }
    }

    /** Процесс отрисовки убит, пока приложение было закрыто: сохранённая страница мертва — гасим звук и уведомление, чтобы не оставалось кнопок, которые ничего не делают. */
    static void pageDied() {
        KxBridge br = survivor;
        if (br != null && (br.mediaPlaying || br.enginePlaying())) {
            // музыка играет нативным движком и без страницы: не обрываем её. Кнопки play/pause/перемотки в шторке работают напрямую,
            // а при следующем запуске новая страница продолжит с того же места (KxBridge.takeCrashResume)
            br.dead = true;
            return;
        }
        survivor = null;
        if (br != null) {
            try {
                br.shutdown();
            } catch (Throwable ignored) {
                // уже освобождено
            }
        }
    }

    private static volatile Boot inst;

    /** Активити закрывается, но играет музыка: страницу (WebView) нужно сохранить для следующего запуска. Вызывать до super.onDestroy(). */
    static boolean shouldRetain(Activity a) {
        Boot b = inst;
        if (b == null) return false;
        KxBridge br = b.bridges.get(a);
        return br != null && br.outlivesActivity(a);
    }

    /** Есть живая страница от закрытой Activity. */
    static boolean hasSurvivor() { return survivor != null; }

    /** Новая Activity берёт живую страницу: мост перепривязывается к ней, страница не перезагружается, музыка не прерывается. */
    static boolean adopt(Activity a) {
        Boot b = inst;
        KxBridge br = survivor;
        if (b == null || br == null) return false;
        try {
            survivor = null;
            b.bridges.put(a, br);
            br.rebind(a);
            NavBar.apply(a);
            br.ensureHook();
            br.priorityPolicy();
            br.backGuard();
            br.refreshBackGuard();
            Log.i(TAG, "page adopted by " + a.getClass().getName());
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "adopt failed", t);
            return false;
        }
    }

    static synchronized void install(Application app) {
        if (installed) return;
        installed = true;
        Boot b = new Boot();
        inst = b;
        app.registerActivityLifecycleCallbacks(b);
        app.registerComponentCallbacks(b); // смена темы устройства приходит сюда (onConfigurationChanged)
    }

    private void attach(Activity a) {
        try {
            // только основная Activity оболочки (у AdMob и др. свои Activity со своими WebView)
            if (!"WebViewActivity".equals(a.getClass().getSimpleName())) return;
            NavBar.apply(a); // кнопки навигации (если включено в билдере); сам ловит свои ошибки
            KxBridge known = bridges.get(a);
            if (known != null) {
                known.ensureHook(); // оболочка могла заменить WebChromeClient
                return;
            }
            WebView wv = findWebView(a);
            if (wv == null) return;
            retireSurvivor(a); // прежняя страница, игравшая в фоне после выхода, уступает место новой
            KxBridge br = new KxBridge(a, wv);
            wv.addJavascriptInterface(br, "KExport");
            bridges.put(a, br);
            br.ensureHook();
            br.priorityPolicy();
            br.backGuard();
            Log.i(TAG, "KExport attached to " + a.getClass().getName());
            // объект виден только документам, загруженным ПОСЛЕ регистрации: если страница уже загружена
            // (WebView создан лениво, регистрация поздняя) - перезагружаем её один раз
            if (wv.getUrl() != null && wv.getProgress() >= 100) {
                Log.i(TAG, "page already loaded, reloading once");
                wv.reload();
            }
        } catch (Throwable t) {
            Log.w(TAG, "attach failed", t);
        }
    }

    private static WebView findWebView(Activity a) {
        try {
            Method m = a.getClass().getMethod("getWebView");
            Object o = m.invoke(a);
            if (o instanceof WebView) return (WebView) o;
        } catch (Throwable ignored) {
            // lateinit ещё не готов или метод переименован - идём обходом View
        }
        View root = a.getWindow() != null ? a.getWindow().peekDecorView() : null;
        return root == null ? null : walk(root);
    }

    private static WebView walk(View v) {
        if (v instanceof WebView) return (WebView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                WebView w = walk(g.getChildAt(i));
                if (w != null) return w;
            }
        }
        return null;
    }

    public void onActivityCreated(Activity a, Bundle b) { }

    public void onActivityPostCreated(Activity a, Bundle b) { attach(a); }

    public void onActivityStarted(Activity a) { attach(a); }

    public void onActivityResumed(Activity a) {
        attach(a);
        KxBridge br = bridges.get(a);
        if (br != null) br.pushTheme(null); // тема могла смениться, пока приложение было в фоне
    }

    /** Светлая/тёмная тема устройства (и любая другая смена конфигурации): сообщаем странице. */
    public void onConfigurationChanged(Configuration c) {
        try {
            for (KxBridge br : new ArrayList<KxBridge>(bridges.values())) br.pushTheme(c);
        } catch (Throwable t) {
            Log.w(TAG, "theme push failed", t);
        }
    }

    public void onLowMemory() { }

    public void onActivityPaused(Activity a) {
        KxBridge br = bridges.get(a);
        if (br != null) br.keepAlive(); // музыка играет — страницу не усыпляем
    }

    public void onActivityStopped(Activity a) {
        KxBridge br = bridges.get(a);
        if (br != null) br.keepAlive();
    }

    public void onActivitySaveInstanceState(Activity a, Bundle b) { }

    public void onActivityDestroyed(Activity a) {
        KxBridge br = bridges.remove(a);
        if (br == null) return;
        if (br.outlivesActivity(a)) {
            // выход из приложения во время воспроизведения: музыку, сервис и уведомление не трогаем
            survivor = br;
            br.keepAliveDetached();
        } else {
            br.shutdown();
        }
    }
}

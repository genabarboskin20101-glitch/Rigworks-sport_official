package kx.engine;

/** Комплексное БПФ для длин 2^k и 3·2^k (нужно для MDX-Net: n_fft = 6144). Не потокобезопасно: один экземпляр на поток. */
final class SepFft {
    final int n;
    private final int m;
    private final boolean tri;
    private final int[] rev;
    private final float[] c2, s2;      // таблица для радикс-2 длины m
    private final float[] cn, sn;      // exp(-2πi t/n), t = 0..n-1 (только для tri)
    private final float[][] sr = new float[3][], si = new float[3][];

    SepFft(int n) {
        this.n = n;
        if (n >= 3 && n % 3 == 0 && isPow2(n / 3)) { tri = true; m = n / 3; }
        else if (isPow2(n)) { tri = false; m = n; }
        else throw new IllegalArgumentException("fft size " + n);
        rev = new int[m];
        int bits = Integer.numberOfTrailingZeros(m);
        for (int i = 0; i < m; i++) rev[i] = bits == 0 ? 0 : Integer.reverse(i) >>> (32 - bits);
        c2 = new float[Math.max(1, m / 2)];
        s2 = new float[Math.max(1, m / 2)];
        for (int i = 0; i < m / 2; i++) {
            double a = -2.0 * Math.PI * i / m;
            c2[i] = (float) Math.cos(a);
            s2[i] = (float) Math.sin(a);
        }
        if (tri) {
            cn = new float[n];
            sn = new float[n];
            for (int i = 0; i < n; i++) {
                double a = -2.0 * Math.PI * i / n;
                cn[i] = (float) Math.cos(a);
                sn[i] = (float) Math.sin(a);
            }
            for (int r = 0; r < 3; r++) { sr[r] = new float[m]; si[r] = new float[m]; }
        } else { cn = sn = null; }
    }

    private static boolean isPow2(int v) { return v > 0 && (v & (v - 1)) == 0; }

    /** Прямое БПФ на месте. */
    void fft(float[] re, float[] im) {
        if (!tri) { radix2(re, im); return; }
        for (int j = 0; j < m; j++) {
            for (int r = 0; r < 3; r++) { sr[r][j] = re[3 * j + r]; si[r][j] = im[3 * j + r]; }
        }
        for (int r = 0; r < 3; r++) radix2(sr[r], si[r]);
        for (int k = 0; k < n; k++) {
            int kk = k % m;
            int t1 = k, t2 = (2 * k) % n;
            float a1 = cn[t1], b1 = sn[t1], a2 = cn[t2], b2 = sn[t2];
            float xr1 = sr[1][kk], xi1 = si[1][kk], xr2 = sr[2][kk], xi2 = si[2][kk];
            re[k] = sr[0][kk] + a1 * xr1 - b1 * xi1 + a2 * xr2 - b2 * xi2;
            im[k] = si[0][kk] + a1 * xi1 + b1 * xr1 + a2 * xi2 + b2 * xr2;
        }
    }

    private void radix2(float[] re, float[] im) {
        final int len = m;
        for (int i = 0; i < len; i++) {
            int j = rev[i];
            if (j > i) {
                float t = re[i]; re[i] = re[j]; re[j] = t;
                t = im[i]; im[i] = im[j]; im[j] = t;
            }
        }
        for (int size = 2; size <= len; size <<= 1) {
            int half = size >> 1, step = len / size;
            for (int start = 0; start < len; start += size) {
                for (int k = 0, tw = 0; k < half; k++, tw += step) {
                    float wr = c2[tw], wi = s2[tw];
                    int a = start + k, b = a + half;
                    float xr = re[b] * wr - im[b] * wi;
                    float xi = re[b] * wi + im[b] * wr;
                    re[b] = re[a] - xr; im[b] = im[a] - xi;
                    re[a] += xr; im[a] += xi;
                }
            }
        }
    }
}

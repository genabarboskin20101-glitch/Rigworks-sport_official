package kx.engine;

import java.util.Arrays;

/**
 * Разделение на дорожки: Demucs-подобные модели (один вход «звук» или два входа «звук + спектр») и MDX-Net (спектр).
 * Нейросеть спрятана за интерфейсом Net, поэтому вся обвязка (окна, наложение, нормализация) проверяется отдельно от ONNX Runtime.
 */
final class Separator {
    static final int RATE = 44100;

    interface Net {
        int inputCount();
        /** Форма входа i; неизвестные (динамические) размеры — значения <= 0. */
        long[] inputShape(int i);
        Out run(float[][] inputs, long[][] shapes) throws Exception;
    }

    static final class Out {
        final float[][] data;
        final long[][] shapes;
        Out(float[][] d, long[][] s) { data = d; shapes = s; }
    }

    interface Prog {
        void on(float fraction);
        boolean cancelled();
    }

    static final class Cancelled extends Exception { Cancelled() { super("cancelled"); } }

    private static void check(Prog p) throws Cancelled { if (p != null && p.cancelled()) throw new Cancelled(); }

    /** Число шагов нейросети для трека такой длины (для расчёта общего процента). */
    static int steps(Net net, int n, boolean mdx) {
        if (mdx) {
            long[] sh = net.inputShape(0);
            int dimT = sh.length >= 4 && sh[3] > 0 ? (int) sh[3] : 256;
            int dimF = sh.length >= 4 && sh[2] > 0 ? (int) sh[2] : 3072;
            int gen = 1024 * (dimT - 1) - 2 * dimF;
            return Math.max(1, (n + gen - 1) / gen);
        }
        int seg = demucsSegment(net);
        int stride = (int) (0.75 * seg);
        return Math.max(1, (n + stride - 1) / stride);
    }

    static boolean isMdx(Net net) {
        if (net.inputCount() != 1) return false;
        long[] s = net.inputShape(0);
        return s.length == 4 && s[1] == 4;
    }

    private static int demucsSegment(Net net) {
        for (int i = 0; i < net.inputCount(); i++) {
            long[] s = net.inputShape(i);
            if (s.length == 3 && s[2] > 0) return (int) s[2];
        }
        return 343980;
    }

    // ---------------------------------------------------------------- Demucs

    /**
     * mix: [2][n] 44,1 кГц. want[s] — какие дорожки нужны (по индексу выхода модели). Возвращает [S][2][n] (null у ненужных).
     * Порядок и число дорожек определяются моделью (S берётся из формы выхода).
     */
    static float[][][] demucs(Net net, float[][] mix, int n, boolean[] want, Prog prog) throws Exception {
        final int T = demucsSegment(net);
        final boolean twoIn = net.inputCount() >= 2;
        int specIdx = -1, wavIdx = -1;
        for (int i = 0; i < net.inputCount(); i++) {
            long[] s = net.inputShape(i);
            if (s.length == 4) specIdx = i; else if (s.length == 3) wavIdx = i;
        }
        if (wavIdx < 0) wavIdx = 0;
        int F = 0, Tf = 0, nfft = 4096;
        if (twoIn && specIdx >= 0) {
            long[] s = net.inputShape(specIdx);
            F = (int) s[2]; Tf = (int) s[3];
            nfft = 2 * F;
        }
        final int hop = nfft / 4;
        final int le = (int) Math.ceil(T / (double) hop);
        if (twoIn && Tf <= 0) Tf = le;
        SepStft stft = twoIn ? new SepStft(nfft, hop) : null;
        final int pad = hop / 2 * 3;

        // глобальная нормализация, как в demucs.separate: по среднему каналу
        double sum = 0, sum2 = 0;
        for (int i = 0; i < n; i++) { double v = 0.5 * (mix[0][i] + mix[1][i]); sum += v; sum2 += v * v; }
        double mean = sum / Math.max(1, n);
        double var = Math.max(0, sum2 / Math.max(1, n) - mean * mean);
        double std = Math.sqrt(var);
        if (std < 1e-8) std = 1.0;
        final float fm = (float) mean, fs = (float) std;

        final int stride = (int) (0.75 * T);
        float[] weight = new float[T];
        for (int i = 0; i < T; i++) weight[i] = (i < T / 2 ? i + 1 : T - i) / (float) (T / 2);
        float[] sumW = new float[n];
        float[][][] acc = null;
        int S = 0;
        float[] cl = new float[T], cr = new float[T];
        int chunks = Math.max(1, (n + stride - 1) / stride), done = 0;
        for (int off = 0; off < n; off += stride) {
            check(prog);
            int len = Math.min(T, n - off);
            Arrays.fill(cl, 0f); Arrays.fill(cr, 0f);
            for (int i = 0; i < len; i++) { cl[i] = (mix[0][off + i] - fm) / fs; cr[i] = (mix[1][off + i] - fm) / fs; }
            float[] wav = new float[2 * T];
            System.arraycopy(cl, 0, wav, 0, T);
            System.arraycopy(cr, 0, wav, T, T);
            float[][] ins = new float[net.inputCount()][];
            long[][] shp = new long[net.inputCount()][];
            ins[wavIdx] = wav; shp[wavIdx] = new long[]{1, 2, T};
            if (twoIn && specIdx >= 0) {
                float[] pl = SepStft.reflectPad(cl, T, pad, pad + le * hop - T);
                float[] pr = SepStft.reflectPad(cr, T, pad, pad + le * hop - T);
                pl = SepStft.reflectPad(pl, pl.length, nfft / 2, nfft / 2);
                pr = SepStft.reflectPad(pr, pr.length, nfft / 2, nfft / 2);
                float[] x = new float[4 * F * Tf];
                stft.analyze(pl, pr, F, 1f / (float) Math.sqrt(nfft), x, 2, Tf);
                ins[specIdx] = x; shp[specIdx] = new long[]{1, 4, F, Tf};
            }
            Out o = net.run(ins, shp);
            // выходы: 4-мерный [1,S,2,T] — время; 5-мерный [1,S,4,F,Tf] — спектр
            int ti = -1, fi = -1;
            for (int i = 0; i < o.shapes.length; i++) {
                if (o.shapes[i].length == 4) ti = i; else if (o.shapes[i].length == 5) fi = i;
            }
            if (ti < 0 && fi < 0) throw new IllegalStateException("model_output");
            int s = (int) o.shapes[ti >= 0 ? ti : fi][1];
            if (acc == null) {
                S = s;
                acc = new float[S][][];
                for (int k = 0; k < S; k++) if (want == null || (k < want.length && want[k])) acc[k] = new float[2][n];
            }
            float[] ol = fi >= 0 ? new float[(Tf + 3) * hop + nfft] : null;
            float[] or = fi >= 0 ? new float[ol.length] : null;
            for (int k = 0; k < S; k++) {
                if (acc[k] == null) continue;
                float[] sl = new float[T], sr = new float[T];
                if (fi >= 0) {
                    int Fo = (int) o.shapes[fi][3], To = (int) o.shapes[fi][4];
                    stft.synth(o.data[fi], k * 4 * Fo * To, Fo, To, 2, To + 4, 1f / (float) Math.sqrt(nfft), ol, or);
                    int st = nfft / 2 + pad;
                    System.arraycopy(ol, st, sl, 0, T);
                    System.arraycopy(or, st, sr, 0, T);
                }
                if (ti >= 0) {
                    float[] td = o.data[ti];
                    int base = k * 2 * T;
                    for (int i = 0; i < T; i++) { sl[i] += td[base + i]; sr[i] += td[base + T + i]; }
                }
                for (int i = 0; i < len; i++) {
                    float w = weight[i];
                    acc[k][0][off + i] += sl[i] * w;
                    acc[k][1][off + i] += sr[i] * w;
                }
            }
            for (int i = 0; i < len; i++) sumW[off + i] += weight[i];
            done++;
            if (prog != null) prog.on(done / (float) chunks);
        }
        if (acc == null) throw new IllegalStateException("empty");
        for (int k = 0; k < S; k++) {
            if (acc[k] == null) continue;
            for (int c = 0; c < 2; c++) {
                float[] a = acc[k][c];
                for (int i = 0; i < n; i++) {
                    float w = sumW[i];
                    a[i] = (w > 1e-9f ? a[i] / w : 0f) * fs + fm;
                }
            }
        }
        return acc;
    }

    // ---------------------------------------------------------------- MDX-Net

    /** Возвращает инструментал [2][n] (первичная дорожка модели UVR-MDX-NET-Inst_*). */
    static float[][] mdx(Net net, float[][] mix, int n, Prog prog) throws Exception {
        long[] sh = net.inputShape(0);
        final int dimF = sh[2] > 0 ? (int) sh[2] : 3072;
        final int dimT = sh[3] > 0 ? (int) sh[3] : 256;
        final int nfft = 2 * dimF, hop = 1024;
        final int chunk = hop * (dimT - 1), trim = nfft / 2, gen = chunk - 2 * trim;
        SepStft stft = new SepStft(nfft, hop);
        int count = Math.max(1, (n + gen - 1) / gen);
        int total = trim + (count - 1) * gen + chunk;
        float[] pl = new float[total], pr = new float[total];
        System.arraycopy(mix[0], 0, pl, trim, n);
        System.arraycopy(mix[1], 0, pr, trim, n);
        float[][] out = new float[2][n];
        float[] al = new float[chunk], ar = new float[chunk];
        float[] ol = new float[(dimT - 1) * hop + nfft], or = new float[ol.length];
        for (int i = 0; i < count; i++) {
            check(prog);
            int st = i * gen;
            System.arraycopy(pl, st, al, 0, chunk);
            System.arraycopy(pr, st, ar, 0, chunk);
            float[] l2 = SepStft.reflectPad(al, chunk, nfft / 2, nfft / 2);
            float[] r2 = SepStft.reflectPad(ar, chunk, nfft / 2, nfft / 2);
            float[] x = new float[4 * dimF * dimT];
            stft.analyze(l2, r2, dimF, 1f, x, 0, dimT);
            Arrays.fill(x, 0, 3 * dimT, 0f);                               // нули для трёх нижних бинов L.re
            Arrays.fill(x, dimF * dimT, dimF * dimT + 3 * dimT, 0f);       // L.im
            Arrays.fill(x, 2 * dimF * dimT, 2 * dimF * dimT + 3 * dimT, 0f); // R.re
            Arrays.fill(x, 3 * dimF * dimT, 3 * dimF * dimT + 3 * dimT, 0f);// R.im
            Out o = net.run(new float[][]{x}, new long[][]{{1, 4, dimF, dimT}});
            stft.synth(o.data[0], 0, dimF, dimT, 0, dimT, 1f / nfft, ol, or);
            int keepFrom = nfft / 2 + trim;   // центр-дополнение STFT + срез краёв кусочка
            int dst = i * gen;
            int cnt = Math.min(gen, n - dst);
            if (cnt > 0) {
                System.arraycopy(ol, keepFrom, out[0], dst, cnt);
                System.arraycopy(or, keepFrom, out[1], dst, cnt);
            }
            if (prog != null) prog.on((i + 1) / (float) count);
        }
        return out;
    }
}

package kx.engine;

/**
 * STFT/обратное STFT сразу для двух каналов (L в вещественной, R в мнимой части одного БПФ).
 * Раскладка спектра — как у моделей: [4, bins, T], каналы L.re, L.im, R.re, R.im.
 */
final class SepStft {
    final int nfft, hop, half;
    final float[] win;
    private final SepFft fft;
    private final float[] zr, zi;
    private float[] env;
    private int envFrames = -1;

    SepStft(int nfft, int hop) {
        this.nfft = nfft; this.hop = hop; this.half = nfft / 2;
        win = new float[nfft];
        for (int i = 0; i < nfft; i++) win[i] = (float) (0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / nfft)); // периодическое Хэнна
        fft = new SepFft(nfft);
        zr = new float[nfft]; zi = new float[nfft];
    }

    static int frames(int len, int nfft, int hop) { return 1 + (len - nfft) / hop; }

    /** Отражающее дополнение, как torch pad mode=reflect. */
    static float[] reflectPad(float[] src, int len, int left, int right) {
        float[] o = new float[left + len + right];
        System.arraycopy(src, 0, o, left, len);
        for (int i = 1; i <= left; i++) o[left - i] = src[Math.min(len - 1, i)];
        for (int i = 1; i <= right; i++) o[left + len - 1 + i] = src[Math.max(0, len - 1 - i)];
        return o;
    }

    /** Кадры frameOff..frameOff+T-1 → out[(c*keep + k)*T + t]. */
    void analyze(float[] l, float[] r, int keep, float scale, float[] out, int frameOff, int T) {
        for (int t = 0; t < T; t++) {
            int base = (frameOff + t) * hop;
            for (int j = 0; j < nfft; j++) { float w = win[j]; zr[j] = l[base + j] * w; zi[j] = r[base + j] * w; }
            fft.fft(zr, zi);
            for (int k = 0; k < keep; k++) {
                int nk = k == 0 ? 0 : nfft - k;
                float lr = (zr[k] + zr[nk]) * 0.5f * scale, li = (zi[k] - zi[nk]) * 0.5f * scale;
                float rr = (zi[k] + zi[nk]) * 0.5f * scale, ri = -(zr[k] - zr[nk]) * 0.5f * scale;
                out[(k) * T + t] = lr;
                out[(keep + k) * T + t] = li;
                out[(2 * keep + k) * T + t] = rr;
                out[(3 * keep + k) * T + t] = ri;
            }
        }
    }

    /**
     * Обратное STFT с наложением. spec — [4, keep, T] со смещением off в общей сетке из totalFrames кадров
     * (остальные кадры нулевые). Результат длиной (totalFrames-1)*hop+nfft, уже поделён на огибающую окна.
     */
    void synth(float[] spec, int specOff, int keep, int T, int frameOff, int totalFrames, float scale, float[] outL, float[] outR) {
        int len = (totalFrames - 1) * hop + nfft;
        java.util.Arrays.fill(outL, 0, len, 0f);
        java.util.Arrays.fill(outR, 0, len, 0f);
        for (int t = 0; t < T; t++) {
            int tt = frameOff + t;
            for (int k = 0; k <= half; k++) {
                float lr = 0, li = 0, rr = 0, ri = 0;
                if (k < keep) {
                    lr = spec[specOff + k * T + t];
                    li = spec[specOff + (keep + k) * T + t];
                    rr = spec[specOff + (2 * keep + k) * T + t];
                    ri = spec[specOff + (3 * keep + k) * T + t];
                }
                if (k == 0 || k == half) { li = 0f; ri = 0f; }   // как irfft: мнимая часть DC и Найквиста игнорируется
                // Z = L + iR
                float zre = lr - ri, zim = li + rr;
                zr[k] = zre; zi[k] = -zim;                 // сопряжение для обратного через прямое БПФ
                if (k != 0 && k != half) {
                    int nk = nfft - k;
                    zr[nk] = lr + ri;                       // conj(L) + i·conj(R)
                    zi[nk] = -(-li + rr);
                }
            }
            fft.fft(zr, zi);
            int base = tt * hop;
            for (int j = 0; j < nfft; j++) {
                float w = win[j] * scale;
                outL[base + j] += zr[j] * w;
                outR[base + j] += -zi[j] * w;
            }
        }
        if (envFrames != totalFrames) {
            env = new float[len];
            for (int t = 0; t < totalFrames; t++) for (int j = 0; j < nfft; j++) env[t * hop + j] += win[j] * win[j];
            envFrames = totalFrames;
        }
        for (int i = 0; i < len; i++) {
            float e = env[i];
            if (e > 1e-11f) { outL[i] /= e; outR[i] /= e; }
        }
    }

}

package kx.engine;

import android.content.Context;
import android.os.PowerManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Задание «разделить трек»: по очереди гоняет выбранные модели, пишет по WAV-файлу на каждую выбранную дорожку. */
final class SepJob implements Runnable {
    private static final String TAG = "SepJob";

    static final class Out {
        String label;
        String model;
        List<String> stems = new ArrayList<>();
        float gain = 1f;
        /** Если задано: модель получает на вход не исходный микс, а дорожку fromStem, выделенную моделью fromModel. */
        String fromModel, fromStem;
        /** Ключи строк списка в интерфейсе, которым соответствует дорожка (через запятую). */
        String key = "";
        /** Имя файла результата и поток записи (заполняются при обработке). */
        String file;
        WavSink sink;
    }

    /** Порядок дорожек в выходе каждой модели. */
    static String[] sourcesOf(String model) {
        String m = model.toLowerCase();
        if (m.contains("htdemucs_6s")) return new String[]{"drums", "bass", "other", "vocals", "guitar", "piano"};
        if (m.contains("drumsep")) return new String[]{"kick", "snare", "cymbals", "toms"};
        return new String[]{"drums", "bass", "other", "vocals"};
    }

    static boolean isMdxId(String model) { return model.toLowerCase().contains("mdx"); }

    private static final float MDX_COMPENSATE = 1.035f;

    private final NativeAudio host;
    private final Context ctx;
    private final File source;
    private final String base;
    private final boolean allowDownload;
    private final List<Out> outs = new ArrayList<>();
    private volatile boolean cancel;
    private volatile File outDirRef;
    private volatile boolean finished;
    private final Runnable onFinish;

    private int lastPct = -1;
    private double doneWork, totalWork;

    /** Адрес, по которому WebView получает дорожки (отдаёт StemServe). */
    static final String STEM_HOST = "https://lmusic-stems.local/";
    private String jobId = "j" + System.currentTimeMillis();
    /** Режим «добавить к готовому»: дорожки того же трека, уже лежащие в last.json, не пересчитываются. */
    private JSONObject prev;
    private String track = "";
    /** model:stem -> файл в папке результата: сырой выход модели, из которого можно сразу делить дальше (например ударные для drumsep). */
    private final JSONObject hid = new JSONObject();
    private final List<File> created = new ArrayList<>();

    /** Корневая папка готовых дорожек: files/sepout/<job>/ ; рядом лежит last.json с описанием последнего результата. */
    static File rootDir(Context c) { return new File(c.getFilesDir(), "sepout"); }

    SepJob(NativeAudio host, Context ctx, File source, String base, JSONObject plan, Runnable onFinish) throws Exception {
        this.host = host;
        this.ctx = ctx;
        this.source = source;
        this.base = base;
        this.onFinish = onFinish;
        this.allowDownload = plan.optBoolean("download", false);
        this.track = plan.optString("track", "");
        if (plan.optBoolean("append", false)) {
            prev = loadPrev(ctx, track);
            if (prev != null) {
                jobId = prev.getString("job");
                JSONObject h = prev.optJSONObject("hid");
                if (h != null) {
                    java.util.Iterator<String> it = h.keys();
                    while (it.hasNext()) { String k = it.next(); hid.put(k, h.getString(k)); }
                }
            }
        }
        JSONArray a = plan.getJSONArray("outputs");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Out x = new Out();
            x.label = o.optString("label", "Дорожка");
            x.model = o.getString("model");
            x.gain = (float) Math.max(0, Math.min(2, o.optDouble("gain", 1)));
            JSONArray st = o.getJSONArray("stems");
            for (int j = 0; j < st.length(); j++) x.stems.add(st.getString(j));
            x.key = o.optString("key", "");
            JSONObject fr = o.optJSONObject("from");
            if (fr != null) { x.fromModel = fr.getString("model"); x.fromStem = fr.getString("stem"); }
            outs.add(x);
        }
        if (outs.isEmpty()) throw new IllegalArgumentException("empty plan");
    }

    void cancel() { cancel = true; }

    /** Описание прошлого результата для того же трека (track) или null, если его нет, он от другого трека или файлы пропали. */
    static JSONObject loadPrev(Context c, String track) {
        try {
            File f = new File(rootDir(c), "last.json");
            if (track == null || track.isEmpty() || !f.isFile()) return null;
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            try (java.io.InputStream in = new java.io.FileInputStream(f)) {
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            }
            JSONObject o = new JSONObject(new String(bo.toByteArray(), "UTF-8"));
            if (!track.equals(o.optString("track", ""))) return null;
            File d = new File(rootDir(c), o.getString("job"));
            JSONArray st = o.getJSONArray("stems");
            for (int i = 0; i < st.length(); i++) if (!new File(d, st.getJSONObject(i).getString("file")).isFile()) return null;
            JSONObject h = o.optJSONObject("hid");
            if (h != null) {
                java.util.Iterator<String> it = h.keys();
                while (it.hasNext()) if (!new File(d, h.getString(it.next())).isFile()) return null;
            }
            return o;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Список нужных моделей, которых ещё нет на устройстве (модель-источник цепочки не нужна, если её выход уже сохранён). */
    static List<String> missing(Context c, JSONObject plan) throws Exception {
        List<String> r = new ArrayList<>();
        JSONObject pv = plan.optBoolean("append", false) ? loadPrev(c, plan.optString("track", "")) : null;
        JSONObject h = pv == null ? null : pv.optJSONObject("hid");
        JSONArray a = plan.getJSONArray("outputs");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            String m = o.getString("model");
            if (!r.contains(m) && !SepModels.has(c, m)) r.add(m);
            JSONObject fr = o.optJSONObject("from");
            if (fr != null) {
                String fm = fr.getString("model");
                boolean have = h != null && h.has(fm + ":" + fr.getString("stem"));
                if (!have && !r.contains(fm) && !SepModels.has(c, fm)) r.add(fm);
            }
        }
        return r;
    }

    private void event(String phase, int pct, String stage, String label, int step, int steps, String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("phase", phase);
            o.put("progress", pct);
            if (stage != null) o.put("stage", stage);
            if (label != null) o.put("label", label);
            o.put("step", step);
            o.put("steps", steps);
            if (msg != null) { if ("done".equals(phase)) o.put("name", msg); else o.put("message", msg); }
            host.sepJs("window.__lmusicSeparateEvent&&window.__lmusicSeparateEvent(" + o.toString() + ")");
        } catch (Throwable t) {
            Log.w(TAG, "event failed", t);
        }
    }

    /** Ход скачивания модели: реальный процент и размер в МБ (не доля общей работы). */
    private void eventDownload(String modelId, String label, int step, int steps, long done, long total) {
        try {
            JSONObject o = new JSONObject();
            o.put("phase", "progress");
            o.put("stage", "download");
            o.put("progress", Math.max(0, Math.min(99, (int) Math.floor(100.0 * Math.max(0, doneWork) / Math.max(1e-9, totalWork)))));
            o.put("label", label);
            o.put("model", modelId);
            o.put("step", step);
            o.put("steps", steps);
            o.put("dlDone", done);
            o.put("dlTotal", total);
            o.put("dl", total > 0 ? Math.max(0, Math.min(100, (int) Math.floor(100.0 * done / total))) : -1);
            host.sepJs("window.__lmusicSeparateEvent&&window.__lmusicSeparateEvent(" + o.toString() + ")");
        } catch (Throwable t) {
            Log.w(TAG, "download event failed", t);
        }
    }

    private void tick(String stage, String label, int step, int steps, double add) {
        double v = doneWork + add;
        int pct = (int) Math.max(0, Math.min(99, Math.floor(100.0 * v / Math.max(1e-9, totalWork))));
        if (pct != lastPct) { lastPct = pct; event("progress", pct, stage, label, step, steps, null); }
    }

    private boolean dependent(Pass p) { return !p.outs.isEmpty() && p.outs.get(0).fromModel != null; }

    private final class Pass {
        String model;
        List<Out> outs = new ArrayList<>();
        /** Дорожки, которые нужны только как вход для следующей модели (в файлы не пишутся). */
        List<String> hidden = new ArrayList<>();
        final Map<String, WavSink> hiddenSinks = new java.util.LinkedHashMap<>();
        boolean need;
        double work;
        double dlWork;
    }

    @Override public void run() {
        PowerManager.WakeLock wl = null;
        File raw = null;
        try {
            try {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                if (pm != null) { wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lmusic:separate"); wl.acquire(60 * 60 * 1000L); }
            } catch (Throwable ignored) { }
            Map<String, Pass> passes = new LinkedHashMap<>();
            for (Out o : outs) {
                if (o.fromModel != null && !hid.has(o.fromModel + ":" + o.fromStem)) { // цепочка: сначала модель-источник выделяет дорожку, потом вторая модель делит её
                    Pass f = passes.get(o.fromModel);
                    if (f == null) { f = new Pass(); f.model = o.fromModel; passes.put(o.fromModel, f); }
                    if (!f.hidden.contains(o.fromStem)) f.hidden.add(o.fromStem);
                }
                Pass p = passes.get(o.model);
                if (p == null) { p = new Pass(); p.model = o.model; passes.put(o.model, p); }
                p.outs.add(o);
            }
            // модель-источник должна быть раньше зависимых: переносим зависимые проходы в конец
            Map<String, Pass> ordered = new LinkedHashMap<>();
            for (Pass p : passes.values()) if (!dependent(p)) ordered.put(p.model, p);
            for (Pass p : passes.values()) if (dependent(p)) ordered.put(p.model, p);
            passes.clear(); passes.putAll(ordered);
            for (Pass p : passes.values()) {
                p.need = !SepModels.has(ctx, p.model);
                if (p.need && !allowDownload) throw new java.io.IOException("need_download");
            }
            // модели качаем первыми: прогресс виден сразу, а без сети не тратим время на декодирование трека
            int dlIdx = 0, dlTotal = 0;
            for (Pass p : passes.values()) if (p.need) dlTotal++;
            for (final Pass p : passes.values()) {
                if (!p.need) continue;
                dlIdx++;
                final int step = dlIdx, steps = dlTotal;
                final String label0 = p.outs.isEmpty() ? "Ударные" : p.outs.get(0).label, modelId = p.model;
                SepModels.ensure(ctx, p.model, new SepModels.Dl() {
                    long lastDone = -1;
                    @Override public void on(long done, long total) {
                        if (done == lastDone && done > 0) return;
                        lastDone = done;
                        eventDownload(modelId, label0, step, steps, done, total);
                    }
                    @Override public boolean cancelled() { return cancel; }
                });
                if (cancel) throw new Separator.Cancelled();
            }
            event("progress", 0, "decode", null, 0, passes.size(), null);
            raw = new File(host.sepDir(), "sep_" + System.currentTimeMillis() + ".pcm.tmp");
            int rate = host.sepDecode(source, raw, "sep" + System.currentTimeMillis());
            if (rate < 8000 || !raw.isFile() || raw.length() < 8) throw new java.io.IOException("decode_failed");
            long frames = raw.length() / 8L;
            if (frames * 1.0 * Separator.RATE / rate > 44100L * 60 * 14) throw new java.io.IOException("too_long");
            float[][] mix = loadResampled(raw, frames, rate);
            raw.delete(); raw = null;
            final int n = mix[0].length;
            if (cancel) throw new Separator.Cancelled();

            // оценка объёма работы для общего процента
            totalWork = 0;
            for (Pass p : passes.values()) {
                int steps = isMdxId(p.model) ? Math.max(1, (n + 254975) / 254976) : Math.max(1, (n + 257984) / 257985);
                p.work = steps;
                p.dlWork = 0;
                totalWork += p.work + p.dlWork + 0.5 * p.outs.size() + 1;
            }
            doneWork = 1;
            int idx = 0, total = passes.size();
            final File outDir = new File(rootDir(ctx), jobId);
            outDirRef = outDir;
            if (!outDir.mkdirs() && !outDir.isDirectory()) throw new java.io.IOException("no_space");
            final org.json.JSONArray stemList = new org.json.JSONArray();
            if (prev != null) { JSONArray ps = prev.getJSONArray("stems"); for (int i = 0; i < ps.length(); i++) stemList.put(ps.getJSONObject(i)); }
            for (final Pass p : passes.values()) {
                idx++;
                final int step = idx;
                final String label0 = p.outs.isEmpty() ? "Ударные" : p.outs.get(0).label;
                if (cancel) throw new Separator.Cancelled();
                tick("load", label0, step, total, 0);
                File mf = SepModels.find(ctx, p.model);
                if (mf == null) throw new java.io.IOException("model_not_found:" + p.model);
                // Результат пишется на диск прямо по ходу обработки (WavSink): в памяти остаётся только сам трек и небольшое окно модели
                final int base0 = stemList.length();
                final List<WavSink> opened = new ArrayList<>();
                final Map<String, String> newHid = new java.util.LinkedHashMap<>(); // model:stem -> файл скрытой дорожки
                int fi = 0;
                for (Out o : p.outs) {
                    o.file = "s" + (base0 + fi++) + ".wav";
                    o.sink = new WavSink(new File(outDir, o.file + ".part"), n);
                    opened.add(o.sink);
                }
                boolean okPass = false;
                try (OrtNet net = new OrtNet(mf)) {
                    final double w = p.work;
                    Separator.Prog prog = new Separator.Prog() {
                        @Override public void on(float f) { tick("separate", label0, step, passes.size(), w * f); }
                        @Override public boolean cancelled() { return cancel; }
                    };
                    // обычная модель слушает весь микс; модель второго этапа — только дорожку, выделенную первой
                    float[][] input = mix;
                    if (!p.outs.isEmpty() && p.outs.get(0).fromModel != null) {
                        String ik = p.outs.get(0).fromModel + ":" + p.outs.get(0).fromStem;
                        if (!hid.has(ik)) throw new IllegalStateException("stem " + p.outs.get(0).fromStem);
                        input = readWav(new File(outDir, hid.getString(ik)), n); // выход первой модели лежит на диске
                    }
                    if (Separator.isMdx(net)) {
                        Separator.Sink si = null, sv = null;
                        for (Out o : p.outs) { if ("vocals".equals(o.stems.get(0))) sv = o.sink; else si = o.sink; }
                        Separator.mdx(net, input, n, si, MDX_COMPENSATE, sv, prog);
                    } else {
                        String[] src = sourcesOf(p.model);
                        Separator.Sink[] sinks = new Separator.Sink[Math.max(src.length, 8)];
                        for (Out o : p.outs) {
                            int k = Arrays.asList(src).indexOf(o.stems.get(0));
                            if (k < 0) throw new IllegalStateException("stem " + o.stems.get(0));
                            sinks[k] = o.sink;
                        }
                        int hi = 0;
                        for (String h : p.hidden) {
                            int k = Arrays.asList(src).indexOf(h);
                            if (k < 0) throw new IllegalStateException("stem " + h);
                            if (sinks[k] != null) { // эта же дорожка нужна и как результат — отдельный файл не нужен
                                for (Out o : p.outs) if (o.sink == sinks[k]) newHid.put(p.model + ":" + h, o.file);
                            } else {
                                String hn = "h" + (hid.length() + hi++) + ".wav";
                                WavSink hs = new WavSink(new File(outDir, hn + ".part"), n);
                                opened.add(hs);
                                sinks[k] = hs;
                                newHid.put(p.model + ":" + h, hn);
                                p.hiddenSinks.put(hn, hs);
                            }
                        }
                        Separator.demucs(net, input, n, sinks, prog);
                    }
                    okPass = true;
                } finally {
                    for (WavSink ws : opened) { if (okPass) ws.close(); else ws.abort(); }
                }
                // готовые файлы: .part -> финальное имя
                for (Out o : p.outs) {
                    File wav = new File(outDir, o.file), part = new File(outDir, o.file + ".part");
                    if (!part.renameTo(wav)) throw new java.io.IOException("publish_failed");
                    created.add(wav);
                }
                for (String hn : p.hiddenSinks.keySet()) {
                    File hw = new File(outDir, hn), hp = new File(outDir, hn + ".part");
                    if (!hp.renameTo(hw)) throw new java.io.IOException("publish_failed");
                    created.add(hw);
                }
                for (Map.Entry<String, String> e : newHid.entrySet()) hid.put(e.getKey(), e.getValue());
                doneWork += p.work;
                for (Out o : p.outs) {
                    if (cancel) throw new Separator.Cancelled();
                    tick("save", o.label, step, total, 0);
                    JSONObject sj = new JSONObject();
                    sj.put("id", "s" + stemList.length());
                    sj.put("label", o.label);
                    sj.put("gain", o.gain);
                    sj.put("key", o.key);
                    sj.put("file", o.file);
                    sj.put("url", STEM_HOST + jobId + "/" + o.file);
                    stemList.put(sj);
                    if (o.fromModel == null && o.stems.size() == 1 && !hid.has(o.model + ":" + o.stems.get(0))) hid.put(o.model + ":" + o.stems.get(0), o.file);
                    doneWork += 0.5;
                }
            }
            JSONObject result = new JSONObject();
            result.put("job", jobId);
            result.put("base", base);
            result.put("track", track);
            result.put("hid", hid);
            result.put("stems", stemList);
            writeText(new File(rootDir(ctx), "last.json"), result.toString());
            finished = true;
            cleanOldJobs(ctx, jobId); // прошлые результаты больше не нужны: освобождаем место
            JSONObject o = new JSONObject(result.toString());
            o.put("phase", "done");
            o.put("progress", 100);
            o.put("step", total);
            o.put("steps", total);
            host.sepJs("window.__lmusicSeparateEvent&&window.__lmusicSeparateEvent(" + o.toString() + ")");
        } catch (Separator.Cancelled c) {
            event("error", 0, null, null, 0, 0, "Обработка отменена");
        } catch (OutOfMemoryError oom) {
            Log.w(TAG, "oom", oom);
            event("error", 0, null, null, 0, 0, "Не хватило памяти: трек слишком длинный для этого устройства");
        } catch (Throwable t) {
            Log.w(TAG, "separate failed", t);
            event("error", 0, null, null, 0, 0, errorText(t));
        } finally {
            if (raw != null) raw.delete();
            if (!finished && outDirRef != null) { // отмена или ошибка: недописанное убираем, прошлый результат не трогаем
                for (File x : created) x.delete();
                File[] fs = outDirRef.listFiles();
                if (fs != null) for (File x : fs) if (x.getName().endsWith(".part")) x.delete();
                if (prev == null) { // свой каталог: пустой удаляем
                    File[] rest = outDirRef.listFiles();
                    if (rest != null) for (File x : rest) x.delete();
                    outDirRef.delete();
                }
            }
            try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
            if (onFinish != null) onFinish.run();
        }
    }

    private static String errorText(Throwable t) {
        String s = String.valueOf(t.getMessage());
        if (t instanceof java.net.UnknownHostException || t instanceof java.net.SocketTimeoutException || t instanceof java.net.ConnectException)
            return "Нет подключения к интернету: не удалось скачать модель ИИ";
        if (s.startsWith("need_download")) return "Сначала нужно скачать модель ИИ";
        if (s.startsWith("model_not_found")) return "Модель не найдена в релизе GitHub: " + s.substring(Math.min(s.length(), 16));
        if (s.startsWith("model_format")) return "Файл модели в релизе не в формате ONNX: " + s.substring(Math.min(s.length(), 13));
        if (s.startsWith("http_") || s.startsWith("api_") || s.startsWith("download_incomplete")) return "Не удалось скачать модель (" + s + ")";
        if (s.contains("too_long")) return "Трек слишком длинный для разделения (больше 14 минут)";
        if (s.contains("decode_failed") || s.contains("no_audio_track")) return "Не удалось декодировать исходный аудиофайл";
        if (s.contains("no_space")) return "Недостаточно свободного места";
        if (s.contains("storage_permission")) return "Для сохранения в папку Music разрешите доступ к файлам и повторите";
        if (s.contains("publish_failed")) return "Не удалось сохранить файл в папку Music";
        if (s.contains("ai.onnxruntime") || t.getClass().getName().startsWith("ai.onnxruntime")) return "Не удалось запустить модель ИИ: " + (s.length() > 80 ? s.substring(0, 80) : s);
        return "Не удалось разделить трек: " + (s.length() > 90 ? s.substring(0, 90) : s);
    }

    // ------------------------------------------------------------ PCM, ресемплер, WAV

    /** Читает interleaved float32 stereo и приводит к 44,1 кГц. */
    static float[][] loadResampled(File raw, long frames, int rate) throws Exception {
        float[][] in = new float[2][(int) frames];
        try (InputStream is = new BufferedInputStream(new FileInputStream(raw), 1 << 20)) {
            byte[] buf = new byte[1 << 20];
            ByteBuffer bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
            int pos = 0, have = 0;
            while (pos < frames) {
                int need = (int) Math.min((buf.length / 8), frames - pos) * 8, got = 0;
                while (got < need) { int r = is.read(buf, got, need - got); if (r < 0) break; got += r; }
                int fr = got / 8;
                if (fr == 0) break;
                bb.clear();
                for (int i = 0; i < fr; i++) { in[0][pos + i] = bb.getFloat(); in[1][pos + i] = bb.getFloat(); }
                pos += fr;
                have = pos;
            }
            if (have < frames) { in[0] = Arrays.copyOf(in[0], have); in[1] = Arrays.copyOf(in[1], have); }
        }
        if (rate == Separator.RATE) return in;
        return new float[][]{resample(in[0], rate), resample(in[1], rate)};
    }

    static float[] resample(float[] x, int rate) {
        final double ratio = rate / (double) Separator.RATE;
        final int outLen = (int) Math.floor(x.length / ratio);
        final double cut = Math.min(1.0, 1.0 / ratio) * 0.97;
        final int zc = 16;
        final double span = zc / cut;
        float[] y = new float[outLen];
        for (int i = 0; i < outLen; i++) {
            double pos = i * ratio;
            int c = (int) Math.floor(pos);
            int lo = (int) Math.ceil(pos - span), hi = (int) Math.floor(pos + span);
            double acc = 0, norm = 0;
            for (int j = lo; j <= hi; j++) {
                double d = j - pos;
                double a = Math.PI * d * cut;
                double s = Math.abs(a) < 1e-9 ? 1.0 : Math.sin(a) / a;
                double w = 0.5 + 0.5 * Math.cos(Math.PI * d / span);
                double k = s * w * cut;
                norm += k;
                if (j >= 0 && j < x.length) acc += x[j] * k;
            }
            y[i] = (float) (norm > 1e-9 ? acc / norm : 0);
        }
        return y;
    }

    /** Потоковая запись WAV 16 бит стерео (формат writeWav): кусок за куском, без хранения дорожки целиком в памяти. */
    static final class WavSink implements Separator.Sink {
        private final java.io.OutputStream os;
        private final byte[] blk = new byte[16384 * 4];
        private final long total;
        private long done;
        private boolean closed;

        WavSink(File f, int n) throws Exception {
            total = n;
            os = new java.io.BufferedOutputStream(new FileOutputStream(f), 1 << 18);
            long data = (long) n * 4;
            ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
            h.put((byte) 'R').put((byte) 'I').put((byte) 'F').put((byte) 'F').putInt((int) (36 + data));
            h.put((byte) 'W').put((byte) 'A').put((byte) 'V').put((byte) 'E').put((byte) 'f').put((byte) 'm').put((byte) 't').put((byte) ' ');
            h.putInt(16).putShort((short) 1).putShort((short) 2).putInt(Separator.RATE).putInt(Separator.RATE * 4).putShort((short) 4).putShort((short) 16);
            h.put((byte) 'd').put((byte) 'a').put((byte) 't').put((byte) 'a').putInt((int) data);
            os.write(h.array());
        }

        @Override public void write(float[] l, float[] r, int off, int len) throws Exception {
            if (done + len > total) len = (int) (total - done);
            ByteBuffer bb = ByteBuffer.wrap(blk).order(ByteOrder.LITTLE_ENDIAN);
            for (int p = 0; p < len; ) {
                int m = Math.min(16384, len - p);
                bb.clear();
                for (int j = 0; j < m; j++) {
                    bb.putShort((short) Math.round(Math.max(-1f, Math.min(0.9999695f, l[off + p + j])) * 32767f));
                    bb.putShort((short) Math.round(Math.max(-1f, Math.min(0.9999695f, r[off + p + j])) * 32767f));
                }
                os.write(blk, 0, m * 4);
                p += m;
            }
            done += len;
        }

        /** Если модель отдала меньше отсчётов, чем длина трека, добиваем тишиной — заголовок остаётся верным. */
        void close() throws Exception {
            if (closed) return;
            closed = true;
            byte[] z = new byte[16384 * 4];
            while (done < total) { int m = (int) Math.min(16384, total - done); os.write(z, 0, m * 4); done += m; }
            os.close();
        }

        void abort() { closed = true; try { os.close(); } catch (Throwable ignored) { } }
    }

    /** Читает WAV 16 бит стерео (формат writeWav) в float [2][n]; нехватка данных добивается тишиной. */
    static float[][] readWav(File f, int n) throws Exception {
        float[][] r = new float[2][n];
        try (java.io.InputStream in = new java.io.BufferedInputStream(new java.io.FileInputStream(f), 1 << 18)) {
            long got = 0;
            while (got < 44) { long k = in.skip(44 - got); if (k <= 0) throw new java.io.EOFException(); got += k; }
            byte[] b = new byte[16384 * 4];
            int pos = 0;
            while (pos < n) {
                int m = Math.min(16384, n - pos), need = m * 4, have = 0;
                while (have < need) { int k = in.read(b, have, need - have); if (k < 0) break; have += k; }
                int fr = have / 4;
                for (int i = 0; i < fr; i++) {
                    r[0][pos + i] = (short) ((b[i * 4] & 0xff) | (b[i * 4 + 1] << 8)) / 32768f;
                    r[1][pos + i] = (short) ((b[i * 4 + 2] & 0xff) | (b[i * 4 + 3] << 8)) / 32768f;
                }
                if (fr < m) break;
                pos += m;
            }
        }
        return r;
    }

    static void writeText(File f, String text) throws Exception {
        File t = new File(f.getParentFile(), f.getName() + ".part");
        try (OutputStream o = new FileOutputStream(t)) { o.write(text.getBytes("UTF-8")); }
        if (f.exists()) f.delete();
        if (!t.renameTo(f)) throw new java.io.IOException("publish_failed");
    }

    /** Удаляет папки всех результатов, кроме текущего. */
    static void cleanOldJobs(Context c, String keep) {
        File[] fs = rootDir(c).listFiles();
        if (fs == null) return;
        for (File d : fs) {
            if (!d.isDirectory() || d.getName().equals(keep)) continue;
            File[] in = d.listFiles();
            if (in != null) for (File x : in) x.delete();
            d.delete();
        }
    }

    static void writeWav(File f, float[][] s, int n, float gain) throws Exception { writeWav(f, s, n, gain, true); }

    /** normalize=true: если пик выше 0 дБ, весь файл ослабляется (старое поведение); false — просто ограничение отсчётов. */
    static void writeWav(File f, float[][] s, int n, float gain, boolean normalize) throws Exception {
        float g = gain;
        if (normalize) {
            float peak = 0;
            for (int c = 0; c < 2; c++) for (int i = 0; i < n; i++) { float v = Math.abs(s[c][i] * gain); if (v > peak) peak = v; }
            g = peak > 0.999f ? gain * 0.999f / peak : gain;
        }
        long data = (long) n * 4;
        try (OutputStream out = new java.io.BufferedOutputStream(new FileOutputStream(f), 1 << 20)) {
            ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
            h.put((byte) 'R').put((byte) 'I').put((byte) 'F').put((byte) 'F').putInt((int) (36 + data));
            h.put((byte) 'W').put((byte) 'A').put((byte) 'V').put((byte) 'E').put((byte) 'f').put((byte) 'm').put((byte) 't').put((byte) ' ');
            h.putInt(16).putShort((short) 1).putShort((short) 2).putInt(Separator.RATE).putInt(Separator.RATE * 4).putShort((short) 4).putShort((short) 16);
            h.put((byte) 'd').put((byte) 'a').put((byte) 't').put((byte) 'a').putInt((int) data);
            out.write(h.array());
            byte[] blk = new byte[16384 * 4];
            ByteBuffer bb = ByteBuffer.wrap(blk).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 0; i < n; ) {
                int m = Math.min(16384, n - i);
                bb.clear();
                for (int j = 0; j < m; j++) {
                    bb.putShort((short) Math.round(Math.max(-1f, Math.min(0.9999695f, s[0][i + j] * g)) * 32767f));
                    bb.putShort((short) Math.round(Math.max(-1f, Math.min(0.9999695f, s[1][i + j] * g)) * 32767f));
                }
                out.write(blk, 0, m * 4);
                i += m;
            }
        }
    }
}

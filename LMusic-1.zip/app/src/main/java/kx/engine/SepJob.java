package kx.engine;

import android.content.Context;
import android.os.PowerManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Задание «разделить трек»: по очереди гоняет выбранные модели, пишет по WAV-файлу на каждую выбранную дорожку. */
final class SepJob implements Runnable {
    private static final String TAG = "SepJob";

    static final class Out {
        String label;
        String model;
        List<String> stems = new ArrayList<>();
        float gain = 1f;
    }

    /** Порядок дорожек в выходе каждой модели. */
    static String[] sourcesOf(String model) {
        String m = model.toLowerCase();
        if (m.contains("htdemucs_6s")) return new String[]{"drums", "bass", "other", "vocals", "guitar", "piano"};
        if (m.contains("drumsep")) return new String[]{"kick", "snare", "cymbals", "toms"};
        return new String[]{"drums", "bass", "other", "vocals"};
    }

    static boolean isMdxId(String model) { return model.toLowerCase().contains("mdx"); }

    private static final float MDX_COMPENSATE = 1.035f;

    private final NativeAudio host;
    private final Context ctx;
    private final File source;
    private final String base;
    private final boolean allowDownload;
    private final List<Out> outs = new ArrayList<>();
    private volatile boolean cancel;
    private final Runnable onFinish;

    private int lastPct = -1;
    private double doneWork, totalWork;

    SepJob(NativeAudio host, Context ctx, File source, String base, JSONObject plan, Runnable onFinish) throws Exception {
        this.host = host;
        this.ctx = ctx;
        this.source = source;
        this.base = base;
        this.onFinish = onFinish;
        this.allowDownload = plan.optBoolean("download", false);
        JSONArray a = plan.getJSONArray("outputs");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Out x = new Out();
            x.label = o.optString("label", "Дорожка");
            x.model = o.getString("model");
            x.gain = (float) Math.max(0, Math.min(2, o.optDouble("gain", 1)));
            JSONArray st = o.getJSONArray("stems");
            for (int j = 0; j < st.length(); j++) x.stems.add(st.getString(j));
            outs.add(x);
        }
        if (outs.isEmpty()) throw new IllegalArgumentException("empty plan");
    }

    void cancel() { cancel = true; }

    /** Список нужных моделей, которых ещё нет на устройстве. */
    static List<String> missing(Context c, JSONObject plan) throws Exception {
        List<String> r = new ArrayList<>();
        JSONArray a = plan.getJSONArray("outputs");
        for (int i = 0; i < a.length(); i++) {
            String m = a.getJSONObject(i).getString("model");
            if (!r.contains(m) && !SepModels.has(c, m)) r.add(m);
        }
        return r;
    }

    private void event(String phase, int pct, String stage, String label, int step, int steps, String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("phase", phase);
            o.put("progress", pct);
            if (stage != null) o.put("stage", stage);
            if (label != null) o.put("label", label);
            o.put("step", step);
            o.put("steps", steps);
            if (msg != null) { if ("done".equals(phase)) o.put("name", msg); else o.put("message", msg); }
            host.sepJs("window.__lmusicSeparateEvent&&window.__lmusicSeparateEvent(" + o.toString() + ")");
        } catch (Throwable t) {
            Log.w(TAG, "event failed", t);
        }
    }

    private void tick(String stage, String label, int step, int steps, double add) {
        double v = doneWork + add;
        int pct = (int) Math.max(0, Math.min(99, Math.floor(100.0 * v / Math.max(1e-9, totalWork))));
        if (pct != lastPct) { lastPct = pct; event("progress", pct, stage, label, step, steps, null); }
    }

    private final class Pass {
        String model;
        List<Out> outs = new ArrayList<>();
        boolean need;
        double work;
        double dlWork;
    }

    @Override public void run() {
        PowerManager.WakeLock wl = null;
        File raw = null;
        try {
            try {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                if (pm != null) { wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lmusic:separate"); wl.acquire(60 * 60 * 1000L); }
            } catch (Throwable ignored) { }
            Map<String, Pass> passes = new LinkedHashMap<>();
            for (Out o : outs) {
                Pass p = passes.get(o.model);
                if (p == null) { p = new Pass(); p.model = o.model; passes.put(o.model, p); }
                p.outs.add(o);
            }
            for (Pass p : passes.values()) {
                p.need = !SepModels.has(ctx, p.model);
                if (p.need && !allowDownload) throw new java.io.IOException("need_download");
            }
            event("progress", 0, "decode", null, 0, passes.size(), null);
            raw = new File(host.sepDir(), "sep_" + System.currentTimeMillis() + ".pcm.tmp");
            int rate = host.sepDecode(source, raw, "sep" + System.currentTimeMillis());
            if (rate < 8000 || !raw.isFile() || raw.length() < 8) throw new java.io.IOException("decode_failed");
            long frames = raw.length() / 8L;
            if (frames * 1.0 * Separator.RATE / rate > 44100L * 60 * 14) throw new java.io.IOException("too_long");
            float[][] mix = loadResampled(raw, frames, rate);
            raw.delete(); raw = null;
            final int n = mix[0].length;
            if (cancel) throw new Separator.Cancelled();

            // оценка объёма работы для общего процента
            totalWork = 0;
            for (Pass p : passes.values()) {
                int steps = isMdxId(p.model) ? Math.max(1, (n + 254975) / 254976) : Math.max(1, (n + 257984) / 257985);
                p.work = steps;
                p.dlWork = p.need ? Math.max(3, steps * 0.5) : 0;
                totalWork += p.work + p.dlWork + 0.5 * p.outs.size() + 1;
            }
            doneWork = 1;
            int idx = 0, total = passes.size();
            ArrayList<String> saved = new ArrayList<>();
            for (final Pass p : passes.values()) {
                idx++;
                final int step = idx;
                final String label0 = p.outs.get(0).label;
                if (p.need) {
                    final double w = p.dlWork;
                    SepModels.ensure(ctx, p.model, new Separator.Prog() {
                        @Override public void on(float f) { tick("download", label0, step, passes.size(), w * f); }
                        @Override public boolean cancelled() { return cancel; }
                    });
                    doneWork += p.dlWork;
                }
                if (cancel) throw new Separator.Cancelled();
                tick("load", label0, step, total, 0);
                File mf = SepModels.find(ctx, p.model);
                if (mf == null) throw new java.io.IOException("model_not_found:" + p.model);
                float[][][] stems;       // [индекс дорожки модели][канал][n]
                float[][] inst = null;   // для MDX
                try (OrtNet net = new OrtNet(mf)) {
                    final double w = p.work;
                    Separator.Prog prog = new Separator.Prog() {
                        @Override public void on(float f) { tick("separate", label0, step, passes.size(), w * f); }
                        @Override public boolean cancelled() { return cancel; }
                    };
                    if (Separator.isMdx(net)) {
                        inst = Separator.mdx(net, mix, n, prog);
                        stems = null;
                    } else {
                        String[] src = sourcesOf(p.model);
                        boolean[] want = new boolean[Math.max(src.length, 8)];
                        for (Out o : p.outs) for (String s : o.stems) {
                            int k = Arrays.asList(src).indexOf(s);
                            if (k < 0) throw new IllegalStateException("stem " + s);
                            want[k] = true;
                        }
                        stems = Separator.demucs(net, mix, n, want, prog);
                    }
                }
                doneWork += p.work;
                for (Out o : p.outs) {
                    if (cancel) throw new Separator.Cancelled();
                    tick("save", o.label, step, total, 0);
                    float[][] res = new float[2][n];
                    for (String s : o.stems) {
                        if (inst != null) {
                            boolean vocals = "vocals".equals(s);
                            for (int c = 0; c < 2; c++) {
                                float[] r = res[c], m = mix[c], q = inst[c];
                                if (vocals) for (int i = 0; i < n; i++) r[i] += m[i] - q[i];
                                else for (int i = 0; i < n; i++) r[i] += q[i] * MDX_COMPENSATE;
                            }
                        } else {
                            int k = Arrays.asList(sourcesOf(p.model)).indexOf(s);
                            if (stems == null || k >= stems.length || stems[k] == null) throw new IllegalStateException("stem " + s);
                            for (int c = 0; c < 2; c++) { float[] r = res[c], q = stems[k][c]; for (int i = 0; i < n; i++) r[i] += q[i]; }
                        }
                    }
                    String fileName = base + " - " + o.label + ".wav";
                    File wav = new File(host.sepDir(), "sep_" + System.currentTimeMillis() + ".wav.tmp");
                    try {
                        writeWav(wav, res, n, o.gain);
                        saved.add(host.sepPublish(wav, fileName));
                    } finally { wav.delete(); }
                    doneWork += 0.5;
                }
                stems = null; inst = null;
            }
            event("done", 100, null, null, total, total, saved.size() == 1 ? saved.get(0) : (saved.size() + " файл. в папке Music"));
        } catch (Separator.Cancelled c) {
            event("error", 0, null, null, 0, 0, "Обработка отменена");
        } catch (OutOfMemoryError oom) {
            Log.w(TAG, "oom", oom);
            event("error", 0, null, null, 0, 0, "Не хватило памяти: трек слишком длинный для этого устройства");
        } catch (Throwable t) {
            Log.w(TAG, "separate failed", t);
            event("error", 0, null, null, 0, 0, errorText(t));
        } finally {
            if (raw != null) raw.delete();
            try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
            if (onFinish != null) onFinish.run();
        }
    }

    private static String errorText(Throwable t) {
        String s = String.valueOf(t.getMessage());
        if (t instanceof java.net.UnknownHostException || t instanceof java.net.SocketTimeoutException || t instanceof java.net.ConnectException)
            return "Нет подключения к интернету: не удалось скачать модель ИИ";
        if (s.startsWith("need_download")) return "Сначала нужно скачать модель ИИ";
        if (s.startsWith("model_not_found")) return "Модель не найдена в релизе GitHub: " + s.substring(Math.min(s.length(), 16));
        if (s.startsWith("model_format")) return "Файл модели в релизе не в формате ONNX: " + s.substring(Math.min(s.length(), 13));
        if (s.startsWith("http_") || s.startsWith("api_") || s.startsWith("download_incomplete")) return "Не удалось скачать модель (" + s + ")";
        if (s.contains("too_long")) return "Трек слишком длинный для разделения (больше 14 минут)";
        if (s.contains("decode_failed") || s.contains("no_audio_track")) return "Не удалось декодировать исходный аудиофайл";
        if (s.contains("no_space")) return "Недостаточно свободного места";
        if (s.contains("storage_permission")) return "Для сохранения в папку Music разрешите доступ к файлам и повторите";
        if (s.contains("publish_failed")) return "Не удалось сохранить файл в папку Music";
        if (s.contains("ai.onnxruntime") || t.getClass().getName().startsWith("ai.onnxruntime")) return "Не удалось запустить модель ИИ: " + (s.length() > 80 ? s.substring(0, 80) : s);
        return "Не удалось разделить трек: " + (s.length() > 90 ? s.substring(0, 90) : s);
    }

    // ------------------------------------------------------------ PCM, ресемплер, WAV

    /** Читает interleaved float32 stereo и приводит к 44,1 кГц. */
    static float[][] loadResampled(File raw, long frames, int rate) throws Exception {
        float[][] in = new float[2][(int) frames];
        try (InputStream is = new BufferedInputStream(new FileInputStream(raw), 1 << 20)) {
            byte[] buf = new byte[1 << 20];
            ByteBuffer bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
            int pos = 0, have = 0;
            while (pos < frames) {
                int need = (int) Math.min((buf.length / 8), frames - pos) * 8, got = 0;
                while (got < need) { int r = is.read(buf, got, need - got); if (r < 0) break; got += r; }
                int fr = got / 8;
                if (fr == 0) break;
                bb.clear();
                for (int i = 0; i < fr; i++) { in[0][pos + i] = bb.getFloat(); in[1][pos + i] = bb.getFloat(); }
                pos += fr;
                have = pos;
            }
            if (have < frames) { in[0] = Arrays.copyOf(in[0], have); in[1] = Arrays.copyOf(in[1], have); }
        }
        if (rate == Separator.RATE) return in;
        return new float[][]{resample(in[0], rate), resample(in[1], rate)};
    }

    static float[] resample(float[] x, int rate) {
        final double ratio = rate / (double) Separator.RATE;
        final int outLen = (int) Math.floor(x.length / ratio);
        final double cut = Math.min(1.0, 1.0 / ratio) * 0.97;
        final int zc = 16;
        final double span = zc / cut;
        float[] y = new float[outLen];
        for (int i = 0; i < outLen; i++) {
            double pos = i * ratio;
            int c = (int) Math.floor(pos);
            int lo = (int) Math.ceil(pos - span), hi = (int) Math.floor(pos + span);
            double acc = 0, norm = 0;
            for (int j = lo; j <= hi; j++) {
                double d = j - pos;
                double a = Math.PI * d * cut;
                double s = Math.abs(a) < 1e-9 ? 1.0 : Math.sin(a) / a;
                double w = 0.5 + 0.5 * Math.cos(Math.PI * d / span);
                double k = s * w * cut;
                norm += k;
                if (j >= 0 && j < x.length) acc += x[j] * k;
            }
            y[i] = (float) (norm > 1e-9 ? acc / norm : 0);
        }
        return y;
    }

    static void writeWav(File f, float[][] s, int n, float gain) throws Exception {
        float peak = 0;
        for (int c = 0; c < 2; c++) for (int i = 0; i < n; i++) { float v = Math.abs(s[c][i] * gain); if (v > peak) peak = v; }
        float g = peak > 0.999f ? gain * 0.999f / peak : gain;
        long data = (long) n * 4;
        try (OutputStream out = new java.io.BufferedOutputStream(new FileOutputStream(f), 1 << 20)) {
            ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
            h.put((byte) 'R').put((byte) 'I').put((byte) 'F').put((byte) 'F').putInt((int) (36 + data));
            h.put((byte) 'W').put((byte) 'A').put((byte) 'V').put((byte) 'E').put((byte) 'f').put((byte) 'm').put((byte) 't').put((byte) ' ');
            h.putInt(16).putShort((short) 1).putShort((short) 2).putInt(Separator.RATE).putInt(Separator.RATE * 4).putShort((short) 4).putShort((short) 16);
            h.put((byte) 'd').put((byte) 'a').put((byte) 't').put((byte) 'a').putInt((int) data);
            out.write(h.array());
            byte[] blk = new byte[16384 * 4];
            ByteBuffer bb = ByteBuffer.wrap(blk).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 0; i < n; ) {
                int m = Math.min(16384, n - i);
                bb.clear();
                for (int j = 0; j < m; j++) {
                    bb.putShort((short) Math.round(Math.max(-1f, Math.min(0.9999695f, s[0][i + j] * g)) * 32767f));
                    bb.putShort((short) Math.round(Math.max(-1f, Math.min(0.9999695f, s[1][i + j] * g)) * 32767f));
                }
                out.write(blk, 0, m * 4);
                i += m;
            }
        }
    }
}

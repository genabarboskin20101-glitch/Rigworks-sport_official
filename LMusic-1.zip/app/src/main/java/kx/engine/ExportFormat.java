package kx.engine;

import java.io.File;
import java.util.Locale;

/** Форматы экспорта: идентификатор из интерфейса → расширение, MIME и способ конвертации из временного WAV. */
final class ExportFormat {
    final String id, ext, mime;

    private ExportFormat(String id, String ext, String mime) { this.id = id; this.ext = ext; this.mime = mime; }

    static ExportFormat of(String id) {
        String k = id == null ? "wav" : id.trim().toLowerCase(Locale.ROOT);
        switch (k) {
            case "aiff": return new ExportFormat(k, "aiff", "audio/x-aiff");
            case "flac": return new ExportFormat(k, "flac", "audio/flac");
            case "alac": return new ExportFormat(k, "m4a", "audio/mp4");
            case "m4a": return new ExportFormat(k, "m4a", "audio/mp4");
            case "mp4": return new ExportFormat(k, "mp4", "audio/mp4");
            case "aac": return new ExportFormat(k, "aac", "audio/aac");
            case "ogg": return new ExportFormat(k, "ogg", "audio/ogg");
            case "dsd": return new ExportFormat(k, "dsf", "audio/x-dsf");
            default: return new ExportFormat("wav", "wav", "audio/wav");
        }
    }

    boolean isWav() { return "wav".equals(id); }

    /** Конвертирует временный WAV (PCM16 стерео 44,1 кГц) в целевой формат. */
    void convert(File wav, File out, ExportEncoders.Progress p) throws Exception {
        switch (id) {
            case "aiff": ExportEncoders.aiff(wav, out, p); break;
            case "flac": ExportEncoders.flac(wav, out, p); break;
            case "alac": ExportEncoders.alac(wav, out, p); break;
            case "dsd": ExportEncoders.dsf(wav, out, p); break;
            case "aac": ExportCodecs.aacAdts(wav, out, p); break;
            case "ogg": ExportCodecs.opusOgg(wav, out, p); break;
            default: ExportCodecs.aacMp4(wav, out, p); break; // m4a, mp4
        }
    }
}

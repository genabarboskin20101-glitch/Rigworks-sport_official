package kx.engine;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;

/** Модели ИИ для разделения: хранение в приложении и скачивание из релиза GitHub (ApixelStudio/LMusic-project, тег aiaudiomodels). */
final class SepModels {
    private static final String API = "https://api.github.com/repos/ApixelStudio/LMusic-project/releases/tags/aiaudiomodels";
    private static final String DL = "https://github.com/ApixelStudio/LMusic-project/releases/download/aiaudiomodels/";
    private static final String UA = "LMusic-Android";

    private SepModels() { }

    private static File dirOf(Context c, String id) {
        return new File(new File(c.getFilesDir(), "aimodels"), id.replaceAll("[^A-Za-z0-9_.-]", "_"));
    }

    /** Готовый файл .onnx или null. */
    static File find(Context c, String id) {
        File d = dirOf(c, id);
        if (!new File(d, ".ok").isFile()) return null;
        File[] fs = d.listFiles();
        if (fs == null) return null;
        for (File f : fs) if (f.isFile() && f.getName().toLowerCase(Locale.ROOT).endsWith(".onnx") && f.length() > 1024) return f;
        return null;
    }

    static boolean has(Context c, String id) { return find(c, id) != null; }

    private static String norm(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", ""); }

    private static final class Asset {
        String name, url; long size;
    }

    private static HttpURLConnection open(String url, int timeout) throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(timeout);
        h.setReadTimeout(timeout);
        h.setInstanceFollowRedirects(true);
        h.setRequestProperty("User-Agent", UA);
        return h;
    }

    private static ArrayList<Asset> listAssets() throws Exception {
        HttpURLConnection h = open(API, 15000);
        h.setRequestProperty("Accept", "application/vnd.github+json");
        try {
            if (h.getResponseCode() != 200) throw new IOException("api_" + h.getResponseCode());
            StringBuilder sb = new StringBuilder();
            try (InputStream in = h.getInputStream()) {
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) sb.append(new String(b, 0, n, "UTF-8"));
            }
            JSONArray arr = new JSONObject(sb.toString()).getJSONArray("assets");
            ArrayList<Asset> out = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject a = arr.getJSONObject(i);
                Asset x = new Asset();
                x.name = a.getString("name");
                x.url = a.getString("browser_download_url");
                x.size = a.optLong("size", 0);
                out.add(x);
            }
            return out;
        } finally {
            h.disconnect();
        }
    }

    /** Подбирает файлы модели в релизе: сам .onnx и сопутствующие файлы с данными (name + что-то). */
    private static ArrayList<Asset> pick(ArrayList<Asset> all, String id) throws IOException {
        String key = norm(id);
        Asset best = null;
        boolean other = false;
        for (Asset a : all) {
            String n = a.name.toLowerCase(Locale.ROOT);
            if (!norm(a.name).contains(key)) continue;
            if (!n.endsWith(".onnx")) { other = true; continue; }
            if (best == null || a.name.length() < best.name.length()) best = a;
        }
        if (best == null) throw new IOException(other ? "model_format:" + id : "model_not_found:" + id);
        ArrayList<Asset> files = new ArrayList<>();
        files.add(best);
        for (Asset a : all) if (a != best && a.name.startsWith(best.name) && a.name.length() > best.name.length()) files.add(a);
        return files;
    }

    /** Скачивает модель, если её ещё нет. Прогресс 0..1 по байтам. */
    static void ensure(Context c, String id, Separator.Prog prog) throws Exception {
        if (has(c, id)) return;
        ArrayList<Asset> files;
        try {
            files = pick(listAssets(), id);
        } catch (IOException e) {
            String m = String.valueOf(e.getMessage());
            if (m.startsWith("model_")) throw e;
            // лимит API или нет ответа: пробуем прямую ссылку по имени
            Asset a = new Asset();
            a.name = id + ".onnx";
            a.url = DL + a.name;
            files = new ArrayList<>();
            files.add(a);
        }
        File d = dirOf(c, id);
        deleteDir(d);
        if (!d.mkdirs() && !d.isDirectory()) throw new IOException("no_space");
        long total = 0;
        for (Asset a : files) total += Math.max(0, a.size);
        long done = 0;
        for (Asset a : files) {
            File part = new File(d, a.name + ".part");
            HttpURLConnection h = open(a.url, 30000);
            try {
                int code = h.getResponseCode();
                if (code != 200) throw new IOException("http_" + code);
                long len = h.getContentLengthLong();
                if (total <= 0 && len > 0) total = len;
                try (InputStream in = h.getInputStream(); FileOutputStream out = new FileOutputStream(part)) {
                    byte[] buf = new byte[256 * 1024];
                    int n;
                    long last = 0;
                    while ((n = in.read(buf)) > 0) {
                        if (prog != null && prog.cancelled()) throw new Separator.Cancelled();
                        out.write(buf, 0, n);
                        done += n;
                        long now = System.nanoTime();
                        if (prog != null && total > 0 && now - last > 120_000_000L) { last = now; prog.on(Math.min(1f, done / (float) total)); }
                    }
                }
                if (a.size > 0 && part.length() != a.size) throw new IOException("download_incomplete");
                if (!part.renameTo(new File(d, a.name))) throw new IOException("publish_failed");
            } catch (Throwable t) {
                deleteDir(d);
                throw t;
            } finally {
                h.disconnect();
            }
        }
        if (prog != null) prog.on(1f);
        new File(d, ".ok").createNewFile();
        if (find(c, id) == null) { deleteDir(d); throw new IOException("model_format:" + id); }
    }

    private static void deleteDir(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        d.delete();
    }
}

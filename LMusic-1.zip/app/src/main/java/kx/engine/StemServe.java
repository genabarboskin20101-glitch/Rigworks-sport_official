package kx.engine;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Отдаёт WebView готовые дорожки разделения по адресу https://lmusic-stems.local/&lt;job&gt;/&lt;файл&gt;.wav.
 * Страница открыта как file://, а Web Audio не принимает звук из элемента &lt;audio&gt; с чужого источника без CORS,
 * поэтому дорожки идут через shouldInterceptRequest с заголовком Access-Control-Allow-Origin и поддержкой Range (перемотка).
 */
final class StemServe {
    private static final String HOST = "lmusic-stems.local";
    private static final Pattern RANGE = Pattern.compile("bytes=(\\d*)-(\\d*)");
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_.-]{1,80}");

    private StemServe() { }

    /** null — запрос не наш, WebView грузит его как обычно. */
    static WebResourceResponse handle(Context c, WebResourceRequest req) {
        try {
            Uri u = req.getUrl();
            if (u == null || !HOST.equals(u.getHost())) return null;
            java.util.List<String> seg = u.getPathSegments();
            if (seg.size() != 2 || !NAME.matcher(seg.get(0)).matches() || !NAME.matcher(seg.get(1)).matches()
                    || seg.get(0).contains("..") || seg.get(1).contains("..")) return error(404, "Not Found");
            File f = new File(new File(SepJob.rootDir(c), seg.get(0)), seg.get(1));
            if (!f.isFile()) return error(404, "Not Found");
            long total = f.length();
            Map<String, String> h = new HashMap<>();
            h.put("Access-Control-Allow-Origin", "*");
            h.put("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges");
            h.put("Accept-Ranges", "bytes");
            h.put("Cache-Control", "no-store");
            String range = null;
            Map<String, String> rh = req.getRequestHeaders();
            if (rh != null) for (Map.Entry<String, String> e : rh.entrySet()) if ("Range".equalsIgnoreCase(e.getKey())) range = e.getValue();
            Matcher m = range == null ? null : RANGE.matcher(range.trim());
            if (m != null && m.matches() && total > 0) {
                long start, end;
                if (m.group(1).isEmpty()) {
                    long n = m.group(2).isEmpty() ? 0 : Long.parseLong(m.group(2));
                    start = Math.max(0, total - n);
                    end = total - 1;
                } else {
                    start = Long.parseLong(m.group(1));
                    end = m.group(2).isEmpty() ? total - 1 : Math.min(total - 1, Long.parseLong(m.group(2)));
                }
                if (start > end || start >= total) {
                    h.put("Content-Range", "bytes */" + total);
                    return new WebResourceResponse("audio/wav", null, 416, "Range Not Satisfiable", h, new ByteArrayInputStream(new byte[0]));
                }
                FileInputStream in = new FileInputStream(f);
                long skipped = 0;
                while (skipped < start) { long k = in.skip(start - skipped); if (k <= 0) break; skipped += k; }
                h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
                h.put("Content-Length", String.valueOf(end - start + 1));
                return new WebResourceResponse("audio/wav", null, 206, "Partial Content", h, new Limited(in, end - start + 1));
            }
            h.put("Content-Length", String.valueOf(total));
            return new WebResourceResponse("audio/wav", null, 200, "OK", h, new FileInputStream(f));
        } catch (Throwable t) {
            return error(500, "Error");
        }
    }

    private static WebResourceResponse error(int code, String text) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse("text/plain", "UTF-8", code, text, h, new ByteArrayInputStream(new byte[0]));
    }

    private static final class Limited extends FilterInputStream {
        private long left;
        Limited(InputStream in, long n) { super(in); left = n; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int r = super.read();
            if (r >= 0) left--;
            return r;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int r = super.read(b, off, (int) Math.min(len, left));
            if (r > 0) left -= r;
            return r;
        }
    }
}

package kx.engine;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

/** Сжатые форматы через системные кодеки Android: AAC (M4A / MP4 / сырой .aac) и Opus в контейнере OGG. */
final class ExportCodecs {
    private ExportCodecs() { }

    private interface Sink {
        void format(MediaFormat f) throws IOException;
        void packet(ByteBuffer d, MediaCodec.BufferInfo i) throws IOException;
        void finish() throws IOException;
        void abort();
    }

    private interface Pcm {
        /** Заполняет dst кадрами PCM16 LE стерео, возвращает число прочитанных БАЙТ (0 — конец). */
        int read(byte[] dst, int maxBytes) throws IOException;
        long totalFrames();
    }

    private static final class WavPcm implements Pcm {
        private final ExportEncoders.WavIn w;
        private final short[] l = new short[4096], r = new short[4096];
        WavPcm(ExportEncoders.WavIn w) { this.w = w; }
        @Override public int read(byte[] dst, int maxBytes) throws IOException {
            int n = w.read(l, r, Math.min(4096, maxBytes / 4));
            for (int i = 0; i < n; i++) {
                dst[i * 4] = (byte) l[i]; dst[i * 4 + 1] = (byte) (l[i] >> 8);
                dst[i * 4 + 2] = (byte) r[i]; dst[i * 4 + 3] = (byte) (r[i] >> 8);
            }
            return n * 4;
        }
        @Override public long totalFrames() { return w.frames; }
    }

    /** Ресемплер 44,1 → 48 кГц (кубическая интерполяция): кодек Opus не принимает 44,1 кГц. */
    private static final class Up48 implements Pcm {
        private final ExportEncoders.WavIn w;
        private final double step;
        private final long outTotal;
        private short[] bl = new short[16384], br = new short[16384];
        private final short[] tl = new short[4096], tr = new short[4096];
        private long base = 0;
        private int len = 0;
        private boolean eof = false;
        private long outIdx = 0;

        Up48(ExportEncoders.WavIn w) {
            this.w = w;
            this.step = (double) w.rate / 48000.0;
            this.outTotal = (long) (w.frames * 48000.0 / w.rate);
        }

        private void ensure(long upTo) throws IOException {
            while (!eof && base + len <= upTo) {
                if (len + 4096 > bl.length) {
                    int keep = 4, drop = len - keep;
                    System.arraycopy(bl, drop, bl, 0, keep);
                    System.arraycopy(br, drop, br, 0, keep);
                    base += drop;
                    len = keep;
                }
                int n = w.read(tl, tr, 4096);
                if (n <= 0) { eof = true; break; }
                System.arraycopy(tl, 0, bl, len, n);
                System.arraycopy(tr, 0, br, len, n);
                len += n;
            }
        }

        private float s(short[] a, long i) {
            if (len == 0) return 0f;
            int j = (int) (i - base);
            if (j < 0) j = 0;
            if (j >= len) j = len - 1;
            return a[j];
        }

        private static float cubic(float y0, float y1, float y2, float y3, float t) {
            float c1 = 0.5f * (y2 - y0), c2 = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3, c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
            return ((c3 * t + c2) * t + c1) * t + y1;
        }

        @Override public int read(byte[] dst, int maxBytes) throws IOException {
            int frames = Math.min(maxBytes / 4, 4096), n = 0;
            while (n < frames && outIdx < outTotal) {
                double pos = outIdx * step;
                long idx = (long) pos;
                float f = (float) (pos - idx);
                ensure(idx + 2);
                for (int c = 0; c < 2; c++) {
                    short[] a = c == 0 ? bl : br;
                    float v = cubic(s(a, idx - 1), s(a, idx), s(a, idx + 1), s(a, idx + 2), f);
                    int q = Math.round(Math.max(-32768f, Math.min(32767f, v)));
                    dst[n * 4 + c * 2] = (byte) q;
                    dst[n * 4 + c * 2 + 1] = (byte) (q >> 8);
                }
                n++;
                outIdx++;
            }
            return n * 4;
        }

        @Override public long totalFrames() { return outTotal; }
    }

    private static final class MuxSink implements Sink {
        private final MediaMuxer m;
        private int track = -1;
        private boolean started = false;
        MuxSink(File out, int fmt) throws IOException { m = new MediaMuxer(out.getAbsolutePath(), fmt); }
        @Override public void format(MediaFormat f) {
            if (started) return;
            track = m.addTrack(f);
            m.start();
            started = true;
        }
        @Override public void packet(ByteBuffer d, MediaCodec.BufferInfo i) {
            if (started) m.writeSampleData(track, d, i);
        }
        @Override public void finish() {
            try { if (started) m.stop(); } finally { m.release(); }
        }
        @Override public void abort() {
            try { if (started) m.stop(); } catch (Throwable ignored) { }
            try { m.release(); } catch (Throwable ignored) { }
        }
    }

    /** Сырой AAC-поток с заголовками ADTS (файл .aac). */
    private static final class AdtsSink implements Sink {
        private final OutputStream os;
        private final int freqIdx;
        AdtsSink(File out, int rate) throws IOException {
            os = new java.io.BufferedOutputStream(new FileOutputStream(out), 1 << 16);
            int[] t = { 96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000 };
            int idx = 4;
            for (int k = 0; k < t.length; k++) if (t[k] == rate) idx = k;
            freqIdx = idx;
        }
        @Override public void format(MediaFormat f) { }
        @Override public void packet(ByteBuffer d, MediaCodec.BufferInfo i) throws IOException {
            int len = i.size + 7;
            byte[] h = new byte[7];
            h[0] = (byte) 0xff;
            h[1] = (byte) 0xf1;
            h[2] = (byte) ((1 << 6) | (freqIdx << 2) | 0);
            h[3] = (byte) ((2 << 6) | ((len >> 11) & 3));
            h[4] = (byte) ((len >> 3) & 0xff);
            h[5] = (byte) (((len & 7) << 5) | 0x1f);
            h[6] = (byte) 0xfc;
            byte[] b = new byte[i.size];
            d.get(b);
            os.write(h);
            os.write(b);
        }
        @Override public void finish() throws IOException { os.flush(); os.close(); }
        @Override public void abort() { try { os.close(); } catch (Throwable ignored) { } }
    }

    private static void encode(Pcm src, String mime, int rate, int bitrate, Sink sink, ExportEncoders.Progress pr) throws IOException {
        MediaCodec codec = null;
        try {
            try {
                MediaFormat f = MediaFormat.createAudioFormat(mime, rate, 2);
                f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 16);
                if (MediaFormat.MIMETYPE_AUDIO_AAC.equals(mime)) {
                    f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                }
                codec = MediaCodec.createEncoderByType(mime);
                codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                codec.start();
            } catch (Exception e) {
                throw new IOException("format_unsupported");
            }
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            byte[] chunk = new byte[1 << 15];
            long fed = 0, total = Math.max(1, src.totalFrames());
            boolean inDone = false, outDone = false;
            long lastActivity = System.currentTimeMillis();
            int lastPct = -1;
            while (!outDone) {
                boolean active = false;
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        ib.clear();
                        int n = src.read(chunk, Math.min(chunk.length, ib.remaining()));
                        long pts = fed * 1000000L / rate;
                        if (n <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            ib.put(chunk, 0, n);
                            codec.queueInputBuffer(ii, 0, n, pts, 0);
                            fed += n / 4;
                            int pct = (int) Math.min(100, 100 * fed / total);
                            if (pr != null && pct != lastPct) { lastPct = pct; pr.on(pct); }
                        }
                        active = true;
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    sink.format(codec.getOutputFormat());
                    active = true;
                } else if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size > 0 && ob != null) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        sink.packet(ob, info);
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    active = true;
                }
                if (active) lastActivity = System.currentTimeMillis();
                else if (System.currentTimeMillis() - lastActivity > 20000) throw new IOException("encoder_stalled");
            }
        } finally {
            if (codec != null) {
                try { codec.stop(); } catch (Throwable ignored) { }
                try { codec.release(); } catch (Throwable ignored) { }
            }
        }
    }

    /** AAC-LC 256 кбит/с в MPEG-4 (для .m4a и .mp4). */
    static void aacMp4(File wav, File out, ExportEncoders.Progress pr) throws Exception {
        try (ExportEncoders.WavIn w = new ExportEncoders.WavIn(wav)) {
            MuxSink s = new MuxSink(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            try {
                encode(new WavPcm(w), MediaFormat.MIMETYPE_AUDIO_AAC, w.rate, 256000, s, pr);
                s.finish();
            } catch (Throwable t) {
                s.abort();
                throw t;
            }
        }
    }

    /** AAC-LC 256 кбит/с, сырой поток ADTS (.aac). */
    static void aacAdts(File wav, File out, ExportEncoders.Progress pr) throws Exception {
        try (ExportEncoders.WavIn w = new ExportEncoders.WavIn(wav)) {
            AdtsSink s = new AdtsSink(out, w.rate);
            try {
                encode(new WavPcm(w), MediaFormat.MIMETYPE_AUDIO_AAC, w.rate, 256000, s, pr);
                s.finish();
            } catch (Throwable t) {
                s.abort();
                throw t;
            }
        }
    }

    /** Opus 192 кбит/с в контейнере OGG (нужен Android 10+: кодек Opus и мультиплексор OGG). */
    static void opusOgg(File wav, File out, ExportEncoders.Progress pr) throws Exception {
        if (Build.VERSION.SDK_INT < 29) throw new IOException("format_unsupported");
        try (ExportEncoders.WavIn w = new ExportEncoders.WavIn(wav)) {
            MuxSink s;
            try {
                s = new MuxSink(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG);
            } catch (Throwable t) {
                throw new IOException("format_unsupported");
            }
            try {
                encode(new Up48(w), MediaFormat.MIMETYPE_AUDIO_OPUS, 48000, 192000, s, pr);
                s.finish();
            } catch (Throwable t) {
                s.abort();
                throw t;
            }
        }
    }
}

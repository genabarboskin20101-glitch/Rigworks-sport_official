package kx.engine;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.ArrayList;

/**
 * Кодеры экспорта без зависимостей от Android: AIFF, FLAC, ALAC (в контейнере M4A), DSD (DSF).
 * Источник — временный WAV (PCM 16 бит, стерео), который рендерит NativeAudio.
 */
final class ExportEncoders {
    private ExportEncoders() { }

    interface Progress { void on(int percent); }

    /** Читает PCM16 стерео из WAV. */
    static final class WavIn implements Closeable {
        final int rate;
        final long frames;
        private final InputStream in;
        private final byte[] raw = new byte[1 << 16];

        WavIn(File f) throws IOException {
            int sr = 44100;
            long off = -1, size = 0;
            try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
                byte[] h = new byte[12];
                r.readFully(h);
                long pos = 12;
                byte[] c = new byte[8];
                while (pos + 8 <= r.length()) {
                    r.seek(pos);
                    r.readFully(c);
                    ByteBuffer b = ByteBuffer.wrap(c).order(ByteOrder.LITTLE_ENDIAN);
                    String id = new String(c, 0, 4, "ISO-8859-1");
                    long len = b.getInt(4) & 0xffffffffL;
                    if ("fmt ".equals(id)) {
                        byte[] fm = new byte[16];
                        r.readFully(fm);
                        sr = ByteBuffer.wrap(fm).order(ByteOrder.LITTLE_ENDIAN).getInt(4);
                    } else if ("data".equals(id)) {
                        off = pos + 8;
                        size = Math.min(len, r.length() - off);
                        break;
                    }
                    pos += 8 + len + (len & 1);
                }
            }
            if (off < 0) throw new IOException("decode_failed");
            rate = sr;
            frames = size / 4;
            FileInputStream fis = new FileInputStream(f);
            fis.getChannel().position(off);
            in = new BufferedInputStream(fis, 1 << 16);
        }

        /** Читает до max кадров, возвращает прочитанное число. */
        int read(short[] l, short[] r, int max) throws IOException {
            int want = Math.min(max, raw.length / 4) * 4, got = 0;
            while (got < want) {
                int n = in.read(raw, got, want - got);
                if (n < 0) break;
                got += n;
            }
            int fr = got / 4;
            for (int i = 0; i < fr; i++) {
                int o = i * 4;
                l[i] = (short) ((raw[o] & 0xff) | (raw[o + 1] << 8));
                r[i] = (short) ((raw[o + 2] & 0xff) | (raw[o + 3] << 8));
            }
            return fr;
        }

        @Override public void close() throws IOException { in.close(); }
    }

    // ------------------------------------------------------------------ AIFF

    static void aiff(File wav, File out, Progress p) throws Exception {
        try (WavIn w = new WavIn(wav); OutputStream os = new java.io.BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
            long dataBytes = w.frames * 4;
            if (dataBytes > 0x7fffffffL - 64) throw new IOException("too_large");
            ByteBuffer h = ByteBuffer.allocate(54).order(ByteOrder.BIG_ENDIAN);
            h.put(ascii("FORM")).putInt((int) (4 + 8 + 18 + 8 + 8 + dataBytes)).put(ascii("AIFF"));
            h.put(ascii("COMM")).putInt(18).putShort((short) 2).putInt((int) w.frames).putShort((short) 16);
            h.put(extended80(w.rate));
            h.put(ascii("SSND")).putInt((int) (8 + dataBytes)).putInt(0).putInt(0);
            os.write(h.array());
            short[] l = new short[8192], r = new short[8192];
            ByteBuffer o = ByteBuffer.allocate(8192 * 4).order(ByteOrder.BIG_ENDIAN);
            long done = 0;
            while (done < w.frames) {
                int n = w.read(l, r, 8192);
                if (n <= 0) break;
                o.clear();
                for (int i = 0; i < n; i++) o.putShort(l[i]).putShort(r[i]);
                os.write(o.array(), 0, n * 4);
                done += n;
                if (p != null) p.on((int) (100 * done / Math.max(1, w.frames)));
            }
        }
    }

    private static byte[] extended80(int rate) {
        int e = 31 - Integer.numberOfLeadingZeros(Math.max(1, rate));
        long mant = ((long) rate) << (63 - e);
        ByteBuffer b = ByteBuffer.allocate(10).order(ByteOrder.BIG_ENDIAN);
        b.putShort((short) (16383 + e)).putLong(mant);
        return b.array();
    }

    private static byte[] ascii(String s) {
        try { return s.getBytes("ISO-8859-1"); } catch (Exception e) { return new byte[4]; }
    }

    // ------------------------------------------------------------------ битовый вывод

    static final class BitOut {
        byte[] buf;
        int len;
        long acc;
        int nacc;

        BitOut(int cap) { buf = new byte[cap]; }

        void reset() { len = 0; acc = 0; nacc = 0; }

        private void ensure() {
            if (len + 16 > buf.length) buf = java.util.Arrays.copyOf(buf, buf.length * 2);
        }

        void write(int n, long v) {
            if (n <= 0) return;
            ensure();
            acc = (acc << n) | (v & ((n >= 63) ? -1L : ((1L << n) - 1)));
            nacc += n;
            while (nacc >= 8) {
                buf[len++] = (byte) (acc >> (nacc - 8));
                nacc -= 8;
                if (len + 16 > buf.length) buf = java.util.Arrays.copyOf(buf, buf.length * 2);
            }
            acc &= (1L << nacc) - 1;
        }

        void unary(long q) {
            while (q >= 32) { write(32, 0); q -= 32; }
            write((int) q + 1, 1);
        }

        void align() { if (nacc > 0) write(8 - nacc, 0); }

        void append(BitOut o) {
            for (int i = 0; i < o.len; i++) write(8, o.buf[i] & 0xff);
            if (o.nacc > 0) write(o.nacc, o.acc);
        }

        long bits() { return (long) len * 8 + nacc; }
    }

    // ------------------------------------------------------------------ FLAC

    private static final int[] CRC8 = new int[256];
    private static final int[] CRC16 = new int[256];
    static {
        for (int i = 0; i < 256; i++) {
            int c = i;
            for (int k = 0; k < 8; k++) c = (c & 0x80) != 0 ? ((c << 1) ^ 0x07) & 0xff : (c << 1) & 0xff;
            CRC8[i] = c;
            int d = i << 8;
            for (int k = 0; k < 8; k++) d = (d & 0x8000) != 0 ? ((d << 1) ^ 0x8005) & 0xffff : (d << 1) & 0xffff;
            CRC16[i] = d;
        }
    }

    private static int crc8(byte[] b, int n) {
        int c = 0;
        for (int i = 0; i < n; i++) c = CRC8[c ^ (b[i] & 0xff)];
        return c;
    }

    private static int crc16(byte[] b, int n) {
        int c = 0;
        for (int i = 0; i < n; i++) c = ((c << 8) & 0xffff) ^ CRC16[((c >> 8) ^ b[i]) & 0xff];
        return c;
    }

    private static void utf8(BitOut b, long v) {
        if (v < 0x80) { b.write(8, v); return; }
        int nb = v < 0x800 ? 2 : v < 0x10000 ? 3 : v < 0x200000 ? 4 : v < 0x4000000 ? 5 : 6;
        b.write(8, ((0xff00 >> nb) & 0xff) | (v >> (6 * (nb - 1))));
        for (int i = nb - 2; i >= 0; i--) b.write(8, 0x80 | ((v >> (6 * i)) & 0x3f));
    }

    /** Один субкадр: CONSTANT / FIXED(0..4) с разбиением Райса / VERBATIM. */
    private static void flacSubframe(BitOut b, int[] x, int n, int bps) {
        long mask = (1L << bps) - 1;
        boolean constant = true;
        for (int i = 1; i < n; i++) if (x[i] != x[0]) { constant = false; break; }
        if (constant) { b.write(8, 0); b.write(bps, x[0] & mask); return; }
        int best = 0;
        long bestSum = Long.MAX_VALUE;
        for (int o = 0; o <= 4 && o < n; o++) {
            long sum = 0;
            for (int i = o; i < n; i++) sum += Math.abs(resid(x, i, o));
            if (sum < bestSum) { bestSum = sum; best = o; }
        }
        final int o = best, cnt = n - o;
        int[] u = new int[cnt];
        for (int i = o; i < n; i++) {
            int r = resid(x, i, o);
            u[i - o] = r >= 0 ? r << 1 : ((-r) << 1) - 1;
        }
        // выбор порядка разбиения
        int maxPo = 0;
        while (maxPo < 8 && n % (1 << (maxPo + 1)) == 0 && (n >> (maxPo + 1)) > o) maxPo++;
        int bestPo = 0;
        long bestBits = Long.MAX_VALUE;
        int[] bestK = null;
        for (int po = 0; po <= maxPo; po++) {
            int parts = 1 << po, per = n >> po;
            int[] ks = new int[parts];
            long bits = 6;
            int idx = 0;
            for (int pi = 0; pi < parts; pi++) {
                int c = pi == 0 ? per - o : per;
                long sum = 0;
                for (int j = 0; j < c; j++) sum += u[idx + j];
                idx += c;
                long bb = Long.MAX_VALUE;
                int bk = 0;
                for (int k = 0; k < 31; k++) {
                    long t = (long) c * (k + 1) + (sum >> k);
                    if (t < bb) { bb = t; bk = k; } else if (k > bk + 2) break;
                }
                ks[pi] = bk;
                bits += 5 + bb;
            }
            if (bits < bestBits) { bestBits = bits; bestPo = po; bestK = ks; }
        }
        long total = 8 + (long) o * bps + bestBits;
        if (total >= 8 + (long) n * bps) {
            b.write(8, 2);
            for (int i = 0; i < n; i++) b.write(bps, x[i] & mask);
            return;
        }
        b.write(8, (8 | o) << 1);
        for (int i = 0; i < o; i++) b.write(bps, x[i] & mask);
        b.write(2, 1);
        b.write(4, bestPo);
        int parts = 1 << bestPo, per = n >> bestPo, idx = 0;
        for (int pi = 0; pi < parts; pi++) {
            int c = pi == 0 ? per - o : per, k = bestK[pi];
            b.write(5, k);
            for (int j = 0; j < c; j++) {
                int v = u[idx + j];
                b.unary(v >>> k);
                if (k > 0) b.write(k, v & ((1 << k) - 1));
            }
            idx += c;
        }
    }

    private static int resid(int[] x, int i, int o) {
        switch (o) {
            case 0: return x[i];
            case 1: return x[i] - x[i - 1];
            case 2: return x[i] - 2 * x[i - 1] + x[i - 2];
            case 3: return x[i] - 3 * x[i - 1] + 3 * x[i - 2] - x[i - 3];
            default: return x[i] - 4 * x[i - 1] + 6 * x[i - 2] - 4 * x[i - 3] + x[i - 4];
        }
    }

    static void flac(File wav, File outF, Progress pr) throws Exception {
        final int BS = 4096;
        try (WavIn w = new WavIn(wav); RandomAccessFile out = new RandomAccessFile(outF, "rw")) {
            out.setLength(0);
            out.write(new byte[8 + 34]);
            int[] L = new int[BS], R = new int[BS], M = new int[BS], S = new int[BS];
            short[] sl = new short[BS], sr = new short[BS];
            byte[] pcm = new byte[BS * 4];
            MessageDigest md = MessageDigest.getInstance("MD5");
            BitOut head = new BitOut(1 << 14), frame = new BitOut(1 << 16);
            BitOut[] sub = { new BitOut(1 << 14), new BitOut(1 << 14), new BitOut(1 << 14), new BitOut(1 << 14) };
            long total = w.frames, done = 0, frameNo = 0;
            int minF = Integer.MAX_VALUE, maxF = 0;
            while (done < total) {
                int n = w.read(sl, sr, (int) Math.min(BS, total - done));
                if (n <= 0) break;
                for (int i = 0; i < n; i++) {
                    L[i] = sl[i]; R[i] = sr[i];
                    M[i] = (L[i] + R[i]) >> 1;
                    S[i] = L[i] - R[i];
                    pcm[i * 4] = (byte) sl[i]; pcm[i * 4 + 1] = (byte) (sl[i] >> 8);
                    pcm[i * 4 + 2] = (byte) sr[i]; pcm[i * 4 + 3] = (byte) (sr[i] >> 8);
                }
                md.update(pcm, 0, n * 4);
                int[][] ch = { L, R, S, M };
                int[] bps = { 16, 16, 17, 16 };
                for (int c = 0; c < 4; c++) { sub[c].reset(); flacSubframe(sub[c], ch[c], n, bps[c]); }
                long sL = sub[0].bits(), sR = sub[1].bits(), sS = sub[2].bits(), sM = sub[3].bits();
                long lr = sL + sR, ls = sL + sS, sr2 = sS + sR, ms = sM + sS;
                long m = Math.min(Math.min(lr, ls), Math.min(sr2, ms));
                int assign, a, bch;
                if (m == lr) { assign = 1; a = 0; bch = 1; }
                else if (m == ls) { assign = 8; a = 0; bch = 2; }
                else if (m == sr2) { assign = 9; a = 2; bch = 1; }
                else { assign = 10; a = 3; bch = 2; }
                frame.reset();
                frame.write(16, 0xfff8);
                boolean std = n == BS;
                frame.write(4, std ? 12 : 7);
                frame.write(4, 9);
                frame.write(4, assign);
                frame.write(3, 4);
                frame.write(1, 0);
                utf8(frame, frameNo);
                if (!std) frame.write(16, n - 1);
                frame.write(8, crc8(frame.buf, frame.len));
                frame.append(sub[a]);
                frame.append(sub[bch]);
                frame.align();
                frame.write(16, crc16(frame.buf, frame.len));
                out.write(frame.buf, 0, frame.len);
                minF = Math.min(minF, frame.len);
                maxF = Math.max(maxF, frame.len);
                frameNo++;
                done += n;
                if (pr != null) pr.on((int) (100 * done / Math.max(1, total)));
            }
            ByteBuffer si = ByteBuffer.allocate(8 + 34).order(ByteOrder.BIG_ENDIAN);
            si.put(ascii("fLaC")).put((byte) 0x80).put((byte) 0).put((byte) 0).put((byte) 34);
            int bsMin = total >= BS ? BS : (int) Math.max(16, total);
            si.putShort((short) bsMin).putShort((short) Math.max(16, total >= BS ? BS : (int) total));
            if (minF == Integer.MAX_VALUE) minF = 0;
            si.put((byte) (minF >> 16)).put((byte) (minF >> 8)).put((byte) minF);
            si.put((byte) (maxF >> 16)).put((byte) (maxF >> 8)).put((byte) maxF);
            long packed = ((long) w.rate << 44) | (1L << 41) | (15L << 36) | (done & 0xfffffffffL);
            si.putLong(packed);
            si.put(md.digest());
            out.seek(0);
            out.write(si.array());
        }
    }

    // ------------------------------------------------------------------ ALAC в M4A

    private static byte[] box(String t, byte[]... parts) {
        int len = 8;
        for (byte[] p : parts) len += p.length;
        ByteBuffer b = ByteBuffer.allocate(len).order(ByteOrder.BIG_ENDIAN);
        b.putInt(len).put(ascii(t));
        for (byte[] p : parts) b.put(p);
        return b.array();
    }

    private static byte[] ints(int... v) {
        ByteBuffer b = ByteBuffer.allocate(v.length * 4).order(ByteOrder.BIG_ENDIAN);
        for (int x : v) b.putInt(x);
        return b.array();
    }

    private static byte[] moovAlac(int rate, long totalSamples, ArrayList<Integer> sizes, int frameLen, int lastLen, long chunkOffset, int maxFrame) {
        int count = sizes.size();
        ByteBuffer stsz = ByteBuffer.allocate(12 + count * 4).order(ByteOrder.BIG_ENDIAN);
        stsz.putInt(0).putInt(0).putInt(count);
        for (int s : sizes) stsz.putInt(s);
        byte[] sttsBody = count > 1 && lastLen != frameLen
                ? ints(0, 2, count - 1, frameLen, 1, lastLen)
                : ints(0, 1, count, count == 1 ? lastLen : frameLen);
        ByteBuffer cfg = ByteBuffer.allocate(24 + 4).order(ByteOrder.BIG_ENDIAN);
        cfg.putInt(0); // version/flags
        cfg.putInt(frameLen).put((byte) 0).put((byte) 16).put((byte) 40).put((byte) 10).put((byte) 14).put((byte) 2)
                .putShort((short) 255).putInt(maxFrame).putInt(rate * 32).putInt(rate);
        ByteBuffer entry = ByteBuffer.allocate(28).order(ByteOrder.BIG_ENDIAN);
        entry.put(new byte[6]).putShort((short) 1).putShort((short) 0).putShort((short) 0).putInt(0)
                .putShort((short) 2).putShort((short) 16).putShort((short) 0).putShort((short) 0).putInt(rate << 16);
        byte[] alacSpecific = box("alac", cfg.array());
        byte[] stsd = box("stsd", ints(0, 1), box("alac", entry.array(), alacSpecific));
        byte[] stbl = box("stbl", stsd, box("stts", sttsBody), box("stsc", ints(0, 1, 1, count, 1)),
                box("stsz", stsz.array()), box("stco", ints(0, 1, (int) chunkOffset)));
        byte[] dinf = box("dinf", box("dref", ints(0, 1), box("url ", ints(1))));
        byte[] minf = box("minf", box("smhd", ints(0, 0)), dinf, stbl);
        byte[] mdhd = box("mdhd", ints(0, 0, 0, rate, (int) totalSamples, 0x55c40000));
        byte[] hdlr = box("hdlr", ints(0, 0), ascii("soun"), ints(0, 0, 0), new byte[] { 0 });
        byte[] mdia = box("mdia", mdhd, hdlr, minf);
        ByteBuffer tk = ByteBuffer.allocate(84).order(ByteOrder.BIG_ENDIAN);
        tk.putInt(7).putInt(0).putInt(0).putInt(1).putInt(0).putInt((int) (totalSamples * 1000L / rate)).putInt(0).putInt(0)
                .putShort((short) 0).putShort((short) 0).putShort((short) 0x0100).putShort((short) 0);
        int[] matrix = { 0x10000, 0, 0, 0, 0x10000, 0, 0, 0, 0x40000000 };
        for (int m : matrix) tk.putInt(m);
        tk.putInt(0).putInt(0);
        byte[] trak = box("trak", box("tkhd", tk.array()), mdia);
        ByteBuffer mv = ByteBuffer.allocate(100).order(ByteOrder.BIG_ENDIAN);
        mv.putInt(0).putInt(0).putInt(0).putInt(1000).putInt((int) (totalSamples * 1000L / rate)).putInt(0x10000).putShort((short) 0x0100)
                .putShort((short) 0).putInt(0).putInt(0);
        for (int m : matrix) mv.putInt(m);
        for (int i = 0; i < 6; i++) mv.putInt(0);
        mv.putInt(2);
        return box("moov", box("mvhd", mv.array()), trak);
    }

    static void alac(File wav, File outF, Progress pr) throws Exception {
        final int FL = 4096;
        File tmp = new File(outF.getPath() + ".mdat");
        ArrayList<Integer> sizes = new ArrayList<>();
        long total;
        int rate, lastLen = FL, maxFrame = 0;
        try (WavIn w = new WavIn(wav); OutputStream os = new java.io.BufferedOutputStream(new FileOutputStream(tmp), 1 << 16)) {
            rate = w.rate;
            total = w.frames;
            short[] l = new short[FL], r = new short[FL];
            BitOut bo = new BitOut(FL * 4 + 64);
            long done = 0;
            while (done < total) {
                int n = w.read(l, r, (int) Math.min(FL, total - done));
                if (n <= 0) break;
                bo.reset();
                bo.write(3, 1);
                bo.write(4, 0);
                bo.write(12, 0);
                boolean partial = n != FL;
                bo.write(4, (partial ? 8 : 0) | 1);
                if (partial) bo.write(32, n);
                for (int i = 0; i < n; i++) { bo.write(16, l[i] & 0xffff); bo.write(16, r[i] & 0xffff); }
                bo.write(3, 7);
                bo.align();
                os.write(bo.buf, 0, bo.len);
                sizes.add(bo.len);
                maxFrame = Math.max(maxFrame, bo.len);
                lastLen = n;
                done += n;
                if (pr != null) pr.on((int) (100 * done / Math.max(1, total)));
            }
            total = done;
        }
        if (sizes.isEmpty()) throw new IOException("decode_failed");
        byte[] ftyp = box("ftyp", ascii("M4A "), ints(0), ascii("M4A "), ascii("mp42"), ascii("isom"));
        long mdatBytes = tmp.length();
        byte[] moov0 = moovAlac(rate, total, sizes, FL, lastLen, 0, maxFrame);
        long off = ftyp.length + moov0.length + 8;
        byte[] moov = moovAlac(rate, total, sizes, FL, lastLen, off, maxFrame);
        try (OutputStream os = new java.io.BufferedOutputStream(new FileOutputStream(outF), 1 << 16);
             InputStream is = new FileInputStream(tmp)) {
            os.write(ftyp);
            os.write(moov);
            os.write(ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putInt((int) (mdatBytes + 8)).put(ascii("mdat")).array());
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        } finally {
            tmp.delete();
        }
    }

    // ------------------------------------------------------------------ DSD (DSF, DSD64)

    private static final double[] NTF_B = { 1.0, -4.0, 6.0, -4.0, 1.0 };
    private static final double[] NTF_A = { 1.0, -3.194364315776, 3.892021387733, -2.135836365377, 0.444444597781 };

    /** Модулятор Σ-Δ 4-го порядка (NTF — Баттерворт, Hinf = 1,5), 1 бит. Вход масштабируется до ±0,45 для устойчивости. */
    private static final class Mod {
        final double d1 = NTF_B[1] - NTF_A[1], d2 = NTF_B[2] - NTF_A[2], d3 = NTF_B[3] - NTF_A[3], d4 = NTF_B[4] - NTF_A[4];
        final double a1 = NTF_A[1], a2 = NTF_A[2], a3 = NTF_A[3], a4 = NTF_A[4];
        double e1, e2, e3, e4, s1, s2, s3, s4;

        int next(double x) {
            double s = d1 * e1 + d2 * e2 + d3 * e3 + d4 * e4 - a1 * s1 - a2 * s2 - a3 * s3 - a4 * s4;
            double u = x + s;
            double v = u >= 0 ? 1.0 : -1.0;
            double e = v - u;
            if (e > 4 || e < -4 || u > 6 || u < -6) { e1 = e2 = e3 = e4 = s1 = s2 = s3 = s4 = 0; return v > 0 ? 1 : 0; }
            e4 = e3; e3 = e2; e2 = e1; e1 = e;
            s4 = s3; s3 = s2; s2 = s1; s1 = s;
            return v > 0 ? 1 : 0;
        }
    }

    static void dsf(File wav, File outF, Progress pr) throws Exception {
        final int OSR = 64, BLOCK = 4096, FR_PER_BLOCK = BLOCK * 8 / OSR;
        try (WavIn w = new WavIn(wav); RandomAccessFile out = new RandomAccessFile(outF, "rw")) {
            if (w.rate != 44100) throw new IOException("format_unsupported");
            out.setLength(0);
            long total = w.frames;
            long samplesPerCh = total * OSR;
            long blocks = (samplesPerCh + BLOCK * 8L - 1) / (BLOCK * 8L);
            long dataBytes = blocks * BLOCK * 2;
            ByteBuffer h = ByteBuffer.allocate(28 + 52 + 12).order(ByteOrder.LITTLE_ENDIAN);
            h.put(ascii("DSD ")).putLong(28).putLong(28 + 52 + 12 + dataBytes).putLong(0);
            h.put(ascii("fmt ")).putLong(52).putInt(1).putInt(0).putInt(2).putInt(2).putInt(2822400).putInt(1)
                    .putLong(samplesPerCh).putInt(BLOCK).putInt(0);
            h.put(ascii("data")).putLong(12 + dataBytes);
            out.write(h.array());
            Mod[] mod = { new Mod(), new Mod() };
            // скользящее окно из 4 отсчётов для кубической интерполяции
            double[][] win = new double[2][4];
            short[] sl = new short[FR_PER_BLOCK], sr = new short[FR_PER_BLOCK];
            byte[][] blk = { new byte[BLOCK], new byte[BLOCK] };
            final double G = 0.45 / 32768.0;
            long done = 0;
            boolean primed = false;
            double[] pending = new double[2];
            for (long b = 0; b < blocks; b++) {
                int n = w.read(sl, sr, FR_PER_BLOCK);
                if (n < 0) n = 0;
                java.util.Arrays.fill(blk[0], (byte) 0x69);
                java.util.Arrays.fill(blk[1], (byte) 0x69);
                for (int i = 0; i < n; i++) {
                    double[] in = { sl[i] * G, sr[i] * G };
                    for (int c = 0; c < 2; c++) {
                        double[] ww = win[c];
                        if (!primed) { ww[0] = ww[1] = ww[2] = in[c]; ww[3] = in[c]; }
                        else { ww[0] = ww[1]; ww[1] = ww[2]; ww[2] = ww[3]; ww[3] = in[c]; }
                    }
                    primed = true;
                    // интерполируем отрезок между ww[1] и ww[2] (задержка в один кадр)
                    for (int c = 0; c < 2; c++) {
                        double[] ww = win[c];
                        double y0 = ww[0], y1 = ww[1], y2 = ww[2], y3 = ww[3];
                        double c0 = y1, c1 = 0.5 * (y2 - y0), c2 = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3, c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2);
                        byte[] bb = blk[c];
                        Mod m = mod[c];
                        int bytePos = i * OSR / 8;
                        for (int k = 0; k < OSR; k++) {
                            double t = (k + 0.0) / OSR;
                            double x = ((c3 * t + c2) * t + c1) * t + c0;
                            int bit = m.next(x);
                            int idx = bytePos + (k >> 3);
                            if (bit != 0) bb[idx] |= (byte) (1 << (k & 7)); else bb[idx] &= (byte) ~(1 << (k & 7));
                        }
                    }
                }
                out.write(blk[0]);
                out.write(blk[1]);
                done += n;
                if (pr != null) pr.on((int) (100 * Math.min(done, total) / Math.max(1, total)));
            }
        }
    }
}

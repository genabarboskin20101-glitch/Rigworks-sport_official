package kx.engine;

import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

/** Сведение готовых дорожек (PCM 16 бит, стерео, 44,1 кГц — формат SepJob.writeWav) с заданной громкостью каждой. */
final class SepMix {
    private SepMix() { }

    private static final int HEADER = 44;
    private static final int BLOCK = 16384;

    /** Пишет в out сумму дорожек files[i] * gains[i]. Если сумма выходит за 0 дБ, весь файл ослабляется без клиппинга. */
    static void mix(List<File> files, float[] gains, File out, Cancel cancel) throws Exception {
        long frames = Long.MAX_VALUE;
        for (File f : files) frames = Math.min(frames, Math.max(0, (f.length() - HEADER) / 4));
        if (files.isEmpty() || frames <= 0) throw new java.io.IOException("decode_failed");
        // проход 1: пик суммы
        float[] pk = new float[1];
        run(files, gains, frames, 1f, null, cancel, true, pk);
        float peak = pk[0];
        float scale = peak > 0.999f ? 0.999f / peak : 1f;
        // проход 2: запись
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 20)) {
            long data = frames * 4;
            ByteBuffer h = ByteBuffer.allocate(HEADER).order(ByteOrder.LITTLE_ENDIAN);
            h.put((byte) 'R').put((byte) 'I').put((byte) 'F').put((byte) 'F').putInt((int) (36 + data));
            h.put((byte) 'W').put((byte) 'A').put((byte) 'V').put((byte) 'E').put((byte) 'f').put((byte) 'm').put((byte) 't').put((byte) ' ');
            h.putInt(16).putShort((short) 1).putShort((short) 2).putInt(Separator.RATE).putInt(Separator.RATE * 4).putShort((short) 4).putShort((short) 16);
            h.put((byte) 'd').put((byte) 'a').put((byte) 't').put((byte) 'a').putInt((int) data);
            os.write(h.array());
            run(files, gains, frames, scale, os, cancel, false, null);
        }
    }

    interface Cancel { boolean cancelled(); }

    private static void run(List<File> files, float[] gains, long frames, float scale, OutputStream os, Cancel cancel,
                            boolean peakOnly, float[] peakOut) throws Exception {
        int k = files.size();
        InputStream[] in = new InputStream[k];
        try {
            for (int i = 0; i < k; i++) {
                in[i] = new java.io.BufferedInputStream(new FileInputStream(files.get(i)), 1 << 18);
                long skip = HEADER, got = 0;
                while (got < skip) { long s = in[i].skip(skip - got); if (s <= 0) throw new EOFException(); got += s; }
            }
            byte[] raw = new byte[BLOCK * 4];
            float[] acc = new float[BLOCK * 2];
            byte[] outBuf = new byte[BLOCK * 4];
            ByteBuffer ob = ByteBuffer.wrap(outBuf).order(ByteOrder.LITTLE_ENDIAN);
            float peak = 0;
            for (long pos = 0; pos < frames; ) {
                if (cancel != null && cancel.cancelled()) throw new Separator.Cancelled();
                int m = (int) Math.min(BLOCK, frames - pos);
                java.util.Arrays.fill(acc, 0, m * 2, 0f);
                for (int i = 0; i < k; i++) {
                    float g = gains[i];
                    int need = m * 4, got = 0;
                    while (got < need) { int r = in[i].read(raw, got, need - got); if (r < 0) throw new EOFException(); got += r; }
                    if (g == 0f) continue;
                    ByteBuffer rb = ByteBuffer.wrap(raw, 0, need).order(ByteOrder.LITTLE_ENDIAN);
                    for (int j = 0; j < m * 2; j++) acc[j] += rb.getShort() * (g / 32768f);
                }
                if (peakOnly) {
                    for (int j = 0; j < m * 2; j++) { float a = Math.abs(acc[j]); if (a > peak) peak = a; }
                } else {
                    ob.clear();
                    for (int j = 0; j < m * 2; j++) ob.putShort((short) Math.round(Math.max(-1f, Math.min(0.9999695f, acc[j] * scale)) * 32767f));
                    os.write(outBuf, 0, m * 4);
                }
                pos += m;
            }
            if (peakOut != null) peakOut[0] = peak;
        } finally {
            for (InputStream s : in) { try { if (s != null) s.close(); } catch (Throwable ignored) { } }
        }
    }
}

package com.lira.ai

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Build
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

internal data class SeparatedFiles(val vocals: File, val instrumental: File)

/**
 * MDX-Net inference for UVR-MDX-NET-Inst_HQ_3.onnx.
 * The model predicts the instrumental stem; vocals are calculated as mix - instrumental.
 * Processing stays on-device and uses the standard MDX STFT layout [1, 4, 3072, 256].
 */
internal object MdxOnnxSeparator {
    const val DEFAULT_MODEL_URL = "https://huggingface.co/lissette/uvr/resolve/main/MDX-Net/UVR-MDX-NET-Inst_HQ_3.onnx"
    private const val SAMPLE_RATE = 44100
    private const val FFT_SIZE = 6144
    private const val HOP = 1024
    private const val TRIM = FFT_SIZE / 2
    private const val DIM_F = 3072
    private const val DIM_T = 256
    private const val COMPENSATION = 1.022f
    private const val CHANNELS = 4
    private const val CHUNK_SIZE = HOP * (DIM_T - 1)
    private const val GEN_SIZE = CHUNK_SIZE - 2 * TRIM
    private const val SEGMENT_SIZE = 15 * SAMPLE_RATE
    private const val MARGIN = SAMPLE_RATE
    private const val SPEC_SIZE = CHANNELS * DIM_F * DIM_T
    private const val MAX_SECONDS = 10 * 60

    fun separate(
        inputFile: File,
        session: OrtSession,
        outputDirectory: File,
        denoise: Boolean,
        onProgress: (Int, String) -> Unit
    ): SeparatedFiles {
        require(inputFile.isFile && inputFile.length() > 0L) { "Исходный аудиофайл пуст или недоступен." }
        outputDirectory.mkdirs()
        onProgress(1, "Чтение аудио")
        val audio = AudioLoader.load44100Stereo(inputFile, MAX_SECONDS)
        require(audio.left.isNotEmpty()) { "В аудиофайле нет звуковых данных." }

        val stem = inputFile.nameWithoutExtension
            .replace(Regex("[^A-Za-z0-9._-]+"), "_")
            .trim('_')
            .ifBlank { "audio" }
        val suffix = System.currentTimeMillis().toString()
        val vocalsFile = File(outputDirectory, "${stem}_vocals_$suffix.wav")
        val instrumentalFile = File(outputDirectory, "${stem}_instrumental_$suffix.wav")
        val inputName = session.inputNames.firstOrNull() ?: "input"
        val outputName = session.outputNames.firstOrNull() ?: "output"
        val fft = FftWorkspace()
        var completed = 0
        val totalSegments = (audio.left.size + SEGMENT_SIZE - 1) / SEGMENT_SIZE

        try {
            WavWriter(vocalsFile, SAMPLE_RATE).use { vocalsWriter ->
                WavWriter(instrumentalFile, SAMPLE_RATE).use { instrumentalWriter ->
                    var segmentIndex = 0
                    var skip = 0
                    while (skip < audio.left.size) {
                        val start = if (skip == 0) 0 else max(0, skip - MARGIN)
                        val end = min(audio.left.size, skip + SEGMENT_SIZE + MARGIN)
                        val length = end - start
                        val segmentLeft = audio.left.copyOfRange(start, end)
                        val segmentRight = audio.right.copyOfRange(start, end)
                        val instrument = inferSegment(
                            segmentLeft, segmentRight, session, inputName, outputName,
                            denoise, fft
                        ) { chunkIndex, chunkCount ->
                            val chunkProgress = (chunkIndex.toDouble() / max(1, chunkCount))
                            val overall = ((segmentIndex + chunkProgress) / max(1, totalSegments) * 100.0).roundToInt()
                            onProgress(4 + (overall * 0.91).roundToInt(), "Разделение аудио · фрагмент ${segmentIndex + 1} из $totalSegments")
                        }
                        val localStart = if (start == 0) 0 else min(MARGIN, length)
                        val localEnd = if (end == audio.left.size) length else max(localStart, length - MARGIN)
                        val retained = localEnd - localStart
                        val vocalLeft = FloatArray(retained)
                        val vocalRight = FloatArray(retained)
                        val instrumentalLeft = FloatArray(retained)
                        val instrumentalRight = FloatArray(retained)
                        for (i in 0 until retained) {
                            val local = localStart + i
                            val global = start + local
                            val instL = instrument.first[local]
                            val instR = instrument.second[local]
                            instrumentalLeft[i] = instL
                            instrumentalRight[i] = instR
                            vocalLeft[i] = audio.left[global] - instL
                            vocalRight[i] = audio.right[global] - instR
                        }
                        vocalsWriter.writeFrames(vocalLeft, vocalRight)
                        instrumentalWriter.writeFrames(instrumentalLeft, instrumentalRight)
                        completed += retained
                        segmentIndex++
                        skip += SEGMENT_SIZE
                        onProgress(
                            min(98, (4 + completed.toDouble() / audio.left.size * 94.0).roundToInt()),
                            "Обработано ${segmentIndex.coerceAtMost(totalSegments)} из $totalSegments фрагментов"
                        )
                    }
                }
            }
            onProgress(100, "Готово")
            return SeparatedFiles(vocalsFile, instrumentalFile)
        } catch (t: Throwable) {
            vocalsFile.delete()
            instrumentalFile.delete()
            throw t
        }
    }

    private fun inferSegment(
        sourceLeft: FloatArray,
        sourceRight: FloatArray,
        session: OrtSession,
        inputName: String,
        outputName: String,
        denoise: Boolean,
        fft: FftWorkspace,
        onChunk: (Int, Int) -> Unit
    ): Pair<FloatArray, FloatArray> {
        val samples = sourceLeft.size
        val pad = GEN_SIZE - (samples % GEN_SIZE)
        val paddedLength = TRIM + samples + pad + TRIM
        val paddedLeft = FloatArray(paddedLength)
        val paddedRight = FloatArray(paddedLength)
        System.arraycopy(sourceLeft, 0, paddedLeft, TRIM, samples)
        System.arraycopy(sourceRight, 0, paddedRight, TRIM, samples)
        val targetLeftPadded = FloatArray(samples + pad)
        val targetRightPadded = FloatArray(samples + pad)
        val chunkCount = (samples + pad) / GEN_SIZE
        var offset = 0
        var chunkIndex = 0
        while (offset < samples + pad) {
            val spec = makeSpectrogram(paddedLeft, paddedRight, offset, fft)
            val prediction = if (denoise) {
                val positive = runModel(session, inputName, outputName, spec)
                val negativeInput = FloatArray(spec.size) { -spec[it] }
                val negative = runModel(session, inputName, outputName, negativeInput)
                FloatArray(SPEC_SIZE) { i -> (positive[i] - negative[i]) * 0.5f }
            } else {
                runModel(session, inputName, outputName, spec)
            }
            val (waveLeft, waveRight) = inverseSpectrogram(prediction, fft)
            System.arraycopy(waveLeft, TRIM, targetLeftPadded, offset, GEN_SIZE)
            System.arraycopy(waveRight, TRIM, targetRightPadded, offset, GEN_SIZE)
            offset += GEN_SIZE
            chunkIndex++
            onChunk(chunkIndex, chunkCount)
        }
        return targetLeftPadded.copyOf(samples) to targetRightPadded.copyOf(samples)
    }

    private fun runModel(
        session: OrtSession,
        inputName: String,
        outputName: String,
        input: FloatArray
    ): FloatArray {
        val environment = OrtEnvironment.getEnvironment()
        val direct = ByteBuffer.allocateDirect(input.size * 4).order(ByteOrder.nativeOrder())
        val floatBuffer = direct.asFloatBuffer()
        floatBuffer.put(input)
        floatBuffer.flip()
        return OnnxTensor.createTensor(
            environment,
            floatBuffer,
            longArrayOf(1L, 4L, DIM_F.toLong(), DIM_T.toLong())
        ).use { tensor ->
            session.run(mapOf(inputName to tensor), setOf(outputName)).use { results ->
                val value = results.get(outputName).orElse(null) as? OnnxTensor
                    ?: throw IllegalStateException("ONNX-модель не вернула выходной тензор '$outputName'.")
                value.use { outTensor ->
                    val outputBuffer = outTensor.floatBuffer
                    outputBuffer.rewind()
                    if (outputBuffer.remaining() != SPEC_SIZE) {
                        throw IllegalArgumentException(
                            "Неподходящая форма ONNX-модели: ожидалось $SPEC_SIZE значений, получено ${outputBuffer.remaining()}. Нужна совместимая MDX-модель 1×4×3072×256."
                        )
                    }
                    FloatArray(SPEC_SIZE).also { values ->
                        outputBuffer.get(values)
                        for (i in values.indices) values[i] *= COMPENSATION
                    }
                }
            }
        }
    }

    private fun makeSpectrogram(
        paddedLeft: FloatArray,
        paddedRight: FloatArray,
        offset: Int,
        fft: FftWorkspace
    ): FloatArray {
        val spec = FloatArray(SPEC_SIZE)
        for (frame in 0 until DIM_T) {
            val center = frame * HOP
            fft.loadFrame(paddedLeft, offset, center)
            fft.forward6144()
            for (f in 0 until DIM_F) {
                spec[f * DIM_T + frame] = fft.re[f].toFloat()
                spec[(DIM_F * DIM_T) + f * DIM_T + frame] = fft.im[f].toFloat()
            }
            fft.loadFrame(paddedRight, offset, center)
            fft.forward6144()
            val rightOffset = 2 * DIM_F * DIM_T
            for (f in 0 until DIM_F) {
                spec[rightOffset + f * DIM_T + frame] = fft.re[f].toFloat()
                spec[rightOffset + DIM_F * DIM_T + f * DIM_T + frame] = fft.im[f].toFloat()
            }
        }
        return spec
    }

    private fun inverseSpectrogram(spec: FloatArray, fft: FftWorkspace): Pair<FloatArray, FloatArray> {
        val sumLeft = DoubleArray(CHUNK_SIZE)
        val sumRight = DoubleArray(CHUNK_SIZE)
        val weight = DoubleArray(CHUNK_SIZE)
        val leftRealChannel = 0
        val leftImagChannel = 1
        val rightRealChannel = 2
        val rightImagChannel = 3
        val plane = DIM_F * DIM_T
        for (frame in 0 until DIM_T) {
            val center = frame * HOP
            for (i in 0 until FFT_SIZE) {
                val target = center + i - TRIM
                if (target in 0 until CHUNK_SIZE) {
                    val w = fft.window[i]
                    weight[target] += w * w
                }
            }
            fft.clearSpectrum()
            for (f in 0 until DIM_F) {
                fft.re[f] = spec[leftRealChannel * plane + f * DIM_T + frame].toDouble()
                fft.im[f] = spec[leftImagChannel * plane + f * DIM_T + frame].toDouble()
            }
            fft.makeHermitianAndInverse()
            for (i in 0 until FFT_SIZE) {
                val target = center + i - TRIM
                if (target in 0 until CHUNK_SIZE) sumLeft[target] += fft.re[i] * fft.window[i]
            }

            fft.clearSpectrum()
            for (f in 0 until DIM_F) {
                fft.re[f] = spec[rightRealChannel * plane + f * DIM_T + frame].toDouble()
                fft.im[f] = spec[rightImagChannel * plane + f * DIM_T + frame].toDouble()
            }
            fft.makeHermitianAndInverse()
            for (i in 0 until FFT_SIZE) {
                val target = center + i - TRIM
                if (target in 0 until CHUNK_SIZE) sumRight[target] += fft.re[i] * fft.window[i]
            }
        }
        val left = FloatArray(CHUNK_SIZE)
        val right = FloatArray(CHUNK_SIZE)
        for (i in 0 until CHUNK_SIZE) {
            val d = weight[i]
            if (d > 1e-9) {
                left[i] = (sumLeft[i] / d).toFloat()
                right[i] = (sumRight[i] / d).toFloat()
            }
        }
        return left to right
    }

    private class FftWorkspace {
        val re = DoubleArray(FFT_SIZE)
        val im = DoubleArray(FFT_SIZE)
        val window = DoubleArray(FFT_SIZE) { i -> 0.5 - 0.5 * cos(2.0 * PI * i / FFT_SIZE) }
        private val subRe = Array(3) { DoubleArray(2048) }
        private val subIm = Array(3) { DoubleArray(2048) }
        private val workRe = DoubleArray(2048)
        private val workIm = DoubleArray(2048)
        private val outRe = DoubleArray(FFT_SIZE)
        private val outIm = DoubleArray(FFT_SIZE)
        private val twCos = DoubleArray(FFT_SIZE) { i -> cos(2.0 * PI * i / FFT_SIZE) }
        private val twSin = DoubleArray(FFT_SIZE) { i -> sin(2.0 * PI * i / FFT_SIZE) }

        fun loadFrame(source: FloatArray, chunkOffset: Int, center: Int) {
            for (i in 0 until FFT_SIZE) {
                val local = reflectIndex(center + i - TRIM, CHUNK_SIZE)
                re[i] = source[chunkOffset + local].toDouble() * window[i]
                im[i] = 0.0
            }
        }

        fun clearSpectrum() {
            java.util.Arrays.fill(re, 0.0)
            java.util.Arrays.fill(im, 0.0)
        }

        fun forward6144() {
            // Mixed-radix Cooley-Tukey: 6144 = 3 × 2048.
            for (branch in 0..2) {
                for (n in 0 until 2048) {
                    workRe[n] = re[3 * n + branch]
                    workIm[n] = im[3 * n + branch]
                }
                fft2048(workRe, workIm)
                System.arraycopy(workRe, 0, subRe[branch], 0, 2048)
                System.arraycopy(workIm, 0, subIm[branch], 0, 2048)
            }
            for (branch in 0..2) {
                val branchBase = branch * 2048
                for (k in 0 until 2048) {
                    var real = 0.0
                    var imag = 0.0
                    for (j in 0..2) {
                        val index = ((k + branchBase) * j) % FFT_SIZE
                        val c = twCos[index]
                        val s = -twSin[index]
                        val a = subRe[j][k]
                        val b = subIm[j][k]
                        real += a * c - b * s
                        imag += a * s + b * c
                    }
                    outRe[k + branchBase] = real
                    outIm[k + branchBase] = imag
                }
            }
            System.arraycopy(outRe, 0, re, 0, FFT_SIZE)
            System.arraycopy(outIm, 0, im, 0, FFT_SIZE)
        }

        fun makeHermitianAndInverse() {
            // The model outputs bins [0, 3071]; bin 3072 and higher were zero-padded.
            re[FFT_SIZE / 2] = 0.0
            im[FFT_SIZE / 2] = 0.0
            for (k in 1 until FFT_SIZE / 2) {
                re[FFT_SIZE - k] = re[k]
                im[FFT_SIZE - k] = -im[k]
            }
            for (i in 0 until FFT_SIZE) im[i] = -im[i]
            forward6144()
            for (i in 0 until FFT_SIZE) {
                re[i] = re[i] / FFT_SIZE.toDouble()
                im[i] = -im[i] / FFT_SIZE
            }
        }

        private fun fft2048(real: DoubleArray, imag: DoubleArray) {
            val n = 2048
            var j = 0
            for (i in 1 until n) {
                var bit = n shr 1
                while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
                j = j xor bit
                if (i < j) {
                    val tr = real[i]; real[i] = real[j]; real[j] = tr
                    val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti
                }
            }
            var len = 2
            while (len <= n) {
                val angle = -2.0 * PI / len
                val wrStep = cos(angle)
                val wiStep = sin(angle)
                val half = len / 2
                var base = 0
                while (base < n) {
                    var wr = 1.0
                    var wi = 0.0
                    for (k in 0 until half) {
                        val evenIndex = base + k
                        val oddIndex = evenIndex + half
                        val oddR = real[oddIndex] * wr - imag[oddIndex] * wi
                        val oddI = real[oddIndex] * wi + imag[oddIndex] * wr
                        val evenR = real[evenIndex]
                        val evenI = imag[evenIndex]
                        real[evenIndex] = evenR + oddR
                        imag[evenIndex] = evenI + oddI
                        real[oddIndex] = evenR - oddR
                        imag[oddIndex] = evenI - oddI
                        val nextWr = wr * wrStep - wi * wiStep
                        wi = wr * wiStep + wi * wrStep
                        wr = nextWr
                    }
                    base += len
                }
                len = len shl 1
            }
        }
    }

    private fun reflectIndex(index: Int, length: Int): Int {
        if (index < 0) return min(length - 1, -index)
        if (index >= length) return max(0, 2 * length - index - 2)
        return index
    }

    private data class StereoAudio(val left: FloatArray, val right: FloatArray)
    private data class DecodedAudio(val left: FloatArray, val right: FloatArray, val sampleRate: Int)

    private object AudioLoader {
        fun load44100Stereo(file: File, maxSeconds: Int): StereoAudio {
            val decoded = tryReadWav(file) ?: decodeCompressed(file)
            if (decoded.left.isEmpty()) throw IllegalArgumentException("Не удалось прочитать звук из файла.")
            if (decoded.left.size.toDouble() / decoded.sampleRate > maxSeconds) {
                throw IllegalArgumentException("Слишком длинный файл. В этой сборке поддерживается до $maxSeconds секунд аудио.")
            }
            if (decoded.sampleRate == SAMPLE_RATE) return StereoAudio(decoded.left, decoded.right)
            val outputFrames = max(1, (decoded.left.size.toDouble() * SAMPLE_RATE / decoded.sampleRate).roundToInt())
            val left = FloatArray(outputFrames)
            val right = FloatArray(outputFrames)
            val ratio = decoded.sampleRate.toDouble() / SAMPLE_RATE
            for (i in 0 until outputFrames) {
                val position = i * ratio
                val i0 = min(decoded.left.lastIndex, floor(position).toInt())
                val i1 = min(decoded.left.lastIndex, i0 + 1)
                val frac = (position - i0).toFloat()
                left[i] = decoded.left[i0] * (1f - frac) + decoded.left[i1] * frac
                right[i] = decoded.right[i0] * (1f - frac) + decoded.right[i1] * frac
            }
            return StereoAudio(left, right)
        }

        private fun tryReadWav(file: File): DecodedAudio? {
            RandomAccessFile(file, "r").use { raf ->
                if (raf.length() < 44L) return null
                if (readAscii(raf, 4) != "RIFF") return null
                readU32(raf)
                if (readAscii(raf, 4) != "WAVE") return null
                var formatTag = 0
                var channelCount = 0
                var rate = 0
                var bits = 0
                var blockAlign = 0
                var dataOffset = -1L
                var dataSize = 0L
                while (raf.filePointer + 8 <= raf.length()) {
                    val chunk = readAscii(raf, 4)
                    val size = readU32(raf)
                    val body = raf.filePointer
                    when (chunk) {
                        "fmt " -> {
                            if (size < 16L) throw IllegalArgumentException("Неверный WAV: заголовок fmt слишком короткий.")
                            formatTag = readU16(raf)
                            channelCount = readU16(raf)
                            rate = readU32(raf).toInt()
                            readU32(raf)
                            blockAlign = readU16(raf)
                            bits = readU16(raf)
                            if (formatTag == 0xFFFE && size >= 40L) {
                                val cbSize = readU16(raf)
                                if (cbSize >= 22) {
                                    val subFormat = readIntLE(raf) // First DWORD of SubFormat GUID: PCM=1, IEEE float=3.
                                    raf.seek(min(body + size, raf.filePointer + 12L))
                                    if (subFormat == 1 || subFormat == 3) formatTag = subFormat
                                }
                            }
                        }
                        "data" -> { dataOffset = body; dataSize = min(size, raf.length() - body); }
                    }
                    val next = body + size + (size and 1L)
                    if (next > raf.length()) break
                    raf.seek(next)
                    if (dataOffset >= 0L && channelCount > 0 && rate > 0) break
                }
                if (dataOffset < 0L || channelCount !in 1..8 || rate <= 0) return null
                if (formatTag != 1 && formatTag != 3) {
                    throw IllegalArgumentException("Этот WAV использует сжатие. Попробуй выбрать исходный MP3, M4A или PCM WAV.")
                }
                if (bits !in setOf(8, 16, 24, 32) || (formatTag == 3 && bits != 32)) {
                    throw IllegalArgumentException("Неподдерживаемая разрядность WAV: $bits bit.")
                }
                val bytesPerSample = bits / 8
                val frameBytes = if (blockAlign > 0) blockAlign else bytesPerSample * channelCount
                val frames = (dataSize / frameBytes).toInt()
                val acc = StereoAccumulator(frames)
                raf.seek(dataOffset)
                repeat(frames) {
                    var left = 0f
                    var right = 0f
                    for (channel in 0 until channelCount) {
                        val value = readPcmSample(raf, formatTag, bits)
                        if (channel == 0) left = value else if (channel == 1) right = value
                    }
                    if (channelCount == 1) right = left
                    val consumed = bytesPerSample * channelCount
                    if (frameBytes > consumed) raf.seek(raf.filePointer + frameBytes - consumed)
                    acc.add(left, right)
                }
                return DecodedAudio(acc.leftArray(), acc.rightArray(), rate)
            }
        }

        private fun decodeCompressed(file: File): DecodedAudio {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                extractor.setDataSource(file.absolutePath)
                var audioTrack = -1
                var inputFormat: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val candidate = extractor.getTrackFormat(i)
                    val mime = candidate.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/")) { audioTrack = i; inputFormat = candidate; break }
                }
                if (audioTrack < 0 || inputFormat == null) throw IllegalArgumentException("Не найден аудиотрек. Выбери аудиофайл, например MP3, WAV, M4A или FLAC.")
                val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: throw IllegalArgumentException("Неизвестный формат аудио.")
                extractor.selectTrack(audioTrack)
                codec = MediaCodec.createDecoderByType(mime)
                codec.configure(inputFormat, null, null, 0)
                codec.start()
                var inputDone = false
                var outputDone = false
                var outputFormat = inputFormat
                var channels = inputFormat.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, 2).coerceIn(1, 8)
                var rate = inputFormat.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, SAMPLE_RATE)
                var encoding = AudioFormat.ENCODING_PCM_16BIT
                val acc = StereoAccumulator((file.length() / 4L).toInt().coerceIn(4096, SAMPLE_RATE * 30))
                val info = MediaCodec.BufferInfo()
                while (!outputDone) {
                    if (!inputDone) {
                        val inputIndex = codec.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val inputBuffer = codec.getInputBuffer(inputIndex) ?: throw IllegalStateException("Не удалось получить буфер декодера.")
                            inputBuffer.clear()
                            val size = extractor.readSampleData(inputBuffer, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            outputFormat = codec.outputFormat
                            channels = outputFormat.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, channels).coerceIn(1, 8)
                            rate = outputFormat.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, rate)
                            encoding = outputFormat.getIntegerOr(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER, MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                        else -> if (outputIndex >= 0) {
                            if (info.size > 0) {
                                val buffer = codec.getOutputBuffer(outputIndex) ?: throw IllegalStateException("Не удалось получить PCM-буфер декодера.")
                                buffer.position(info.offset)
                                buffer.limit(info.offset + info.size)
                                readDecodedPcm(buffer.slice().order(ByteOrder.LITTLE_ENDIAN), channels, encoding, acc)
                            }
                            codec.releaseOutputBuffer(outputIndex, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        }
                    }
                }
                if (rate <= 0) throw IllegalArgumentException("Декодер вернул неверную частоту дискретизации.")
                return DecodedAudio(acc.leftArray(), acc.rightArray(), rate)
            } catch (t: Throwable) {
                if (t is IllegalArgumentException) throw t
                throw IllegalArgumentException("Не удалось декодировать аудио: ${t.message ?: t.javaClass.simpleName}. Попробуй PCM WAV, MP3 или M4A.", t)
            } finally {
                try { codec?.stop() } catch (_: Throwable) { }
                try { codec?.release() } catch (_: Throwable) { }
                extractor.release()
            }
        }

        private fun readDecodedPcm(buffer: ByteBuffer, channels: Int, encoding: Int, acc: StereoAccumulator) {
            val sampleBytes = when (encoding) {
                AudioFormat.ENCODING_PCM_FLOAT, AudioFormat.ENCODING_PCM_32BIT -> 4
                AudioFormat.ENCODING_PCM_24BIT_PACKED -> 3
                AudioFormat.ENCODING_PCM_8BIT -> 1
                else -> 2
            }
            val frameBytes = sampleBytes * channels
            val frames = buffer.remaining() / frameBytes
            repeat(frames) {
                var left = 0f
                var right = 0f
                for (channel in 0 until channels) {
                    val value = when (encoding) {
                        AudioFormat.ENCODING_PCM_FLOAT -> buffer.float.coerceIn(-1.0f, 1.0f)
                        AudioFormat.ENCODING_PCM_32BIT -> (buffer.int.toDouble() / 2147483648.0).toFloat()
                        AudioFormat.ENCODING_PCM_24BIT_PACKED -> readPacked24(buffer)
                        AudioFormat.ENCODING_PCM_8BIT -> ((buffer.get().toInt() and 0xff) - 128) / 128.0f
                        else -> buffer.short / 32768.0f
                    }
                    if (channel == 0) left = value else if (channel == 1) right = value
                }
                if (channels == 1) right = left
                acc.add(left, right)
            }
        }

        private fun readPacked24(buffer: ByteBuffer): Float {
            val b0 = buffer.get().toInt() and 0xff
            val b1 = buffer.get().toInt() and 0xff
            val b2 = buffer.get().toInt() and 0xff
            var value = b0 or (b1 shl 8) or (b2 shl 16)
            if ((value and 0x800000) != 0) value = value or -0x1000000
            return value / 8388608.0f
        }

        private fun readPcmSample(raf: RandomAccessFile, formatTag: Int, bits: Int): Float {
            if (formatTag == 3) return Float.fromBits(readIntLE(raf)).coerceIn(-1.0f, 1.0f)
            return when (bits) {
                8 -> ((raf.read() and 0xff) - 128) / 128.0f
                16 -> (readU16(raf).toShort().toInt()) / 32768.0f
                24 -> {
                    val b0 = raf.read() and 0xff; val b1 = raf.read() and 0xff; val b2 = raf.read() and 0xff
                    var value = b0 or (b1 shl 8) or (b2 shl 16)
                    if ((value and 0x800000) != 0) value = value or -0x1000000
                    value / 8388608.0f
                }
                32 -> (readIntLE(raf).toDouble() / 2147483648.0).toFloat()
                else -> throw IllegalArgumentException("Разрядность WAV не поддерживается.")
            }
        }

        private fun readAscii(raf: RandomAccessFile, count: Int) = ByteArray(count).also { raf.readFully(it) }.toString(Charsets.US_ASCII)
        private fun readU16(raf: RandomAccessFile): Int {
            val a = raf.read(); val b = raf.read()
            if (a < 0 || b < 0) throw IllegalArgumentException("Повреждённый WAV-файл.")
            return a or (b shl 8)
        }
        private fun readIntLE(raf: RandomAccessFile): Int {
            val a = raf.read(); val b = raf.read(); val c = raf.read(); val d = raf.read()
            if (a < 0 || b < 0 || c < 0 || d < 0) throw IllegalArgumentException("Повреждённый аудиофайл.")
            return a or (b shl 8) or (c shl 16) or (d shl 24)
        }
        private fun readU32(raf: RandomAccessFile) = readIntLE(raf).toLong() and 0xffffffffL
        private fun MediaFormat.getIntegerOr(key: String, default: Int): Int = try { getInteger(key) } catch (_: Throwable) { default }
    }

    private class StereoAccumulator(initialFrames: Int) {
        private var left = FloatArray(initialFrames.coerceIn(4096, SAMPLE_RATE * MAX_SECONDS).coerceAtLeast(4096))
        private var right = FloatArray(left.size)
        private var count = 0
        fun add(l: Float, r: Float) {
            if (count >= SAMPLE_RATE * MAX_SECONDS) throw IllegalArgumentException("Слишком длинный аудиофайл. Максимум — ${MAX_SECONDS / 60} минут.")
            if (count == left.size) {
                val newSize = min(SAMPLE_RATE * MAX_SECONDS, max(left.size + 4096, left.size + left.size / 2))
                left = left.copyOf(newSize)
                right = right.copyOf(newSize)
            }
            left[count] = if (l.isFinite()) l else 0f
            right[count] = if (r.isFinite()) r else 0f
            count++
        }
        fun leftArray() = left.copyOf(count)
        fun rightArray() = right.copyOf(count)
    }

    private class WavWriter(private val file: File, private val rate: Int) : Closeable {
        private val raf = RandomAccessFile(file, "rw")
        private var dataBytes = 0L
        init { raf.setLength(0L); raf.write(ByteArray(44)) }

        fun writeFrames(left: FloatArray, right: FloatArray) {
            require(left.size == right.size)
            val buffer = ByteBuffer.allocate(left.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            for (i in left.indices) {
                val l = (left[i].coerceIn(-1f, 1f) * 32767f).roundToInt().coerceIn(-32768, 32767)
                val r = (right[i].coerceIn(-1f, 1f) * 32767f).roundToInt().coerceIn(-32768, 32767)
                buffer.putShort(l.toShort()); buffer.putShort(r.toShort())
            }
            raf.write(buffer.array())
            dataBytes += buffer.capacity().toLong()
        }

        override fun close() {
            val end = raf.filePointer
            raf.seek(0L)
            raf.write("RIFF".toByteArray(Charsets.US_ASCII))
            writeIntLE(raf, (dataBytes + 36L).coerceAtMost(0xffffffffL).toInt())
            raf.write("WAVE".toByteArray(Charsets.US_ASCII))
            raf.write("fmt ".toByteArray(Charsets.US_ASCII)); writeIntLE(raf, 16)
            writeShortLE(raf, 1); writeShortLE(raf, 2); writeIntLE(raf, rate)
            writeIntLE(raf, rate * 4); writeShortLE(raf, 4); writeShortLE(raf, 16)
            raf.write("data".toByteArray(Charsets.US_ASCII)); writeIntLE(raf, dataBytes.coerceAtMost(0xffffffffL).toInt())
            raf.seek(end)
            raf.close()
        }
        private fun writeShortLE(output: RandomAccessFile, value: Int) {
            output.write(value and 0xff); output.write((value ushr 8) and 0xff)
        }
        private fun writeIntLE(output: RandomAccessFile, value: Int) {
            output.write(value and 0xff); output.write((value ushr 8) and 0xff)
            output.write((value ushr 16) and 0xff); output.write((value ushr 24) and 0xff)
        }
    }
}

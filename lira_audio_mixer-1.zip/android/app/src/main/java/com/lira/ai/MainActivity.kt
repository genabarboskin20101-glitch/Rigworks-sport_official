package com.lira.ai

import android.annotation.SuppressLint
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var rootContainer: FrameLayout
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val isBusy = AtomicBoolean(false)
    private val preferences by lazy { getSharedPreferences("lira-audio-onnx", MODE_PRIVATE) }
    private val ortEnvironment by lazy { OrtEnvironment.getEnvironment() }

    @Volatile private var audioFile: File? = null
    @Volatile private var audioDisplayName: String = ""
    @Volatile private var modelFile: File? = null
    @Volatile private var modelSession: OrtSession? = null
    @Volatile private var vocalsOutput: File? = null
    @Volatile private var instrumentalOutput: File? = null
    @Volatile private var lastError: String? = null
    @Volatile private var pageReady = false
    @Volatile private var pendingExport: File? = null

    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importAudio(uri)
    }
    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importModel(uri)
    }
    private val wavSavePicker = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) exportPending(uri)
    }
    private val zipSavePicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) exportPending(uri)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(247, 247, 251))
            clipToPadding = false
        }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.addJavascriptInterface(this, "LiraNativeBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return !(uri.scheme == "file" && uri.toString().startsWith("file:///android_asset/"))
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                if (uri.host != "appassets.androidplatform.net") return null
                val file = when (uri.path) {
                    "/output/vocals" -> vocalsOutput
                    "/output/instrumental" -> instrumentalOutput
                    else -> null
                } ?: return null
                if (!file.isFile) return WebResourceResponse("text/plain", "UTF-8", null)
                return try {
                    val total = file.length()
                    val cors = mutableMapOf(
                        "Access-Control-Allow-Origin" to "*",
                        "Accept-Ranges" to "bytes",
                        "Cache-Control" to "no-store"
                    )
                    val range = request?.requestHeaders?.entries?.firstOrNull { it.key.equals("Range", true) }?.value
                    val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").matchEntire(it.trim()) }
                    if (m != null && total > 0) {
                        val startRaw = m.groupValues[1]; val endRaw = m.groupValues[2]
                        val start: Long; val end: Long
                        if (startRaw.isEmpty()) { val n = endRaw.toLongOrNull() ?: 0L; start = (total - n).coerceAtLeast(0L); end = total - 1 }
                        else { start = startRaw.toLong(); end = (endRaw.toLongOrNull() ?: (total - 1)).coerceAtMost(total - 1) }
                        if (start > end || start >= total) {
                            cors["Content-Range"] = "bytes */$total"
                            WebResourceResponse("audio/wav", null, 416, "Range Not Satisfiable", cors, ByteArrayInputStream(ByteArray(0)))
                        } else {
                            val input = FileInputStream(file)
                            var skipped = 0L
                            while (skipped < start) { val n = input.skip(start - skipped); if (n <= 0) break; skipped += n }
                            cors["Content-Range"] = "bytes $start-$end/$total"
                            cors["Content-Length"] = (end - start + 1).toString()
                            WebResourceResponse("audio/wav", null, 206, "Partial Content", cors, LimitedInputStream(input, end - start + 1))
                        }
                    } else {
                        cors["Content-Length"] = total.toString()
                        WebResourceResponse("audio/wav", null, 200, "OK", cors, FileInputStream(file))
                    }
                } catch (_: Throwable) {
                    WebResourceResponse("text/plain", "UTF-8", null)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageReady = true
                pushStatus()
            }
        }
        rootContainer.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        rootContainer.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val safe = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom)
            } else {
                @Suppress("DEPRECATION")
                view.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }
        window.statusBarColor = Color.rgb(247, 247, 251)
        window.navigationBarColor = Color.rgb(247, 247, 251)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        setContentView(rootContainer)
        rootContainer.requestApplyInsets()
        webView.loadUrl("file:///android_asset/www/index.html")
        restoreSavedModel()
    }

    private fun restoreSavedModel() {
        val savedPath = preferences.getString(KEY_MODEL_PATH, null) ?: return
        val file = File(savedPath).takeIf { it.isFile && it.canRead() } ?: return
        ioScope.launch {
            try {
                loadModel(file)
                modelFile = file
                pushStatus()
            } catch (t: Throwable) {
                lastError = "Не удалось загрузить сохранённую модель: ${friendlyError(t)}"
                callJs("onModelStatus", modelStatus(message = lastError))
            }
        }
    }

    @JavascriptInterface
    fun getStatus(): String = statusJson().toString()

    @JavascriptInterface
    fun chooseAudio() {
        runOnUiThread { audioPicker.launch(arrayOf("audio/*", "application/octet-stream")) }
    }

    @JavascriptInterface
    fun chooseModel() {
        runOnUiThread { modelPicker.launch(arrayOf("*/*")) }
    }

    @JavascriptInterface
    fun clearAudio() {
        audioFile?.delete()
        audioFile = null
        audioDisplayName = ""
        vocalsOutput?.delete(); vocalsOutput = null
        instrumentalOutput?.delete(); instrumentalOutput = null
        pushStatus()
    }

    @JavascriptInterface
    fun downloadDefaultModel() {
        if (!isBusy.compareAndSet(false, true)) return
        callJs("onProgress", JSONObject().put("percent", 0).put("title", "Загрузка модели").put("message", "Подключение к серверу модели…"))
        ioScope.launch {
            try {
                val dir = File(filesDir, "models").apply { mkdirs() }
                val partial = File(dir, "UVR-MDX-NET-Inst_HQ_3.onnx.part")
                val target = File(dir, "UVR-MDX-NET-Inst_HQ_3.onnx")
                partial.delete()
                val connection = (URL(MdxOnnxSeparator.DEFAULT_MODEL_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 20000
                    readTimeout = 60000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "Lira-Audio-ONNX/0.4")
                }
                try {
                    connection.connect()
                    if (connection.responseCode !in 200..299) throw IllegalStateException("Сервер модели вернул HTTP ${connection.responseCode}.")
                    val total = connection.contentLengthLong
                    var copied = 0L
                    var lastPercent = -1
                    var lastUnknownLengthReport = 0L
                    connection.inputStream.use { input -> FileOutputStream(partial).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            copied += read
                            val percent = if (total > 0) (copied * 100 / total).toInt().coerceIn(0, 99) else 0
                            val shouldReport = if (total > 0) percent != lastPercent else copied - lastUnknownLengthReport >= 1024L * 1024L
                            if (shouldReport) {
                                lastPercent = percent
                                lastUnknownLengthReport = copied
                                callJs("onDownloadProgress", JSONObject().put("percent", percent).put("message", "Загружено ${formatBytes(copied)}${if (total > 0) " из ${formatBytes(total)}" else ""}"))
                            }
                        }
                    } }
                } finally { connection.disconnect() }
                if (partial.length() < 20L * 1024L * 1024L) throw IllegalStateException("Файл слишком маленький — загрузка модели, возможно, была прервана.")
                val checksum = sha256(partial)
                if (!checksum.equals(DEFAULT_MODEL_SHA256, ignoreCase = true)) {
                    throw IllegalStateException("Контрольная сумма модели не совпала. Удали частичную загрузку и попробуй скачать модель ещё раз.")
                }
                if (!partial.renameTo(target)) {
                    partial.copyTo(target, overwrite = true)
                    partial.delete()
                }
                loadModel(target)
                modelFile = target
                preferences.edit().putString(KEY_MODEL_PATH, target.absolutePath).apply()
                lastError = null
                callJs("onModelStatus", modelStatus(message = "Модель скачана и готова"))
            } catch (t: Throwable) {
                File(filesDir, "models/UVR-MDX-NET-Inst_HQ_3.onnx.part").delete()
                lastError = friendlyError(t)
                callJs("onError", JSONObject.quote("Не удалось скачать модель: ${friendlyError(t)}"))
            } finally {
                isBusy.set(false)
                pushStatus()
            }
        }
    }

    @JavascriptInterface
    fun separateAudio(denoise: Boolean) {
        if (!isBusy.compareAndSet(false, true)) return
        val input = audioFile
        val session = modelSession
        if (input == null || !input.isFile) {
            isBusy.set(false); callJs("onError", JSONObject.quote("Сначала выбери аудиофайл.")); return
        }
        if (session == null) {
            isBusy.set(false); callJs("onError", JSONObject.quote("Сначала выбери или скачай ONNX-модель.")); return
        }
        callJs("onProcessStarted", "{}")
        ioScope.launch {
            try {
                val outputDir = File(filesDir, "outputs").apply { mkdirs() }
                val stems = MdxOnnxSeparator.separate(input, session, outputDir, denoise) { pct, message ->
                    callJs("onProgress", JSONObject().put("percent", pct).put("title", "Выполняется разделение").put("message", message))
                }
                vocalsOutput = stems.vocals
                instrumentalOutput = stems.instrumental
                lastError = null
                callJs("onProcessDone", resultJson())
            } catch (t: Throwable) {
                lastError = friendlyError(t)
                callJs("onError", JSONObject.quote("Не удалось разделить аудио: ${friendlyError(t)}"))
            } finally {
                isBusy.set(false)
                pushStatus()
            }
        }
    }

    @JavascriptInterface
    fun exportStem(stem: String) {
        val file = when (stem.lowercase(Locale.ROOT)) {
            "vocals" -> vocalsOutput
            "instrumental" -> instrumentalOutput
            else -> null
        }
        if (file == null || !file.isFile) {
            callJs("onError", JSONObject.quote("Сначала выполни разделение аудио.")); return
        }
        pendingExport = file
        runOnUiThread { wavSavePicker.launch(file.name) }
    }

    @JavascriptInterface
    fun exportMix(vocalGain: Double, instrumentalGain: Double) {
        val vocals = vocalsOutput
        val instrumental = instrumentalOutput
        if (vocals == null || instrumental == null || !vocals.isFile || !instrumental.isFile) {
            callJs("onError", JSONObject.quote("Сначала выполни разделение аудио.")); return
        }
        val vg = vocalGain.toFloat().coerceIn(0f, 2f)
        val ig = instrumentalGain.toFloat().coerceIn(0f, 2f)
        callJs("onExportDone", JSONObject.quote("Сводим итоговый файл…"))
        ioScope.launch {
            try {
                val mixFile = File(cacheDir, "Lira_Audio_mix.wav")
                renderMix(vocals, instrumental, mixFile, vg, ig)
                pendingExport = mixFile
                runOnUiThread { wavSavePicker.launch("Lira_Audio_mix.wav") }
            } catch (t: Throwable) {
                callJs("onError", JSONObject.quote("Не удалось свести файл: ${friendlyError(t)}"))
            }
        }
    }

    /** Both stems are 44.1 kHz 16-bit stereo PCM WAV with a 44-byte header (see WavWriter). */
    private fun renderMix(vocals: File, instrumental: File, target: File, vocalGain: Float, instGain: Float) {
        val frameBytes = 4
        val dataV = (vocals.length() - 44L).coerceAtLeast(0L) / frameBytes * frameBytes
        val dataI = (instrumental.length() - 44L).coerceAtLeast(0L) / frameBytes * frameBytes
        val total = maxOf(dataV, dataI)
        RandomAccessFile(vocals, "r").use { rv ->
            RandomAccessFile(instrumental, "r").use { ri ->
                FileOutputStream(target).use { out ->
                    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray(Charsets.US_ASCII)).putInt((total + 36L).toInt())
                    h.put("WAVE".toByteArray(Charsets.US_ASCII)).put("fmt ".toByteArray(Charsets.US_ASCII)).putInt(16)
                    h.putShort(1.toShort()).putShort(2.toShort()).putInt(44100).putInt(44100 * 4).putShort(4.toShort()).putShort(16.toShort())
                    h.put("data".toByteArray(Charsets.US_ASCII)).putInt(total.toInt())
                    out.write(h.array())
                    rv.seek(44L); ri.seek(44L)
                    val chunk = 1 shl 16
                    val bv = ByteArray(chunk); val bi = ByteArray(chunk); val bo = ByteArray(chunk)
                    var done = 0L
                    while (done < total) {
                        val want = minOf(chunk.toLong(), total - done).toInt()
                        java.util.Arrays.fill(bv, 0); java.util.Arrays.fill(bi, 0)
                        if (done < dataV) rv.readFully(bv, 0, minOf(want.toLong(), dataV - done).toInt())
                        if (done < dataI) ri.readFully(bi, 0, minOf(want.toLong(), dataI - done).toInt())
                        var i = 0
                        while (i < want) {
                            val a = (bv[i].toInt() and 0xff) or (bv[i + 1].toInt() shl 8)
                            val b = (bi[i].toInt() and 0xff) or (bi[i + 1].toInt() shl 8)
                            val m = (a * vocalGain + b * instGain).toInt().coerceIn(-32768, 32767)
                            bo[i] = (m and 0xff).toByte(); bo[i + 1] = ((m shr 8) and 0xff).toByte()
                            i += 2
                        }
                        out.write(bo, 0, want)
                        done += want
                    }
                }
            }
        }
    }

    @JavascriptInterface
    fun exportAll() {
        val vocals = vocalsOutput
        val instrumental = instrumentalOutput
        if (vocals == null || instrumental == null || !vocals.isFile || !instrumental.isFile) {
            callJs("onError", JSONObject.quote("Сначала выполни разделение аудио.")); return
        }
        ioScope.launch {
            try {
                val zipFile = File(cacheDir, "lira_stems_${System.currentTimeMillis()}.zip")
                ZipOutputStream(FileOutputStream(zipFile)).use { zip ->
                    listOf(vocals, instrumental).forEach { file ->
                        zip.putNextEntry(ZipEntry(file.name))
                        FileInputStream(file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
                pendingExport = zipFile
                runOnUiThread { zipSavePicker.launch("Lira_Audio_stems.zip") }
            } catch (t: Throwable) {
                callJs("onError", JSONObject.quote("Не удалось подготовить ZIP: ${friendlyError(t)}"))
            }
        }
    }

    private fun importAudio(uri: Uri) {
        if (!isBusy.compareAndSet(false, true)) return
        callJs("onProgress", JSONObject().put("percent", 0).put("title", "Добавление аудио").put("message", "Копирование файла в локальное хранилище…"))
        ioScope.launch {
            try {
                val info = queryFile(uri)
                val suffix = info.name.substringAfterLast('.', "audio").lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "").ifBlank { "audio" }
                val safeName = info.name.substringBeforeLast('.', info.name).replace(Regex("[^A-Za-z0-9._-]+"), "_").ifBlank { "audio" }
                val dir = File(filesDir, "audio").apply { mkdirs() }
                val target = File(dir, "${safeName}_${System.currentTimeMillis()}.$suffix")
                contentResolver.openInputStream(uri)?.use { source -> FileOutputStream(target).use { source.copyTo(it) } }
                    ?: throw IllegalArgumentException("Не удалось прочитать выбранный файл.")
                if (target.length() == 0L) throw IllegalArgumentException("Выбранный файл пуст.")
                audioFile?.delete()
                audioFile = target
                audioDisplayName = info.name
                vocalsOutput?.delete(); vocalsOutput = null
                instrumentalOutput?.delete(); instrumentalOutput = null
                lastError = null
                callJs("onAudioSelected", JSONObject()
                    .put("ready", true)
                    .put("name", info.name)
                    .put("meta", "${formatBytes(target.length())} · добавлен в локальное хранилище"))
                pushStatus()
            } catch (t: Throwable) {
                callJs("onError", JSONObject.quote("Не удалось добавить аудио: ${friendlyError(t)}"))
            } finally { isBusy.set(false) }
        }
    }

    private fun importModel(uri: Uri) {
        if (!isBusy.compareAndSet(false, true)) return
        callJs("onProgress", JSONObject().put("percent", 0).put("title", "Проверка модели").put("message", "Копирование ONNX-файла и создание сессии…"))
        ioScope.launch {
            try {
                val info = queryFile(uri)
                if (!info.name.endsWith(".onnx", ignoreCase = true)) {
                    throw IllegalArgumentException("Выбери файл с расширением .onnx.")
                }
                val dir = File(filesDir, "models").apply { mkdirs() }
                val safeName = info.name.replace(Regex("[^A-Za-z0-9._-]+"), "_")
                val target = File(dir, "model_${System.currentTimeMillis()}_$safeName")
                contentResolver.openInputStream(uri)?.use { source -> FileOutputStream(target).use { source.copyTo(it) } }
                    ?: throw IllegalArgumentException("Не удалось прочитать ONNX-файл.")
                if (target.length() < 1024L) throw IllegalArgumentException("ONNX-файл слишком маленький или повреждён.")
                loadModel(target)
                modelFile = target
                preferences.edit().putString(KEY_MODEL_PATH, target.absolutePath).apply()
                lastError = null
                callJs("onModelStatus", modelStatus(message = "ONNX-модель загружена"))
                pushStatus()
            } catch (t: Throwable) {
                lastError = friendlyError(t)
                callJs("onError", JSONObject.quote("Не удалось загрузить модель: ${friendlyError(t)}"))
            } finally { isBusy.set(false) }
        }
    }

    private fun loadModel(file: File) {
        val options = OrtSession.SessionOptions()
        val newSession: OrtSession
        try {
            options.setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            options.setInterOpNumThreads(1)
            newSession = ortEnvironment.createSession(file.absolutePath, options)
            val inputs = newSession.inputNames
            val outputs = newSession.outputNames
            if (inputs.isEmpty() || outputs.isEmpty()) {
                newSession.close()
                throw IllegalArgumentException("ONNX-файл не содержит входных и выходных тензоров.")
            }
        } finally { options.close() }
        val old = modelSession
        modelSession = newSession
        old?.close()
    }

    private fun exportPending(uri: Uri) {
        val file = pendingExport ?: return
        ioScope.launch {
            try {
                contentResolver.openOutputStream(uri, "w")?.use { output -> FileInputStream(file).use { it.copyTo(output) } }
                    ?: throw IllegalStateException("Не удалось открыть выбранное место сохранения.")
                callJs("onExportDone", JSONObject.quote("Сохранено: ${file.name}"))
            } catch (t: Throwable) {
                callJs("onError", JSONObject.quote("Не удалось сохранить файл: ${friendlyError(t)}"))
            } finally { pendingExport = null }
        }
    }

    private data class FileInfo(val name: String, val size: Long)
    private fun queryFile(uri: Uri): FileInfo {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "audio"
        var size = -1L
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val n = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                val s = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                if (n >= 0) name = cursor.getString(n) ?: name
                if (s >= 0 && !cursor.isNull(s)) size = cursor.getLong(s)
            }
        }
        return FileInfo(name, size)
    }

    private fun statusJson(): JSONObject {
        val input = audioFile?.takeIf { it.isFile }
        val model = modelFile?.takeIf { it.isFile && modelSession != null }
        val vocals = vocalsOutput?.takeIf { it.isFile }
        val instrumental = instrumentalOutput?.takeIf { it.isFile }
        return JSONObject()
            .put("audioReady", input != null)
            .put("audioName", if (input != null) audioDisplayName.ifBlank { input.name } else "")
            .put("audioMeta", input?.let { "${formatBytes(it.length())} · добавлен в локальное хранилище" } ?: "")
            .put("modelReady", model != null)
            .put("modelName", model?.name?.replace(Regex("^model_[0-9]+_"), "") ?: "")
            .put("modelMeta", if (model != null) "UVR MDX-Net · локальная ONNX-модель" else "UVR MDX-Net · целевой выход: инструментал")
            .put("outputReady", vocals != null && instrumental != null)
            .put("vocalsUrl", if (vocals != null) outputUrl("vocals", vocals) else "")
            .put("instrumentalUrl", if (instrumental != null) outputUrl("instrumental", instrumental) else "")
            .put("error", lastError ?: "")
    }

    private fun resultJson() = JSONObject()
        .put("ready", true)
        .put("vocalsUrl", vocalsOutput?.let { outputUrl("vocals", it) } ?: "")
        .put("instrumentalUrl", instrumentalOutput?.let { outputUrl("instrumental", it) } ?: "")

    private fun outputUrl(stem: String, file: File) = "https://appassets.androidplatform.net/output/$stem?v=${file.lastModified()}"

    private fun modelStatus(message: String? = null) = JSONObject()
        .put("ready", modelSession != null && modelFile?.isFile == true)
        .put("name", modelFile?.name?.replace(Regex("^model_[0-9]+_"), "") ?: "")
        .put("meta", "UVR MDX-Net · целевой выход: инструментал")
        .put("message", message ?: "")

    private fun pushStatus() {
        if (pageReady) callJs("setStatus", statusJson())
    }

    private fun callJs(method: String, argument: String) {
        if (!pageReady) return
        runOnUiThread {
            try { webView.evaluateJavascript("window.LiraAudioApp && window.LiraAudioApp.$method($argument);", null) }
            catch (_: Throwable) { }
        }
    }
    private fun callJs(method: String, argument: JSONObject) = callJs(method, argument.toString())

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte) }
    }

    private fun friendlyError(t: Throwable): String {
        val message = t.message?.trim().orEmpty().ifBlank { t.javaClass.simpleName }
        return if (message.length > 400) message.take(397) + "…" else message
    }
    private fun formatBytes(value: Long): String = when {
        value < 0 -> "размер неизвестен"
        value < 1024 -> "$value Б"
        value < 1024 * 1024 -> String.format(Locale.US, "%.1f КБ", value / 1024.0)
        else -> String.format(Locale.US, "%.1f МБ", value / (1024.0 * 1024.0))
    }

    override fun onDestroy() {
        super.onDestroy()
        pageReady = false
        ioScope.cancel()
        try { modelSession?.close() } catch (_: Throwable) { }
        modelSession = null
        webView.removeJavascriptInterface("LiraNativeBridge")
        webView.destroy()
    }

    companion object {
        private const val KEY_MODEL_PATH = "onnx_model_path"
        private const val DEFAULT_MODEL_SHA256 = "317554b07fe1ea5279a77f2b1520a41ea4b93432560c4ffd08792c30fddf9adc"
    }
}

private class LimitedInputStream(source: InputStream, private var remaining: Long) : FilterInputStream(source) {
    override fun read(): Int {
        if (remaining <= 0) return -1
        val r = super.read(); if (r >= 0) remaining--; return r
    }
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (remaining <= 0) return -1
        val r = super.read(b, off, minOf(len.toLong(), remaining).toInt()); if (r > 0) remaining -= r; return r
    }
}

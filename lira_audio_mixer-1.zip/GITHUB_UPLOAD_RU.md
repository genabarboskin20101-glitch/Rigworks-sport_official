# Как загрузить проект в GitHub для сборки APK

Ошибка `Android Gradle project was not found` означает, что GitHub Actions видит workflow, но не видит Android-исходники (`settings.gradle.kts`). Одного файла `.yml` для сборки недостаточно.

Загрузите **все содержимое этого архива** в корень репозитория так, чтобы структура была такой:

```text
.github/
└── workflows/
    └── build-android.yml
android/
├── app/
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
web/
├── app.js
├── index.html
└── style.css
README_RU.md
```

Не загружайте только `.github/workflows/build-android.yml` и не создавайте дополнительный каталог `lira_offline_kit/` вокруг этих файлов. После загрузки откройте вкладку **Actions** и запустите **Build Android APK**.

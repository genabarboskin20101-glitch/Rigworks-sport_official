package kx.engine;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.content.Context;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** JS-интерфейс window.KExport. Все методы возвращают строку (JSON). */
public final class KxBridge {
    private static final String TAG = "KX";
    private static final String OK = "{\"ok\":true}";
    private static final long CACHE_LIMIT = 3L << 30;

    volatile Activity act;
    private final WebView web;
    private final File dir;
    private final HashMap<String, RandomAccessFile> open = new HashMap<String, RandomAccessFile>();
    private final HashMap<String, Long> sizes = new HashMap<String, Long>();
    private final ConcurrentHashMap<String, Exporter> jobs = new ConcurrentHashMap<String, Exporter>();
    private final Set<String> uris = Collections.synchronizedSet(new HashSet<String>());
    private final AtomicInteger seq = new AtomicInteger();
    private final ConcurrentHashMap<String, Uri> uriSrc = new ConcurrentHashMap<String, Uri>();
    private final ArrayList<Picked> picked = new ArrayList<Picked>();
    volatile boolean hooked;
    volatile boolean mediaPlaying;

    private static final class Picked {
        Uri uri;
        String name = "";
        long size = -1;
    }

    KxBridge(Activity a, WebView w) {
        act = a;
        web = w;
        dir = new File(a.getCacheDir(), "kx");
        dir.mkdirs();
    }

    /** Приложение открыто заново, а страница жива (музыка играла в фоне): подключаем её к новой Activity без перезагрузки. */
    void rebind(Activity a) {
        act = a;
        detached = false;
        closing = false;
        backCb = null;
        backCbOn = false;
        MediaNotif m;
        synchronized (this) { m = media; }
        if (m != null) m.setActivity(a);
        refreshBackGuard();
    }

    /** Высота панели навигации снизу в CSS px (для отступа нижних панелей страницы); 0, если режим выключен. */
    @JavascriptInterface
    public int navInsetBottom() {
        return NavBar.navBottomCss();
    }

    /** Высота статус-бара/выреза сверху в CSS px (для отступа верхней панели страницы); 0, если скрыт. */
    @JavascriptInterface
    public int statusInsetTop() {
        return NavBar.statusTopCss();
    }

    // ---------- виброотклик (p0.24-haptic) ----------
    // navigator.vibrate в WebView ненадёжен (нужны разрешение и свежая активация, короткие импульсы режутся), поэтому
    // страница зовёт KExport.haptic("tick" | "tap" | "detent" | "detentMajor" | "release" | "confirm" | "heart" | "on" | "off" | "trackChange").
    // Порядок: 1) Vibrator (составные примитивы на API 30+, иначе волновая форма с амплитудами) — нужно <uses-permission VIBRATE>;
    // 2) без разрешения — View.performHapticFeedback (разрешение не требуется). Возвращает true, если эффект запущен.
    private Vibrator vib;
    private boolean vibInit;
    private volatile boolean vibPerm = true;
    private int primMask = -1; // биты: 1 CLICK, 2 TICK, 4 QUICK_RISE, 8 QUICK_FALL, 16 SLOW_RISE

    private synchronized Vibrator vibrator() {
        if (!vibInit) {
            vibInit = true;
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    Object vm = act.getSystemService("vibrator_manager");
                    if (vm instanceof android.os.VibratorManager) vib = ((android.os.VibratorManager) vm).getDefaultVibrator();
                }
                if (vib == null) vib = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null && !vib.hasVibrator()) vib = null;
                vibPerm = act.checkSelfPermission("android.permission.VIBRATE") == PackageManager.PERMISSION_GRANTED;
            } catch (Throwable t) {
                Log.w(TAG, "vibrator init failed", t);
            }
        }
        return vib;
    }

    /** Длительности сегментов (чётные индексы — импульс, нечётные — пауза) в мс; минимум импульса 8-10 мс, иначе моторчик не отрабатывает. */
    private static long[] hapticTimings(String n) {
        if ("tick".equals(n)) return new long[]{10};
        if ("tap".equals(n)) return new long[]{14};
        if ("detent".equals(n)) return new long[]{8};
        if ("detentMajor".equals(n)) return new long[]{16};
        if ("release".equals(n)) return new long[]{12, 26, 8};
        if ("confirm".equals(n)) return new long[]{12, 30, 10};
        if ("heart".equals(n)) return new long[]{16, 70, 12, 140, 8};
        if ("on".equals(n)) return new long[]{8, 10, 9, 9, 10, 8, 12, 7, 14};
        if ("off".equals(n)) return new long[]{14, 7, 12, 8, 10, 9, 9, 10, 8};
        if ("trackChange".equals(n)) return new long[]{8, 14, 9, 12, 10, 10, 12, 8, 15};
        return null;
    }

    private static int hapticAmp(String n, int onIndex, int onCount) {
        if ("detent".equals(n)) return 70;
        if ("tick".equals(n)) return 95;
        if ("tap".equals(n)) return 140;
        if ("detentMajor".equals(n)) return 150;
        if ("release".equals(n)) return 120;
        if ("confirm".equals(n)) return onIndex == 0 ? 150 : 90;
        if ("heart".equals(n)) return onIndex == 0 ? 220 : (onIndex == 1 ? 170 : 110);
        float k = onCount <= 1 ? 1f : (float) onIndex / (float) (onCount - 1); // нарастание (on/trackChange) или затухание (off)
        if ("off".equals(n)) k = 1f - k;
        return 55 + Math.round(k * 200f);
    }

    @SuppressWarnings("deprecation")
    private boolean playWaveform(Vibrator v, String n) {
        long[] t = hapticTimings(n);
        if (t == null) return false;
        if (Build.VERSION.SDK_INT >= 26 && v.hasAmplitudeControl()) {
            int[] a = new int[t.length];
            int onCount = (t.length + 1) / 2;
            for (int i = 0; i < t.length; i++) a[i] = (i % 2 == 0) ? hapticAmp(n, i / 2, onCount) : 0;
            v.vibrate(VibrationEffect.createWaveform(t, a, -1));
        } else if (Build.VERSION.SDK_INT >= 26) {
            long[] w = new long[t.length];
            System.arraycopy(t, 0, w, 0, t.length);
            v.vibrate(VibrationEffect.createWaveform(w, -1));
        } else {
            long[] legacy = new long[t.length + 1]; // у старого API первый элемент — пауза до начала
            System.arraycopy(t, 0, legacy, 1, t.length);
            v.vibrate(legacy, -1);
        }
        return true;
    }

    private int primitives(Vibrator v) {
        if (primMask >= 0) return primMask;
        int m = 0;
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                if (v.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_CLICK)) m |= 1;
                if (v.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_TICK)) m |= 2;
                if (v.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_QUICK_RISE)) m |= 4;
                if (v.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_QUICK_FALL)) m |= 8;
                if (v.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_SLOW_RISE)) m |= 16;
            }
        } catch (Throwable ignored) {
            m = 0;
        }
        primMask = m;
        return m;
    }

    /** API 30+: аппаратные примитивы дают заметно более «чистый» отклик, чем сырые импульсы; false — примитивов нет, нужна волновая форма. */
    private boolean playComposition(Vibrator v, String n) {
        if (Build.VERSION.SDK_INT < 30) return false;
        int m = primitives(v);
        VibrationEffect.Composition c = VibrationEffect.startComposition();
        final int CLICK = VibrationEffect.Composition.PRIMITIVE_CLICK, TICK = VibrationEffect.Composition.PRIMITIVE_TICK;
        if ("tick".equals(n) && (m & 2) != 0) c.addPrimitive(TICK, 0.75f);
        else if ("detent".equals(n) && (m & 2) != 0) c.addPrimitive(TICK, 0.5f);
        else if ("detentMajor".equals(n) && (m & 1) != 0) c.addPrimitive(CLICK, 0.45f);
        else if ("tap".equals(n) && (m & 1) != 0) c.addPrimitive(CLICK, 0.6f);
        else if ("release".equals(n) && (m & 1) != 0) c.addPrimitive(CLICK, 0.4f);
        else if ("confirm".equals(n) && (m & 3) == 3) {
            c.addPrimitive(CLICK, 0.6f);
            c.addPrimitive(TICK, 0.4f, 40);
        } else if ("heart".equals(n) && (m & 1) != 0) {
            c.addPrimitive(CLICK, 0.9f);
            c.addPrimitive(CLICK, 0.6f, 90);
        } else if ("on".equals(n) && (m & 4) != 0) c.addPrimitive(VibrationEffect.Composition.PRIMITIVE_QUICK_RISE, 0.8f);
        else if ("off".equals(n) && (m & 8) != 0) c.addPrimitive(VibrationEffect.Composition.PRIMITIVE_QUICK_FALL, 0.8f);
        else if ("trackChange".equals(n) && (m & 16) != 0) c.addPrimitive(VibrationEffect.Composition.PRIMITIVE_SLOW_RISE, 0.7f);
        else return false;
        v.vibrate(c.compose());
        return true;
    }

    private static int feedbackConst(String n) {
        int api = Build.VERSION.SDK_INT;
        if ("tick".equals(n) || "detent".equals(n)) return api >= 34 && "detent".equals(n) ? 25 : 4; // SEGMENT_FREQUENT_TICK / CLOCK_TICK
        if ("detentMajor".equals(n)) return api >= 34 ? 24 : 4; // SEGMENT_TICK
        if ("tap".equals(n)) return 1; // VIRTUAL_KEY
        if ("release".equals(n)) return api >= 27 ? 7 : 1; // KEYBOARD_RELEASE
        if ("confirm".equals(n) || "heart".equals(n)) return api >= 30 ? 16 : 1; // CONFIRM
        if ("on".equals(n)) return api >= 34 ? 21 : (api >= 23 ? 6 : 1); // TOGGLE_ON / CONTEXT_CLICK
        if ("off".equals(n)) return api >= 34 ? 22 : (api >= 23 ? 6 : 1); // TOGGLE_OFF / CONTEXT_CLICK
        if ("trackChange".equals(n)) return api >= 30 ? 13 : 1; // GESTURE_END
        return -1;
    }

    private boolean performFeedback(String n) {
        final int c = feedbackConst(n);
        if (c < 0) return false;
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    // 2 = FLAG_IGNORE_GLOBAL_SETTING (на Android 13+ игнорируется системой): у приложения есть свой выключатель вибро
                    web.performHapticFeedback(c, 2);
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        });
        return true;
    }

    /** Запускает эффект по имени. true — эффект запущен (нативно), false — страница может попробовать navigator.vibrate. */
    @JavascriptInterface
    public boolean haptic(String name) {
        try {
            if (name == null) return false;
            Vibrator v = vibrator();
            if (v != null && vibPerm) {
                try {
                    if (playComposition(v, name) || playWaveform(v, name)) {
                        hapticPath = "vibrator";
                        return true;
                    }
                } catch (SecurityException se) {
                    vibPerm = false; // разрешения VIBRATE в манифесте нет — дальше сразу performHapticFeedback
                } catch (Throwable t) {
                    Log.w(TAG, "vibrate failed: " + t);
                }
            }
            hapticPath = "feedback(без VIBRATE)";
            return performFeedback(name);
        } catch (Throwable t) {
            return false;
        }
    }

    private volatile String hapticPath = "none";

    /** Диагностика для страницы (Настройки → Вибрация → «Проверить вибрацию»). */
    @JavascriptInterface
    public String hapticInfo() {
        try {
            Vibrator v = vibrator();
            JSONObject o = new JSONObject();
            o.put("api", Build.VERSION.SDK_INT);
            o.put("hasVibrator", v != null);
            o.put("perm", act.checkSelfPermission("android.permission.VIBRATE") == PackageManager.PERMISSION_GRANTED);
            o.put("amp", v != null && Build.VERSION.SDK_INT >= 26 && v.hasAmplitudeControl());
            o.put("path", hapticPath);
            return o.toString();
        } catch (Throwable t) {
            return "{}";
        }
    }

    /** Оборвать текущую вибрацию (например, на время кроссфейда или при сворачивании). */
    @JavascriptInterface
    public void hapticCancel() {
        try {
            Vibrator v = vibrator();
            if (v != null && vibPerm) v.cancel();
        } catch (Throwable ignored) {
            // нет разрешения / уже остановлено
        }
    }

    /** Тема устройства: "dark" или "light" (uiMode системной конфигурации). Для страницы: KExport.theme(). */
    @JavascriptInterface
    public String theme() {
        return isNight(null) ? "dark" : "light";
    }

    boolean isNight(Configuration cfg) {
        try {
            Configuration c = cfg != null ? cfg : act.getApplicationContext().getResources().getConfiguration();
            return (c.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Сообщает странице тему: вызывает window.__kxThemeSet('dark'|'light') (его ставит скрипт, который вшивает билдер). */
    void pushTheme(Configuration cfg) {
        final String js = "window.__kxThemeSet&&window.__kxThemeSet('" + (isNight(cfg) ? "dark" : "light") + "')";
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    web.evaluateJavascript(js, null);
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        });
    }

    // ---------- вспомогательное ----------

    static JSONObject o(Object... kv) {
        JSONObject j = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) j.put((String) kv[i], kv[i + 1]);
        } catch (Exception ignored) {
            // значения собираются из своих же типов
        }
        return j;
    }

    static String err(String msg) {
        return o("ok", false, "error", msg).toString();
    }

    static String err(Throwable t) {
        Log.w(TAG, "bridge error", t);
        return err(t.getClass().getSimpleName() + ": " + t.getMessage());
    }

    private static boolean validId(String id) {
        return id != null && id.matches("[A-Za-z0-9_\\-]{1,64}");
    }

    File fileFor(String id) {
        if (!validId(id)) return null;
        File f = new File(dir, id + ".bin");
        return (f.exists() && new File(dir, id + ".ok").exists()) ? f : null;
    }

    Src srcFor(String id) {
        if (!validId(id)) return null;
        Uri u = uriSrc.get(id);
        if (u != null) return new Src(u);
        File f = fileFor(id);
        return f == null ? null : new Src(f);
    }

    /** Подменяет WebChromeClient оболочки обёрткой FileHook (API 26+); вызывается из потока UI. */
    void ensureHook() {
        try {
            if (Build.VERSION.SDK_INT < 26) return;
            WebChromeClient cur = web.getWebChromeClient();
            if (cur == null) return;
            if (!(cur instanceof FileHook)) web.setWebChromeClient(new FileHook(cur, this));
            hooked = true;
        } catch (Throwable t) {
            Log.w(TAG, "ensureHook failed", t);
        }
    }

    /** Запоминает URI, которые пользователь выбрал в системном диалоге (вызывается из FileHook). */
    void recordPicked(Uri[] uris) {
        if (uris == null) return;
        ContentResolver cr = act.getContentResolver();
        for (Uri u : uris) {
            if (u == null) continue;
            Picked p = new Picked();
            p.uri = u;
            Cursor c = null;
            try {
                c = cr.query(u, new String[] {OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null);
                if (c != null && c.moveToFirst()) {
                    int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int si = c.getColumnIndex(OpenableColumns.SIZE);
                    if (ni >= 0 && !c.isNull(ni)) p.name = c.getString(ni);
                    if (si >= 0 && !c.isNull(si)) p.size = c.getLong(si);
                }
            } catch (Throwable t) {
                Log.w(TAG, "query picked failed", t);
            } finally {
                if (c != null) c.close();
            }
            if (p.size < 0) {
                try {
                    AssetFileDescriptor f = cr.openAssetFileDescriptor(u, "r");
                    if (f != null) {
                        p.size = f.getLength();
                        f.close();
                    }
                } catch (Throwable ignored) {
                    // размер определится позже или совпадение не найдётся
                }
            }
            synchronized (this) {
                picked.add(p);
                while (picked.size() > 300) picked.remove(0);
            }
        }
    }

    private static String sha1(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format("%02x", b & 0xff));
        return sb.toString();
    }

    private long free() {
        return new StatFs(dir.getPath()).getAvailableBytes();
    }

    private void trimCache(long need) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        ArrayList<File> bins = new ArrayList<File>();
        long total = 0;
        for (File f : fs) {
            if (f.getName().endsWith(".bin")) {
                bins.add(f);
                total += f.length();
            }
        }
        Collections.sort(bins, new java.util.Comparator<File>() {
            public int compare(File a, File b) {
                return Long.compare(a.lastModified(), b.lastModified());
            }
        });
        for (File f : bins) {
            if (total <= CACHE_LIMIT && free() >= need) break;
            total -= f.length();
            String base = f.getName().substring(0, f.getName().length() - 4);
            f.delete();
            new File(dir, base + ".ok").delete();
        }
    }

    void emit(JSONObject ev) {
        String s = ev.toString()
                .replace(String.valueOf((char) 0x2028), "\\u2028")
                .replace(String.valueOf((char) 0x2029), "\\u2029");
        final String js = "window.__kx&&window.__kx.onEvent&&window.__kx.onEvent(" + s + ")";
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    web.evaluateJavascript(js, null);
                } catch (Throwable t) {
                    Log.w(TAG, "emit failed", t);
                }
            }
        });
    }

    void keepScreenOn(final boolean on) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    if (on) act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } catch (Throwable ignored) {
                    // окно уже закрыто
                }
            }
        });
    }

    void jobDone(String id) {
        jobs.remove(id);
    }

    void registerUri(String u) {
        uris.add(u);
    }

    private MediaNotif media;

    private synchronized MediaNotif media() {
        if (media == null) {
            media = new MediaNotif(act, new MediaNotif.Sink() {
                @Override
                public void action(String name, long posMs) {
                    if ("close".equals(name)) { // ✕ в уведомлении: закрываем приложение целиком (команду страница не получает)
                        closeApp();
                        return;
                    }
                    if ("next".equals(name) || "prev".equals(name)) {
                        if (nativeStep("next".equals(name) ? 1 : -1)) return; // шаг выполнен движком; страница подстроится сама
                    }
                    // play/pause/перемотка выполняются движком мгновенно, не дожидаясь страницы: в фоне она отвечает с большой задержкой,
                    // а команды копились в очереди и срабатывали пачкой через секунды. Страница получает уже готовый результат и лишь подстраивается
                    String sendName = name;
                    if ("play".equals(name) || "pause".equals(name)) {
                        if (nativeTransport(name, posMs)) sendName = "n" + name;
                    } else if ("seek".equals(name)) {
                        nativeTransport(name, posMs);
                    }
                    final boolean nativeDone = !sendName.equals(name) || "seek".equals(name);
                    final String js = "window.__kxMedia&&window.__kxMedia('" + sendName + "'," + posMs + ")";
                    final AtomicBoolean acked = new AtomicBoolean(false);
                    uiH.post(new Runnable() {
                        public void run() {
                            try {
                                // команда из уведомления: страница могла быть усыплена (свёрнуто, пауза) — без этого таймеры
                                // замирают и смена трека/перемотка зависают на полпути
                                web.onResume();
                                web.resumeTimers();
                                // callback вызывается только когда страница реально выполнила код: так понимаем, что её заморозила система
                                web.evaluateJavascript(js, new ValueCallback<String>() {
                                    @Override
                                    public void onReceiveValue(String v) {
                                        acked.set(true);
                                        jsAliveAt = android.os.SystemClock.elapsedRealtime();
                                    }
                                });
                            } catch (Throwable ignored) {
                                // WebView уже уничтожен
                            }
                        }
                    });
                    // страница не ответила (Realme/ColorOS заморозил процесс отрисовки): play/pause/перемотку выполняем сами
                    if (!nativeDone && ("play".equals(name) || "pause".equals(name) || "seek".equals(name))) {
                        final String nm = name;
                        final long pm = posMs;
                        uiH.postDelayed(new Runnable() {
                            public void run() {
                                if (!acked.get()) nativeTransport(nm, pm);
                            }
                        }, 600L);

                    }
                }
            });
        }
        return media;
    }

    /** Когда страница последний раз отвечала на команду/сообщение (elapsedRealtime). */
    private volatile long jsAliveAt;
    private final AtomicBoolean stateBusy = new AtomicBoolean(false);
    private volatile long stateSentAt;

    // ---------- следующий/предыдущий трек из шторки без страницы ----------
    // Страница заранее присылает окно очереди вокруг текущего трека: {ep, ad (активная дека), idx, items:[{id,key,title,artist,album,dur,art}]}.
    // Шаг выполняет движок: грузит соседний трек из кэша в активную деку, играет, обновляет уведомление и сообщает странице (__kxNStep).
    private volatile org.json.JSONArray mq;
    private volatile int mqIdx = -1;
    private volatile int mqDeck;
    private volatile int stepEpoch;
    private static int stepTok = 1000000000;

    @JavascriptInterface
    public void mediaQueue(String json) {
        try {
            JSONObject o = new JSONObject(json);
            synchronized (this) {
                if (o.optInt("ep", 0) < stepEpoch) return; // страница ещё не обработала наши шаги: её окно устарело
                mq = o.getJSONArray("items");
                mqIdx = o.optInt("idx", -1);
                mqDeck = o.optInt("ad", 0);
            }
        } catch (Throwable t) {
            Log.w(TAG, "mediaQueue failed", t);
        }
    }

    @JavascriptInterface
    public void mediaQueueClear() {
        synchronized (this) {
            mq = null;
            mqIdx = -1;
        }
    }

    private void postJs(final String js) {
        uiH.post(new Runnable() {
            public void run() {
                try {
                    web.onResume();
                    web.resumeTimers();
                    web.evaluateJavascript(js, null);
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        });
    }

    /** true — шаг выполнен нативно; false — нужно выполнить его через страницу. */
    private boolean nativeStep(int d) {
        try {
            NativeAudio n;
            org.json.JSONArray q;
            int idx, dk;
            synchronized (this) {
                n = na;
                q = mq;
                idx = mqIdx;
                dk = mqDeck;
            }
            if (n == null || q == null || idx < 0 || idx >= q.length()) return false;
            if (d < 0 && n.nativePosSec() > 3.0) return nativeTransport("seek", 0L); // как в приложении: сначала в начало трека
            int t = idx + d;
            if (t < 0 || t >= q.length()) return false;
            JSONObject it = q.getJSONObject(t);
            String key = it.optString("key", "");
            String id = it.optString("id", "");
            if (key.length() == 0 || id.length() == 0) return false;
            int tok;
            synchronized (KxBridge.class) { tok = ++stepTok; }
            if (!n.stepTo(dk, key, tok)) return false;
            long dur = it.optLong("dur", 0L);
            int ep;
            synchronized (this) {
                ep = ++stepEpoch;
                mqIdx = t;
            }
            mediaPlaying = true;
            media().set(it.optString("title", ""), it.optString("artist", ""), it.optString("album", ""), dur, it.optString("art", ""));
            media().state(true, 0L);
            postJs("window.__kxNStep&&window.__kxNStep(" + JSONObject.quote(id) + "," + dk + "," + tok + "," + JSONObject.quote(key) + "," + dur + "," + ep + ")");
            Log.i(TAG, "native step: " + d);
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "native step failed", t);
            return false;
        }
    }

    /** play/pause/перемотка из шторки без участия страницы: управляем нативным движком напрямую и обновляем уведомление. */
    private boolean nativeTransport(String name, long posMs) {
        try {
            NativeAudio n;
            synchronized (this) { n = na; }
            if (n == null) return false;
            boolean pl;
            if ("pause".equals(name)) {
                if (!n.nativePause()) return false;
                pl = false;
            } else if ("play".equals(name)) {
                if (!n.nativePlay()) return false;
                pl = true;
            } else {
                if (!n.nativeSeek(posMs / 1000.0)) return false;
                pl = n.nativeIsPlaying();
            }
            double ps = n.nativePosSec();
            long pos = "seek".equals(name) ? posMs : (long) (Math.max(0.0, ps) * 1000.0);
            mediaPlaying = pl;
            media().state(pl, pos);
            Log.i(TAG, "native transport: " + name);
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "native transport failed", t);
            return false;
        }
    }

    // ---------- работа в фоне на Realme/OPPO/ColorOS ----------
    private volatile boolean bgAsked;

    /** Один раз просит снять ограничения фоновой работы (без этого ColorOS замораживает страницу плеера через ~10 с после сворачивания). */
    void askBackgroundOnce() {
        try {
            Activity a = act;
            if (a == null || bgAsked) return;
            android.content.SharedPreferences sp = a.getApplicationContext().getSharedPreferences("kx_bg", Context.MODE_PRIVATE);
            if (sp.getBoolean("asked", false)) return;
            if (Build.VERSION.SDK_INT >= 23) {
                android.os.PowerManager pm = (android.os.PowerManager) a.getSystemService(Context.POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(a.getPackageName())) return;
            }
            bgAsked = true;
            sp.edit().putBoolean("asked", true).apply();
            showBgDialog();
        } catch (Throwable t) {
            Log.w(TAG, "askBackgroundOnce failed", t);
        }
    }

    private void showBgDialog() {
        uiH.post(new Runnable() {
            public void run() {
                try {
                    final Activity a = act;
                    if (a == null || a.isFinishing()) return;
                    new android.app.AlertDialog.Builder(a)
                            .setTitle("Работа в фоне")
                            .setMessage("Чтобы кнопки плеера в шторке и на экране блокировки работали, когда приложение свёрнуто, "
                                    + "разрешите LMusic работать в фоне.\n\nНа Realme/OPPO дополнительно: Настройки → Батарея → LMusic → "
                                    + "«Разрешить фоновую активность» и «Автозапуск»; в списке недавних приложений потяните карточку LMusic вниз и нажмите замок.")
                            .setPositiveButton("Разрешить", new android.content.DialogInterface.OnClickListener() {
                                public void onClick(android.content.DialogInterface d, int w) {
                                    openBatterySettings(a);
                                }
                            })
                            .setNeutralButton("Автозапуск", new android.content.DialogInterface.OnClickListener() {
                                public void onClick(android.content.DialogInterface d, int w) {
                                    openAutoStart(a);
                                }
                            })
                            .setNegativeButton("Позже", null)
                            .show();
                } catch (Throwable t) {
                    Log.w(TAG, "bg dialog failed", t);
                }
            }
        });
    }

    private static void openBatterySettings(Activity a) {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + a.getPackageName()));
            a.startActivity(i);
        } catch (Throwable t) {
            openAppDetails(a);
        }
    }

    /** Экраны «Автозапуск»/«Фоновая активность» Realme/OPPO/ColorOS (названия отличаются по версиям системы); если ни один не открылся — сведения о приложении. */
    private static void openAutoStart(Activity a) {
        String[][] targets = {
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
                {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerConsumptionActivity"},
                {"com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity"},
                {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
        };
        for (String[] t : targets) {
            try {
                Intent i = new Intent();
                i.setClassName(t[0], t[1]);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                a.startActivity(i);
                return;
            } catch (Throwable ignored) {
                // такого экрана в этой версии системы нет — пробуем следующий
            }
        }
        openAppDetails(a);
    }

    private static void openAppDetails(Activity a) {
        try {
            a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.getPackageName())));
        } catch (Throwable ignored) {
            // нет такого экрана настроек
        }
    }

    /** Страница может вызвать сама (кнопка в настройках): KExport.bgSettings() — показать подсказку про фоновую работу ещё раз. */
    @JavascriptInterface
    public void bgSettings() {
        showBgDialog();
    }

    /** Процесс отрисовки WebView не должен терять приоритет, когда приложение свёрнуто (иначе система его убивает и страница замирает). */
    void priorityPolicy() {
        try {
            if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        } catch (Throwable t) {
            Log.w(TAG, "priorityPolicy failed", t);
        }
    }

    /** Пока играет музыка, не даём оболочке «усыпить» WebView при сворачивании (onPause/pauseTimers): страница должна продолжать работать. */
    void keepAlive() {
        if (!mediaPlaying) return;
        Runnable r = new Runnable() {
            public void run() {
                try {
                    if (!mediaPlaying) return;
                    web.onResume();
                    web.resumeTimers();
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        };
        // оболочка вызывает onPause() уже после нашего колбэка — возобновляем сразу же и повторяем, пока она не успокоится
        web.post(r);
        web.postDelayed(r, 60);
        web.postDelayed(r, 250);
        web.postDelayed(r, 1200);
    }

    /** Новый трек для уведомления плеера: обложка - JPEG в base64 (может быть пустой строкой). */
    @JavascriptInterface
    public void mediaSet(String title, String artist, String album, double durationMs, String artB64) {
        try {
            media().set(title, artist, album, (long) durationMs, artB64);
            askBackgroundOnce();
        } catch (Throwable t) {
            Log.w(TAG, "mediaSet failed", t);
        }
    }

    /** Играет/пауза и позиция в мс. */
    @JavascriptInterface
    public void mediaState(boolean playing, double positionMs) {
        try {
            mediaPlaying = playing;
            media().state(playing, (long) positionMs);
            refreshBackGuard();
        } catch (Throwable t) {
            Log.w(TAG, "mediaState failed", t);
        }
    }

    /** Трек в избранном или нет: сердце в уведомлении. Страница шлёт при смене трека и при каждом переключении избранного. */
    @JavascriptInterface
    public void mediaFav(boolean fav) {
        try {
            media().fav(fav);
        } catch (Throwable t) {
            Log.w(TAG, "mediaFav failed", t);
        }
    }

    // ---------- нативное аудио (p0.28-naudio) ----------
    // Страница (LMusic) отдаёт файлы треков движку kx.engine.NativeAudio и управляет «деками»; воспроизведение, кросс-фейд и эффекты
    // считаются в процессе приложения (MediaCodec + AudioTrack), а не в процессе отрисовки WebView — нагрузка на телефон звук не рвёт.
    // События и состояние приходят обратно вызовом window.__kxA({...}).
    private NativeAudio na;

    private synchronized NativeAudio na() {
        return na;
    }

    /** Запускает движок. Возвращает {"ok":true,"rate":44100} или {"ok":false,"error":...}. */
    @JavascriptInterface
    public synchronized String naInit(int bufferMs) {
        try {
            if (na == null) {
                NativeAudio n = new NativeAudio(act, new NativeAudio.Host() {
                    @Override
                    public void js(final String code) {
                        // снимки позиции идут 2-10 раз в секунду: если страница заморожена системой, они копились бы в очереди.
                        // Пока предыдущий снимок не обработан, новые «играющие» снимки не шлём (раз в 3 с пропускаем один)
                        final boolean snap = code.startsWith("window.__kxA&&window.__kxA({s:[");
                        if (snap && code.contains(",1,1]")) {
                            long now = android.os.SystemClock.elapsedRealtime();
                            if (stateBusy.get() && now - stateSentAt < 3000L) return;
                        }
                        if (snap) {
                            stateBusy.set(true);
                            stateSentAt = android.os.SystemClock.elapsedRealtime();
                        }
                        uiH.post(new Runnable() {
                            public void run() {
                                try {
                                    if (snap) {
                                        web.evaluateJavascript(code, new ValueCallback<String>() {
                                            @Override
                                            public void onReceiveValue(String v) {
                                                stateBusy.set(false);
                                                jsAliveAt = android.os.SystemClock.elapsedRealtime();
                                            }
                                        });
                                    } else {
                                        web.evaluateJavascript(code, null);
                                    }
                                } catch (Throwable ignored) {
                                    // WebView уже уничтожен
                                }
                            }
                        });
                    }
                });
                n.start(bufferMs);
                n.setCastMute(castMuted);
                na = n;
                startSys();
            } else {
                na.setBufferMs(bufferMs);
            }
            return "{\"ok\":true,\"rate\":" + NativeAudio.OUT_RATE + "}";
        } catch (Throwable t) {
            Log.w(TAG, "naInit failed", t);
            return "{\"ok\":false,\"error\":\"" + String.valueOf(t.getMessage()).replace('"', ' ') + "\"}";
        }
    }

    @JavascriptInterface
    public boolean naHas(String key) {
        try {
            NativeAudio n = na();
            return n != null && n.has(key);
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean naPutBegin(String key) {
        try {
            NativeAudio n = na();
            return n != null && n.putBegin(key);
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean naPutChunk(String key, String b64) {
        try {
            NativeAudio n = na();
            return n != null && n.putChunk(key, b64);
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean naPutEnd(String key) {
        try {
            NativeAudio n = na();
            return n != null && n.putEnd(key);
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public void naLoad(int deck, String key, int tok) {
        try {
            NativeAudio n = na();
            if (n != null) n.load(deck, key, tok);
        } catch (Throwable t) {
            Log.w(TAG, "naLoad failed", t);
        }
    }

    /** Трек из медиатеки (id из listAudio) -> кэш движка на нативной стороне. Результат — событие {e:'put'} в window.__kxA. */
    @JavascriptInterface
    public boolean naPutDev(String key, String id) {
        try {
            NativeAudio n = na();
            if (n == null || !audioGranted()) return false;
            n.putDevAsync(key, Long.parseLong(id));
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public void naUnload(int deck) {
        try {
            NativeAudio n = na();
            if (n != null) n.unload(deck);
        } catch (Throwable t) {
            Log.w(TAG, "naUnload failed", t);
        }
    }

    @JavascriptInterface
    public void naPlay(int deck) {
        try {
            NativeAudio n = na();
            if (n != null) n.play(deck);
        } catch (Throwable t) {
            Log.w(TAG, "naPlay failed", t);
        }
    }

    @JavascriptInterface
    public void naPause(int deck) {
        try {
            NativeAudio n = na();
            if (n != null) n.pause(deck);
        } catch (Throwable t) {
            Log.w(TAG, "naPause failed", t);
        }
    }

    @JavascriptInterface
    public void naSeek(int deck, double sec) {
        try {
            NativeAudio n = na();
            if (n != null) n.seek(deck, sec);
        } catch (Throwable t) {
            Log.w(TAG, "naSeek failed", t);
        }
    }

    @JavascriptInterface
    public void naTempoTone(double tempo, double semitones) {
        try {
            NativeAudio n = na();
            if (n != null) n.tempoTone(tempo, semitones);
        } catch (Throwable t) {
            Log.w(TAG, "naTempoTone failed", t);
        }
    }

    @JavascriptInterface
    public void naRate(int deck, double rate) {
        try {
            NativeAudio n = na();
            if (n != null) n.rate(deck, rate);
        } catch (Throwable t) {
            Log.w(TAG, "naRate failed", t);
        }
    }

    /** Автоматизация громкости дека: which 0 — gain, 1 — vol; op 0 cancel, 1 set, 2 linear, 3 curve, 4 hold, 5 target; offset — секунды от «сейчас». */
    @JavascriptInterface
    public void naParam(int deck, int which, int op, double offset, double v, double extra, String curve) {
        try {
            NativeAudio n = na();
            if (n != null) n.param(deck, which, op, offset, v, extra, curve);
        } catch (Throwable t) {
            Log.w(TAG, "naParam failed", t);
        }
    }

    @JavascriptInterface
    public void naFx(String csv) {
        try {
            NativeAudio n = na();
            if (n != null) n.fx(csv);
        } catch (Throwable t) {
            Log.w(TAG, "naFx failed", t);
        }
    }

    @JavascriptInterface
    public void naVisible(boolean v) {
        try {
            NativeAudio n = na();
            if (n != null) n.setVisible(v);
        } catch (Throwable t) {
            Log.w(TAG, "naVisible failed", t);
        }
    }

    @JavascriptInterface
    public void naBuffer(int ms) {
        try {
            NativeAudio n = na();
            if (n != null) n.setBufferMs(ms);
        } catch (Throwable t) {
            Log.w(TAG, "naBuffer failed", t);
        }
    }

    /** Масштабирование двумя пальцами: по умолчанию выключено (настройка «Внешний вид → Анимации и жесты»). */
    @JavascriptInterface
    public String setPinchZoom(final boolean on) {
        uiH.post(new Runnable() {
            public void run() {
                try {
                    android.webkit.WebSettings ws = web.getSettings();
                    ws.setSupportZoom(on);
                    ws.setBuiltInZoomControls(on);
                    ws.setDisplayZoomControls(false);
                    if (!on) {
                        // масштаб выключен: возвращаем уже накопленный pinch-zoom к 100%
                        web.postDelayed(new Runnable() {
                            public void run() {
                                try { web.zoomBy(0.01f); } catch (Throwable ignored) { /* не поддерживается */ }
                            }
                        }, 150);
                    }
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        });
        return OK;
    }

    // ---------- автопауза и трансляция на устройства поблизости (p0.30-cast) ----------
    // SysWatch сообщает странице о звонке, записи видео/звука и отключении наушников/Bluetooth (window.__kxSys(вид, вкл)); решает страница
    // по настройкам «Автопауза». Если страница заморожена системой и не ответила, пауза выполняется здесь, нативным движком.
    // Cast ищет DLNA/UPnP-устройства (телевизоры, колонки) и воспроизводит на них трек; состояние уходит в window.__kxCast({...}).
    private Cast cast;
    private Near near;
    private SysWatch sys;
    private volatile boolean castMuted;
    private volatile boolean cfgCall = true, cfgVideo = true, cfgRec = true, cfgOut = true, cfgResume = true;
    private volatile String nativePausedBy = "";

    private synchronized Cast cast() {
        if (cast == null) {
            cast = new Cast(act, new Cast.Sink() {
                @Override
                public void js(final String code) {
                    uiH.post(new Runnable() {
                        public void run() {
                            try {
                                web.evaluateJavascript(code, null);
                            } catch (Throwable ignored) {
                                // WebView уже уничтожен
                            }
                        }
                    });
                }

                @Override
                public void mute(boolean m) {
                    castMuted = m;
                    NativeAudio n = na();
                    if (n != null) n.setCastMute(m);
                }

                @Override
                public java.io.File fileFor(String key) {
                    NativeAudio n = na();
                    return n == null ? null : n.fileForKey(key);
                }
            });
        }
        return cast;
    }

    private boolean castActive() {
        Cast c;
        synchronized (this) { c = cast; }
        return c != null && c.active();
    }

    private synchronized void startSys() {
        if (sys != null) return;
        sys = new SysWatch(act, new SysWatch.Sink() {
            @Override
            public void event(String kind, boolean on) {
                sysEvent(kind, on);
            }
        });
        sys.start();
    }

    private void sysEvent(final String kind, final boolean on) {
        final String js = "window.__kxSys&&window.__kxSys('" + kind + "'," + on + ")";
        final AtomicBoolean acked = new AtomicBoolean(false);
        uiH.post(new Runnable() {
            public void run() {
                try {
                    web.onResume();
                    web.resumeTimers();
                    web.evaluateJavascript(js, new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String v) {
                            acked.set(true);
                            jsAliveAt = android.os.SystemClock.elapsedRealtime();
                        }
                    });
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        });
        uiH.postDelayed(new Runnable() {
            public void run() {
                if (!acked.get()) nativeSysFallback(kind, on);
            }
        }, 700L);
    }

    /** Страница не ответила: пауза/возобновление по событию системы выполняются нативным движком. */
    private void nativeSysFallback(String kind, boolean on) {
        try {
            if ("route".equals(kind)) return;
            if (castActive()) return;
            boolean isOut = "out".equals(kind);
            boolean pauseEvt = isOut ? !on : on; // звонок/запись началась или наушники отключились
            boolean enabled = "call".equals(kind) ? cfgCall : "rec".equals(kind) ? cfgRec : cfgOut;
            if (pauseEvt) {
                if (enabled && enginePlaying()) {
                    nativePausedBy = kind;
                    nativeTransport("pause", 0L);
                }
            } else if (!isOut && cfgResume && kind.equals(nativePausedBy)) {
                nativePausedBy = "";
                nativeTransport("play", 0L);
            }
        } catch (Throwable t) {
            Log.w(TAG, "sys fallback failed", t);
        }
    }

    /** Настройки автопаузы из страницы: {"call":true,"video":true,"rec":true,"out":true,"resume":true}. */
    @JavascriptInterface
    public String sysCfg(String json) {
        try {
            JSONObject o = new JSONObject(json);
            cfgCall = o.optBoolean("call", true);
            cfgVideo = o.optBoolean("video", true);
            cfgRec = o.optBoolean("rec", true);
            cfgOut = o.optBoolean("out", true);
            cfgResume = o.optBoolean("resume", true);
            startSys();
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    /** Текущий выход звука (динамик, проводные наушники, Bluetooth): {"id","name","type"}. Для профилей эквалайзера по устройствам. */
    @JavascriptInterface
    public String audioRoute() {
        return SysWatch.currentOutput(act);
    }

    /** Идёт ли сейчас звонок / запись (для первичной синхронизации страницы). */
    @JavascriptInterface
    public String sysInfo() {
        SysWatch w;
        synchronized (this) { w = sys; }
        return "{\"ok\":true,\"call\":" + (w != null && w.callActive()) + ",\"rec\":" + (w != null && w.recActive()) + "}";
    }

    private synchronized Near near() {
        if (near == null) {
            near = new Near(act, new Near.Sink() {
                @Override
                public void js(final String code) {
                    uiH.post(new Runnable() {
                        public void run() {
                            try {
                                web.evaluateJavascript(code, null);
                            } catch (Throwable ignored) {
                                // WebView уже уничтожен
                            }
                        }
                    });
                }
            });
        }
        return near;
    }

    /** Bluetooth-устройства и системные маршруты поблизости (для экрана «Трансляция»). */
    @JavascriptInterface
    public String nearList() {
        try {
            return near().json();
        } catch (Throwable t) {
            return err(t);
        }
    }

    /** Сопряжение с найденным Bluetooth-устройством. */
    @JavascriptInterface
    public String nearPair(String addr) {
        try {
            near().pair(addr);
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public String castScan(boolean on) {
        try {
            if (on) {
                cast().scanStart();
                near().start();
            } else {
                Cast c;
                Near nr;
                synchronized (this) { c = cast; nr = near; }
                if (c != null) c.scanStop();
                if (nr != null) nr.stop();
            }
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public String castList() {
        try {
            return cast().stateJson();
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public String castSelect(String id) {
        try {
            cast().select(id);
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public void castArt(String b64) {
        try {
            cast().art(b64);
        } catch (Throwable t) {
            Log.w(TAG, "castArt failed", t);
        }
    }

    @JavascriptInterface
    public void castLoad(String key, String title, String artist, String album, double durSec, double startSec, boolean play) {
        try {
            cast().load(key, title, artist, album, durSec, startSec, play);
        } catch (Throwable t) {
            Log.w(TAG, "castLoad failed", t);
        }
    }

    @JavascriptInterface
    public void castTransport(String cmd, double posSec) {
        try {
            Cast c;
            synchronized (this) { c = cast; }
            if (c != null) c.transport(cmd, posSec);
        } catch (Throwable t) {
            Log.w(TAG, "castTransport failed", t);
        }
    }

    @JavascriptInterface
    public void castTick(double posSec) {
        Cast c;
        synchronized (this) { c = cast; }
        if (c != null) c.tick(posSec);
    }

    @JavascriptInterface
    public void castVolume(int v) {
        try {
            Cast c;
            synchronized (this) { c = cast; }
            if (c != null) c.volume(v);
        } catch (Throwable t) {
            Log.w(TAG, "castVolume failed", t);
        }
    }

    private void startFirst(final String[] actions, final String[][] extras, final String failMsg) {
        uiH.post(new Runnable() {
            public void run() {
                Activity a = act;
                for (int i = 0; i < actions.length; i++) {
                    try {
                        Intent it = new Intent(actions[i]);
                        if (extras != null && extras[i] != null) {
                            for (int k = 0; k + 1 < extras[i].length; k += 2) it.putExtra(extras[i][k], extras[i][k + 1]);
                        }
                        a.startActivity(it);
                        return;
                    } catch (Throwable ignored) {
                        // пробуем следующий вариант
                    }
                }
                try {
                    web.evaluateJavascript("window.__kxCast&&window.__kxCast({\"e\":\"toast\",\"m\":" + Cast.q(failMsg) + "})", null);
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        });
    }

    /** Системная панель выбора вывода звука (Bluetooth, Cast и другие устройства поблизости). */
    @JavascriptInterface
    public String openSystemOutput() {
        startFirst(new String[] { "com.android.settings.panel.action.MEDIA_OUTPUT", "android.settings.panel.action.VOLUME",
                        Settings.ACTION_BLUETOOTH_SETTINGS },
                new String[][] { { "com.android.settings.panel.extra.PACKAGE_NAME", act.getPackageName() }, null, null },
                "На этом устройстве нет системной панели вывода звука");
        return OK;
    }

    /** Системный экран «Дублирование экрана» (Miracast / Wi-Fi Display / Smart View) для телевизоров и мониторов. */
    @JavascriptInterface
    public String openCastSettings() {
        startFirst(new String[] { Settings.ACTION_CAST_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS },
                null, "На этом устройстве нет экрана дублирования");
        return OK;
    }

    /** Экран «О приложении» в системных настройках: чтобы выдать разрешение «Устройства поблизости», если оно было отклонено. */
    @JavascriptInterface
    public String openAppSettings() {
        uiH.post(new Runnable() {
            public void run() {
                try {
                    act.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + act.getPackageName())));
                } catch (Throwable ignored) {
                    // нет экрана настроек
                }
            }
        });
        return OK;
    }

    @JavascriptInterface
    public String openBluetoothSettings() {
        startFirst(new String[] { Settings.ACTION_BLUETOOTH_SETTINGS }, null, "Не удалось открыть настройки Bluetooth");
        return OK;
    }

    // ---------- выход из приложения во время воспроизведения (p0.25-notif) ----------
    // 1) «назад» при играющей музыке сворачивает приложение (moveTaskToBack) — страница, музыка и уведомление живут дальше;
    //    Android 13+ (в манифесте включён OnBackInvokedCallback): обработчик OnBackInvokedDispatcher, пока музыка играет;
    //    Android 7-12: перехват KEYCODE_BACK в Window.Callback.
    // 2) если Activity всё же уничтожена при играющей музыке (смахивание из «недавних»), Boot оставляет этот мост жить:
    //    сервис и уведомление не снимаются, страница продолжает играть в отсоединённом WebView.
    // 3) ✕ в уведомлении (closeApp) закрывает всё: пауза и сохранение в странице, снятие уведомления и сервиса, закрытие задачи, завершение процесса.
    private final android.os.Handler uiH = new android.os.Handler(android.os.Looper.getMainLooper());
    private volatile boolean closing;
    private Object backCb;
    private boolean backCbOn;

    /** Activity уничтожена, мост живёт дальше (страница в фоне). */
    private volatile boolean detached;
    /** Прежняя страница играла, когда запускалась новая: новая должна продолжить воспроизведение сама. */
    private static volatile long resumeAt;

    /** Страница при старте спрашивает: продолжить ли воспроизведение, прерванное закрытием вкладки (один раз, не дольше 30 с). */
    @JavascriptInterface
    public boolean takeResume() {
        long t = resumeAt;
        resumeAt = 0L;
        return t != 0L && android.os.SystemClock.elapsedRealtime() - t < 30000L;
    }

    /** Процесс отрисовки (страница) убит системой: JS больше не работает, но нативный движок и уведомление ещё живы. */
    volatile boolean dead;
    /** Позиция (сек) и время гибели страницы, пока играла музыка: новая страница продолжит с этого места сама. */
    private static volatile long crashAt;
    private static volatile double crashPos = -1;

    boolean enginePlaying() {
        NativeAudio n;
        synchronized (this) { n = na; }
        return n != null && n.nativeIsPlaying();
    }

    /** Запоминает, что страница погибла во время воспроизведения (вызывать до shutdown()). */
    void markCrash() {
        try {
            NativeAudio n;
            synchronized (this) { n = na; }
            if (!(mediaPlaying || (n != null && n.nativeIsPlaying()))) return;
            crashPos = n != null ? n.nativePosSec() : -1;
            crashAt = android.os.SystemClock.elapsedRealtime();
        } catch (Throwable t) {
            Log.w(TAG, "markCrash failed", t);
        }
    }

    /** Новая страница спрашивает: не оборвалась ли музыка из-за гибели прежней страницы. -1 — нет, -2 — да, позиция неизвестна, иначе позиция в секундах. */
    @JavascriptInterface
    public double takeCrashResume() {
        long t = crashAt;
        double p = crashPos;
        crashAt = 0L;
        crashPos = -1;
        if (t == 0L || android.os.SystemClock.elapsedRealtime() - t > 180000L) return -1;
        return p >= 0 ? p : -2;
    }

    boolean outlivesActivity(Activity a) {
        if (dead) return false;
        try {
            // пережить закрытие вкладки должен и трек на паузе: иначе уведомление исчезает и им нельзя управлять, не заходя в приложение
          return !closing && !a.isChangingConfigurations() && (mediaPlaying || (media != null && media.active()));
        } catch (Throwable t) {
            return false;
        }
    }

    /** Activity уничтожена, а музыка играет: не даём WebView уснуть (view.post у отсоединённого WebView не сработает — идём через свой Handler). */
    void keepAliveDetached() {
        detached = true;
        final Runnable r = new Runnable() {
            public void run() {
                try {
                    if (!mediaPlaying) return;
                    web.onResume();
                    web.resumeTimers();
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
            }
        };
        r.run();
        uiH.postDelayed(r, 120);
        uiH.postDelayed(r, 600);
        uiH.postDelayed(r, 2000);
    }

    /** Запущена новая Activity, а страница прежней ещё играет в фоне: останавливаем и сохраняем её, снимаем её уведомление — новая страница создаст своё. */
    void retire() {
        if (dead) markCrash(); // страница мертва: JS уже не сохранит позицию, запоминаем её здесь
        final boolean was = mediaPlaying;
        if (was) resumeAt = android.os.SystemClock.elapsedRealtime();
        mediaPlaying = false;
        closing = true;
        try {
            web.evaluateJavascript("window.__kxMedia&&window.__kxMedia('" + (was ? "retire" : "close") + "',0)", null);
        } catch (Throwable ignored) {
            // WebView уже уничтожен
        }
        shutdown();
        uiH.postDelayed(new Runnable() {
            public void run() {
                try {
                    web.destroy();
                } catch (Throwable ignored) {
                    // уже уничтожен
                }
            }
        }, 500);
    }

    /** ✕ в уведомлении: закрыть приложение целиком. */
    void closeApp() {
        closing = true;
        mediaPlaying = false;
        uiH.post(new Runnable() {
            public void run() {
                try {
                    web.evaluateJavascript("window.__kxMedia&&window.__kxMedia('close',0)", null); // пауза + сохранение позиции
                } catch (Throwable ignored) {
                    // WebView уже уничтожен
                }
                uiH.postDelayed(new Runnable() {
                    public void run() {
                        try {
                            shutdown();
                        } catch (Throwable ignored) {
                            // ресурсы уже освобождены
                        }
                        Boot.forgetSurvivor();
                        try {
                            act.finishAndRemoveTask();
                        } catch (Throwable t) {
                            try {
                                act.finishAffinity();
                            } catch (Throwable ignored) {
                                // Activity уже закрыта
                            }
                        }
                        uiH.postDelayed(new Runnable() {
                            public void run() {
                                android.os.Process.killProcess(android.os.Process.myPid());
                            }
                        }, 300);
                    }
                }, 250);
            }
        });
    }

    /** Страница сама закрывает верхний слой (окно, меню, плейлисты…): если закрывать нечего — выполняем fallback (свернуть приложение). */
    private void pageBackThen(final Runnable ifUnhandled) {
        final boolean[] done = { false };
        final Runnable fallback = new Runnable() {
            public void run() {
                if (done[0]) return;
                done[0] = true;
                try {
                    ifUnhandled.run();
                } catch (Throwable ignored) {
                    // Activity уже закрыта
                }
            }
        };
        try {
            web.evaluateJavascript("(function(){try{return window.__lmBackStep&&window.__lmBackStep()?'1':'0'}catch(e){return '0'}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        if (done[0]) return;
                        uiH.removeCallbacks(fallback);
                        if (v != null && v.contains("1")) { done[0] = true; return; }
                        fallback.run();
                    }
                });
            uiH.postDelayed(fallback, 800);
        } catch (Throwable t) {
            fallback.run();
        }
    }

    private void minimize() {
        try {
            act.moveTaskToBack(true);
        } catch (Throwable t) {
            Log.w(TAG, "moveTaskToBack failed", t);
        }
    }

    /** «Назад» при играющей музыке: true — событие поглощено (страница закрывает слой или приложение сворачивается). */
    private boolean backToBackground(boolean doIt) {
        if (!mediaPlaying || closing) return false;
        if (doIt) pageBackThen(new Runnable() { public void run() { minimize(); } });
        return true;
    }

    /** Android 7-12: перехват кнопки «назад» в Window.Callback (на 13+ «назад» приходит иначе — см. refreshBackGuard). Вызывается один раз при подключении моста. */
    void backGuard() {
        try {
            if (Build.VERSION.SDK_INT >= 33) return;
            final android.view.Window w = act.getWindow();
            final android.view.Window.Callback orig = w.getCallback();
            if (orig == null) return;
            w.setCallback((android.view.Window.Callback) java.lang.reflect.Proxy.newProxyInstance(
                    KxBridge.class.getClassLoader(), new Class<?>[] { android.view.Window.Callback.class },
                    new java.lang.reflect.InvocationHandler() {
                        public Object invoke(Object proxy, java.lang.reflect.Method m, Object[] args) throws Throwable {
                            try {
                                if (args != null && args.length == 1 && "dispatchKeyEvent".equals(m.getName())) {
                                    android.view.KeyEvent e = (android.view.KeyEvent) args[0];
                                    if (e.getKeyCode() == android.view.KeyEvent.KEYCODE_BACK
                                            && backToBackground(e.getAction() == android.view.KeyEvent.ACTION_UP && !e.isCanceled())) {
                                        return Boolean.TRUE;
                                    }
                                }
                                return m.invoke(orig, args);
                            } catch (java.lang.reflect.InvocationTargetException ite) {
                                throw ite.getCause() != null ? ite.getCause() : ite;
                            }
                        }
                    }));
        } catch (Throwable t) {
            Log.w(TAG, "backGuard failed", t);
        }
    }

    /** Android 13+: пока музыка играет, держим свой обработчик «назад» поверх обработчика оболочки; на паузе снимаем — «назад» работает как раньше. */
    void refreshBackGuard() {
        uiH.post(new Runnable() {
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT < 33) return;
                    android.window.OnBackInvokedDispatcher d = act.getOnBackInvokedDispatcher();
                    boolean want = mediaPlaying && !closing;
                    if (want && !backCbOn) {
                        android.window.OnBackInvokedCallback cb = new android.window.OnBackInvokedCallback() {
                            public void onBackInvoked() {
                                pageBackThen(new Runnable() { public void run() { minimize(); } });
                            }
                        };
                        d.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_OVERLAY, cb);
                        backCb = cb;
                        backCbOn = true;
                    } else if (!want && backCbOn) {
                        d.unregisterOnBackInvokedCallback((android.window.OnBackInvokedCallback) backCb);
                        backCb = null;
                        backCbOn = false;
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "refreshBackGuard failed", t);
                }
            }
        });
    }

    /** Убрать уведомление плеера. */
    @JavascriptInterface
    public void mediaClear() {
        try {
            mediaPlaying = false;
            mediaQueueClear();
            media().clear();
            refreshBackGuard();
        } catch (Throwable t) {
            Log.w(TAG, "mediaClear failed", t);
        }
    }

    void shutdown() {
        try {
            if (sys != null) {
                sys.stop();
                sys = null;
            }
            Cast c;
            Near nr;
            synchronized (this) { c = cast; cast = null; nr = near; near = null; }
            if (nr != null) nr.stop();
            if (c != null) c.shutdown();
            castMuted = false;
        } catch (Throwable t) {
            Log.w(TAG, "cast/sys shutdown failed", t);
        }
        if (media != null) media.release();
        if (na != null) {
            try {
                na.release();
            } catch (Throwable ignored) {
                // уже освобождён
            }
            na = null;
        }
        for (Exporter e : jobs.values()) e.cancel();
        synchronized (this) {
            for (RandomAccessFile r : open.values()) {
                try {
                    r.close();
                } catch (Throwable ignored) {
                    // уже закрыт
                }
            }
            open.clear();
        }
    }

    // ---------- методы для JS ----------

    @JavascriptInterface
    public String ping() {
        return "pong";
    }

    @JavascriptInterface
    public String caps() {
        try {
            JSONObject o = Probe.caps();
            o.put("zeroCopy", hooked);
            o.put("allFilesAccess", hasAllFilesAccessInternal());
            return o.toString();
        } catch (Throwable t) {
            return err(t);
        }
    }

    // ---------- доступ ко всей файловой системе устройства (чтение) ----------
    // API 30+: разрешение MANAGE_EXTERNAL_STORAGE (запрашивается через системный экран настроек,
    // пользователь выдаёт его вручную — обычный runtime-диалог для него недоступен).
    // API <30: обычное разрешение READ_EXTERNAL_STORAGE, запрашивается стандартным runtime-диалогом.
    // В любом случае в AndroidManifest.xml должно быть объявлено соответствующее <uses-permission>
    // (это правит сам сборщик, пункт «Разрешения»; это разрешение в нём нужно завести отдельно).

    private boolean hasAllFilesAccessInternal() {
        try {
            if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
            return act.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Есть ли уже разрешение на чтение всей файловой системы. */
    @JavascriptInterface
    public String hasAllFilesAccess() {
        return "{\"ok\":true,\"granted\":" + hasAllFilesAccessInternal() + "}";
    }

    /** Запрашивает разрешение: на API 30+ открывает системный экран «Доступ ко всем файлам» для этого
     *  приложения, на более старых — обычный runtime-запрос READ/WRITE_EXTERNAL_STORAGE. Результат
     *  асинхронный — страница должна опросить hasAllFilesAccess() после возврата в приложение
     *  (например, в обработчике возобновления/видимости страницы). */
    @JavascriptInterface
    public String requestAllFilesAccess() {
        try {
            act.runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if (Build.VERSION.SDK_INT >= 30) {
                            try {
                                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                                i.setData(Uri.parse("package:" + act.getPackageName()));
                                act.startActivity(i);
                            } catch (Throwable t) {
                                act.startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                            }
                        } else {
                            act.requestPermissions(new String[] {
                                "android.permission.READ_EXTERNAL_STORAGE",
                                "android.permission.WRITE_EXTERNAL_STORAGE"
                            }, 7421);
                        }
                    } catch (Throwable t) {
                        Log.w(TAG, "requestAllFilesAccess failed", t);
                    }
                }
            });
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    /** Список записей в директории (абсолютный путь, например из Environment.getExternalStorageDirectory()
     *  или произвольного /storage/... при выданном MANAGE_EXTERNAL_STORAGE). Непрочитанные элементы
     *  (нет доступа, спецфайлы) молча пропускаются, а не валят весь список. */
    @JavascriptInterface
    public String listDir(String path) {
        try {
            if (!hasAllFilesAccessInternal()) return err("no_permission");
            if (path == null || path.length() == 0) return err("bad_path");
            File dirF = new File(path);
            if (!dirF.isAbsolute()) return err("bad_path");
            File[] kids = dirF.listFiles();
            if (kids == null) return err("not_readable");
            JSONArray arr = new JSONArray();
            for (File f : kids) {
                JSONObject e = new JSONObject();
                e.put("name", f.getName());
                e.put("path", f.getAbsolutePath());
                e.put("dir", f.isDirectory());
                e.put("size", f.isFile() ? f.length() : 0);
                e.put("mtime", f.lastModified());
                arr.put(e);
            }
            return o("ok", true, "entries", arr).toString();
        } catch (Throwable t) {
            return err(t);
        }
    }

    private static final long FS_READ_CHUNK = 2L << 20; // 2 МБ за вызов — безопасно для JS-моста

    /** Читает кусок произвольного файла как base64, начиная с offset. eof=true, когда дочитали до конца. */
    @JavascriptInterface
    public String readFileChunk(String path, long offset) {
        RandomAccessFile raf = null;
        try {
            if (!hasAllFilesAccessInternal()) return err("no_permission");
            if (path == null || path.length() == 0) return err("bad_path");
            File f = new File(path);
            if (!f.isAbsolute() || !f.isFile()) return err("bad_path");
            raf = new RandomAccessFile(f, "r");
            long total = raf.length();
            if (offset < 0 || offset > total) return err("bad_offset");
            long want = Math.min(FS_READ_CHUNK, total - offset);
            byte[] buf = new byte[(int) want];
            raf.seek(offset);
            raf.readFully(buf);
            String b64 = Base64.encodeToString(buf, Base64.NO_WRAP);
            boolean eof = offset + want >= total;
            return o("ok", true, "data", b64, "size", total, "eof", eof).toString();
        } catch (Throwable t) {
            return err(t);
        } finally {
            if (raf != null) {
                try { raf.close(); } catch (Throwable ignored) { /* уже закрыт */ }
            }
        }
    }

    @JavascriptInterface
    public synchronized String ingestBegin(String id, String name, long size, long lastModified, String mime) {
        try {
            if (!validId(id) || size <= 0) return err("bad_args");
            File bin = new File(dir, id + ".bin");
            File ok = new File(dir, id + ".ok");
            RandomAccessFile prev = open.remove(id);
            if (prev != null) prev.close();
            if (ok.exists() && bin.length() == size) {
                bin.setLastModified(System.currentTimeMillis());
                return "{\"ok\":true,\"cached\":true}";
            }
            ok.delete();
            bin.delete();
            long need = size + (64L << 20);
            if (free() < need) trimCache(need);
            if (free() < need) return err("no_space");
            open.put(id, new RandomAccessFile(bin, "rw"));
            sizes.put(id, size);
            return "{\"ok\":true,\"cached\":false}";
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public synchronized String ingestChunk(String id, long offset, String b64) {
        try {
            RandomAccessFile raf = open.get(id);
            if (raf == null) return err("not_open");
            byte[] b = Base64.decode(b64, Base64.DEFAULT);
            raf.seek(offset);
            raf.write(b);
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public synchronized String ingestEnd(String id) {
        try {
            RandomAccessFile raf = open.remove(id);
            if (raf == null) return err("not_open");
            raf.close();
            File bin = new File(dir, id + ".bin");
            Long want = sizes.remove(id);
            if (want == null || bin.length() != want.longValue()) {
                bin.delete();
                return err("size_mismatch");
            }
            new File(dir, id + ".ok").createNewFile();
            // info не считаем: фоновая передача не должна в конце замораживать страницу разбором файла;
            // экспорт при необходимости вызовет probe(id)
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    /** Дешёвая проверка: есть ли источник уже в нативном кэше (без разбора файла и без передачи байтов). */
    @JavascriptInterface
    public String has(String id) {
        try {
            boolean c = false;
            if (validId(id)) {
                File f = fileFor(id);
                if (f != null) {
                    f.setLastModified(System.currentTimeMillis());
                    c = true;
                } else {
                    c = uriSrc.get(id) != null;
                }
            }
            return "{\"ok\":true,\"cached\":" + c + "}";
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public String probe(String id) {
        try {
            Src s = srcFor(id);
            if (s == null) return err("unknown_id");
            return infoJson(s);
        } catch (Throwable t) {
            return err(t);
        }
    }

    private String infoJson(Src s) throws Exception {
        JSONObject r = o("ok", true);
        try {
            r.put("info", Probe.info(act, s));
        } catch (Throwable t) {
            // не медиафайл (например, картинка) - это не ошибка передачи
            r.put("info", JSONObject.NULL);
            r.put("probeError", String.valueOf(t));
        }
        return r.toString();
    }

    /** Находит среди выбранных пользователем файлов тот, что соответствует File из страницы (по имени и размеру). */
    @JavascriptInterface
    public synchronized String resolve(String name, long size, long lastModified) {
        try {
            Picked hit = null;
            for (int i = picked.size() - 1; i >= 0; i--) {
                Picked p = picked.get(i);
                if (p.size == size && name != null && name.equals(p.name)) {
                    hit = p;
                    break;
                }
            }
            if (hit == null) return o("ok", false, "error", "not_picked", "picked", picked.size(), "hook", hooked).toString();
            try {
                AssetFileDescriptor afd = act.getContentResolver().openAssetFileDescriptor(hit.uri, "r");
                if (afd == null) return err("unreadable");
                afd.close();
            } catch (Throwable t) {
                return o("ok", false, "error", "unreadable", "detail", String.valueOf(t)).toString();
            }
            String id = "u" + sha1(hit.uri.toString());
            uriSrc.put(id, hit.uri);
            // Разбор контейнера здесь не нужен: редактор info не использует, а вызов синхронный (JS-поток
            // стоит, пока идёт демукс) — страница замирала на сотни мс при каждом импорте. Экспорт сам
            // спросит probe(id), если info пустой.
            JSONObject r = o("ok", true, "id", id, "zeroCopy", true);
            r.put("info", JSONObject.NULL);
            return r.toString();
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public synchronized String clearCache() {
        File[] fs = dir.listFiles();
        int n = 0;
        if (fs != null) {
            for (File f : fs) {
                if (f.delete()) n++;
            }
        }
        return o("ok", true, "deleted", n).toString();
    }

    @JavascriptInterface
    public String exportStart(String jobJson) {
        try {
            if (Build.VERSION.SDK_INT < 29) return unsupported("api<29");
            if (!jobs.isEmpty()) return err("busy");
            Exporter e = Exporter.parse(this, "j" + seq.incrementAndGet(), new JSONObject(jobJson));
            if (!e.unsupported.isEmpty()) return unsupported(e.unsupported.toArray(new String[0]));
            jobs.put(e.jobId, e);
            e.start();
            return o("ok", true, "jobId", e.jobId).toString();
        } catch (Throwable t) {
            return err(t);
        }
    }

    private static String unsupported(String... items) {
        return o("ok", false, "unsupported", new JSONArray(Arrays.asList(items))).toString();
    }

    @JavascriptInterface
    public String exportCancel(String jobId) {
        Exporter e = jobs.get(jobId);
        if (e != null) e.cancel();
        return OK;
    }

    // ---------- «Поделиться» файлом из страницы (например, трек Lmusic) ----------
    // Страница передаёт байты кусками (как ingest*), мост собирает файл во временном кэше,
    // публикует его через MediaStore (API 29+: content:// без каких-либо разрешений и без FileProvider в манифесте)
    // и открывает системный список приложений (ACTION_SEND + chooser). Прежние копии, созданные этим методом,
    // удаляются при следующей отправке (папка Music/LMusic), поэтому место не копится.
    private final HashMap<String, RandomAccessFile> shareOpen = new HashMap<String, RandomAccessFile>();
    private final HashMap<String, String[]> shareMeta = new HashMap<String, String[]>();
    private final HashMap<String, Long> shareSize = new HashMap<String, Long>();

    private static String safeFileName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (n.length() > 120) {
            int dot = n.lastIndexOf('.');
            String ext = (dot > 0 && n.length() - dot <= 8) ? n.substring(dot) : "";
            n = n.substring(0, 120 - ext.length()) + ext;
        }
        return n.length() == 0 ? "track" : n;
    }

    private static String guessAudioMime(String name, String mime) {
        if (mime != null && mime.startsWith("audio/") && !mime.contains("*")) return mime;
        String n = name == null ? "" : name.toLowerCase(java.util.Locale.ROOT);
        if (n.endsWith(".m4a") || n.endsWith(".mp4")) return "audio/mp4";
        if (n.endsWith(".aac")) return "audio/aac";
        if (n.endsWith(".wav")) return "audio/wav";
        if (n.endsWith(".flac")) return "audio/flac";
        if (n.endsWith(".ogg") || n.endsWith(".opus") || n.endsWith(".oga")) return "audio/ogg";
        if (n.endsWith(".amr")) return "audio/amr";
        return "audio/mpeg";
    }

    private static String extForMime(String mime) {
        if ("audio/mp4".equals(mime)) return ".m4a";
        if ("audio/aac".equals(mime)) return ".aac";
        if ("audio/wav".equals(mime)) return ".wav";
        if ("audio/flac".equals(mime)) return ".flac";
        if ("audio/ogg".equals(mime)) return ".ogg";
        if ("audio/amr".equals(mime)) return ".amr";
        return ".mp3";
    }

    @JavascriptInterface
    public String canShareFile() {
        return OK;
    }

    @JavascriptInterface
    public synchronized String shareFileBegin(String id, String name, String mime, long size) {
        try {
            if (!validId(id) || size <= 0) return err("bad_args");
            RandomAccessFile prev = shareOpen.remove(id);
            if (prev != null) prev.close();
            File tmp = new File(dir, "share_" + id + ".tmp");
            tmp.delete();
            long need = size + (32L << 20);
            if (free() < need) trimCache(need);
            if (free() < need) return err("no_space");
            String fixedMime = guessAudioMime(name, mime);
            String fixedName = safeFileName(name);
            if (fixedName.indexOf('.') < 0) fixedName = fixedName + extForMime(fixedMime);
            shareOpen.put(id, new RandomAccessFile(tmp, "rw"));
            shareMeta.put(id, new String[] { fixedName, fixedMime });
            shareSize.put(id, size);
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public synchronized String shareFileChunk(String id, long offset, String b64) {
        try {
            RandomAccessFile raf = shareOpen.get(id);
            if (raf == null) return err("not_open");
            byte[] b = Base64.decode(b64, Base64.DEFAULT);
            raf.seek(offset);
            raf.write(b);
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    @JavascriptInterface
    public synchronized String shareFileEnd(String id, final String title) {
        File tmp = new File(dir, "share_" + id + ".tmp");
        try {
            RandomAccessFile raf = shareOpen.remove(id);
            if (raf == null) return err("not_open");
            raf.close();
            Long want = shareSize.remove(id);
            String[] m = shareMeta.remove(id);
            if (want == null || m == null || tmp.length() != want.longValue()) return err("size_mismatch");
            final String mime = m[1];
            final Uri u = publishShared(tmp, m[0], mime);
            if (u == null) return err("publish_failed");
            act.runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType(mime);
                        i.putExtra(Intent.EXTRA_STREAM, u);
                        if (title != null && title.length() > 0) {
                            i.putExtra(Intent.EXTRA_SUBJECT, title);
                            i.putExtra(Intent.EXTRA_TITLE, title);
                        }
                        i.setClipData(android.content.ClipData.newRawUri("", u));
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        Intent ch = Intent.createChooser(i, title == null || title.length() == 0 ? null : title);
                        ch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        act.startActivity(ch);
                    } catch (Throwable t) {
                        Log.w(TAG, "share chooser failed", t);
                    }
                }
            });
            return OK;
        } catch (Throwable t) {
            return err(t);
        } finally {
            tmp.delete();
        }
    }

    private static void copyStream(java.io.InputStream in, java.io.OutputStream out) throws java.io.IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }

    private Uri publishShared(File src, String name, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = act.getContentResolver();
            Uri col = android.provider.MediaStore.Audio.Media.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY);
            try { // прежние копии, созданные приложением
                cr.delete(col, android.provider.MediaStore.MediaColumns.RELATIVE_PATH + "=?", new String[] { "Music/LMusic/" });
            } catch (Throwable ignored) { /* не критично */ }
            android.content.ContentValues v = new android.content.ContentValues();
            v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Music/LMusic");
            v.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(col, v);
            if (u == null) return null;
            try {
                java.io.FileInputStream in = new java.io.FileInputStream(src);
                java.io.OutputStream out = cr.openOutputStream(u);
                if (out == null) throw new java.io.IOException("no_output_stream");
                try { copyStream(in, out); } finally { try { in.close(); } catch (Throwable ignored) { } out.close(); }
            } catch (Throwable t) {
                try { cr.delete(u, null, null); } catch (Throwable ignored) { /* уже нет */ }
                throw new Exception(t);
            }
            v.clear();
            v.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, v, null, null);
            return u;
        }
        // API < 29: файл во внешнем кэше приложения и file:// (для старых систем строгий режим отключаем)
        File base = act.getExternalCacheDir();
        if (base == null) return null;
        File d = new File(base, "share");
        d.mkdirs();
        File[] old = d.listFiles();
        if (old != null) for (File f : old) f.delete();
        File out = new File(d, name);
        java.io.FileInputStream in = new java.io.FileInputStream(src);
        java.io.FileOutputStream os = new java.io.FileOutputStream(out);
        try { copyStream(in, os); } finally { try { in.close(); } catch (Throwable ignored) { } os.close(); }
        try {
            android.os.StrictMode.class.getMethod("disableDeathOnFileUriExposure").invoke(null);
        } catch (Throwable ignored) { /* на 24+ без этого FileUriExposedException; на новых систем сюда не попадаем */ }
        return Uri.fromFile(out);
    }

    // ---------- медиатека устройства (музыка): список и чтение без «доступа ко всем файлам» ----------
    // Нужно обычное разрешение: READ_MEDIA_AUDIO (Android 13+) или READ_EXTERNAL_STORAGE (Android 12 и ниже);
    // оно объявляется в манифесте сборщиком (пункт «Музыка и аудио») и запрашивается стандартным системным окном.
    private boolean audioGranted() {
        try {
            String p = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : "android.permission.READ_EXTERNAL_STORAGE";
            return act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public String hasAudioAccess() {
        return "{\"ok\":true,\"granted\":" + audioGranted() + "}";
    }

    /** Показывает системное окно запроса. Результат асинхронный: страница опрашивает hasAudioAccess(). */
    @JavascriptInterface
    public String requestAudioAccess() {
        try {
            act.runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if (audioGranted()) return;
                        String p = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : "android.permission.READ_EXTERNAL_STORAGE";
                        act.requestPermissions(new String[] { p }, 7422);
                    } catch (Throwable t) {
                        Log.w(TAG, "requestAudioAccess failed", t);
                    }
                }
            });
            return OK;
        } catch (Throwable t) {
            return err(t);
        }
    }

    /** Музыка из медиатеки: id, name, size, mtime (мс), title, artist, album, duration (мс), mime. */
    @JavascriptInterface
    public String listAudio() {
        android.database.Cursor c = null;
        try {
            if (!audioGranted()) return err("no_permission");
            Uri col = Build.VERSION.SDK_INT >= 29
                    ? android.provider.MediaStore.Audio.Media.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL)
                    : android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            String[] proj = { "_id", "_display_name", "_size", "date_modified", "title", "artist", "album", "duration", "mime_type" };
            c = act.getContentResolver().query(col, proj, "is_music != 0 AND _size >= ?", new String[] { "100000" }, "date_added DESC");
            if (c == null) return err("query_failed");
            JSONArray arr = new JSONArray();
            while (c.moveToNext()) {
                JSONObject e = new JSONObject();
                String artist = c.getString(5);
                e.put("id", String.valueOf(c.getLong(0)));
                e.put("name", c.getString(1) == null ? "track" : c.getString(1));
                e.put("size", c.getLong(2));
                e.put("mtime", c.getLong(3) * 1000L);
                e.put("title", c.getString(4) == null ? "" : c.getString(4));
                e.put("artist", artist == null || "<unknown>".equals(artist) ? "" : artist);
                e.put("album", c.getString(6) == null ? "" : c.getString(6));
                e.put("duration", c.getLong(7));
                e.put("mime", c.getString(8) == null ? "" : c.getString(8));
                arr.put(e);
            }
            return o("ok", true, "entries", arr).toString();
        } catch (Throwable t) {
            return err(t);
        } finally {
            if (c != null) {
                try { c.close(); } catch (Throwable ignored) { /* уже закрыт */ }
            }
        }
    }

    /** Кусок аудиофайла (по id из listAudio) как base64, начиная с offset; eof=true на последнем куске. */
    @JavascriptInterface
    public String readAudioChunk(String id, long offset) {
        android.os.ParcelFileDescriptor pfd = null;
        try {
            if (!audioGranted()) return err("no_permission");
            long mid = Long.parseLong(id);
            Uri u = android.content.ContentUris.withAppendedId(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mid);
            pfd = act.getContentResolver().openFileDescriptor(u, "r");
            if (pfd == null) return err("open_failed");
            java.io.FileInputStream in = new java.io.FileInputStream(pfd.getFileDescriptor());
            java.nio.channels.FileChannel ch = in.getChannel();
            long total = ch.size();
            if (offset < 0 || offset > total) return err("bad_offset");
            long want = Math.min(FS_READ_CHUNK, total - offset);
            byte[] buf = new byte[(int) want];
            ch.position(offset);
            int got = 0;
            while (got < buf.length) {
                int n = in.read(buf, got, buf.length - got);
                if (n < 0) break;
                got += n;
            }
            if (got != buf.length) return err("short_read");
            String b64 = Base64.encodeToString(buf, Base64.NO_WRAP);
            return o("ok", true, "data", b64, "size", total, "eof", offset + want >= total).toString();
        } catch (Throwable t) {
            return err(t);
        } finally {
            if (pfd != null) {
                try { pfd.close(); } catch (Throwable ignored) { /* уже закрыт */ }
            }
        }
    }

    /** Обложка трека из медиатеки: встроенная картинка или миниатюра MediaStore, JPEG до 512px; null — обложки нет. */
    private byte[] artBytes(long mid) {
        Context app = act.getApplicationContext();
        Uri u = android.content.ContentUris.withAppendedId(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mid);
        android.graphics.Bitmap bm = null;
        byte[] pic = null;
        android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
        try {
            r.setDataSource(app, u);
            pic = r.getEmbeddedPicture();
        } catch (Throwable ignored) {
            // нет встроенной обложки или файл не читается
        } finally {
            try { r.release(); } catch (Throwable ignored) { /* уже освобождён */ }
        }
        if (pic != null && pic.length > 0) {
            android.graphics.BitmapFactory.Options bo = new android.graphics.BitmapFactory.Options();
            bo.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeByteArray(pic, 0, pic.length, bo);
            int sample = 1;
            while (bo.outWidth / (sample * 2) >= 512 && bo.outHeight / (sample * 2) >= 512) sample *= 2;
            android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
            o2.inSampleSize = sample;
            bm = android.graphics.BitmapFactory.decodeByteArray(pic, 0, pic.length, o2);
        }
        if (bm == null && Build.VERSION.SDK_INT >= 29) {
            try {
                bm = app.getContentResolver().loadThumbnail(u, new android.util.Size(512, 512), null);
            } catch (Throwable ignored) {
                // у файла нет миниатюры
            }
        }
        if (bm == null) return null;
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out);
        bm.recycle();
        return out.toByteArray();
    }

    /** Обложка трека из медиатеки (по id из listAudio): JPEG до 512px в base64; data="" если обложки нет. */
    @JavascriptInterface
    public String audioArt(String id) {
        try {
            if (!audioGranted()) return err("no_permission");
            byte[] b = artBytes(Long.parseLong(id));
            if (b == null) return o("ok", true, "data", "").toString();
            return o("ok", true, "data", Base64.encodeToString(b, Base64.NO_WRAP), "mime", "image/jpeg").toString();
        } catch (Throwable t) {
            return err(t);
        }
    }

    private final java.util.concurrent.ExecutorService artExec = java.util.concurrent.Executors.newSingleThreadExecutor(new java.util.concurrent.ThreadFactory() {
        public Thread newThread(Runnable r) {
            Thread th = new Thread(r, "kx-art");
            th.setDaemon(true);
            th.setPriority(Thread.NORM_PRIORITY - 1);
            return th;
        }
    });
    private volatile int artGen;
    private final AtomicInteger artPending = new AtomicInteger();

    /**
     * Обложки пачкой в фоновом потоке: страница не ждёт каждый вызов (раньше audioArt по одному блокировал JS-поток и список).
     * Каждая готовая обложка приходит вызовом window.__kxArt(id, base64) ("" — обложки нет), в конце — window.__kxArtDone(пачка).
     * Новый вызов отменяет предыдущую пачку; список id через запятую.
     */
    @JavascriptInterface
    public boolean artBatch(final String idsCsv) {
        try {
            if (!audioGranted() || idsCsv == null) return false;
            final int gen = ++artGen;
            artExec.execute(new Runnable() {
                @Override
                public void run() {
                    String[] ids = idsCsv.split(",");
                    for (String id : ids) {
                        if (gen != artGen) return;
                        String data = "";
                        try {
                            byte[] b = artBytes(Long.parseLong(id.trim()));
                            if (b != null) data = Base64.encodeToString(b, Base64.NO_WRAP);
                        } catch (Throwable ignored) {
                            // без обложки
                        }
                        while (artPending.get() > 4 && gen == artGen) {
                            try { Thread.sleep(15); } catch (InterruptedException e) { return; }
                        }
                        final String js = "window.__kxArt&&window.__kxArt('" + id.trim() + "','" + data + "')";
                        artPending.incrementAndGet();
                        uiH.post(new Runnable() {
                            public void run() {
                                try {
                                    web.evaluateJavascript(js, null);
                                } catch (Throwable ignored) {
                                    // WebView уже уничтожен
                                } finally {
                                    artPending.decrementAndGet();
                                }
                            }
                        });
                    }
                    final String done = "window.__kxArtDone&&window.__kxArtDone(" + gen + ")";
                    uiH.post(new Runnable() {
                        public void run() {
                            try {
                                web.evaluateJavascript(done, null);
                            } catch (Throwable ignored) {
                                // WebView уже уничтожен
                            }
                        }
                    });
                }
            });
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @JavascriptInterface
    public String openUri(String uri) {
        return launch(uri, false);
    }

    @JavascriptInterface
    public String shareUri(String uri) {
        return launch(uri, true);
    }

    private String launch(String s, final boolean share) {
        if (s == null || !uris.contains(s)) return err("unknown_uri");
        final Uri u = Uri.parse(s);
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    Intent i;
                    if (share) {
                        i = new Intent(Intent.ACTION_SEND);
                        i.setType("video/mp4");
                        i.putExtra(Intent.EXTRA_STREAM, u);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        act.startActivity(Intent.createChooser(i, null));
                    } else {
                        i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(u, "video/mp4");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        act.startActivity(i);
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "launch failed", t);
                }
            }
        });
        return OK;
    }
}

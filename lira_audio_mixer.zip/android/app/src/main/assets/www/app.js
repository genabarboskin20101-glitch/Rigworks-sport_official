(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = { audioReady: false, modelReady: false, busy: false, outputReady: false };
  let toastHandle = null;
  function toast(message) {
    const el = $('toast'); el.textContent = String(message || 'Готово'); el.classList.remove('hidden');
    clearTimeout(toastHandle); toastHandle = setTimeout(() => el.classList.add('hidden'), 3200);
  }
  function bridge() { return window.LiraNativeBridge; }
  function updateButton() {
    $('startProcess').disabled = !state.audioReady || !state.modelReady || state.busy;
    if (state.busy) $('processHint').textContent = 'Не закрывай приложение, пока обрабатывается аудио.';
    else if (!state.audioReady || !state.modelReady) $('processHint').textContent = 'Сначала выбери аудио и загрузи ONNX-модель.';
    else $('processHint').textContent = 'Аудио и модель готовы. Разделение запускается автоматически; кнопку можно использовать повторно.';
  }
  function setAudio(data) {
    state.audioReady = !!(data && data.ready);
    if (state.audioReady) {
      $('audioTitle').textContent = 'Аудиофайл добавлен'; $('audioSubtitle').textContent = 'Готов к локальной обработке';
      $('audioDropzone').classList.add('ready'); $('audioFileRow').classList.remove('hidden');
      $('audioFileName').textContent = data.name || 'audio'; $('audioFileMeta').textContent = data.meta || 'Готов к обработке';
    } else {
      $('audioTitle').textContent = 'Добавь аудиофайл'; $('audioSubtitle').textContent = 'Файл обрабатывается локально на устройстве';
      $('audioDropzone').classList.remove('ready'); $('audioFileRow').classList.add('hidden');
    }
    updateButton();
  }
  function setModel(data) {
    state.modelReady = !!(data && data.ready);
    $('modelName').textContent = data?.name || (state.modelReady ? 'Модель загружена' : 'Модель не загружена');
    $('modelMeta').textContent = data?.meta || 'UVR MDX-Net · целевой выход: инструментал';
    $('modelStatus').classList.toggle('ready', state.modelReady);
    $('modelStatus').innerHTML = state.modelReady ? '<span class="yellow-dot"></span> Модель готова к инференсу' : '<span class="yellow-dot"></span> Требуется файл модели';
    updateButton();
  }
  function setProgress(pct, title, message) {
    $('progressCard').classList.remove('hidden'); const value = Math.max(0, Math.min(100, Number(pct) || 0));
    $('progressBar').style.width = value + '%'; $('progressPercent').textContent = Math.round(value) + '%';
    $('progressTitle').textContent = title || 'Обработка'; $('progressMessage').textContent = message || 'Пожалуйста, подожди';
  }
  function markBusy(busy) {
    state.busy = !!busy; $('chooseAudio').disabled = state.busy; $('chooseModel').disabled = state.busy; $('downloadModel').disabled = state.busy; $('removeAudio').disabled = state.busy;
    $('startProcess').innerHTML = state.busy ? '<span>◌</span> Обработка…' : '<span>✦</span> Разделить аудио'; updateButton();
  }
  // ---- Mixer: two synchronized <audio> elements with gain 0–200% via Web Audio ----
  const mixer = (() => {
    let vEl = null, iEl = null, ctx = null, vGain = null, iGain = null, ready = false, seeking = false;
    const lv = { vocals: 1, inst: 1 }, muted = { vocals: false, inst: false };
    const fmt = (t) => { t = Math.max(0, Math.floor(t || 0)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
    const dur = () => (iEl && isFinite(iEl.duration) ? iEl.duration : (vEl && isFinite(vEl.duration) ? vEl.duration : 0));
    function make() { const el = new Audio(); el.crossOrigin = 'anonymous'; el.preload = 'auto'; return el; }
    function applyGain() {
      const v = muted.vocals ? 0 : lv.vocals, i = muted.inst ? 0 : lv.inst;
      if (vGain && iGain) { vGain.gain.value = v; iGain.gain.value = i; }
      else { if (vEl) vEl.volume = Math.min(1, v); if (iEl) iEl.volume = Math.min(1, i); }
    }
    function ui() {
      const d = dur(), t = iEl ? iEl.currentTime : 0;
      if (!seeking) $('mixSeek').value = d ? Math.round(t / d * 1000) : 0;
      $('mixTime').textContent = fmt(t) + ' / ' + fmt(d);
      $('mixPlay').textContent = iEl && !iEl.paused ? '❚❚' : '▶';
    }
    function load(vUrl, iUrl) {
      dispose();
      vEl = make(); iEl = make();
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        ctx = new AC();
        vGain = ctx.createGain(); iGain = ctx.createGain();
        ctx.createMediaElementSource(vEl).connect(vGain).connect(ctx.destination);
        ctx.createMediaElementSource(iEl).connect(iGain).connect(ctx.destination);
      } catch (_) { ctx = null; vGain = iGain = null; }
      vEl.src = vUrl; iEl.src = iUrl;
      iEl.addEventListener('timeupdate', () => {
        if (!iEl.paused && vEl && Math.abs(vEl.currentTime - iEl.currentTime) > 0.12) vEl.currentTime = iEl.currentTime;
        ui();
      });
      ['loadedmetadata', 'durationchange', 'pause', 'play'].forEach((e) => iEl.addEventListener(e, ui));
      iEl.addEventListener('ended', () => { vEl.pause(); iEl.currentTime = 0; vEl.currentTime = 0; ui(); });
      ready = true; applyGain(); ui();
    }
    function dispose() {
      ready = false;
      [vEl, iEl].forEach((el) => { if (el) { el.pause(); el.removeAttribute('src'); el.load(); } });
      if (ctx) { try { ctx.close(); } catch (_) {} }
      vEl = iEl = ctx = vGain = iGain = null; ui();
    }
    async function toggle() {
      if (!ready) return;
      if (ctx && ctx.state === 'suspended') { try { await ctx.resume(); } catch (_) {} }
      if (iEl.paused) { vEl.currentTime = iEl.currentTime; await Promise.all([iEl.play(), vEl.play()]).catch(() => toast('Не удалось начать воспроизведение')); }
      else { iEl.pause(); vEl.pause(); }
      ui();
    }
    function seekTo(frac) { if (!ready) return; const t = frac * dur(); iEl.currentTime = t; vEl.currentTime = t; ui(); }
    function setGain(key, pct) { lv[key] = pct / 100; applyGain(); }
    function toggleMute(key) { muted[key] = !muted[key]; applyGain(); return muted[key]; }
    function reset() { lv.vocals = lv.inst = 1; muted.vocals = muted.inst = false; applyGain(); }
    function levels() { return { vocals: muted.vocals ? 0 : lv.vocals, inst: muted.inst ? 0 : lv.inst }; }
    return { load, dispose, toggle, seekTo, setGain, toggleMute, reset, levels, setSeeking(v) { seeking = v; } };
  })();
  function setResult(data) {
    state.outputReady = !!(data && data.ready);
    if (!state.outputReady) { $('resultsPanel').classList.add('hidden'); mixer.dispose(); return; }
    $('resultsPanel').classList.remove('hidden');
    if (data.vocalsUrl && data.instrumentalUrl) mixer.load(data.vocalsUrl, data.instrumentalUrl);
    $('resultsPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  window.LiraAudioApp = {
    setStatus(data) {
      setAudio({ ready: !!data.audioReady, name: data.audioName, meta: data.audioMeta });
      setModel({ ready: !!data.modelReady, name: data.modelName, meta: data.modelMeta });
      if (data.outputReady) setResult(data); if (data.error) toast(data.error);
    },
    onAudioSelected(data) {
      markBusy(false); setAudio(data); setResult({ ready: false });
      if (data?.ready && state.modelReady) startSeparation(true);
      else toast('Аудио добавлено. Как только модель будет готова, разделение начнётся автоматически.');
    },
    onModelStatus(data) {
      markBusy(false); setModel(data);
      if (data.ready) {
        setProgress(100, 'Модель готова', data.message || 'Модель загружена и готова к инференсу');
        if (state.audioReady) startSeparation(true);
      }
      if (data.message) toast(data.message);
    },
    onProgress(data) { markBusy(true); setProgress(data.percent, data.title, data.message); },
    onProcessStarted() { markBusy(true); setProgress(0, 'Подготовка аудио', 'Чтение и преобразование аудиофайла'); $('resultsPanel').classList.add('hidden'); },
    onProcessDone(data) { markBusy(false); setProgress(100, 'Разделение завершено', 'Дорожки готовы. Можно прослушать их и сохранить в файлы.'); setResult(data); toast('Вокал и инструментал готовы'); },
    onError(message) { markBusy(false); toast(message || 'Неизвестная ошибка'); setProgress(0, 'Не удалось выполнить операцию', String(message || 'Проверь аудио и модель')); },
    onExportDone(message) { toast(message || 'Файл сохранён'); },
    onDownloadProgress(data) { markBusy(true); setProgress(data.percent, 'Загрузка модели', data.message); }
  };
  $('chooseAudio').addEventListener('click', () => bridge()?.chooseAudio ? bridge().chooseAudio() : toast('Выбор аудио доступен в Android-приложении.'));
  $('removeAudio').addEventListener('click', () => { if (bridge()?.clearAudio) bridge().clearAudio(); setAudio({ ready: false }); setResult({ ready: false }); });
  $('chooseModel').addEventListener('click', () => bridge()?.chooseModel ? bridge().chooseModel() : toast('Выбор ONNX-модели доступен в Android-приложении.'));
  $('downloadModel').addEventListener('click', () => {
    if (bridge()?.downloadDefaultModel) { setProgress(0, 'Загрузка модели', 'Подключение к серверу модели…'); bridge().downloadDefaultModel(); }
    else toast('Загрузка модели доступна в Android-приложении.');
  });
  function startSeparation(automatic = false) {
    if (!state.audioReady || !state.modelReady || state.busy) return;
    markBusy(true); $('progressCard').classList.remove('hidden'); $('resultsPanel').classList.add('hidden');
    if (bridge()?.separateAudio) {
      if (automatic) setProgress(0, 'Автоматическое разделение', 'Модель и аудио готовы — начинаем обработку');
      bridge().separateAudio($('denoise').checked);
    } else {
      markBusy(false);
      toast('Запусти приложение в Android-оболочке для локального инференса.');
    }
  }
  $('startProcess').addEventListener('click', () => startSeparation(false));
  $('exportVocals').addEventListener('click', () => bridge()?.exportStem ? bridge().exportStem('vocals') : toast('Экспорт доступен в Android-приложении.'));
  $('exportInstrumental').addEventListener('click', () => bridge()?.exportStem ? bridge().exportStem('instrumental') : toast('Экспорт доступен в Android-приложении.'));
  function bindGain(sliderId, valId, muteId, key) {
    const s = $(sliderId), m = $(muteId);
    s.addEventListener('input', () => { $(valId).textContent = s.value + '%'; mixer.setGain(key, Number(s.value)); if (m.dataset.muted === '1') { m.dataset.muted = '0'; m.textContent = '🔊'; mixer.toggleMute(key); } });
    m.addEventListener('click', () => { const nowMuted = mixer.toggleMute(key); m.dataset.muted = nowMuted ? '1' : '0'; m.textContent = nowMuted ? '🔇' : '🔊'; });
  }
  bindGain('vocalsGain', 'vocalsGainVal', 'vocalsMute', 'vocals');
  bindGain('instGain', 'instGainVal', 'instMute', 'inst');
  $('mixPlay').addEventListener('click', () => mixer.toggle());
  $('mixSeek').addEventListener('input', () => { mixer.setSeeking(true); mixer.seekTo(Number($('mixSeek').value) / 1000); });
  ['change', 'pointerup', 'touchend'].forEach((e) => $('mixSeek').addEventListener(e, () => mixer.setSeeking(false)));
  $('resetMix').addEventListener('click', () => {
    mixer.reset();
    [['vocalsGain', 'vocalsGainVal', 'vocalsMute'], ['instGain', 'instGainVal', 'instMute']].forEach(([s, v, m]) => { $(s).value = 100; $(v).textContent = '100%'; $(m).dataset.muted = '0'; $(m).textContent = '🔊'; });
  });
  $('exportMix').addEventListener('click', () => {
    const l = mixer.levels();
    if (l.vocals === 0 && l.inst === 0) { toast('Обе дорожки выключены — увеличь громкость хотя бы одной.'); return; }
    bridge()?.exportMix ? bridge().exportMix(l.vocals, l.inst) : toast('Экспорт доступен в Android-приложении.');
  });
  $('exportAll').addEventListener('click', () => bridge()?.exportAll ? bridge().exportAll() : toast('Экспорт доступен в Android-приложении.'));
  const openHelp = () => $('helpModal').classList.remove('hidden'); const closeHelp = () => $('helpModal').classList.add('hidden');
  $('helpButton').addEventListener('click', openHelp); $('closeHelp').addEventListener('click', closeHelp); $('closeHelpButton').addEventListener('click', closeHelp);
  $('helpModal').addEventListener('click', (event) => { if (event.target === $('helpModal')) closeHelp(); });
  try { const raw = bridge()?.getStatus?.(); if (raw) window.LiraAudioApp.setStatus(JSON.parse(raw)); } catch (_) { /* Web preview has no native bridge. */ }
  updateButton();
})();

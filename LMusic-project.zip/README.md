# LMusic — сборка APK через GitHub Actions

1. Создайте репозиторий на GitHub (лучше приватный — в нём лежит ключ подписи).
2. Распакуйте этот архив в корень репозитория (должны быть `app/`, `signing/`, `build.gradle`, `settings.gradle`).
3. Положите `build-apk.yml` в `.github/workflows/build-apk.yml`.
4. Закоммитьте — сборка стартует сама (Actions → Build LMusic APK). Через несколько минут APK: Releases → lmusic-latest → LMusic.apk.

Где что:
- `app/src/main/assets/www/index.html` — страница приложения (ваш Lmusic17.html). Замена страницы: перезалить этот файл.
- `app/src/main/java/kx/engine/` — нативный мост KExport (код из build-kx.yml); `KxFactory` заменён на `KxApp`.
- `app/src/main/java/com/lmusic/app/WebViewActivity.java` — оболочка (WebView).
- `app/build.gradle` — идентификатор `com.lmusic.app`, версия, подпись.
- `signing/lmusic.keystore` — постоянный ключ (пароль `lmusic-android`): новые сборки ставятся поверх старых.
